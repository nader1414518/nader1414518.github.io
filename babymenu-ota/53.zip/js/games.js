/* ============================================================
   🧩 ألعاب تعليمية — بيبي منيو
   ٦ ألعاب بالصور للأطفال من سنتين:
     ⭐ الذاكرة · 🐘 الظل · 🎨 الألوان · 🔢 عدّ معايا · 🤔 مين مختلف؟ · 🔤 الحروف
   - كل الرسومات إيموجي (من غير صور)، والأصوات من sfx.js
   - في الوضع العربي أسامي الصور بتظهر بالإنجليزي كمان عشان يتعلم الاتنين
   - الحروف: عربي في الوضع العربي، وإنجليزي في الوضع الإنجليزي
   - الصفحات: #/games و #/games/<id> — ومفيش إعلانات جوه الألعاب (ads.js)
   - بيتحمّل قبل app.js، وبيستخدم دوال app.js (tx, num, isAr, esc, togglesHtml, baby) وقت الرسم بس
   ============================================================ */
(function () {
  const it = (e, ar, en, g) => ({ e, ar, en, g });

  /* ---------- البيانات ---------- */
  const GAMES = [
    { id: 'memory', e: '⭐', color: 'blue', age: 2,
      ar: 'لعبة الذاكرة', en: 'Memory match',
      skill: { ar: 'الذاكرة والتركيز', en: 'Memory & focus' },
      how: { ar: 'اقلب كارتين ودوّر على الاتنين اللي شبه بعض', en: 'Flip two cards and find the matching pairs' } },
    { id: 'shadow', e: '🐘', color: 'lav', age: 2,
      ar: 'لعبة الظل', en: 'Shadow match',
      skill: { ar: 'الأشكال والملاحظة', en: 'Shapes & observation' },
      how: { ar: 'مين صاحب الظل ده؟ اختار الصورة الصح', en: 'Whose shadow is this? Pick the right picture' } },
    { id: 'shapes', e: '🔷', color: 'peach', age: 2,
      ar: 'تطابق الأشكال', en: 'Shape puzzle',
      skill: { ar: 'الأشكال وأساميها', en: 'Shapes & their names' },
      how: { ar: 'اسحب كل شكل وحطه في مكانه على اللوحة — أو دوس عليه وبعدين على مكانه', en: 'Drag each shape into its place — or tap it, then tap its place' } },
    { id: 'puzzle', e: '🦁', color: 'green', age: 2,
      ar: 'بازل الحيوانات', en: 'Animal puzzle',
      skill: { ar: 'تركيب الصور', en: 'Putting pictures together' },
      how: { ar: 'ركّب القطع عشان تكمّل صورة الحيوان — اسحبها أو دوس عليها وبعدين على مكانها', en: 'Put the pieces together to finish the picture — drag them, or tap a piece then its place' } },
    { id: 'colors', e: '🎨', color: 'pink', age: 2,
      ar: 'الألوان', en: 'Colors',
      skill: { ar: 'أسامي الألوان', en: 'Learning colors' },
      how: { ar: 'إيه الحاجة اللي لونها زي البقعة دي؟', en: 'Which thing is the same color as the splash?' } },
    { id: 'count', e: '🔢', color: 'cream', age: 3,
      ar: 'عدّ معايا', en: 'Count with me',
      skill: { ar: 'الأرقام والعد', en: 'Numbers & counting' },
      how: { ar: 'عدّ الصور واختار الرقم الصح', en: 'Count the pictures and pick the right number' } },
    { id: 'odd', e: '🤔', color: 'mint', age: 3,
      ar: 'مين مختلف؟', en: 'Odd one out',
      skill: { ar: 'التصنيف والتفكير', en: 'Sorting & thinking' },
      how: { ar: 'فيه صورة مش زي الباقيين.. لاقيها!', en: 'One picture doesn’t belong.. find it!' } },
    { id: 'letters', e: '✏️', color: 'blue', age: 4,
      ar: 'الحروف', en: 'Letters',
      skill: { ar: 'أول حرف في الكلمة', en: 'First letter sounds' },
      how: { ar: 'إيه الصورة اللي اسمها بيبدأ بالحرف ده؟', en: 'Which picture starts with this letter?' } },
  ];

  const MEM_THEMES = [
    { id: 'sea', e: '🐬', ar: 'البحر', en: 'Sea', color: 'blue', items: [
      it('🐬', 'دولفين', 'Dolphin'), it('🦀', 'كابوريا', 'Crab'), it('🐢', 'سلحفاية', 'Turtle'), it('🐙', 'أخطبوط', 'Octopus'),
      it('🐠', 'سمكة', 'Fish'), it('🐳', 'حوت', 'Whale'), it('🦈', 'قرش', 'Shark'), it('🐧', 'بطريق', 'Penguin')] },
    { id: 'farm', e: '🐮', ar: 'المزرعة', en: 'Farm', color: 'green', items: [
      it('🐮', 'بقرة', 'Cow'), it('🐑', 'خروف', 'Sheep'), it('🐔', 'فرخة', 'Hen'), it('🐴', 'حصان', 'Horse'),
      it('🐐', 'معزة', 'Goat'), it('🦆', 'بطة', 'Duck'), it('🐰', 'أرنب', 'Rabbit'), it('🐫', 'جمل', 'Camel')] },
    { id: 'fruit', e: '🍓', ar: 'الفاكهة', en: 'Fruit', color: 'pink', items: [
      it('🍎', 'تفاحة', 'Apple'), it('🍌', 'موزة', 'Banana'), it('🍇', 'عنب', 'Grapes'), it('🍓', 'فراولة', 'Strawberry'),
      it('🍉', 'بطيخة', 'Watermelon'), it('🍊', 'برتقانة', 'Orange'), it('🥝', 'كيوي', 'Kiwi'), it('🍍', 'أناناس', 'Pineapple')] },
    { id: 'go', e: '🚗', ar: 'المواصلات', en: 'Vehicles', color: 'cream', items: [
      it('🚗', 'عربية', 'Car'), it('🚌', 'أتوبيس', 'Bus'), it('🚲', 'عجلة', 'Bicycle'), it('✈️', 'طيارة', 'Airplane'),
      it('🚀', 'صاروخ', 'Rocket'), it('🚂', 'قطر', 'Train'), it('🚁', 'هليكوبتر', 'Helicopter'), it('⛵', 'مركب', 'Sailboat')] },
  ];
  /* عدد الأزواج وعدد الأعمدة لكل مستوى */
  const MEM_LEVELS = [
    { n: 3, cols: 3, ar: 'سهل', en: 'Easy' },
    { n: 6, cols: 3, ar: 'وسط', en: 'Medium' },
    { n: 8, cols: 4, ar: 'صعب', en: 'Hard' },
  ];

  /* الظل: كل جولة ٣ اختيارات من مجموعات أشكال مختلفة عشان الظلال متتلخبطش في بعض */
  const SHADOWS = [
    it('🐘', 'فيل', 'Elephant', 'quad'), it('🦒', 'زرافة', 'Giraffe', 'quad'), it('🐎', 'حصان', 'Horse', 'quad'),
    it('🐕', 'كلب', 'Dog', 'quad'), it('🐪', 'جمل', 'Camel', 'quad'), it('🐇', 'أرنب', 'Rabbit', 'quad'),
    it('🐓', 'ديك', 'Rooster', 'bird'), it('🦆', 'بطة', 'Duck', 'bird'),
    it('🐟', 'سمكة', 'Fish', 'sea'), it('🐙', 'أخطبوط', 'Octopus', 'sea'), it('🦀', 'كابوريا', 'Crab', 'sea'), it('🐢', 'سلحفاية', 'Turtle', 'sea'),
    it('🦋', 'فراشة', 'Butterfly', 'bug'), it('🐌', 'حلزونة', 'Snail', 'bug'),
    it('🍎', 'تفاحة', 'Apple', 'fruit'), it('🍌', 'موزة', 'Banana', 'fruit'), it('🍇', 'عنب', 'Grapes', 'fruit'), it('🍓', 'فراولة', 'Strawberry', 'fruit'),
    it('🚗', 'عربية', 'Car', 'ride'), it('🚲', 'عجلة', 'Bicycle', 'ride'), it('✈️', 'طيارة', 'Airplane', 'ride'), it('🚀', 'صاروخ', 'Rocket', 'ride'), it('⛵', 'مركب', 'Sailboat', 'ride'),
    it('🎈', 'بلونة', 'Balloon', 'thing'), it('☂️', 'شمسية', 'Umbrella', 'thing'), it('⭐', 'نجمة', 'Star', 'thing'),
    it('🌙', 'قمر', 'Moon', 'thing'), it('🏠', 'بيت', 'House', 'thing'), it('🔑', 'مفتاح', 'Key', 'thing'),
  ];

  /* الألوان: إيموجي لونها واحد على آيفون وأندرويد */
  const COLORS = [
    { id: 'red', hex: '#E5484D', ar: 'أحمر', en: 'Red', items: [it('🍎', 'تفاحة', 'Apple'), it('🍓', 'فراولة', 'Strawberry'), it('🍒', 'كريز', 'Cherries'), it('🚒', 'عربية مطافي', 'Fire truck')] },
    { id: 'yellow', hex: '#F2C200', ar: 'أصفر', en: 'Yellow', items: [it('🍌', 'موزة', 'Banana'), it('🌻', 'عباد الشمس', 'Sunflower'), it('🐥', 'كتكوت', 'Chick'), it('🍋', 'ليمونة', 'Lemon')] },
    { id: 'green', hex: '#3FA34D', ar: 'أخضر', en: 'Green', items: [it('🥦', 'بروكلي', 'Broccoli'), it('🥒', 'خيارة', 'Cucumber'), it('🐸', 'ضفدع', 'Frog'), it('🍀', 'ورقة برسيم', 'Clover')] },
    { id: 'blue', hex: '#3B7DDD', ar: 'أزرق', en: 'Blue', items: [it('🐳', 'حوت', 'Whale'), it('💧', 'نقطة مية', 'Water drop'), it('🧢', 'كاب', 'Cap'), it('🫐', 'توت', 'Blueberries')] },
    { id: 'orange', hex: '#F7811E', ar: 'برتقاني', en: 'Orange', items: [it('🍊', 'برتقانة', 'Orange'), it('🥕', 'جزرة', 'Carrot'), it('🎃', 'قرع', 'Pumpkin'), it('🏀', 'كورة سلة', 'Basketball')] },
    { id: 'purple', hex: '#8E5BD8', ar: 'بنفسجي', en: 'Purple', items: [it('🍇', 'عنب', 'Grapes'), it('🍆', 'بتنجان', 'Eggplant'), it('💜', 'قلب', 'Heart')] },
    { id: 'brown', hex: '#8A5A33', ar: 'بني', en: 'Brown', items: [it('🐻', 'دبدوب', 'Teddy bear'), it('🍪', 'بسكوتة', 'Cookie'), it('🌰', 'أبو فروة', 'Chestnut'), it('🥔', 'بطاطساية', 'Potato')] },
  ];

  const COUNT_ITEMS = ['🍎', '🍓', '🍌', '⭐', '🎈', '🐥', '🚗', '🐟', '🌸', '🧁'];
  /* "مخلوطين": يعدّ نوع واحد بس وسط حاجات تانية */
  const COUNT_LEVELS = [
    { max: 5, ar: '١ – ٥', en: '1 – 5' },
    { max: 10, ar: '١ – ١٠', en: '1 – 10' },
    { max: 6, mix: true, ar: 'مخلوطين', en: 'Mixed' },
  ];

  const ODD_CATS = [
    { id: 'fruit', ar: 'فاكهة', en: 'fruit', one: { ar: 'دي فاكهة', en: 'a fruit' }, items: ['🍎', '🍌', '🍇', '🍓', '🍉', '🍊', '🍍', '🍒'] },
    { id: 'animal', ar: 'حيوانات', en: 'animals', one: { ar: 'ده حيوان', en: 'an animal' }, items: ['🐶', '🐱', '🐮', '🐰', '🐻', '🐵', '🦁', '🐸'] },
    { id: 'ride', ar: 'مواصلات', en: 'vehicles', one: { ar: 'دي وسيلة مواصلات', en: 'a vehicle' }, items: ['🚗', '🚌', '🚲', '✈️', '🚀', '🚂', '🚁', '⛵'] },
    { id: 'wear', ar: 'هدوم', en: 'clothes', one: { ar: 'ده لبس', en: 'clothing' }, items: ['👕', '👖', '🧦', '👟', '🧢', '👗', '🧤', '🧣'] },
    { id: 'veg', ar: 'خضار', en: 'veggies', one: { ar: 'ده خضار', en: 'a vegetable' }, items: ['🥕', '🥒', '🌽', '🥦', '🫑', '🧅', '🥔', '🍆'] },
  ];
  /* فاكهة وخضار مع بعض صعبة على السن ده — منحطهمش في نفس الجولة */
  const ODD_SKIP = [['fruit', 'veg']];

  /* الحروف: حرف + كلمة بتبدأ بيه + صورة (L = الحرف زي ما بيتعرض) */
  const L = (l, w, e, en) => ({ l, w, e, en });
  const AR_LETTERS = [
    L('أ', 'أرنب', '🐰', 'Rabbit'), L('ب', 'بطة', '🦆', 'Duck'), L('ت', 'تفاحة', '🍎', 'Apple'), L('ث', 'ثعلب', '🦊', 'Fox'),
    L('ج', 'جمل', '🐫', 'Camel'), L('ح', 'حصان', '🐴', 'Horse'), L('خ', 'خروف', '🐑', 'Sheep'), L('د', 'دب', '🐻', 'Bear'),
    L('ذ', 'ذرة', '🌽', 'Corn'), L('ر', 'ريشة', '🪶', 'Feather'), L('ز', 'زرافة', '🦒', 'Giraffe'), L('س', 'سمكة', '🐟', 'Fish'),
    L('ش', 'شمس', '☀️', 'Sun'), L('ص', 'صاروخ', '🚀', 'Rocket'), L('ض', 'ضفدع', '🐸', 'Frog'), L('ط', 'طيارة', '✈️', 'Airplane'),
    L('ظ', 'ظرف', '✉️', 'Envelope'), L('ع', 'عنب', '🍇', 'Grapes'), L('غ', 'غزالة', '🦌', 'Deer'), L('ف', 'فيل', '🐘', 'Elephant'),
    L('ق', 'قطة', '🐱', 'Cat'), L('ك', 'كلب', '🐶', 'Dog'), L('ل', 'ليمونة', '🍋', 'Lemon'), L('م', 'موزة', '🍌', 'Banana'),
    L('ن', 'نحلة', '🐝', 'Bee'), L('هـ', 'هدية', '🎁', 'Gift'), L('و', 'وردة', '🌹', 'Rose'), L('ي', 'يد', '✋', 'Hand'),
  ];
  const EN_LETTERS = [
    L('A', 'Apple', '🍎'), L('B', 'Ball', '⚽'), L('C', 'Cat', '🐱'), L('D', 'Dog', '🐶'), L('E', 'Egg', '🥚'), L('F', 'Fish', '🐟'),
    L('G', 'Grapes', '🍇'), L('H', 'Hat', '🎩'), L('I', 'Ice cream', '🍦'), L('J', 'Juice', '🧃'), L('K', 'Key', '🔑'), L('L', 'Lion', '🦁'),
    L('M', 'Moon', '🌙'), L('N', 'Nose', '👃'), L('O', 'Orange', '🍊'), L('P', 'Pizza', '🍕'), L('Q', 'Queen', '👸'), L('R', 'Rabbit', '🐰'),
    L('S', 'Sun', '☀️'), L('T', 'Tree', '🌳'), L('U', 'Umbrella', '☂️'), L('V', 'Violin', '🎻'), L('W', 'Whale', '🐳'), L('Y', 'Yo-yo', '🪀'),
    L('Z', 'Zebra', '🦓'),
  ];
  /* الحروف اللي مبتتوصلش باللي بعدها — من غيرها بنلزق أول حرف ملوّن بباقي الكلمة (ZWJ) */
  const NOJOIN = 'اأإآدذرزوؤة';

  /* 🔷 تطابق الأشكال: لوحة خشب فيها أماكن الأشكال (زي البازل الخشب)، والطفل يحط كل شكل في مكانه */
  const ptsStar = (cx, cy, R, r) => Array.from({ length: 10 }, (_, i) => {
    const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r : R;
    return `${(cx + rr * Math.cos(a)).toFixed(1)},${(cy + rr * Math.sin(a)).toFixed(1)}`;
  }).join(' ');
  const ptsNgon = (n, cx, cy, R) => Array.from({ length: n }, (_, i) => {
    const a = -Math.PI / 2 + i * 2 * Math.PI / n;
    return `${(cx + R * Math.cos(a)).toFixed(1)},${(cy + R * Math.sin(a)).toFixed(1)}`;
  }).join(' ');
  /* d = رسمة الشكل في مربع 100×100، k = مكان المسكة الخشب في نص الشكل */
  const SHAPES = [
    { id: 'square', ar: 'مربع', en: 'Square', d: '<rect x="12" y="12" width="76" height="76" rx="7"/>', k: [50, 50] },
    { id: 'circle', ar: 'دايرة', en: 'Circle', d: '<circle cx="50" cy="50" r="41"/>', k: [50, 50] },
    { id: 'triangle', ar: 'مثلث', en: 'Triangle', d: '<polygon points="50,9 93,86 7,86"/>', k: [50, 61] },
    { id: 'rect', ar: 'مستطيل', en: 'Rectangle', d: '<rect x="5" y="25" width="90" height="50" rx="6"/>', k: [50, 50] },
    { id: 'star', ar: 'نجمة', en: 'Star', d: `<polygon points="${ptsStar(50, 54, 46, 19)}"/>`, k: [50, 56] },
    { id: 'heart', ar: 'قلب', en: 'Heart', d: '<path d="M50 88C20 68 7 52 7 35 7 20 18 10 31 10c8 0 14 4 19 11 5-7 11-11 19-11 13 0 24 10 24 25 0 17-13 33-43 53z"/>', k: [50, 42] },
    { id: 'hexagon', ar: 'سداسي', en: 'Hexagon', d: `<polygon points="${ptsNgon(6, 50, 50, 44)}"/>`, k: [50, 50] },
    { id: 'pentagon', ar: 'خماسي', en: 'Pentagon', d: `<polygon points="${ptsNgon(5, 50, 54, 44)}"/>`, k: [50, 56] },
    { id: 'diamond', ar: 'معين', en: 'Diamond', d: '<polygon points="50,5 90,50 50,95 10,50"/>', k: [50, 50] },
    { id: 'trapezoid', ar: 'شبه منحرف', en: 'Trapezoid', d: '<polygon points="28,20 72,20 94,80 6,80"/>', k: [50, 52] },
    { id: 'oval', ar: 'بيضاوي', en: 'Oval', d: '<ellipse cx="50" cy="50" rx="45" ry="30"/>', k: [50, 50] },
    { id: 'semi', ar: 'نص دايرة', en: 'Semicircle', d: '<path d="M6 74a44 44 0 0 1 88 0z"/>', k: [50, 56] },
  ];
  const SH_COLORS = ['#E5484D', '#F2C200', '#3FA34D', '#3B7DDD', '#F7811E', '#8E5BD8', '#E2558F', '#1BA6A6'];
  const SH_LEVELS = [
    { n: 3, cols: 3, ar: 'سهل', en: 'Easy' },
    { n: 6, cols: 3, ar: 'وسط', en: 'Medium' },
    { n: 12, cols: 4, ar: 'صعب', en: 'Hard' },
  ];

  /* 🧩 بازل الحيوانات والطيور: صورة متقسمة ٣ أو ٤ أو ٥ قطع بحواف بازل */
  const PZ_SETS = [
    { id: 'animals', e: '🦁', ar: 'حيوانات', en: 'Animals', items: [
      it('🦁', 'أسد', 'Lion'), it('🐘', 'فيل', 'Elephant'), it('🦒', 'زرافة', 'Giraffe'), it('🐯', 'نمر', 'Tiger'),
      it('🐻', 'دب', 'Bear'), it('🐼', 'باندا', 'Panda'), it('🐵', 'قرد', 'Monkey'), it('🐶', 'كلب', 'Dog'),
      it('🐱', 'قطة', 'Cat'), it('🐰', 'أرنب', 'Rabbit'), it('🐮', 'بقرة', 'Cow'), it('🐴', 'حصان', 'Horse'),
      it('🦓', 'حمار وحشي', 'Zebra'), it('🐫', 'جمل', 'Camel'), it('🦊', 'ثعلب', 'Fox'), it('🐸', 'ضفدع', 'Frog')] },
    { id: 'birds', e: '🦜', ar: 'طيور', en: 'Birds', items: [
      it('🦜', 'ببغاء', 'Parrot'), it('🦉', 'بومة', 'Owl'), it('🐧', 'بطريق', 'Penguin'), it('🦆', 'بطة', 'Duck'),
      it('🐓', 'ديك', 'Rooster'), it('🦩', 'فلامنجو', 'Flamingo'), it('🦚', 'طاووس', 'Peacock'), it('🕊️', 'حمامة', 'Dove'),
      it('🐥', 'كتكوت', 'Chick'), it('🦅', 'نسر', 'Eagle'), it('🦢', 'بجعة', 'Swan')] },
  ];
  const PZ_COUNTS = [3, 4, 5];
  const PZ_BG = ['#FFE3D3', '#DDF1E9', '#E9E0FA', '#FFF0C9', '#DCE8FD', '#FDE0E8', '#E2F2DA'];
  const PZ_PAD = 42;   /* مساحة حوالين كل قطعة عشان البروز بتاع البازل */

  const ROUNDS = 8;

  /* ---------- أدوات ---------- */
  const $ = () => document.getElementById('app');
  const sfx = n => { if (window.BeebySfx) window.BeebySfx.play(n); };
  const rnd = n => Math.floor(Math.random() * n);
  const shuffle = a => { const b = a.slice(); for (let i = b.length - 1; i > 0; i--) { const j = rnd(i + 1); [b[i], b[j]] = [b[j], b[i]]; } return b; };
  const take = (a, k) => shuffle(a).slice(0, k);
  const nm = x => (isAr() ? x.ar : x.en);
  /* الاسم + الإنجليزي جنبه في الوضع العربي (عشان يتعلم الاتنين) */
  const nm2 = x => `<b>${esc(nm(x))}</b>${isAr() && x.en ? ` <span class="gm-en" dir="ltr">${esc(x.en)}</span>` : ''}`;
  /* أول حرف ملوّن: "فيل" ⇒ ف ملوّنة ومتوصلة بباقي الكلمة */
  function firstLetter(w) {
    const ch = w[0], rest = w.slice(1);
    if (!isAr()) return `<i>${esc(ch)}</i>${esc(rest)}`;
    const zwj = NOJOIN.includes(ch) ? '' : '&zwj;';
    return `<i>${ch}${zwj}</i>${zwj}${esc(rest)}`;
  }

  const PREF_KEY = 'bb_games';
  function prefs() {
    let p = {};
    try { p = JSON.parse(localStorage.getItem(PREF_KEY) || '{}') || {}; } catch (e) {}
    return {
      theme: MEM_THEMES.some(t => t.id === p.theme) ? p.theme : 'sea',
      level: MEM_LEVELS[p.level] ? p.level : 0,
      cmax: COUNT_LEVELS[p.cmax] ? p.cmax : 0,
      shl: SH_LEVELS[p.shl] ? p.shl : 0,
      pzt: PZ_SETS.some(t => t.id === p.pzt) ? p.pzt : 'animals',
      pzn: PZ_COUNTS[p.pzn] ? p.pzn : 0,
    };
  }
  function savePref(k, v) {
    const p = prefs();
    p[k] = v;
    try { localStorage.setItem(PREF_KEY, JSON.stringify(p)); } catch (e) {}
  }

  /* اللعبة اللي على الشاشة وحالتها — بتتصفّر لما تدخل لعبة من صفحة تانية،
     وبتفضل زي ما هي لو الصفحة اترسمت تاني (تغيير اللغة أو الوضع أو الصوت) */
  let cur = null;
  let S = null;
  let gen = 0;                       /* بيزيد مع كل لعبة جديدة — المؤقتات القديمة بتتجاهل نفسها */
  const later = (fn, ms) => { const g = gen; setTimeout(() => { if (g === gen && S) fn(); }, ms); };
  /* خرج من صفحة اللعبة؟ نلغي المؤقتات، ولما يرجع تبدأ لعبة جديدة
     (الـ listener ده قبل بتاع app.js لأن الملف بيتحمّل قبله) */
  window.addEventListener('hashchange', () => {
    if (cur && location.hash !== '#/games/' + cur) { cur = null; S = null; gen++; }
  });

  function newGame(id) {
    gen++;
    if (id === 'memory') {
      const p = prefs();
      const th = MEM_THEMES.find(t => t.id === p.theme);
      const lv = MEM_LEVELS[p.level];
      const picks = take(th.items, lv.n);
      const cards = shuffle(picks.concat(picks)).map((x, i) => ({ i, x, up: false, done: false }));
      return { id, th, lv, cards, open: [], moves: 0, found: 0, lock: false, miss: null, won: false };
    }
    if (id === 'puzzle') {
      const p = prefs();
      const set = PZ_SETS.find(t => t.id === p.pzt);
      const n = PZ_COUNTS[p.pzn];
      const prev = S && S.id === 'puzzle' ? S.item.e : null;   /* "العب تاني" ⇒ حيوان تاني */
      const pool = set.items.filter(x => x.e !== prev);
      const item = take(pool.length ? pool : set.items, 1)[0];
      const knobs = {};
      const pieces = pzLayout(n).map((r, i) => Object.assign({ i, placed: false }, r));
      pieces.forEach(pc => { pc.d = pzPath(pc, pieces, knobs); });
      const base = pzBase(item, take(PZ_BG, 1)[0]);
      pieces.forEach(pc => { pc.src = pzCut(base, pc); });
      return {
        id, set, n, item, pieces, sel: null, placed: 0, miss: 0, won: false,
        img: base.toDataURL('image/jpeg', 0.9),
        guide: pzGuide(base),
        order: shuffle(pieces.map(pc => pc.i)),
      };
    }
    if (id === 'shapes') {
      const lv = SH_LEVELS[prefs().shl];
      const picks = take(SHAPES, lv.n);
      const cols = shuffle(SH_COLORS);
      return {
        id, lv, sel: null, placed: 0, miss: 0, won: false,
        holes: picks.map((sh, i) => ({ i, s: sh, filled: false, color: null })),
        pieces: shuffle(picks.map((sh, i) => ({ i, s: sh, color: cols[i % cols.length], placed: false }))),
      };
    }
    return { id, round: 0, miss: 0, used: [], q: null, lock: false, won: false };
  }

  /* ---------- صفحة الألعاب ---------- */
  function renderHub() {
    const ageTxt = a => (isAr() ? (a === 2 ? 'من سنتين' : `من ${num(a)} سنين`) : `Age ${a}+`);
    const ico = g => g.id === 'shadow' ? `<i>${g.e}</i>${g.e}`
      : g.id === 'memory' ? `<span class="gm-mini"><i class="b">${STAR_SVG}</i><i class="f">🐬</i></span>`
      : g.id === 'letters' ? `<span class="gm-abc">${isAr() ? 'أ ب' : 'A B'}</span>`
      : g.id === 'shapes' ? SH_ICON
      : g.id === 'puzzle' ? '<span class="gm-pzico"><i>🦁</i><i>🦁</i></span>'
      : g.e;
    const tips = [
      ['💛', 'العبي معاه وقولي أسامي الحاجات بصوت عالي — كده بيتعلم كلمات جديدة أسرع.', 'Play together and say the names out loud — it helps them learn new words faster.'],
      ['🌍', 'أسامي الصور مكتوبة بالعربي والإنجليزي عشان يتعلم الاتنين.', null],
      ['⏱️', 'من سنتين لـ ٥ سنين: ساعة شاشة في اليوم بالكتير (الأكاديمية الأمريكية لطب الأطفال) — وأقل من سنة ونص بلاش شاشات.', 'Ages 2–5: no more than 1 hour of screen time a day (American Academy of Pediatrics) — and no screens under 18 months.'],
      ['🚫', 'مفيش إعلانات جوه الألعاب.', 'No ads inside the games.'],
    ].filter(t => isAr() || t[2]);
    $().innerHTML = `
      <div class="topbar">
        <a class="backbtn" href="#/">←</a>
        <div class="logo">🧩</div>
        <h1 class="gm-h1">${isAr() ? 'ألعاب تعليمية' : 'Learning games'}<small>${isAr() ? 'العب واتعلم بالصور' : 'Play & learn with pictures'}</small></h1>
        ${togglesHtml()}
      </div>

      <div class="gm-hub">
        ${GAMES.map((g, i) => `
        <a class="gm-tile ac-${g.color} rise" style="--i:${i}" href="#/games/${g.id}">
          <span class="gm-tile-ico ${g.id === 'shadow' ? 'is-shadow' : ''}" aria-hidden="true">${ico(g)}</span>
          <b>${nm(g)}</b>
          <small>${tx(g.skill)}</small>
          <span class="gm-age">${ageTxt(g.age)}</span>
        </a>`).join('')}
      </div>

      <div class="tips">
        ${tips.map((t, i) => `<div class="tip rise" style="--i:${i + 6}"><span class="ic">${t[0]}</span><span>${isAr() ? t[1] : t[2]}</span></div>`).join('')}
      </div>
    `;
  }

  /* ---------- صفحة اللعبة ---------- */
  function renderGame() {
    const g = GAMES.find(x => x.id === S.id);
    $().innerHTML = `
      <div class="topbar">
        <a class="backbtn" href="#/games">←</a>
        <div class="logo">${g.e}</div>
        <h1 class="gm-h1">${nm(g)}<small>${tx(g.skill)}</small></h1>
        ${togglesHtml()}
      </div>
      <div class="gm-play gm-p-${S.id}">
        ${optsHtml()}
        ${S.id === 'memory' || S.id === 'shapes' || S.id === 'puzzle' ? `<p class="gm-how">${tx(g.how)}</p>` : ''}
        <div class="gm-bar" id="gm-bar"></div>
        <div id="gm-stage"></div>
      </div>
    `;
    paintBar();
    if (S.id === 'memory') paintBoard();
    else if (S.id === 'shapes') paintShapes();
    else if (S.id === 'puzzle') paintPuzzle();
    else {
      /* الحروف بتتغير مع اللغة — لو اللغة اتغيرت في النص نبدأ جولة بحروف اللغة الجديدة */
      if (!S.q || (S.id === 'letters' && S.q.lang !== lang)) S.q = makeQ();
      paintRound();
    }
    if (S.won) showWin(true);
  }

  function optsHtml() {
    const chip = (act, v, label, sel) => `<button class="wk-chip ${sel ? 'sel' : ''}" data-act="${act}" data-v="${v}">${label}</button>`;
    if (S.id === 'memory') {
      const p = prefs();
      return `
        <div class="week-chips gm-chips">${MEM_THEMES.map(t => chip('gmtheme', t.id, `${t.e} ${nm(t)}`, t.id === p.theme)).join('')}</div>
        <div class="gm-seg">${MEM_LEVELS.map((l, i) => chip('gmlevel', i, `${nm(l)} <small>${num(l.n * 2)}</small>`, i === p.level)).join('')}</div>`;
    }
    if (S.id === 'count') {
      const p = prefs();
      return `<div class="gm-seg">${COUNT_LEVELS.map((l, i) => chip('gmcmax', i, nm(l), i === p.cmax)).join('')}</div>`;
    }
    if (S.id === 'puzzle') {
      const p = prefs();
      const pcs = n => (isAr() ? `${num(n)} قطع` : `${n} pieces`);
      return `
        <div class="gm-seg">${PZ_SETS.map(t => chip('gmpzt', t.id, `${t.e} ${nm(t)}`, t.id === p.pzt)).join('')}</div>
        <div class="gm-seg">${PZ_COUNTS.map((n, i) => chip('gmpzn', i, pcs(n), i === p.pzn)).join('')}</div>`;
    }
    if (S.id === 'shapes') {
      const p = prefs();
      return `<div class="gm-seg">${SH_LEVELS.map((l, i) => chip('gmshl', i, `${nm(l)} <small>${num(l.n)}</small>`, i === p.shl)).join('')}</div>`;
    }
    return '';
  }

  function paintBar() {
    const bar = document.getElementById('gm-bar');
    if (!bar) return;
    const again = `<button class="gm-again" data-act="gmrestart" aria-label="${isAr() ? 'من الأول' : 'Restart'}">🔄</button>`;
    if (S.id === 'memory') {
      bar.innerHTML = `
        <span>${isAr() ? 'الأزواج' : 'Pairs'} <b>${isAr() ? `${num(S.found)} من ${num(S.lv.n)}` : `${S.found} / ${S.lv.n}`}</b></span>
        <span>${isAr() ? 'المحاولات' : 'Tries'} <b>${num(S.moves)}</b></span>
        ${again}`;
      return;
    }
    if (S.id === 'puzzle') {
      const n = S.pieces.length;
      bar.innerHTML = `<span>${isAr() ? 'القطع' : 'Pieces'} <b>${isAr() ? `${num(S.placed)} من ${num(n)}` : `${S.placed} / ${n}`}</b></span>${again}`;
      return;
    }
    if (S.id === 'shapes') {
      const n = S.holes.length;
      bar.innerHTML = `<span>${isAr() ? 'الأشكال' : 'Shapes'} <b>${isAr() ? `${num(S.placed)} من ${num(n)}` : `${S.placed} / ${n}`}</b></span>${again}`;
      return;
    }
    const dots = Array.from({ length: ROUNDS }, (_, i) => `<i class="${i < S.round ? 'on' : i === S.round ? 'now' : ''}"></i>`).join('');
    bar.innerHTML = `<span class="gm-dots" aria-label="${isAr() ? `سؤال ${num(Math.min(S.round + 1, ROUNDS))} من ${num(ROUNDS)}` : `Question ${Math.min(S.round + 1, ROUNDS)} of ${ROUNDS}`}">${dots}</span>${again}`;
  }

  /* ---------- ⭐ الذاكرة ---------- */
  const STAR_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.9 6 6.5.8-4.8 4.5 1.2 6.5L12 17.2l-5.8 3.2 1.2-6.5L2.6 9.4l6.5-.8z"/></svg>';

  const cardLabel = c => (c.up || c.done ? nm(c.x) : (isAr() ? `كارت ${num(c.i + 1)}` : `Card ${c.i + 1}`));
  function cardHtml(c) {
    return `
      <button class="mem-card ${c.up || c.done ? 'up' : ''} ${c.done ? 'done' : ''}" data-act="gmflip" data-i="${c.i}" data-sfx="off" aria-label="${esc(cardLabel(c))}">
        <span class="mem-in">
          <span class="mem-back">${STAR_SVG}</span>
          <span class="mem-face"><span class="mem-emo">${c.x.e}</span><small class="mem-name">${esc(nm(c.x))}${isAr() ? `<em dir="ltr">${esc(c.x.en)}</em>` : ''}</small></span>
        </span>
      </button>`;
  }

  function paintBoard() {
    const st = document.getElementById('gm-stage');
    if (!st) return;
    st.innerHTML = `<div class="mem-board ac-${S.th.color}" style="--cols:${S.lv.cols}">${S.cards.map(cardHtml).join('')}</div>`;
  }

  function paintCard(c) {
    const el = document.querySelector(`.mem-card[data-i="${c.i}"]`);
    if (!el) return;
    el.classList.toggle('up', c.up || c.done);
    el.classList.toggle('done', c.done);
    el.setAttribute('aria-label', cardLabel(c));
  }

  /* الكارتين اللي مش شبه بعض بيرجعوا يتقلبوا — ولو الطفل داس على كارت تالت قبلها بنقلبهم فورًا */
  function closeMiss() {
    if (!S.miss) return;
    clearTimeout(S.miss);
    S.miss = null;
    S.open.forEach(k => { S.cards[k].up = false; paintCard(S.cards[k]); });
    S.open = [];
  }

  function memFlip(i) {
    const c = S.cards[i];
    if (!c || S.lock || S.won || c.done || c.up) return;
    closeMiss();
    c.up = true;
    paintCard(c);
    sfx('flip');
    S.open.push(i);
    if (S.open.length < 2) return;

    S.moves++;
    const [a, b] = S.open.map(k => S.cards[k]);
    if (a.x.e === b.x.e) {
      S.lock = true;
      later(() => {
        a.done = b.done = true;
        S.open = [];
        S.found++;
        S.lock = false;
        paintCard(a); paintCard(b);
        sfx('yay');
        paintBar();
        if (S.found === S.lv.n) { S.won = true; later(() => showWin(), 650); }
      }, 420);
    } else {
      const g = gen;
      S.miss = setTimeout(() => { if (g === gen && S) closeMiss(); }, 1100);
    }
    paintBar();
  }

  /* ---------- جولات: الظل / الألوان / العد / مين مختلف / الحروف ---------- */
  /* كل سؤال فيه opts (الاختيارات) و ok (الإجابة الصح من جوه opts) */
  function makeQ() {
    if (S.id === 'shadow') {
      const groups = shuffle([...new Set(SHADOWS.map(s => s.g))]).slice(0, 3);
      const fresh = SHADOWS.filter(s => !S.used.includes(s.e));
      const inG = fresh.filter(s => s.g === groups[0]);
      const target = take(inG.length ? inG : fresh, 1)[0];
      const others = groups.filter(g => g !== target.g).slice(0, 2).map(g => take(SHADOWS.filter(s => s.g === g), 1)[0]);
      while (others.length < 2) others.push(take(SHADOWS.filter(s => s.g !== target.g && !others.includes(s)), 1)[0]);
      S.used.push(target.e);
      return { ok: target, opts: shuffle([target, ...others]) };
    }
    if (S.id === 'colors') {
      const fresh = COLORS.filter(c => S.used.filter(u => u === c.id).length < 2);   /* كل لون بحد أقصى مرتين في الجولة */
      const col = take(fresh.length ? fresh : COLORS, 1)[0];
      S.used.push(col.id);
      const ok = take(col.items, 1)[0];
      /* المشتتات من ألوان تانية، ومن غير نفس الإيموجي (العنب في البنفسجي بس) */
      const others = take(COLORS.filter(c => c.id !== col.id), 2).map(c => take(c.items.filter(x => x.e !== ok.e), 1)[0]);
      return { col, ok, opts: shuffle([ok, ...others]) };
    }
    if (S.id === 'count') {
      const lv = COUNT_LEVELS[prefs().cmax];
      let n;
      const lo = lv.mix ? 2 : 1;   /* في المخلوطين: على الأقل ٢ عشان يبقى فيه عدّ */
      do { n = lo + rnd(lv.max - lo + 1); } while (S.q && S.q.n === n);
      const [e, d1, d2] = take(COUNT_ITEMS.filter(x => !S.q || x !== S.q.e), 3);
      let items = Array.from({ length: n }, () => ({ e, t: true }));
      if (lv.mix) {
        const total = Math.max(n + 3, 8 + rnd(3));
        const extra = Array.from({ length: total - n }, (_, i) => ({ e: i % 2 ? d1 : d2, t: false }));
        items = shuffle(items.concat(extra));
      }
      const near = [n - 2, n - 1, n + 1, n + 2].filter(v => v >= 1 && v <= Math.max(lv.max, 5));
      return { n, e, items, ok: n, opts: shuffle([n, ...take(near, 2)]) };
    }
    if (S.id === 'letters') {
      const set = isAr() ? AR_LETTERS : EN_LETTERS;
      const fresh = set.filter(x => !S.used.includes(x.l));
      const ok = take(fresh.length ? fresh : set, 1)[0];
      S.used.push(ok.l);
      const others = take(set.filter(x => x !== ok), 2);
      return { lang, ok, opts: shuffle([ok, ...others]) };
    }
    /* odd */
    let A, B;
    do { [A, B] = take(ODD_CATS, 2); } while (ODD_SKIP.some(p => p.includes(A.id) && p.includes(B.id)));
    const odd = take(B.items, 1)[0];
    return { A, B, ok: odd, opts: shuffle([...take(A.items, 3), odd]) };
  }

  const SPLASH = hex => `<svg class="gm-splash" viewBox="0 0 120 120" aria-hidden="true">
    <path fill="${hex}" d="M60 8c10 0 14 10 22 12s20-4 25 6-4 18-2 26 13 15 7 25-18 6-25 11-8 20-21 20-14-13-22-16-22 2-26-9 7-16 6-25S6 41 13 32s19-1 26-8S48 8 60 8z"/>
    <ellipse cx="44" cy="40" rx="13" ry="8" fill="#fff" opacity=".28" transform="rotate(-30 44 40)"/>
    <circle cx="104" cy="98" r="6" fill="${hex}"/><circle cx="16" cy="96" r="4.5" fill="${hex}"/><circle cx="108" cy="18" r="4" fill="${hex}"/>
  </svg>`;

  function paintRound() {
    const st = document.getElementById('gm-stage');
    if (!st || !S.q) return;
    const q = S.q;
    const btn = (i, inner, label, cls) => `<button class="gm-opt ${cls || ''}" data-act="gmpick" data-i="${i}" data-sfx="off"${label ? ` aria-label="${esc(label)}"` : ''}><span class="gm-in">${inner}</span></button>`;
    let top = '', opts = '', say = '';
    if (S.id === 'shadow') {
      top = `<div class="gm-q"><span class="gm-sil" aria-label="${isAr() ? 'ظل' : 'shadow'}">${q.ok.e}</span></div>`;
      opts = q.opts.map((o, i) => btn(i, o.e, nm(o))).join('');
      say = isAr() ? 'مين صاحب الظل ده؟ 🤔' : 'Whose shadow is this? 🤔';
    } else if (S.id === 'colors') {
      top = `<div class="gm-q">${SPLASH(q.col.hex)}</div>`;
      opts = q.opts.map((o, i) => btn(i, o.e, nm(o))).join('');
      say = isAr() ? 'إيه اللي لونه كده؟ 🎨' : 'What is this color? 🎨';
    } else if (S.id === 'count') {
      let k = 0;
      const size = q.items.length <= 3 ? 'lg' : q.items.length <= 6 ? 'md' : 'sm';
      top = `<div class="gm-q gm-count gm-${size}">${q.items.map(x => x.t
        ? `<span class="gm-it" data-n="${num(++k)}" style="--d:${k - 1}">${x.e}</span>`
        : `<span class="gm-it gm-x">${x.e}</span>`).join('')}</div>`;
      opts = q.opts.map((v, i) => btn(i, num(v), '', 'gm-num')).join('');
      say = isAr() ? `كام ${q.e} هنا؟` : `How many ${q.e}?`;
    } else if (S.id === 'letters') {
      top = `<div class="gm-q"><span class="gm-letter" dir="auto">${q.ok.l}</span></div>`;
      opts = q.opts.map((o, i) => btn(i, o.e, o.w)).join('');
      say = isAr() ? 'إيه اللي اسمه بيبدأ بالحرف ده؟ 🤔' : 'What starts with this letter? 🤔';
    } else {
      opts = q.opts.map((o, i) => btn(i, o)).join('');
      say = isAr() ? 'مين مش زي الباقيين؟ 🤔' : 'Which one doesn’t belong? 🤔';
    }
    q.say = say;   /* بنرجعله بعد رسالة "حاول تاني" */
    st.innerHTML = `
      ${top}
      <p class="gm-say" id="gm-say" aria-live="polite">${say}</p>
      <div class="gm-opts gm-n${q.opts.length}">${opts}</div>`;
  }

  function pick(i, btn) {
    if (S.lock || S.won || !S.q) return;
    const q = S.q;
    if (q.opts[i] !== q.ok) {
      S.miss++;
      btn.classList.remove('no'); void btn.offsetWidth; btn.classList.add('no');
      btn.disabled = true;
      sfx('nope');
      /* "حاول تاني 😢" مكان السؤال، وبعد شوية يرجع السؤال (لو لسه مجاوبش صح) */
      const sayEl = document.getElementById('gm-say');
      if (sayEl) {
        sayEl.innerHTML = `<span class="gm-oops">${isAr() ? 'حاول تاني' : 'Try again'} 😢</span>`;
        const k = (S.oops = (S.oops || 0) + 1);
        later(() => {
          const el = document.getElementById('gm-say');
          if (S.oops === k && S.q === q && !S.lock && el) el.innerHTML = q.say;
        }, 1800);
      }
      return;
    }
    S.lock = true;
    btn.classList.add('ok');
    sfx('yay');
    const say = document.getElementById('gm-say');
    const set = html => { if (say) say.innerHTML = html; };
    let wait = 1500;
    if (S.id === 'shadow') {
      const sil = document.querySelector('.gm-sil');
      if (sil) sil.classList.add('reveal');
      set(`${q.ok.e} ${nm2(q.ok)} 👏`);
    } else if (S.id === 'colors') {
      set(`<span class="gm-col" style="--c:${q.col.hex}">${esc(nm(q.col))}</span>${isAr() ? ` <span class="gm-en" dir="ltr">${q.col.en}</span>` : ''} — ${q.ok.e} ${nm2(q.ok)}`);
      wait += 300;
    } else if (S.id === 'count') {
      const st = document.querySelector('.gm-count');
      if (st) st.classList.add('counted');
      wait += q.n * 180;
      set(`<b>${num(q.n)}</b> ${q.e} 👏`);
    } else if (S.id === 'letters') {
      set(`${q.ok.e} <span class="gm-word" dir="auto">${firstLetter(q.ok.w)}</span>${isAr() ? ` <span class="gm-en" dir="ltr">${q.ok.en}</span>` : ''}`);
      wait += 400;
    } else {
      document.querySelectorAll('.gm-opt').forEach(b => { if (b !== btn) b.classList.add('same'); });
      set(isAr()
        ? `${q.ok} <b>${q.B.one.ar}</b>، والباقي ${q.A.ar} 👏`
        : `${q.ok} is <b>${q.B.one.en}</b> — the rest are ${q.A.en} 👏`);
      wait += 600;
    }
    later(() => {
      S.round++;
      S.lock = false;
      if (S.round >= ROUNDS) { S.won = true; paintBar(); showWin(); return; }
      S.q = makeQ();
      paintBar();
      paintRound();
    }, wait);
  }

  /* ---------- 🔷 تطابق الأشكال ---------- */
  const SH_ICON = `<svg class="gm-shico" viewBox="0 0 120 84" aria-hidden="true">
    <rect x="3" y="3" width="114" height="78" rx="14" fill="#E9C48F" stroke="#C99B5E" stroke-width="3"/>
    <circle cx="30" cy="42" r="17" fill="rgba(95,58,22,.4)"/>
    <polygon points="${ptsStar(62, 44, 19, 8)}" fill="#F2C200" stroke="rgba(0,0,0,.2)" stroke-width="2"/>
    <rect x="80" y="27" width="28" height="28" rx="4" fill="#E5484D" stroke="rgba(0,0,0,.2)" stroke-width="2"/>
    <circle cx="62" cy="45" r="4" fill="#F5E2BF"/><circle cx="94" cy="41" r="4" fill="#F5E2BF"/>
  </svg>`;
  const shHole = sh => `<svg class="sh-cut" viewBox="0 0 100 100" aria-hidden="true"><g fill="rgba(95,58,22,.42)" stroke="rgba(70,40,12,.45)" stroke-width="3" stroke-linejoin="round">${sh.d}</g></svg>`;
  const shPiece = (sh, color, cls) => `<svg class="${cls || ''}" viewBox="0 0 100 100" aria-hidden="true">
    <g fill="${color}" stroke="rgba(0,0,0,.22)" stroke-width="3" stroke-linejoin="round">${sh.d}</g>
    <circle cx="${sh.k[0]}" cy="${sh.k[1]}" r="9" fill="#F5E2BF" stroke="#C9A06A" stroke-width="2"/>
    <circle cx="${sh.k[0] - 3}" cy="${sh.k[1] - 3}" r="3" fill="#fff" opacity=".75"/></svg>`;
  const shSayDefault = () => (isAr() ? 'اسحب الشكل لمكانه 👆' : 'Drag a shape to its place 👆');

  function paintShapes() {
    const st = document.getElementById('gm-stage');
    if (!st) return;
    const left = S.pieces.filter(pc => !pc.placed);
    st.innerHTML = `
      <div class="sh-board" style="--cols:${S.lv.cols}">
        ${S.holes.map(h => `
        <button class="sh-hole ${h.filled ? 'filled' : ''}" data-act="gmshhole" data-h="${h.i}" data-sfx="off"
          aria-label="${esc(h.filled ? nm(h.s) : (isAr() ? 'مكان شكل' : 'Shape slot'))}">
          ${shHole(h.s)}${h.filled ? shPiece(h.s, h.color, 'sh-in') : ''}
          ${h.filled ? `<small class="sh-name">${esc(nm(h.s))}</small>` : ''}
        </button>`).join('')}
      </div>
      <p class="gm-say" id="gm-say" aria-live="polite">${shSayDefault()}</p>
      <div class="sh-tray ${left.length > 6 ? 'many' : ''}">
        ${left.map(pc => `<button class="sh-piece ${S.sel === pc.i ? 'sel' : ''}" data-act="gmshpiece" data-p="${pc.i}" data-sfx="off" aria-label="${esc(nm(pc.s))}">${shPiece(pc.s, pc.color)}</button>`).join('')}
      </div>`;
  }

  function shSay(html, back) {
    const el = document.getElementById('gm-say');
    if (!el) return;
    el.innerHTML = html;
    if (back) {
      const k = (S.sayK = (S.sayK || 0) + 1);
      later(() => { const e2 = document.getElementById('gm-say'); if (S.sayK === k && !S.won && e2) e2.innerHTML = S.id === 'puzzle' ? pzSayDefault() : shSayDefault(); }, 1800);
    }
  }
  const shake = el => { if (!el) return; el.classList.remove('no'); void el.offsetWidth; el.classList.add('no'); };

  /* حط الشكل pid في المكان hid: لو نفس الشكل يتثبت، غير كده "حاول تاني 😢" والشكل يرجع */
  function shPlace(pid, hid) {
    const pc = S.pieces.find(x => x.i === pid), h = S.holes[hid];
    if (!pc || !h || pc.placed || h.filled || S.won) return;
    if (pc.s.id !== h.s.id) {
      S.miss++;
      sfx('nope');
      shake(document.querySelector(`.sh-hole[data-h="${hid}"]`));
      shake(document.querySelector(`.sh-piece[data-p="${pid}"]`));
      shSay(`<span class="gm-oops">${isAr() ? 'حاول تاني' : 'Try again'} 😢</span>`, true);
      return;
    }
    pc.placed = true; h.filled = true; h.color = pc.color;
    S.placed++; S.sel = null;
    sfx('yay');
    paintShapes();
    const hel = document.querySelector(`.sh-hole[data-h="${hid}"]`);
    if (hel) hel.classList.add('pop');
    shSay(`${nm2(h.s)} 👏`, true);
    paintBar();
    if (S.placed === S.holes.length) { S.won = true; later(() => showWin(), 800); }
  }

  /* اللمس: دوس على شكل يتعلّم، وبعدين دوس على مكانه */
  let shDragEnd = 0;
  function shTapPiece(pid) {
    if (!S || S.won || Date.now() - shDragEnd < 350) return;   /* لسه خالص سحب — دي مش ضغطة */
    S.sel = S.sel === pid ? null : pid;
    document.querySelectorAll('.sh-piece').forEach(b => b.classList.toggle('sel', +b.dataset.p === S.sel));
    if (S.sel != null) { sfx('flip'); shSay(isAr() ? 'دلوقتي دوس على مكانه 👆' : 'Now tap its place 👆'); }
  }
  function shTapHole(hid) {
    if (!S || S.won || Date.now() - shDragEnd < 350) return;
    if (S.sel == null) { if (!S.holes[hid].filled) shSay(isAr() ? 'اختار شكل من تحت الأول 👇' : 'Pick a shape below first 👇', true); return; }
    shPlace(S.sel, hid);
  }

  /* شكل فاضي قريب من (x, y) على الشاشة */
  function shHoleAt(x, y) {
    let best = null, bd = Infinity;
    document.querySelectorAll('.sh-hole:not(.filled)').forEach(el => {
      const r = el.getBoundingClientRect();
      const d = Math.hypot(x - (r.left + r.width / 2), y - (r.top + r.height / 2));
      if (d < r.width * 0.75 && d < bd) { bd = d; best = el; }
    });
    return best;
  }

  /* ---------- 🧩 بازل الحيوانات والطيور ---------- */
  /* تقسيم الصورة (٣٠٠×٣٠٠): ٣ شرايح، أو ٤ مربعات، أو ٥ (صفين ٢ و٣) — وبالعرض أو بالطول عشوائي */
  function pzLayout(n) {
    const F = 300, flip = Math.random() < 0.5;
    let r;
    if (n === 4) r = [[0, 0, 150, 150], [150, 0, 150, 150], [0, 150, 150, 150], [150, 150, 150, 150]];
    else if (n === 5) {
      const top = flip ? 3 : 2, bot = 5 - top;
      r = Array.from({ length: top }, (_, i) => [i * F / top, 0, F / top, F / 2])
        .concat(Array.from({ length: bot }, (_, i) => [i * F / bot, F / 2, F / bot, F / 2]));
    } else {
      r = Array.from({ length: n }, (_, i) => [i * F / n, 0, F / n, F]);
      if (flip) r = r.map(([x, y, w, h]) => [y, x, h, w]);
    }
    return r.map(([x, y, w, h]) => ({ x, y, w, h }));
  }
  /* حدود القطعة: كل ضلع بيتقسم عند أركان القطع اللي جنبه، وكل جزء داخلي طويل كفاية ليه "بروز" بازل
     اتجاه البروز متسجل في knobs بمفتاح الجزء — فالقطعتين اللي على الجنبين بيتقابلوا مظبوط */
  function pzPath(pc, all, knobs) {
    const F = 300;
    const cs = q => [[q.x, q.y], [q.x + q.w, q.y], [q.x + q.w, q.y + q.h], [q.x, q.y + q.h]];
    const c = cs(pc);
    let d = `M${c[0][0]} ${c[0][1]}`;
    for (let si = 0; si < 4; si++) {
      const [ax, ay] = c[si], [bx, by] = c[(si + 1) % 4];
      const horiz = ay === by;
      const len = Math.abs(horiz ? bx - ax : by - ay);
      const ux = Math.sign(bx - ax), uy = Math.sign(by - ay);
      const nx = uy, ny = -ux;   /* لبرّه (اللفة مع عقارب الساعة) */
      const ts = [0, len];
      all.forEach(o => cs(o).forEach(([cx, cy]) => {
        const t = horiz ? (cy === ay ? (cx - ax) * ux : -1) : (cx === ax ? (cy - ay) * uy : -1);
        if (t > 0.5 && t < len - 0.5 && !ts.includes(t)) ts.push(t);
      }));
      ts.sort((a, b) => a - b);
      const border = horiz ? (ay === 0 || ay === F) : (ax === 0 || ax === F);
      const P = (t, v) => `${(ax + ux * t + nx * v).toFixed(1)} ${(ay + uy * t + ny * v).toFixed(1)}`;
      for (let k = 0; k < ts.length - 1; k++) {
        const t0 = ts[k], t1 = ts[k + 1];
        if (border || t1 - t0 < 90) { d += ` L${P(t1, 0)}`; continue; }
        const x0 = ax + ux * t0, y0 = ay + uy * t0, x1 = ax + ux * t1, y1 = ay + uy * t1;
        const key = [Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1)].join(',');
        if (!(key in knobs)) knobs[key] = Math.random() < 0.5 ? 1 : -1;
        const sg = (horiz ? ny : nx) * knobs[key];   /* + = بروز لبرّه، - = تجويف */
        const m = (t0 + t1) / 2, v = y => sg * y;
        d += ` L${P(m - 13, 0)} C${P(m - 9, v(8))} ${P(m - 22, v(20))} ${P(m - 14, v(30))}`
          + ` C${P(m - 6, v(40))} ${P(m + 6, v(40))} ${P(m + 14, v(30))}`
          + ` C${P(m + 22, v(20))} ${P(m + 9, v(8))} ${P(m + 13, 0)} L${P(t1, 0)}`;
      }
    }
    return d + 'Z';
  }
  /* صورة الحيوان: الإيموجي كبير في النص على خلفية باستيل — canvas مقاسه ٦٠٠ (ضعف وحدات الصورة) */
  function pzBase(item, bg) {
    const c = document.createElement('canvas');
    c.width = c.height = 600;
    const g = c.getContext('2d');
    g.fillStyle = bg; g.fillRect(0, 0, 600, 600);
    g.fillStyle = 'rgba(255, 255, 255, .55)';
    g.beginPath(); g.arc(300, 300, 275, 0, Math.PI * 2); g.fill();
    g.font = '480px "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
    g.textAlign = 'center'; g.textBaseline = 'alphabetic';
    const m = g.measureText(item.e);
    const asc = m.actualBoundingBoxAscent || 380, desc = m.actualBoundingBoxDescent || 70;
    g.fillText(item.e, 300, 300 + (asc - desc) / 2);
    return c;
  }
  /* كل قطعة صورة PNG جاهزة متقصوصة بشكل البازل (Path2D) — بدل SVG image + clipPath اللي سفاري مش بيرسمها كويس */
  function pzCut(base, pc) {
    const SC = 2, P = PZ_PAD;
    const c = document.createElement('canvas');
    c.width = (pc.w + 2 * P) * SC; c.height = (pc.h + 2 * P) * SC;
    const g = c.getContext('2d');
    g.scale(SC, SC); g.translate(P - pc.x, P - pc.y);
    const path = new Path2D(pc.d);
    g.save(); g.clip(path); g.drawImage(base, 0, 0, 300, 300); g.restore();
    g.lineJoin = 'round';
    g.lineWidth = 3; g.strokeStyle = 'rgba(255, 255, 255, .9)'; g.stroke(path);
    g.lineWidth = 1.2; g.strokeStyle = 'rgba(60, 40, 20, .28)'; g.stroke(path);
    return c.toDataURL('image/png');
  }
  /* الصورة الباهتة اللي على اللوحة (شفافية جوه الصورة نفسها مش CSS — عشان تبان صح في الوضع الليلي وسفاري) */
  function pzGuide(base) {
    const c = document.createElement('canvas');
    c.width = c.height = 600;
    const g = c.getContext('2d');
    g.globalAlpha = 0.22;
    g.drawImage(base, 0, 0);
    return c.toDataURL('image/png');
  }
  const pzImg = pc => `<img src="${pc.src}" alt="" draggable="false">`;
  const pzSayDefault = () => (isAr() ? 'ركّب القطع في أماكنها 👆' : 'Put the pieces in place 👆');

  function paintPuzzle() {
    const st = document.getElementById('gm-stage');
    if (!st) return;
    const P = PZ_PAD, pct = v => (v / 3).toFixed(3) + '%';   /* من وحدات الصورة (٣٠٠) لنسبة من اللوحة */
    const done = S.placed === S.pieces.length;
    const k = S.n === 3 ? 0.42 : 0.44;     /* حجم القطع تحت */
    const mg = -Math.round(P * k * 0.45);  /* الحواف الشفافة حوالين القطعة تتداخل شوية عشان القطع تقرب من بعض */
    st.innerHTML = `
      <div class="pz-board ${done ? 'done' : ''}" id="pz-board" data-act="gmpzboard" data-sfx="off" role="img" aria-label="${esc(nm(S.item))}">
        <img class="pz-guide" src="${S.guide}" alt="" draggable="false">
        <svg class="pz-lines" viewBox="0 0 300 300" aria-hidden="true">${S.pieces.map(pc => `<path d="${pc.d}"/>`).join('')}</svg>
        ${S.pieces.filter(pc => pc.placed).map(pc => `
        <div class="pz-placed" data-p="${pc.i}" style="left:${pct(pc.x - P)};top:${pct(pc.y - P)};width:${pct(pc.w + 2 * P)};height:${pct(pc.h + 2 * P)}">${pzImg(pc)}</div>`).join('')}
        ${done ? `<img class="pz-full" src="${S.img}" alt="" draggable="false">` : ''}
      </div>
      <p class="gm-say" id="gm-say" aria-live="polite">${pzSayDefault()}</p>
      <div class="pz-tray">
        ${S.order.map(i => S.pieces[i]).filter(pc => !pc.placed).map(pc => `
        <button class="pz-piece ${S.sel === pc.i ? 'sel' : ''}" data-act="gmpzpiece" data-p="${pc.i}" data-sfx="off"
          aria-label="${isAr() ? 'قطعة' : 'Piece'} ${num(pc.i + 1)}"
          style="width:${Math.round((pc.w + 2 * P) * k)}px;height:${Math.round((pc.h + 2 * P) * k)}px;margin:${mg}px">${pzImg(pc)}</button>`).join('')}
      </div>`;
  }

  function pzPlace(id) {
    const pc = S.pieces[id];
    if (!pc || pc.placed || S.won) return;
    pc.placed = true; S.placed++; S.sel = null;
    const done = S.placed === S.pieces.length;
    if (done) S.won = true;
    paintPuzzle(); paintBar();
    const el = document.querySelector(`.pz-placed[data-p="${id}"]`);
    if (el) el.classList.add('pop');
    sfx('yay');
    if (done) { shSay(`${S.item.e} ${nm2(S.item)} 👏`); later(() => showWin(), 1400); }
    else shSay(isAr() ? 'برافو! كمّل 👏' : 'Great! Keep going 👏', true);
  }
  function pzWrong(id) {
    S.miss++;
    sfx('nope');
    shake(document.querySelector(`.pz-piece[data-p="${id}"]`));
    shSay(`<span class="gm-oops">${isAr() ? 'حاول تاني' : 'Try again'} 😢</span>`, true);
  }
  function pzTapPiece(id) {
    if (!S || S.won || Date.now() - shDragEnd < 350) return;
    S.sel = S.sel === id ? null : id;
    document.querySelectorAll('.pz-piece').forEach(b => b.classList.toggle('sel', +b.dataset.p === S.sel));
    if (S.sel != null) { sfx('flip'); shSay(isAr() ? 'دلوقتي دوس على مكانها في الصورة 👆' : 'Now tap its place in the picture 👆'); }
  }
  function pzTapBoard(e) {
    if (!S || S.won || Date.now() - shDragEnd < 350) return;
    const b = document.getElementById('pz-board').getBoundingClientRect(), k = b.width / 300;
    const px = (e.clientX - b.left) / k, py = (e.clientY - b.top) / k;
    const slot = S.pieces.find(pc => !pc.placed && px >= pc.x && px <= pc.x + pc.w && py >= pc.y && py <= pc.y + pc.h);
    if (!slot) return;
    if (S.sel == null) { shSay(isAr() ? 'اختار قطعة من تحت الأول 👇' : 'Pick a piece below first 👇', true); return; }
    if (slot.i === S.sel) pzPlace(S.sel); else pzWrong(S.sel);
  }

  /* ---------- ✋ السحب (للأشكال والبازل) ----------
     نسخة من القطعة بتمشي مع الصباع (فوقه شوية عشان تبان)، ولما يسيب بنسأل اللعبة: اتحطت فين؟ */
  const DRAGGERS = {
    shapes: {
      sel: '.sh-piece',
      start(id) {
        const holeEl = document.querySelector('.sh-hole');
        const w = holeEl ? holeEl.getBoundingClientRect().width : 80;
        const pc = S.pieces.find(x => x.i === id);
        return { w, h: w, html: shPiece(pc.s, pc.color) };
      },
      over(x, y) {
        const o = x == null ? null : shHoleAt(x, y);
        document.querySelectorAll('.sh-hole').forEach(el => el.classList.toggle('over', el === o));
      },
      drop(id, x, y) { const hole = shHoleAt(x, y); if (hole) shPlace(id, +hole.dataset.h); },
    },
    puzzle: {
      sel: '.pz-piece',
      start(id) {
        const pc = S.pieces[id];
        const k = document.getElementById('pz-board').getBoundingClientRect().width / 300;
        return { w: (pc.w + 2 * PZ_PAD) * k, h: (pc.h + 2 * PZ_PAD) * k, html: pzImg(pc) };
      },
      over(x, y) {
        const el = document.getElementById('pz-board');
        if (!el) return;
        const b = el.getBoundingClientRect();
        el.classList.toggle('over', x != null && x > b.left && x < b.right && y > b.top && y < b.bottom);
      },
      /* قريبة من مكانها الصح ⇒ تتثبت؛ على اللوحة بس في مكان غلط ⇒ "حاول تاني"؛ برا اللوحة ⇒ ترجع وخلاص */
      drop(id, x, y) {
        const pc = S.pieces[id], el = document.getElementById('pz-board');
        if (!pc || !el) return;
        const b = el.getBoundingClientRect(), k = b.width / 300;
        const tx = b.left + (pc.x + pc.w / 2) * k, ty = b.top + (pc.y + pc.h / 2) * k;
        if (Math.hypot(x - tx, y - ty) < Math.min(pc.w, pc.h) * k * 0.5 + 14) return pzPlace(id);
        if (x > b.left && x < b.right && y > b.top && y < b.bottom) pzWrong(id);
      },
    },
  };
  let drag = null;
  function dragPos(e) {
    const x = e.clientX, y = e.clientY - drag.h * 0.45;   /* نص القطعة فوق الصباع */
    drag.ghost.style.transform = `translate(${x - drag.w / 2}px, ${y - drag.h / 2}px)`;
    return [x, y];
  }
  function dragEnd(e, cancel) {
    if (!drag) return;
    const d = drag;
    drag = null;
    if (d.ghost) d.ghost.remove();
    d.cfg.over(null);
    d.el.classList.remove('dragging');
    if (!d.moved) return;          /* ضغطة عادية — الـ click هيتعامل معاها */
    shDragEnd = Date.now();
    if (cancel || !S || S.id !== d.game || S.won || !d.last) return;
    d.cfg.drop(d.id, d.last[0], d.last[1]);
  }
  const app0 = document.getElementById('app');
  app0.addEventListener('pointerdown', e => {
    if (!S || S.won || drag || (e.pointerType === 'mouse' && e.button !== 0)) return;
    const cfg = DRAGGERS[S.id];
    const el = cfg && e.target.closest && e.target.closest(cfg.sel);
    if (!el) return;
    drag = { cfg, game: S.id, el, id: +el.dataset.p, x0: e.clientX, y0: e.clientY, moved: false, ghost: null, last: null, w: 80, h: 80 };
    try { el.setPointerCapture(e.pointerId); } catch (_) {}
  });
  app0.addEventListener('pointermove', e => {
    if (!drag) return;
    if (!drag.moved) {
      if (Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) < 8) return;
      drag.moved = true;
      const g0 = drag.cfg.start(drag.id);
      drag.w = g0.w; drag.h = g0.h;
      const g = document.createElement('div');
      g.className = 'sh-ghost';
      g.style.width = g0.w + 'px'; g.style.height = g0.h + 'px';
      g.innerHTML = g0.html;
      document.body.appendChild(g);
      drag.ghost = g;
      drag.el.classList.add('dragging');
      S.sel = null;
      document.querySelectorAll(drag.cfg.sel + '.sel').forEach(b => b.classList.remove('sel'));
    }
    e.preventDefault();
    drag.last = dragPos(e);
    drag.cfg.over(drag.last[0], drag.last[1]);
  });
  app0.addEventListener('pointerup', e => dragEnd(e, false));
  app0.addEventListener('pointercancel', e => dragEnd(e, true));
  app0.addEventListener('lostpointercapture', e => { if (drag && e.target === drag.el) dragEnd(e, false); });
  window.addEventListener('hashchange', () => { if (drag) dragEnd(null, true); });

  /* ---------- 🏆 الفوز ---------- */
  function stars() {
    if (S.id === 'memory') {
      const n = S.lv.n;
      return S.moves <= n + Math.ceil(n / 2) ? 3 : S.moves <= n * 2 ? 2 : 1;
    }
    return S.miss <= 1 ? 3 : S.miss <= 4 ? 2 : 1;
  }

  function showWin(quiet) {
    const app = $();
    if (!app || app.querySelector('.gm-win')) return;
    const st = stars();
    const name = (typeof baby !== 'undefined' && baby && typeof nameBlank === 'function' && !nameBlank(baby.name)) ? baby.name : '';
    const title = name ? (isAr() ? `برافو يا ${esc(name)}! 🎉` : `Bravo, ${esc(name)}! 🎉`) : (isAr() ? 'برافو! 🎉' : 'Bravo! 🎉');
    let line;
    if (S.id === 'memory') {
      const t = S.moves;
      line = isAr()
        ? `لقيت الـ ${num(S.lv.n)} أزواج في ${num(t)} ${t <= 10 ? 'محاولات' : 'محاولة'}`
        : `Found all ${S.lv.n} pairs in ${t} tries`;
    } else {
      /* البازل: اسم الحيوان دايمًا (هو أحلى حاجة في آخر الصورة) */
      line = S.id === 'puzzle'
        ? `${S.item.e} ${esc(nm(S.item))} — ${isAr() ? 'الصورة كاملة!' : 'picture complete!'}${S.miss === 0 ? ' 👌' : ''}`
        : S.miss === 0
        ? (isAr() ? 'كلهم صح من أول مرة! 👌' : 'All right on the first try! 👌')
        : S.id === 'shapes'
          ? (isAr() ? 'كل الأشكال في أماكنها 👏' : 'Every shape in its place 👏')
          : (isAr() ? `خلصت الـ ${num(ROUNDS)} أسئلة 👏` : `All ${ROUNDS} done 👏`);
    }
    const PAL = ['#FF8FA3', '#FFB88C', '#FFD66B', '#7FD4B0', '#8FB8F5', '#C3A6EE'];
    const confetti = Array.from({ length: 34 }, (_, i) =>
      `<i style="left:${rnd(100)}%;background:${PAL[i % PAL.length]};animation-delay:${(rnd(90) / 100).toFixed(2)}s;animation-duration:${(2.2 + rnd(140) / 100).toFixed(2)}s;--r:${rnd(360)}deg"></i>`).join('');
    const box = document.createElement('div');
    box.className = 'gm-win';
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');
    box.setAttribute('aria-label', isAr() ? 'برافو' : 'Bravo');
    box.innerHTML = `
      <div class="gm-confetti" aria-hidden="true">${confetti}</div>
      <div class="gm-win-card">
        <div class="gm-trophy" aria-hidden="true">🏆</div>
        <div class="gm-stars" aria-label="${num(st)} / ${num(3)}">${[1, 2, 3].map(k => `<span class="${k <= st ? 'on' : ''}" style="--k:${k}">⭐</span>`).join('')}</div>
        <h2>${title}</h2>
        <p>${line}</p>
        <button class="gm-btn" data-act="gmrestart">🔄 ${isAr() ? 'العب تاني' : 'Play again'}</button>
        <a class="gm-btn ghost" href="#/games">🧩 ${isAr() ? 'لعبة تانية' : 'Another game'}</a>
      </div>`;
    app.appendChild(box);
    if (!quiet) { sfx('win'); setTimeout(() => sfx('yay'), 450); }
  }

  /* ---------- الأزرار ---------- */
  document.getElementById('app').addEventListener('click', e => {
    const btn = e.target.closest('[data-act^="gm"]');
    if (!btn || !S) return;
    const act = btn.dataset.act;
    if (act === 'gmflip') return memFlip(+btn.dataset.i);
    if (act === 'gmpick') return pick(+btn.dataset.i, btn);
    if (act === 'gmrestart') { S = newGame(S.id); renderGame(); return; }
    if (act === 'gmtheme') { savePref('theme', btn.dataset.v); S = newGame('memory'); renderGame(); return; }
    if (act === 'gmlevel') { savePref('level', +btn.dataset.v); S = newGame('memory'); renderGame(); return; }
    if (act === 'gmcmax') { savePref('cmax', +btn.dataset.v); S = newGame('count'); renderGame(); return; }
    if (act === 'gmpzt') { savePref('pzt', btn.dataset.v); S = newGame('puzzle'); renderGame(); return; }
    if (act === 'gmpzn') { savePref('pzn', +btn.dataset.v); S = newGame('puzzle'); renderGame(); return; }
    if (act === 'gmpzpiece') return pzTapPiece(+btn.dataset.p);
    if (act === 'gmpzboard') return pzTapBoard(e);
    if (act === 'gmshl') { savePref('shl', +btn.dataset.v); S = newGame('shapes'); renderGame(); return; }
    if (act === 'gmshpiece') return shTapPiece(+btn.dataset.p);
    if (act === 'gmshhole') return shTapHole(+btn.dataset.h);
  });

  /* بيتنادي من render() في app.js */
  window.renderGames = function (id) {
    const g = GAMES.some(x => x.id === id) ? id : null;
    if (g !== cur) {
      cur = g;
      S = g ? newGame(g) : null;
      if (!g) gen++;
    }
    if (!g) return renderHub();
    renderGame();
  };
})();
