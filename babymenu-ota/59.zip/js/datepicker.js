/* ============================================================
   📅 منتقي تاريخ جوه التطبيق — بدل منتقي iOS/أندرويد
   ليه؟ منتقي النظام بياخد لغة الموبايل مش لغة التطبيق (Reset بالإنجليزي والأرقام إنجليزي)
   هنا: لغة التطبيق نفسها — أرقام عربي، شهور بالمصري، الأسبوع يبدأ السبت، و"مسح" بدل Reset.

   الفكرة: خانة <input type="date"> بتفضل موجودة (مخفية) وشايلة القيمة بصيغة yyyy-mm-dd
   وكل الكود القديم بيقرا منها عادي — وجنبها زرار بيعرض التاريخ ويفتح المنتقي.
   ============================================================ */
(function () {
  const AR_D = '٠١٢٣٤٥٦٧٨٩';
  const isAr = () => document.documentElement.lang !== 'en';
  const n = v => isAr() ? String(v).replace(/\d/g, d => AR_D[d]) : String(v);
  const MONTHS = {
    ar: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
    en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  };
  /* عربي: الأسبوع يبدأ السبت — إنجليزي: يبدأ الأحد */
  const WEEK = {
    ar: { start: 6, names: ['أحد', 'اتنين', 'تلات', 'أربع', 'خميس', 'جمعة', 'سبت'] },  /* مترتبة زي getDay: الأحد = 0 */
    en: { start: 0, names: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] },
  };
  const L = () => (isAr() ? 'ar' : 'en');
  const TXT = {
    clear: { ar: 'مسح', en: 'Clear' },
    cancel: { ar: 'إلغاء', en: 'Cancel' },
    today: { ar: 'النهارده', en: 'Today' },
    pick: { ar: 'اختاري التاريخ', en: 'Pick a date' },
    birth: { ar: 'تاريخ الميلاد', en: 'Birth date' },
    prev: { ar: 'الشهر اللي فات', en: 'Previous month' },
    next: { ar: 'الشهر الجاي', en: 'Next month' },
    prevY: { ar: 'السنة اللي فاتت', en: 'Previous year' },
    nextY: { ar: 'السنة الجاية', en: 'Next year' },
    years: { ar: 'اختاري السنة', en: 'Pick a year' },
    ok: { ar: 'تمام', en: 'Done' },
  };
  /* 🎡 عجلة السنين: ارتفاع كل سطر، وعدد السنين اللي بتظهر قبل أقصى سنة */
  const ROW = 44, YEARS_BACK = 15;

  const pad = v => String(v).padStart(2, '0');
  const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = s => {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  };
  const fmt = s => {
    const d = parse(s);
    if (!d) return '';
    return isAr()
      ? `${n(d.getDate())} ${MONTHS.ar[d.getMonth()]} ${n(d.getFullYear())}`
      : `${d.getDate()} ${MONTHS.en[d.getMonth()].slice(0, 3)} ${d.getFullYear()}`;
  };
  const placeholder = inp => (/birth/.test(inp.id) ? TXT.birth : TXT.pick)[L()];

  /* ---------- الزرار اللي بيعرض التاريخ ---------- */
  function refresh(inp) {
    const b = inp._dpBtn;
    if (!b) return;
    const v = fmt(inp.value);
    b.textContent = v || placeholder(inp);
    b.classList.toggle('empty', !v);
  }

  function enhance(inp) {
    if (inp._dpBtn) return;
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'date-btn ' + (inp.className || '');
    if (inp.getAttribute('aria-label')) b.setAttribute('aria-label', inp.getAttribute('aria-label'));
    inp._dpBtn = b;
    inp.style.display = 'none';
    inp.setAttribute('tabindex', '-1');
    inp.after(b);
    b.addEventListener('click', () => open(inp));
    refresh(inp);
  }

  function scan(root) {
    (root.querySelectorAll ? root : document).querySelectorAll('input[type="date"]').forEach(enhance);
  }

  /* أي تغيير في القيمة (✕ مثلًا) ⇒ نحدّث الزرار */
  ['input', 'change'].forEach(ev => document.addEventListener(ev, e => {
    if (e.target && e.target.type === 'date') refresh(e.target);
  }, true));

  /* ---------- المنتقي نفسه ---------- */
  let cur = null; /* { inp, view: Date (أول الشهر), mode: 'days'|'months'|'years', from, wheelY } */

  function setValue(inp, v) {
    inp.value = v;
    inp.dispatchEvent(new Event('input', { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    refresh(inp);
  }

  function close() {
    const ov = document.getElementById('dp-overlay');
    if (ov) { ov.classList.remove('open'); setTimeout(() => ov.remove(), 180); }
    cur = null;
  }

  function open(inp) {
    const sel = parse(inp.value);
    const max = parse(inp.max);
    const base = sel || (max && max < new Date() ? max : new Date());
    cur = { inp, view: new Date(base.getFullYear(), base.getMonth(), 1), mode: 'days' };
    let ov = document.getElementById('dp-overlay');
    if (!ov) {
      ov = document.createElement('div');
      ov.id = 'dp-overlay';
      ov.addEventListener('click', onClick);
      document.body.appendChild(ov);
    }
    draw();
    requestAnimationFrame(() => ov.classList.add('open'));
  }

  function draw() {
    const ov = document.getElementById('dp-overlay');
    if (!ov || !cur) return;
    const lg = L();
    const { inp, view, mode } = cur;
    const sel = inp.value;
    const max = parse(inp.max);
    const today = iso(new Date());
    const y = view.getFullYear(), m = view.getMonth();
    const nextMonth = new Date(y, m + 1, 1);
    const canNext = !max || nextMonth <= max;
    const canNextY = !max || new Date(y + 1, 0, 1) <= max;
    /* في RTL زرار "اللي فات" على اليمين وسهمه لليمين — والزراير dir=ltr عشان السهم مايتقلبش */
    const back = isAr() ? '›' : '‹', fwd = isAr() ? '‹' : '›';

    let body;
    if (mode === 'years') {
      const ys = yearRange();
      body = `
        <div class="dp-head"><span class="dp-title static">${TXT.years[lg]}</span></div>
        <div class="dp-wheel-wrap">
          <div class="dp-wheel-band" aria-hidden="true"></div>
          <div class="dp-wheel" id="dp-wheel" role="listbox" aria-label="${TXT.years[lg]}">
            ${ys.map(yy => `<button class="dp-yr" data-dp="year" data-y="${yy}" role="option">${n(yy)}</button>`).join('')}
          </div>
        </div>
        <button class="dp-btn dp-wheel-ok" data-dp="yearok">${TXT.ok[lg]}</button>`;
    } else if (mode === 'months') {
      body = `
        <div class="dp-head">
          <button class="dp-nav" dir="ltr" data-dp="prevY" aria-label="${TXT.prevY[lg]}">${back}</button>
          <button class="dp-title dp-t-year" data-dp="years">${n(y)} ▾</button>
          <button class="dp-nav" dir="ltr" data-dp="nextY" aria-label="${TXT.nextY[lg]}" ${canNextY ? '' : 'disabled'}>${fwd}</button>
        </div>
        <div class="dp-months">
          ${MONTHS[lg].map((name, i) => {
            const dis = max && new Date(y, i, 1) > max;
            const on = sel && parse(sel).getFullYear() === y && parse(sel).getMonth() === i;
            return `<button class="dp-month ${on ? 'sel' : ''}" data-dp="month" data-m="${i}" ${dis ? 'disabled' : ''}>${name}</button>`;
          }).join('')}
        </div>`;
    } else {
      const w = WEEK[lg];
      const first = new Date(y, m, 1).getDay();
      const lead = (first - w.start + 7) % 7;
      const days = new Date(y, m + 1, 0).getDate();
      const cells = [];
      for (let i = 0; i < lead; i++) cells.push('<span></span>');
      for (let d = 1; d <= days; d++) {
        const v = `${y}-${pad(m + 1)}-${pad(d)}`;
        const dis = max && new Date(y, m, d) > max;
        cells.push(`<button class="dp-day ${v === sel ? 'sel' : ''} ${v === today ? 'today' : ''}" data-dp="day" data-v="${v}" ${dis ? 'disabled' : ''}>${n(d)}</button>`);
      }
      const names = [...w.names.slice(w.start), ...w.names.slice(0, w.start)];
      body = `
        <div class="dp-head">
          <button class="dp-nav" dir="ltr" data-dp="prev" aria-label="${TXT.prev[lg]}">${back}</button>
          <span class="dp-title-row">
            <button class="dp-title dp-t-month" data-dp="months">${MONTHS[lg][m]} ▾</button>
            <button class="dp-title dp-t-year" data-dp="years">${n(y)} ▾</button>
          </span>
          <button class="dp-nav" dir="ltr" data-dp="next" aria-label="${TXT.next[lg]}" ${canNext ? '' : 'disabled'}>${fwd}</button>
        </div>
        <div class="dp-week">${names.map(x => `<span>${x}</span>`).join('')}</div>
        <div class="dp-grid">${cells.join('')}</div>`;
    }

    const todayOk = !max || new Date() <= new Date(max.getTime() + 86399999);
    ov.innerHTML = `
      <div class="dp-card" role="dialog" aria-modal="true" dir="${isAr() ? 'rtl' : 'ltr'}">
        ${body}
        <div class="dp-foot">
          <button class="dp-btn ghost" data-dp="clear" ${sel ? '' : 'disabled'}>${TXT.clear[lg]}</button>
          ${todayOk ? `<button class="dp-btn ghost" data-dp="today">${TXT.today[lg]}</button>` : ''}
          <button class="dp-btn" data-dp="cancel">${TXT.cancel[lg]}</button>
        </div>
      </div>`;
    if (mode === 'years') setupWheel();
  }

  /* السنين من (أقصى سنة - ١٥) لحد أقصى سنة (تاريخ الميلاد: السنة دي) — ولو المختار أقدم بنوسّع لحد عنده */
  function yearRange() {
    const max = parse(cur.inp.max);
    const hi = max ? max.getFullYear() : new Date().getFullYear() + 5;
    const lo = Math.min(hi - YEARS_BACK, cur.view.getFullYear());
    const out = [];
    for (let yy = lo; yy <= hi; yy++) out.push(yy);
    return out;
  }

  /* العجلة: بتبدأ على السنة الحالية في المنتقي، واللي في النص بيتعلّم وبيكبر والباقي بيلف ويبهت */
  function setupWheel() {
    const wh = document.getElementById('dp-wheel');
    if (!wh) return;
    const items = [...wh.querySelectorAll('.dp-yr')];
    const idx = Math.max(0, items.findIndex(b => +b.dataset.y === cur.view.getFullYear()));
    cur.wheelY = +items[idx].dataset.y;
    wh.scrollTop = idx * ROW;
    let raf = 0;
    const paint = () => {
      raf = 0;
      const pos = wh.scrollTop / ROW;
      const c = Math.min(items.length - 1, Math.max(0, Math.round(pos)));
      items.forEach((b, i) => {
        const d = i - pos;
        const ad = Math.min(Math.abs(d), 3);
        b.style.transform = `rotateX(${(-d * 20).toFixed(1)}deg) scale(${(1 - ad * 0.08).toFixed(3)})`;
        b.style.opacity = (1 - ad * 0.28).toFixed(2);
        b.classList.toggle('on', i === c);
        b.setAttribute('aria-selected', i === c);
      });
      if (cur) cur.wheelY = +items[c].dataset.y;
    };
    wh.addEventListener('scroll', () => { if (!raf) raf = requestAnimationFrame(paint); }, { passive: true });
    paint();
  }

  /* بعد اختيار السنة: نرجع للشاشة اللي جينا منها (الأيام أو الشهور) بنفس الشهر — ولو الشهر بعد أقصى تاريخ ناخد آخر شهر مسموح */
  function pickYear(yy) {
    const max = parse(cur.inp.max);
    let v = new Date(yy, cur.view.getMonth(), 1);
    if (max && v > max) v = new Date(max.getFullYear(), max.getMonth(), 1);
    cur.view = v;
    cur.mode = cur.from || 'days';
  }

  function onClick(e) {
    if (!cur) return;
    if (e.target.id === 'dp-overlay') return close();      /* الضغط برا الكارت = إلغاء */
    const b = e.target.closest('[data-dp]');
    if (!b || b.disabled) return;
    const a = b.dataset.dp;
    const v = cur.view;
    if (a === 'prev') cur.view = new Date(v.getFullYear(), v.getMonth() - 1, 1);
    else if (a === 'next') cur.view = new Date(v.getFullYear(), v.getMonth() + 1, 1);
    else if (a === 'prevY') cur.view = new Date(v.getFullYear() - 1, v.getMonth(), 1);
    else if (a === 'nextY') cur.view = new Date(v.getFullYear() + 1, v.getMonth(), 1);
    else if (a === 'months') cur.mode = 'months';
    else if (a === 'years') { cur.from = cur.mode; cur.mode = 'years'; }
    else if (a === 'year') {
      /* ضغطة على سنة: تلف للنص الأول عشان تبان إنها اتختارت، وبعدين نكمّل */
      const wh = document.getElementById('dp-wheel');
      const yy = +b.dataset.y;
      const i = [...wh.querySelectorAll('.dp-yr')].indexOf(b);
      wh.scrollTo({ top: i * ROW, behavior: 'smooth' });
      setTimeout(() => { if (cur && cur.mode === 'years') { pickYear(yy); draw(); } }, 260);
      return;
    }
    else if (a === 'yearok') {
      /* السنة اللي في النص دلوقتي (حتى لو العجلة لسه بتلف) */
      const wh = document.getElementById('dp-wheel');
      const items = wh ? [...wh.querySelectorAll('.dp-yr')] : [];
      const it = items[Math.min(items.length - 1, Math.max(0, Math.round(wh.scrollTop / ROW)))];
      pickYear(it ? +it.dataset.y : cur.wheelY);
    }
    else if (a === 'month') { cur.view = new Date(v.getFullYear(), +b.dataset.m, 1); cur.mode = 'days'; }
    else if (a === 'day') { const inp = cur.inp; close(); return setValue(inp, b.dataset.v); }
    else if (a === 'today') { const inp = cur.inp; close(); return setValue(inp, iso(new Date())); }
    else if (a === 'clear') { const inp = cur.inp; close(); return setValue(inp, ''); }
    else if (a === 'cancel') return close();
    draw();
  }

  /* زرار الرجوع في أندرويد/السحب: لو المنتقي مفتوح والصفحة اتغيّرت نقفله */
  window.addEventListener('hashchange', () => { if (cur) close(); });

  new MutationObserver(muts => {
    for (const mu of muts) mu.addedNodes.forEach(nd => { if (nd.nodeType === 1) scan(nd.matches && nd.matches('input[type="date"]') ? nd.parentNode : nd); });
  }).observe(document.body, { childList: true, subtree: true });
  scan(document);

  /* تغيير اللغة ⇒ نص الزراير يتغيّر */
  new MutationObserver(() => document.querySelectorAll('input[type="date"]').forEach(refresh))
    .observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });

  window.BeebyDatePicker = { open, scan };
})();
