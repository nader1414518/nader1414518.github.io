/* ============================================================
   🍱 اللانش بوكس — أفكار لانش بوكس للأطفال من بعد ٣ سنين
   الكارت بيظهر في الرئيسية بعد كارت ٣٦ شهر، ولوحده لو عمر الطفل أكبر من ٣ سنين.

   كل فكرة = وجبة متكاملة: 🌾 نشويات + 💪 بروتين + 🥒 خضار + 🍎 فاكهة
   متعدّلة لسن ٣ سنين: العنب والطماطم الشيري متقطعين بالطول، مفيش مكسرات صحيحة ولا فشار،
   ومية بدل العصير.

   ➕ لإضافة فكرة: ضيفي عنصر جديد في LUNCHBOX_IDEAS بالشكل ده:
   { cat: 'sandwich', box: ['🥪','🥒','🍎'],             // التصنيف + ٣ أيقونات العلبة (الأساسي، خضار، فاكهة)
     title:   { ar: '...', en: '...' },
     carb:    { ar: '...', en: '...' },  protein: { ar: '...', en: '...' },
     veg:     { ar: '...', en: '...' },  fruit:   { ar: '...', en: '...' },
     tip:     { ar: '...', en: '...' } }               // اختياري
   ============================================================ */

const LUNCHBOX_CATS = [
  { id: 'sandwich', e: '🥪', ar: 'ساندوتشات', en: 'Sandwiches', color: 'peach' },
  { id: 'roll',     e: '🌯', ar: 'رول وتورتيلا', en: 'Rolls & wraps', color: 'mint' },
  { id: 'pizza',    e: '🍕', ar: 'بيتزا', en: 'Pizza', color: 'pink' },
  { id: 'warm',     e: '🍝', ar: 'رز ومكرونة وفراخ', en: 'Rice, pasta & chicken', color: 'cream' },
  { id: 'brekkie',  e: '🥞', ar: 'فطار وبان كيك', en: 'Breakfast & pancakes', color: 'blue' },
  { id: 'fun',      e: '🐻', ar: 'أشكال تفرّح', en: 'Fun shapes', color: 'lav' },
  { id: 'fruit',    e: '🍓', ar: 'فاكهة وألوان', en: 'Fruit & colors', color: 'green' },
];

const LB = (ar, en) => ({ ar, en });

const LUNCHBOX_IDEAS = [
  /* ---------- 🥪 ساندوتشات ---------- */
  { cat: 'sandwich', box: ['🥪', '🥒', '🍎'], title: LB('ساندوتش جبنة', 'Cheese sandwich'),
    carb: LB('عيش بلدي', 'Baladi bread'), protein: LB('جبنة قريش أو بيضاء', 'Cottage or white cheese'),
    veg: LB('أصابع خيار وجزر', 'Cucumber & carrot sticks'), fruit: LB('شرايح تفاح', 'Apple slices') },
  { cat: 'sandwich', box: ['🥚', '🫑', '🍐'], title: LB('ساندوتش بيض', 'Egg sandwich'),
    carb: LB('عيش بلدي', 'Baladi bread'), protein: LB('بيضة مسلوقة مهروسة', 'Mashed boiled egg'),
    veg: LB('خيار وفلفل ألوان', 'Cucumber & bell pepper'), fruit: LB('جوافة', 'Guava') },
  { cat: 'sandwich', box: ['🥪', '🥬', '🍎'], title: LB('ساندوتش تونة', 'Tuna sandwich'),
    carb: LB('عيش بلدي أو توست أسمر', 'Baladi or brown toast'), protein: LB('تونة مصفّاة من الزيت', 'Drained tuna'),
    veg: LB('خس وخيار', 'Lettuce & cucumber'), fruit: LB('تفاحة', 'Apple') },
  { cat: 'sandwich', box: ['🥙', '🍅', '🍌'], title: LB('ميني ساندوتش فول', 'Mini foul sandwich'),
    carb: LB('عيش بلدي صغير', 'Small baladi bread'), protein: LB('فول مهروس بزيت زيتون', 'Mashed fava beans'),
    veg: LB('خيار وطماطم شيري متقطعة', 'Cucumber & cut cherry tomatoes'), fruit: LB('موزة', 'Banana') },
  { cat: 'sandwich', box: ['🧆', '🥒', '🍊'], title: LB('ساندوتش طعمية', 'Taameya sandwich'),
    carb: LB('عيش بلدي', 'Baladi bread'), protein: LB('طعمية في الفرن + طحينة', 'Baked taameya + tahini'),
    veg: LB('خيار وطماطم', 'Cucumber & tomato'), fruit: LB('برتقالة', 'Orange'),
    tip: LB('الطعمية في الفرن أخف من المقلية', 'Oven-baked taameya is lighter than fried') },
  { cat: 'sandwich', box: ['🥔', '🥕', '🥭'], title: LB('ساندوتش بطاطس بالبيض', 'Potato & egg sandwich'),
    carb: LB('عيش بلدي', 'Baladi bread'), protein: LB('بطاطس مهروسة + بيضة', 'Mashed potato + egg'),
    veg: LB('جزر وخيار', 'Carrot & cucumber'), fruit: LB('مكعبات مانجو', 'Mango cubes') },
  { cat: 'sandwich', box: ['🥪', '🥬', '🍊'], title: LB('ساندوتش فراخ وخضار', 'Chicken & veggie sandwich'),
    carb: LB('توست أسمر', 'Brown toast'), protein: LB('فراخ مشوية مقطّعة', 'Shredded grilled chicken'),
    veg: LB('خس وطماطم', 'Lettuce & tomato'), fruit: LB('يوسفي', 'Tangerine') },
  { cat: 'sandwich', box: ['🧀', '🥒', '🍇'], title: LB('توست بالجبنة السايحة', 'Grilled cheese toast'),
    carb: LB('توست', 'Toast'), protein: LB('موتزاريلا أو شيدر', 'Mozzarella or cheddar'),
    veg: LB('خيار وطماطم', 'Cucumber & tomato'), fruit: LB('عنب متقطع بالطول', 'Grapes cut lengthwise') },
  { cat: 'sandwich', box: ['🥪', '🥕', '🍓'], title: LB('ساندوتش سلطة البيض', 'Egg salad sandwich'),
    carb: LB('توست أسمر', 'Brown toast'), protein: LB('بيض مسلوق مهروس بالزبادي', 'Egg mashed with yogurt'),
    veg: LB('جزر وخيار', 'Carrot & cucumber'), fruit: LB('فراولة', 'Strawberries') },
  { cat: 'sandwich', box: ['🥪', '🫑', '🍇'], title: LB('ساندوتش الألوان', 'Rainbow sandwich'),
    carb: LB('توست مقطّع أصابع', 'Toast fingers'), protein: LB('جبنة', 'Cheese'),
    veg: LB('شرايح خضار ملونة جوه وجنب', 'Colorful veggie slices'), fruit: LB('عنب متقطع', 'Cut grapes'),
    tip: LB('رصّي الأصابع جنب بعض زي قوس قزح', 'Line the fingers up like a rainbow') },

  /* ---------- 🌯 رول وتورتيلا ---------- */
  { cat: 'roll', box: ['🌯', '🥬', '🍎'], title: LB('رول تورتيلا بالفراخ', 'Chicken tortilla roll'),
    carb: LB('تورتيلا', 'Tortilla'), protein: LB('فراخ + جبنة', 'Chicken + cheese'),
    veg: LB('خس وخيار', 'Lettuce & cucumber'), fruit: LB('شرايح تفاح', 'Apple slices') },
  { cat: 'roll', box: ['🌯', '🥕', '🍇'], title: LB('سوشي التورتيلا', 'Tortilla sushi'),
    carb: LB('تورتيلا ملفوفة ومقطّعة دواير', 'Rolled & sliced tortilla'), protein: LB('جبنة + ديك رومي', 'Cheese + turkey'),
    veg: LB('خيار وجزر', 'Cucumber & carrot'), fruit: LB('عنب متقطع', 'Cut grapes'),
    tip: LB('الدواير الصغيرة سهلة في إيد الطفل', 'Little pinwheels are easy for small hands') },
  { cat: 'roll', box: ['🥚', '🥒', '🍊'], title: LB('رول الأومليت', 'Omelette roll'),
    carb: LB('تورتيلا أو عيش بلدي', 'Tortilla or baladi bread'), protein: LB('أومليت بالسبانخ', 'Spinach omelette'),
    veg: LB('خيار وطماطم', 'Cucumber & tomato'), fruit: LB('برتقالة', 'Orange') },
  { cat: 'roll', box: ['🌯', '🥕', '🍌'], title: LB('رول عيش بلدي', 'Baladi bread roll'),
    carb: LB('عيش بلدي ملفوف', 'Rolled baladi bread'), protein: LB('جبنة قريش', 'Cottage cheese'),
    veg: LB('خيار وجزر', 'Cucumber & carrot'), fruit: LB('موزة', 'Banana') },
  { cat: 'roll', box: ['🌯', '🫑', '🍓'], title: LB('كريب رول بالخضار', 'Veggie crepe roll'),
    carb: LB('كريب', 'Crepe'), protein: LB('فراخ أو جبنة', 'Chicken or cheese'),
    veg: LB('فلفل وجزر سوتيه جوه الرول', 'Sautéed pepper & carrot inside'), fruit: LB('فراولة', 'Strawberries') },

  /* ---------- 🍕 بيتزا ---------- */
  { cat: 'pizza', box: ['🍕', '🫑', '🍓'], title: LB('ميني بيتزا عيش بلدي', 'Mini baladi pizza'),
    carb: LB('عيش بلدي صغير', 'Small baladi bread'), protein: LB('صلصة + جبنة', 'Tomato sauce + cheese'),
    veg: LB('فلفل وخيار', 'Pepper & cucumber'), fruit: LB('فراولة', 'Strawberries') },
  { cat: 'pizza', box: ['🍕', '🥒', '🍇'], title: LB('بيتزا التوست', 'Toast pizza'),
    carb: LB('توست أسمر', 'Brown toast'), protein: LB('صلصة + جبنة + زيتون مقطّع', 'Sauce + cheese + sliced olives'),
    veg: LB('خيار', 'Cucumber'), fruit: LB('عنب متقطع', 'Cut grapes') },
  { cat: 'pizza', box: ['🍕', '🥒', '🍊'], title: LB('بيتزا التورتيلا', 'Tortilla pizza'),
    carb: LB('تورتيلا', 'Tortilla'), protein: LB('صلصة + جبنة قليلة الدسم', 'Sauce + light cheese'),
    veg: LB('أصابع خيار', 'Cucumber sticks'), fruit: LB('برتقال', 'Orange') },

  /* ---------- 🍝 رز ومكرونة وفراخ ---------- */
  { cat: 'warm', box: ['🍝', '🥕', '🍊'], title: LB('مكرونة بالفراخ', 'Chicken pasta'),
    carb: LB('مكرونة', 'Pasta'), protein: LB('قطع فراخ', 'Chicken pieces'),
    veg: LB('جزر وخيار', 'Carrot & cucumber'), fruit: LB('برتقالة', 'Orange') },
  { cat: 'warm', box: ['🍚', '🥒', '🍊'], title: LB('رز وقطع فراخ', 'Rice & chicken'),
    carb: LB('رز بالخضار (جزر وبسلة)', 'Veggie rice (carrot & peas)'), protein: LB('قطع فراخ', 'Chicken pieces'),
    veg: LB('خيار', 'Cucumber'), fruit: LB('برتقالة', 'Orange') },
  { cat: 'warm', box: ['🥔', '🥕', '🍐'], title: LB('بطاطس مسلوقة وبيض', 'Boiled potatoes & egg'),
    carb: LB('بطاطس مسلوقة بالشبت', 'Potatoes with dill'), protein: LB('بيضة مسلوقة + جبنة', 'Boiled egg + cheese'),
    veg: LB('خيار وجزر', 'Cucumber & carrot'), fruit: LB('كمثرى', 'Pear') },
  { cat: 'warm', box: ['🍗', '🥕', '🍓'], title: LB('ناجتس الفراخ البيتي', 'Homemade chicken nuggets'),
    carb: LB('بطاطس وقرنبيط في الفرن', 'Oven potatoes & cauliflower'), protein: LB('صدور فراخ بانيه في الفرن', 'Oven-baked breaded chicken'),
    veg: LB('جزر وخيار', 'Carrot & cucumber'), fruit: LB('فراولة', 'Strawberries'),
    tip: LB('كاتشب قليل في علبة صغيرة للغمس', 'A little ketchup in a small cup for dipping') },
  { cat: 'warm', box: ['🍜', '🥦', '🍎'], title: LB('نودلز بالخضار', 'Veggie noodles'),
    carb: LB('نودلز قمح كامل', 'Whole-wheat noodles'), protein: LB('بيضة أو فراخ مقطّعة', 'Egg or chicken'),
    veg: LB('خضار ملونة سوتيه', 'Sautéed colorful veggies'), fruit: LB('تفاح وتوت', 'Apple & berries') },
  { cat: 'warm', box: ['🍗', '🥒', '🍇'], title: LB('أسياخ الفراخ والجبنة', 'Chicken & cheese skewers'),
    carb: LB('عيش بلدي صغير أو كراكرز', 'Small bread or crackers'), protein: LB('فراخ مشوية + مكعبات جبنة', 'Grilled chicken + cheese cubes'),
    veg: LB('خيار وطماطم شيري متقطعة', 'Cucumber & cut cherry tomatoes'), fruit: LB('عنب متقطع', 'Cut grapes'),
    tip: LB('أعواد بسن مش حاد، أو شيليها وقدّميها مكعبات', 'Use blunt sticks, or serve as cubes') },
  { cat: 'warm', box: ['🍗', '🍅', '🍓'], title: LB('مكعبات البروتين', 'Protein cubes'),
    carb: LB('عيش قمح كامل', 'Whole-wheat bread'), protein: LB('فراخ مشوية مكعبات + صوص زبادي', 'Grilled chicken cubes + yogurt dip'),
    veg: LB('خيار وطماطم وجزر', 'Cucumber, tomato & carrot'), fruit: LB('فراولة', 'Strawberries') },

  /* ---------- 🥞 فطار وبان كيك ---------- */
  { cat: 'brekkie', box: ['🥞', '🥒', '🍓'], title: LB('بان كيك الموز', 'Banana pancakes'),
    carb: LB('بان كيك شوفان صغير', 'Mini oat pancakes'), protein: LB('زبادي أو حتة جبنة', 'Yogurt or cheese'),
    veg: LB('أصابع خيار', 'Cucumber sticks'), fruit: LB('موز وفراولة', 'Banana & strawberries') },
  { cat: 'brekkie', box: ['🥚', '🥦', '🫐'], title: LB('مافن البيض', 'Egg muffins'),
    carb: LB('توست مقطّع نجوم', 'Star-shaped toast'), protein: LB('بيض بالخضار في قوالب الكب كيك', 'Veggie egg muffins'),
    veg: LB('فلفل وسبانخ جوه المافن', 'Pepper & spinach inside'), fruit: LB('توت وعنب متقطع', 'Berries & cut grapes') },
  { cat: 'brekkie', box: ['🥚', '🥒', '🍞'], title: LB('الفطار المصري', 'Egyptian breakfast'),
    carb: LB('توست أو عيش بلدي', 'Toast or baladi bread'), protein: LB('بيضة مسلوقة', 'Boiled egg'),
    veg: LB('خيار', 'Cucumber'), fruit: LB('تمرتين من غير نوى', '2 pitted dates') },
  { cat: 'brekkie', box: ['🥚', '🍅', '🍐'], title: LB('بيض وجبنة مكعبات', 'Eggs & cheese cubes'),
    carb: LB('عيش بلدي', 'Baladi bread'), protein: LB('بيض مسلوق + جبنة مكعبات', 'Boiled egg + cheese cubes'),
    veg: LB('خيار وطماطم', 'Cucumber & tomato'), fruit: LB('أي فاكهة موسمية', 'Any seasonal fruit') },
  { cat: 'brekkie', box: ['🥣', '🥒', '🥝'], title: LB('زبادي وجرانولا', 'Yogurt & granola'),
    carb: LB('جرانولا أو شوفان', 'Granola or oats'), protein: LB('زبادي', 'Yogurt'),
    veg: LB('أصابع خيار', 'Cucumber sticks'), fruit: LB('توت وكيوي وفراولة', 'Berries, kiwi & strawberries'),
    tip: LB('حطي الجرانولا في علبة لوحدها عشان تفضل مقرمشة', 'Pack granola separately to keep it crunchy') },

  /* ---------- 🐻 أشكال تفرّح ---------- */
  { cat: 'fun', box: ['🥪', '🥕', '🍓'], title: LB('الوش المبتسم', 'Smiley face'),
    carb: LB('ساندوتش عيش دايرة', 'Round sandwich'), protein: LB('جبنة قريش', 'Cottage cheese'),
    veg: LB('جزر شعر + خيار', 'Carrot hair + cucumber'), fruit: LB('فراولة', 'Strawberries'),
    tip: LB('عيون زيتون وبُق شريحة فلفل أحمر', 'Olive eyes and a red-pepper smile') },
  { cat: 'fun', box: ['🐻', '🥕', '🫐'], title: LB('الدبدوب', 'Teddy bear'),
    carb: LB('توست مقصوص دب', 'Bear-shaped toast'), protein: LB('جبنة', 'Cheese'),
    veg: LB('خيار وجزر', 'Cucumber & carrot'), fruit: LB('توت وعنب متقطع', 'Berries & cut grapes'),
    tip: LB('دايرة جبنة للبُق وحبتين توت للعيون', 'A cheese circle snout and berry eyes') },
  { cat: 'fun', box: ['🥪', '🥒', '🍓'], title: LB('قطار الطاقة', 'Energy train'),
    carb: LB('ساندوتشات مربعة صغيرة (العربيات)', 'Little square sandwiches'), protein: LB('جبنة', 'Cheese'),
    veg: LB('عجل من حلقات الخيار + جزر', 'Cucumber wheels + carrot'), fruit: LB('فراولة', 'Strawberries') },
  { cat: 'fun', box: ['🐟', '🥬', '🫐'], title: LB('أسماك في البحر', 'Fish in the sea'),
    carb: LB('توست مقصوص سمكة', 'Fish-shaped toast'), protein: LB('تونة', 'Tuna'),
    veg: LB('خس (البحر) + خيار نجوم', 'Lettuce sea + cucumber stars'), fruit: LB('توت', 'Berries') },
  { cat: 'fun', box: ['⭐', '🥕', '🍓'], title: LB('نجوم الطاقة', 'Energy stars'),
    carb: LB('توست قمح كامل نجوم', 'Whole-wheat toast stars'), protein: LB('جبنة نجوم', 'Cheese stars'),
    veg: LB('جزر وخيار', 'Carrot & cucumber'), fruit: LB('فراولة', 'Strawberries') },
  { cat: 'fun', box: ['🥒', '🍅', '🫐'], title: LB('قوارب الخيار', 'Cucumber boats'),
    carb: LB('كراكرز قمح كامل', 'Whole-wheat crackers'), protein: LB('خيار محشي جبنة قريش', 'Cucumber filled with cottage cheese'),
    veg: LB('شراع فلفل + طماطم متقطعة', 'Pepper sails + cut tomatoes'), fruit: LB('توت', 'Berries') },
  { cat: 'fun', box: ['🌯', '🥬', '🍓'], title: LB('الدودة الصغيرة', 'Little caterpillar'),
    carb: LB('رول تورتيلا متقطع ومرصوص زي دودة', 'Tortilla pinwheels in a line'), protein: LB('فراخ وجبنة', 'Chicken & cheese'),
    veg: LB('خس وخيار ووردة جزر', 'Lettuce, cucumber & a carrot flower'), fruit: LB('فراولة وتوت', 'Strawberries & berries'),
    tip: LB('الراس نص طماطاية بعيون — مش طماطم شيري صحيحة', 'Head = half a tomato, not a whole cherry tomato') },
  { cat: 'fun', box: ['🥙', '🥕', '🍓'], title: LB('جاردن بوكس', 'Garden box'),
    carb: LB('كراكرز قمح كامل أو عيش محمص', 'Crackers or toasted bread'), protein: LB('حمص مهروس على شكل وردة', 'Hummus flower'),
    veg: LB('جزر وخيار وطماطم', 'Carrot, cucumber & tomato'), fruit: LB('فراولة', 'Strawberries') },

  /* ---------- 🍓 فاكهة وألوان ---------- */
  { cat: 'fruit', box: ['🍓', '🥝', '🫐'], title: LB('قوس قزح الفاكهة', 'Fruit rainbow'),
    carb: LB('كراكرز أو توست جنبها', 'Crackers or toast on the side'), protein: LB('جبنة مقصوصة سحاب', 'Cheese clouds'),
    veg: LB('أصابع خيار', 'Cucumber sticks'), fruit: LB('فراولة، يوسفي، مانجو، كيوي، توت', 'Strawberry, tangerine, mango, kiwi, berries') },
  { cat: 'fruit', box: ['🥝', '🥪', '🍌'], title: LB('شجرة الفاكهة', 'Fruit tree'),
    carb: LB('ساندوتش صغير جنبها', 'A mini sandwich on the side'), protein: LB('زبادي', 'Yogurt'),
    veg: LB('خيار', 'Cucumber'), fruit: LB('كيوي (الورق) + موز (الجذع) + توت', 'Kiwi leaves, banana trunk, berries') },
  { cat: 'fruit', box: ['🥣', '🍓', '🍊'], title: LB('كوب الفاكهة والزبادي', 'Fruit & yogurt cup'),
    carb: LB('جرانولا', 'Granola'), protein: LB('زبادي', 'Yogurt'),
    veg: LB('أصابع خيار', 'Cucumber sticks'), fruit: LB('فاكهة ملونة مقطّعة', 'Chopped colorful fruit') },
];

/* 💡 نصايح اللانش بوكس */
const LUNCHBOX_TIPS = {
  safety: [
    LB('العنب والطماطم الشيري: قطّعيهم بالطول لأرباع — صحاح ممكن يخنقوا', 'Cut grapes & cherry tomatoes lengthwise into quarters — whole ones are a choking risk'),
    LB('مفيش مكسرات صحيحة ولا فشار قبل ٤ سنين — المكسرات مطحونة أو زبدة رقيقة، ولو المدرسة مانعاها اسمعي كلامهم', 'No whole nuts or popcorn before age 4 — use ground nuts or a thin spread, and follow school nut rules'),
    LB('الجزر النيّ أصابع رفيعة أو مسلوق سلقة خفيفة', 'Raw carrots in thin sticks, or lightly steamed'),
    LB('البيض والتونة والفراخ والزبادي محتاجين كيس تلج صغير في الشنطة', 'Eggs, tuna, chicken & yogurt need a small ice pack'),
    LB('زجاجة مية بدل العصير', 'A water bottle instead of juice'),
  ],
  fun: [
    LB('السر مش في كترة الأصناف — السر في التنويع والتقديم الحلو', 'It’s not about many items — it’s variety and a cute presentation'),
    LB('قطّاعات الأشكال (نجوم، قلوب، دبدوب) بتخلّي الساندوتش العادي مغامرة', 'Shape cutters turn a plain sandwich into an adventure'),
    LB('كوبايات السيليكون الملونة بتفصل الأصناف وبتفرّح', 'Colorful silicone cups keep foods apart and look fun'),
    LB('خليه يختار بين فكرتين — هياكل أكتر لما يكون هو اللي اختار', 'Let them pick between two ideas — kids eat more of what they chose'),
  ],
};
