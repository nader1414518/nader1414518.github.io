/* ============================================================
   ☁️ تحديث الكود على الهوا (OTA) — زي Shorebird
   التطبيق بينزّل نسخة الويب الجديدة (HTML/CSS/JS) من GitHub Pages
   من غير ما يعدّي على المتجر، وتشتغل من أول فتحة بعدها.
   - المصدر: https://nader1414518.github.io/babymenu-ota.json
   - النشر: scripts/ota-publish.sh (بيعمل zip لـ www ويرفعه)
   - أمان: لو النسخة الجديدة مارسمتش الصفحة خلال 10 ثواني، المكتبة بترجع للنسخة اللي قبلها لوحدها.
   - تغييرات الكود الأصلي (plugins/أذونات/أيقونات) لسه محتاجة المتجر — الـ OTA للويب بس.
   ============================================================ */
(function () {
  const MANIFEST_URL = 'https://nader1414518.github.io/babymenu-ota.json';
  const WEB_VERSION = window.BB_WEB_VERSION || 0;

  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const Updater = () => (isNative() && window.Capacitor.Plugins.CapacitorUpdater) || null;

  /* نقول للمكتبة إن النسخة شغالة — بس لما الصفحة الرئيسية تترسم فعلًا.
     لو نسخة OTA بايظة ومارسمتش، مش هنبعت الإشارة ⇒ رجوع تلقائي للنسخة السليمة */
  function confirmHealthy(up) {
    let tries = 0;
    const tick = () => {
      const app = document.getElementById('app');
      if (app && app.children.length) {
        up.notifyAppReady().catch(() => {});
        return;
      }
      if (++tries < 40) setTimeout(tick, 200);
    };
    tick();
  }

  async function fetchManifest() {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 6000);
    try {
      const res = await fetch(MANIFEST_URL + '?t=' + Date.now(), { cache: 'no-store', signal: ctrl.signal });
      return res.ok ? await res.json() : null;
    } catch { return null; } finally { clearTimeout(t); }
  }

  let checking = false;
  async function checkForUpdate() {
    const up = Updater();
    if (!up || checking) return;
    checking = true;
    try {
      const m = await fetchManifest();
      if (!m || !m.version || !m.url) return;
      const plat = window.Capacitor.getPlatform();
      const target = parseInt(m.version, 10);
      if (!(target > WEB_VERSION)) return;                       /* شغالين على نفس النسخة أو أحدث */

      /* نسخة الويب دي محتاجة تطبيق أصلي (native build) مش أقل من كده */
      const info = await window.Capacitor.Plugins.App.getInfo();
      const build = parseInt(info && info.build, 10);
      const minNative = m.minNative && m.minNative[plat];
      if (minNative && !(build >= minNative)) return;

      /* اتنزّلت قبل كده؟ */
      const list = (await up.list()).bundles || [];
      let bundle = list.find(b => b.version === String(target) && b.status !== 'error');
      if (!bundle) {
        bundle = await up.download({ url: m.url, version: String(target), checksum: m.checksum || undefined });
      }
      /* immediate: نطبّقها دلوقتي (إعادة تحميل) */
      if (m.immediate) { await up.set({ id: bundle.id }); return; }
      /* غير كده: تتطبّق لوحدها أول فتحة جديدة للتطبيق — ونعرض شريط "حدّثي دلوقتي" عشان ماتستناش */
      await up.next({ id: bundle.id });
      pending = { id: bundle.id, version: target };
      showReady();

      /* تنضيف النسخ القديمة اللي مش مستخدمة */
      const cur = await up.current();
      for (const b of list) {
        if (b.id !== bundle.id && b.id !== cur.bundle.id && b.id !== 'builtin') up.delete({ id: b.id }).catch(() => {});
      }
    } catch (e) {
      console.warn('[ota]', e && e.message);
    } finally {
      checking = false;
    }
  }

  /* ---------- تطبيق التحديث اللي اتنزّل ---------- */
  let pending = null;   /* { id, version } — نسخة اتنزّلت ومستنية تتطبّق */
  const isAr = () => document.documentElement.lang !== 'en';

  function apply() {
    const up = Updater();
    if (!up || !pending) return;
    up.set({ id: pending.id }).catch(e => console.warn('[ota] set', e && e.message));  /* بيعيد تحميل الصفحة على النسخة الجديدة */
  }

  function showReady() {
    if (document.getElementById('ota-bar')) return;
    const el = document.createElement('div');
    el.id = 'ota-bar';
    el.setAttribute('role', 'status');
    const t = document.createElement('span');
    t.textContent = isAr() ? '✨ في تحديث جديد جاهز' : '✨ A new update is ready';
    const go = document.createElement('button');
    go.type = 'button';
    go.className = 'ota-go';
    go.textContent = isAr() ? 'حدّثي دلوقتي' : 'Update now';
    go.addEventListener('click', () => { go.disabled = true; apply(); });
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'ota-x';
    x.textContent = '✕';
    x.setAttribute('aria-label', isAr() ? 'بعدين' : 'Later');
    x.addEventListener('click', () => el.remove());
    el.append(t, go, x);
    document.body.appendChild(el);
  }

  /* رجعت للتطبيق بعد غياب دقيقة أو أكتر ومعانا نسخة جاهزة ⇒ نطبّقها على طول
     (التطبيق كده كده بيرجع للرئيسية بعد الغياب). لو راجعة من إشعار بيفتح صفحة، نسيبها. */
  let pausedAt = 0;
  function onResume() {
    const away = pausedAt ? Date.now() - pausedAt : 0;
    pausedAt = 0;
    if (pending && away >= 60000) {
      setTimeout(() => { if (!(window.__PUSH_ROUTE_UNTIL > Date.now())) apply(); }, 1500);
      return;
    }
    checkForUpdate();
  }

  function start() {
    const up = Updater();
    if (!up) return;
    confirmHealthy(up);
    setTimeout(checkForUpdate, 800);  /* أول ما التطبيق يفتح */
    try {
      window.Capacitor.Plugins.App.addListener('pause', () => { pausedAt = Date.now(); });
      window.Capacitor.Plugins.App.addListener('resume', onResume);
    } catch {}
  }

  window.BeebyOTA = { check: checkForUpdate, apply, showReady, webVersion: WEB_VERSION };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
