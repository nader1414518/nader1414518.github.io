/* ============================================================
   🌍 لغات إضافية: ألماني / فرنساوي / برتغالي
   الفكرة: التطبيق جواه بيشتغل بالإنجليزي (lang = 'en') — وقبل ما أي نص يتعرض بنترجمه من قاموس
   لغة المستخدم (window.BB_I18N[ui]). أي نص مالوش ترجمة بيفضل إنجليزي.
   الكود القديم متغيّرش: documentElement.lang بيفضل 'en' لأي لغة غير العربي، واللغة الفعلية في data-ui.
   ============================================================ */
(function () {
  const SUPPORTED = ['ar', 'en', 'de', 'fr', 'pt', 'zh', 'tr'];
  const NAMES = { ar: 'العربية', en: 'English', de: 'Deutsch', fr: 'Français', pt: 'Português', zh: '中文', tr: 'Türkçe' };
  const LOCALE = { ar: 'ar-EG', en: 'en-GB', de: 'de-DE', fr: 'fr-FR', pt: 'pt-BR', zh: 'zh-CN', tr: 'tr-TR' };
  let saved = null;
  try { const v = localStorage.getItem('bb_lang'); saved = v ? JSON.parse(v) : null; } catch {}
  const dev = ((navigator.language || 'en') + '').toLowerCase().slice(0, 2);
  const ui = SUPPORTED.includes(saved) ? saved : (SUPPORTED.includes(dev) ? dev : 'en');
  window.BBI18N = { ui, SUPPORTED, NAMES, LOCALE, locale: LOCALE[ui] };
  window.BB_I18N = window.BB_I18N || {};
  if (ui === 'de' || ui === 'fr' || ui === 'pt' || ui === 'zh' || ui === 'tr') {
    document.write('<script src="js/i18n-' + ui + '.js?v=13"><\/script>');
    window.BBI18N.start = start;
  }
  document.documentElement.dataset.ui = ui;

  /* ---------- المترجم ---------- */
  let DICT = null;
  const RULES = [];                      /* [regex, fn(match) => string] للنصوص اللي فيها أرقام/أسماء */
  window.BBI18N.rule = (re, fn) => RULES.push([re, fn]);
  const norm = s => s.replace(/\s+/g, ' ').trim();
  /* أسماء الشهور والأيام الإنجليزي + الأرقام بتتحوّل لـ {0} {1}… قبل البحث في القاموس، وبترجع بلغة المستخدم */
  const EN_M = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const EN_D = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const TOK = new RegExp('\\b(' + EN_M.concat(EN_D, EN_M.map(m => m.slice(0, 3)).filter(m => m !== 'May'), EN_D.map(d => d.slice(0, 3))).join('|') + ')\\b|\\d+', 'g');
  const loc = () => window.BBI18N.locale;
  const fmt = (o, d) => { try { return new Intl.DateTimeFormat(loc(), o).format(d); } catch { return null; } };
  function localTok(t) {
    if (/^\d/.test(t)) return t;
    let i = EN_M.indexOf(t); if (i >= 0) return fmt({ month: 'long' }, new Date(2000, i, 15)) || t;
    i = EN_M.findIndex(m => m.slice(0, 3) === t); if (i >= 0) return fmt({ month: 'short' }, new Date(2000, i, 15)) || t;
    i = EN_D.indexOf(t); if (i >= 0) return fmt({ weekday: 'long' }, new Date(2000, 0, 2 + i)) || t;
    i = EN_D.findIndex(d => d.slice(0, 3) === t); if (i >= 0) return fmt({ weekday: 'short' }, new Date(2000, 0, 2 + i)) || t;
    return t;
  }
  const DEC = /^[\s•·—–\-⚠☐✓✔✨️‍\p{Extended_Pictographic}]+/u;
  const DEC_END = /[\s•·️‍▾▸▴:;,.!?…\p{Extended_Pictographic}]+$/u;
  const SEPS = [': ', ' — ', ' · ', ' or ', ' + ', ' / ', ' • ', '. '];
  const MR = '(' + EN_M.join('|') + '|' + EN_M.map(m => m.slice(0, 3)).join('|') + ')', DR = '(' + EN_D.join('|') + ')';
  const DATE_RE = new RegExp('^(?:' + DR + ',?\\s+)?(\\d{1,2})\\s+' + MR + '(?:\\s+(\\d{4}))?$');
  function look(k) {
    let o = DICT[k]; if (o !== undefined) return o;
    const dm = k.match(DATE_RE);
    if (dm) {
      const mi = dm[3].length === 3 ? EN_M.findIndex(m => m.slice(0, 3) === dm[3]) : EN_M.indexOf(dm[3]);
      const d = new Date(+(dm[4] || 2000), mi, +dm[2]);
      const f = fmt(Object.assign({ day: 'numeric', month: dm[3].length === 3 ? 'short' : 'long' }, dm[1] ? { weekday: 'long' } : {}, dm[4] ? { year: 'numeric' } : {}), d);
      if (f) return f;
    }
    const toks = []; const t = k.replace(TOK, m => { toks.push(m); return '{' + (toks.length - 1) + '}'; });
    if (toks.length) {
      o = DICT[t];
      if (o !== undefined) return o.replace(/\{(\d+)\}/g, (_, i) => localTok(toks[+i] !== undefined ? toks[+i] : ''));
    }
    for (const [re, fn] of RULES) { const m = k.match(re); if (m) return fn(m, tr1); }
    return undefined;
  }
  function tr1(k, depth) {
    depth = depth || 0;
    let o = look(k); if (o !== undefined) return o;
    const pre = (k.match(DEC) || [''])[0], post = (k.match(DEC_END) || [''])[0];
    if (pre || post) {
      const core = k.slice(pre.length, k.length - post.length);
      if (core && core !== k) { o = look(core); if (o !== undefined) return pre + o + post; }
    }
    if (depth < 2) {
      let best = null, bestHits = 0;
      for (const sep of SEPS) {
        if (k.indexOf(sep) < 0) continue;
        const parts = k.split(sep); let hit = 0;
        const outp = parts.map(p => { const r = p.trim() ? tr1(p, depth + 1) : undefined; if (r !== undefined) { hit++; return r; } return p; });
        if (hit === parts.length) return outp.join(sep);
        if (hit > bestHits) { bestHits = hit; best = outp.join(sep); }
      }
      if (best) return best;
    }
    return undefined;
  }
  function tr(s) {
    if (!s) return s;
    const k = norm(s);
    if (!k || !/[A-Za-z]/.test(k)) return s;
    const out = tr1(k);
    if (out === undefined || out === k) return s;
    const lead = s.match(/^\s*/)[0], trail = s.match(/\s*$/)[0];
    return lead + out + trail;
  }
  window.BBI18N.TOK_SRC = TOK.source;
  window.BBI18N.tr = s => (DICT ? tr(s) : s);
  const ATTRS = ['aria-label', 'title', 'placeholder', 'alt', 'data-now'];
  const mine = new WeakMap();
  const SKIP = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, CODE: 1, NOSCRIPT: 1, SVG: 0 };
  function doText(n) {
    const v = n.nodeValue;
    if (mine.get(n) === v) return;
    const o = tr(v);
    if (o !== v) { n.nodeValue = o; mine.set(n, o); }
  }
  function doEl(el) {
    for (const a of ATTRS) { const v = el.getAttribute && el.getAttribute(a); if (v) { const o = tr(v); if (o !== v) el.setAttribute(a, o); } }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { if (!SKIP[root.parentNode && root.parentNode.nodeName]) doText(root); return; }
    if (root.nodeType !== 1 || SKIP[root.nodeName] || root.closest('[data-noi18n]')) return;
    doEl(root);
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode: n => (n.nodeType === 1 && (SKIP[n.nodeName] || n.hasAttribute('data-noi18n'))) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT,
    });
    let n;
    while ((n = tw.nextNode())) { if (n.nodeType === 3) doText(n); else doEl(n); }
  }
  function start() {
    DICT = window.BB_I18N[ui] || {};
    window.BBI18N.dict = DICT;
    const run = () => {
      document.title = tr(document.title);
      walk(document.body);
      new MutationObserver(muts => {
        for (const m of muts) {
          if (m.type === 'characterData') { if (!SKIP[m.target.parentNode && m.target.parentNode.nodeName]) doText(m.target); }
          else if (m.type === 'attributes') doEl(m.target);
          else m.addedNodes.forEach(walk);
        }
      }).observe(document.body, { childList: true, characterData: true, subtree: true, attributes: true, attributeFilter: ATTRS });
    };
    if (document.body) run(); else document.addEventListener('DOMContentLoaded', run);
  }
})();
