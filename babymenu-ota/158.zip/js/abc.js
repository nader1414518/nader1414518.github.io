/* ============================================================
   🔤 حرف وحيوان — #/games/abc و #/games/abc/<sea|forest>
   الطفل يختار عالم، يدوس على أي حيوان فيطلع كارت بالاسم وأول حرف بالأحمر + كارت الحرف.
   مفيش مكسب ولا خسارة — ولما يكتشف كل حيوانات العالم بيسمع "Yay" مرة واحدة.
   صور الحيوانات الكرتونية اللي في img/cut (القص: scripts/puzzle-cutout.py، وللخلفية البيضا scripts/white-cutout.py)
   ============================================================ */
(function () {
  const $ = () => document.getElementById('app');
  const sfx = n => { if (window.BeebySfx) BeebySfx.play(n); };
  /* اسم الحيوان وبعده صوته (manifest.json → "fx": {"lion": "fx/lion.mp3"}) — لو دوس على حيوان تاني القديم بيتلغي */
  let turn = 0;
  function speak(x) {
    const S = window.BeebySfx;
    if (!S || !S.say) return;
    const my = ++turn;
    S.say(isAr() ? x.ar : x.en, null).then(d => setTimeout(() => { if (my === turn && /^#\/games\/abc\//.test(location.hash)) S.fx(x.id); }, d ? d * 1000 + 150 : 0));
  }

  const cut = n => `<img src="img/cut/${n}.webp" alt="" draggable="false">`;

  /* x,y = مكان مركز الحيوان في المشهد (٪) — w = عرضه (٪ من عرض المشهد) */
  const WORLDS = {
    sea: {
      ar: 'البحر', en: 'Sea',
      items: [
        { id: 'whale', ar: 'حوت', en: 'Whale', art: cut('whale'), x: 69, y: 17, w: 44 },
        { id: 'fish', ar: 'سمكة', en: 'Fish', art: cut('goldfish'), x: 25, y: 23, w: 40 },
        { id: 'dolphin', ar: 'دولفين', en: 'Dolphin', art: cut('dolphin'), x: 31, y: 43, w: 44 },
        { id: 'octopus', ar: 'أخطبوط', en: 'Octopus', art: cut('octopus'), x: 73, y: 45, w: 42 },
        { id: 'turtle', ar: 'سلحفاة', en: 'Turtle', art: cut('seaturtle'), x: 52, y: 64, w: 42 },
        { id: 'crab', ar: 'كابوريا', en: 'Crab', art: cut('crab'), x: 25, y: 79, w: 38 },
        { id: 'starfish', ar: 'نجمة البحر', en: 'Starfish', art: cut('starfish'), x: 77, y: 83, w: 28 },
      ],
    },
    forest: {
      ar: 'الغابة', en: 'Forest',
      /* ground: x = نص الحيوان، y = المكان اللي واقف/قاعد عليه (٪ من المشهد)، f = أسفل الرسمة جوه الصورة (٪) */
      items: [   /* الزرافة الأول عشان تبقى ورا (مربع صورتها واسع) */
        { id: 'giraffe', ar: 'زرافة', en: 'Giraffe', art: cut('giraffe'), x: 52, y: 62, w: 52, f: 96.8, on: 'ground' },
        { id: 'monkey', ar: 'قرد', en: 'Monkey', art: cut('monkey2'), x: 30, y: 29, w: 30, f: 91.2, on: 'branch' },
        { id: 'panda', ar: 'باندا', en: 'Panda', art: cut('panda'), x: 74, y: 33, w: 33, f: 91, on: 'trunk', flip: true },
        { id: 'elephant', ar: 'فيل', en: 'Elephant', art: cut('elephant'), x: 21, y: 64, w: 40, f: 89, on: 'ground' },
        { id: 'lion', ar: 'أسد', en: 'Lion', art: cut('lion'), x: 80, y: 63, w: 33, f: 91, on: 'ground' },
        { id: 'tiger', ar: 'نمر', en: 'Tiger', art: cut('tiger'), x: 52, y: 80, w: 33, f: 96.8, on: 'ground' },
        { id: 'zebra', ar: 'حمار وحشي', en: 'Zebra', art: cut('zebra'), x: 22, y: 95, w: 41, f: 96.8, on: 'ground' },
        { id: 'fox', ar: 'ثعلب', en: 'Fox', art: cut('fox'), x: 79, y: 95, w: 37, f: 96.8, on: 'ground' },
      ],
    },
  };

  /* فرع القرد: طالع من جذع الشجرة اللي على الشمال، وبيتحرك مع القرد عشان رجليه تفضل عليه في أي مقاس شاشة */
  const leaf = (x, y, r, c, s) => `<path transform="translate(${x} ${y}) rotate(${r}) scale(${s || 1})" d="M0 0Q14-15 34 0Q14 15 0 0z" fill="${c}"/>`;
  const BRANCH = `<svg class="abc-branch" viewBox="0 0 300 70" preserveAspectRatio="xMaxYMin meet" aria-hidden="true">
    <path d="M0 4Q90 12 170 8T286 10q14 2 12 9-3 8-22 8-70 0-120 6T0 46z" fill="#6E4326"/><path d="M0 10Q90 17 170 13t112 1" fill="none" stroke="#94603A" stroke-width="5" stroke-linecap="round"/>
    ${leaf(282, 16, -35, '#7CC65A')}${leaf(284, 20, 20, '#5CAD4B')}${leaf(96, 34, 70, '#5CAD4B')}${leaf(104, 32, 30, '#7CC65A', .8)}</svg>`;
  /* جذوع الشجر (٪ من المشهد): الباندا حاضن اللي على اليمين، وفرع القرد خارج من اللي على الشمال */
  const trunk = side => `<svg class="abc-trunk ${side}" viewBox="0 0 60 400" preserveAspectRatio="none" aria-hidden="true">
    ${side === 'r'
    ? '<path d="M8 0h60v400H0q16-30 12-90V0z" fill="#6E4326"/><path d="M20 10v110M32 90v170M18 250v100" fill="none" stroke="#94603A" stroke-width="3.5" stroke-linecap="round"/>'
    : '<path d="M-8 0h46q-6 170 0 300t22 100H-8z" fill="#6E4326"/><path d="M12 20v120M24 150v150M10 300v70" fill="none" stroke="#94603A" stroke-width="3.5" stroke-linecap="round"/>'}</svg>`;

  /* ---------- خلفيات المشاهد ---------- */
  const bg = b => `<svg class="abc-bg" viewBox="0 0 360 560" preserveAspectRatio="xMidYMax slice" aria-hidden="true">${b}</svg>`;
  const weed = (x, h, c) => `<path d="M${x} 560q-16-${h * .25} 0-${h * .5}t0-${h * .5}" fill="none" stroke="${c}" stroke-width="13" stroke-linecap="round"/>`;
  const bubbles = [[40, 90, 6], [52, 70, 3.5], [320, 190, 7], [308, 165, 4], [180, 130, 4], [150, 300, 5], [336, 360, 4]]
    .map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#fff" fill-opacity=".18" stroke="#fff" stroke-opacity=".6" stroke-width="1.5"/>`).join('');
  const coral = (x, y, c, s) => `<path transform="translate(${x} ${y}) scale(${s})" d="M0 0V-52M0-22L-22-40v-18M0-14L22-34v-22M-22-44l-12-8M22-40l12-8" fill="none" stroke="${c}" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/>`;
  const SEA_BG = bg(`<defs><linearGradient id="abcSea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9FE3F7"/><stop offset="1" stop-color="#3F8FCB"/></linearGradient></defs>
    <rect width="360" height="560" fill="url(#abcSea)"/><path d="M0 0h360v26q-30 14-60 0t-60 0-60 0-60 0-60 0-60 0z" fill="#fff" opacity=".35"/>
    <path d="M0 330q50-60 90-20t70 100v150H0zM360 300q-60-20-90 60t-60 90v110h150z" fill="#2E3A6B" opacity=".55"/>
    ${coral(26, 505, '#FF8A65', 1.3)}${coral(338, 490, '#F277A8', 1.4)}${coral(205, 515, '#FFB74D', .9)}
    ${weed(8, 190, '#4DAE7B')}${weed(352, 160, '#62BE6B')}${weed(318, 105, '#3E9C74')}${weed(140, 80, '#62BE6B')}
    <path d="M0 505q90-34 180-8t180-6v69H0z" fill="#F7D9A8"/><g fill="#E5BE86"><circle cx="40" cy="530" r="4"/><circle cx="120" cy="542" r="3"/><circle cx="235" cy="528" r="4"/><circle cx="300" cy="545" r="3"/></g>${bubbles}`);
  const bush = (x, y, s, c) => `<g transform="translate(${x} ${y}) scale(${s})" fill="${c}"><circle cx="-34" cy="4" r="22"/><circle cx="-8" cy="-12" r="29"/><circle cx="24" cy="-4" r="25"/><circle cx="46" cy="10" r="17"/><rect x="-54" y="6" width="116" height="26" rx="13"/></g>`;
  const big = (x, y, r, s, c) => `<g transform="translate(${x} ${y}) rotate(${r}) scale(${s})"><path d="M0 0C20-48 82-50 120 0 82 50 20 48 0 0z" fill="${c}"/><path d="M6 0h100M36 0l18-20M36 0l18 20M66 0l18-18M66 0l18 18" fill="none" stroke="#fff" stroke-opacity=".18" stroke-width="3" stroke-linecap="round"/></g>`;
  const flower = (x, y, c) => `<g transform="translate(${x} ${y})" fill="${c}"><circle cx="-5" r="4.5"/><circle cx="5" r="4.5"/><circle cy="-5" r="4.5"/><circle cy="5" r="4.5"/><circle r="3.2" fill="#FFE066"/></g>`;
  const far = (x, w) => `<path d="M${x} 400q${w * .4}-180 ${w * .1}-400h${w}q-${w * .3} 220 ${w * .1} 400z" fill="#5DAF84" opacity=".55"/>`;
  const FOREST_BG = bg(`<defs><radialGradient id="abcJg" cx=".5" cy=".38" r=".75"><stop offset="0" stop-color="#D4F4B4"/><stop offset=".55" stop-color="#98D693"/><stop offset="1" stop-color="#4F9E7C"/></radialGradient></defs>
    <rect width="360" height="560" fill="url(#abcJg)"/>${far(70, 26)}${far(250, 20)}${far(150, 12)}
    ${bush(30, 280, 1.7, '#5FAE7C')}${bush(330, 262, 1.8, '#5FAE7C')}${bush(180, 320, 1.5, '#72BD82')}
    ${bush(20, 340, 1.5, '#3F8F66')}${bush(345, 356, 1.6, '#3F8F66')}${bush(150, 352, 1.1, '#4A9C6C')}${bush(240, 350, .9, '#4A9C6C')}
    <path d="M0 356q90-26 180-4t180-8v216H0z" fill="#69B658"/><path d="M0 450q100-34 200-6t160-8v124H0z" fill="#57A24C"/><path d="M0 524q90-24 180 0t180-6v42H0z" fill="#468C42"/>
    <path d="M170 354q52 50 0 92t-24 114h96q-34-60 12-110t-60-96z" fill="#E4C48C" opacity=".85"/>
    <g fill="#2F7551"><path d="M0 0h360v34q-22 30-48 8-16 30-48 10-22 28-52 4-26 26-54 2-26 26-52 0-24 24-48-4-22 22-58 2z"/></g>
    <g fill="#245C40"><path d="M0 0h360v14q-30 24-62 4-24 22-56 3-30 22-60 2-30 22-62 1-28 22-60 0-26 20-60 2z"/></g>
    <g fill="none" stroke="#2F7551" stroke-width="5" stroke-linecap="round"><path d="M96 20q-8 70 6 112"/><path d="M214 24q12 50-2 88"/></g>
    ${leaf(100, 74, 150, '#3F8F5C')}${leaf(98, 110, 30, '#3F8F5C')}${leaf(217, 66, 25, '#3F8F5C')}${leaf(212, 104, 140, '#3F8F5C')}
    ${big(-14, 548, -62, .85, '#2F7551')}${big(-20, 566, -22, .9, '#245C40')}${big(374, 552, 242, .85, '#2F7551')}${big(382, 568, 200, .8, '#245C40')}
    ${flower(52, 408, '#FF8FB0')}${flower(332, 420, '#fff')}${flower(150, 516, '#fff')}${flower(306, 478, '#FF8FB0')}${flower(120, 430, '#C79BFF')}`);

  /* ---------- الاسم وأول حرف بلغة المستخدم ---------- */
  function wordOf(x) {
    if (isAr()) return x.ar;
    /* اللغات اللي بحروف لاتيني: الكلمة المترجمة — الصيني مالوش حروف فبيتعلّم الإنجليزي */
    const ui = window.BBI18N && BBI18N.ui;
    const d = ui && ui !== 'zh' && window.BB_I18N && window.BB_I18N[ui];
    return (d && d[x.en]) || x.en;
  }
  const firstLetter = w => Array.from(w)[0].toLocaleUpperCase(isAr() ? 'ar' : ((window.BBI18N && BBI18N.ui !== 'zh' && BBI18N.locale) || 'en'));
  function wordHtml(w) {
    const ch = Array.from(w), a = ch[0], rest = ch.slice(1).join('');
    /* ZWJ عشان الحروف العربي تفضل متوصلة بعد تلوين أول حرف */
    const j = isAr() && !'اأإآدذرزو'.includes(a) ? '‍' : '';
    return `<span class="abc-first">${a}${j}</span>${j}${rest}`;
  }

  let found = {};      /* اللي الطفل اكتشفه في العالم الحالي */
  let curWorld = null, openItem = null;

  const topbar = (back, title, sub) => `
    <div class="topbar">
      <a class="backbtn" href="${back}">←</a>
      <div class="logo">🔤</div>
      <h1 class="gm-h1">${title}<small>${sub}</small></h1>
      ${togglesHtml()}
    </div>`;

  function renderPick() {
    const art = { sea: `${SEA_BG}<span class="abc-pk-an">${cut('octopus')}</span><span class="abc-pk-an b">${cut('goldfish')}</span>`, forest: `${FOREST_BG}<span class="abc-pk-an">${cut('lion')}</span><span class="abc-pk-an b">${cut('monkey2')}</span>` };
    $().innerHTML = `${topbar('#/games', isAr() ? 'حرف وحيوان' : 'Animals & letters', isAr() ? 'تروحوا فين؟' : 'Where shall we go?')}
      <div class="abc-pick">
        ${Object.keys(WORLDS).map((k, i) => `<a class="abc-world rise" style="--i:${i}" href="#/games/abc/${k}">${art[k]}<b>${isAr() ? WORLDS[k].ar : WORLDS[k].en}</b></a>`).join('')}
      </div>`;
  }

  function renderScene(k) {
    const wd = WORLDS[k];
    $().innerHTML = `${topbar('#/games/abc', isAr() ? wd.ar : wd.en, isAr() ? 'دوس على أي حيوان' : 'Tap any animal')}
      <div class="abc-scene">
        ${k === 'sea' ? SEA_BG : FOREST_BG}
        ${k === 'forest' ? trunk('l') + trunk('r') : ''}
        ${wd.items.map((x, i) => `<button type="button" class="abc-an ${x.on ? 'on-' + x.on : ''} ${x.flip ? 'flip' : ''} ${found[x.id] ? 'seen' : ''}" data-abc="${x.id}" data-sfx="off" style="left:${x.x}%;top:${x.y}%;width:${x.w}%;--i:${i}${x.f ? ';--f:-' + x.f + '%' : ''}" aria-label="${isAr() ? x.ar : x.en}">${x.on === 'branch' ? BRANCH : ''}<span>${x.art}</span></button>`).join('')}
      </div>`;
    if (openItem) showCard(openItem);
  }

  function closeCard() {
    const o = document.querySelector('.abc-pop');
    if (o) o.remove();
    openItem = null;
  }
  function showCard(x) {
    const scene = document.querySelector('.abc-scene');
    if (!scene) return;
    const old = document.querySelector('.abc-pop');
    if (old) old.remove();
    openItem = x;
    const w = wordOf(x);
    const d = document.createElement('div');
    d.className = 'abc-pop';
    d.innerHTML = `<div class="abc-cards" data-noi18n>
        <div class="abc-card abc-letter">${firstLetter(w)}</div>
        <div class="abc-card abc-wordcard"><span class="abc-pic">${x.art}</span><b>${wordHtml(w)}</b></div>
      </div>`;
    scene.appendChild(d);
  }

  function tapAnimal(id) {
    const wd = WORLDS[curWorld];
    const x = wd && wd.items.find(v => v.id === id);
    if (!x) return;
    sfx('pop');
    showCard(x);
    const t0 = ++turn;
    setTimeout(() => { if (t0 === turn) speak(x); }, 220);
    const btn = document.querySelector(`.abc-an[data-abc="${id}"]`);
    if (btn) btn.classList.add('seen');
    if (!found[id]) {
      found[id] = true;
      if (wd.items.every(v => found[v.id])) found._all = 'pending';
    }
  }

  document.addEventListener('click', e => {
    if (!e.target.closest) return;
    const pop = e.target.closest('.abc-pop');
    if (pop) {
      if (e.target.closest('.abc-card')) { sfx('pop'); if (openItem) speak(openItem); return; }
      closeCard();
      /* اكتشف كل الحيوانات: "Yay" مرة واحدة في الآخر */
      if (found._all === 'pending') { found._all = 'done'; sfx('yay'); }
      return;
    }
    const an = e.target.closest('[data-abc]');
    if (an) tapAnimal(an.dataset.abc);
  });

  window.renderAbc = function (sub) {
    const k = sub && WORLDS[sub[0]] ? sub[0] : null;
    if (k !== curWorld) { curWorld = k; found = {}; openItem = null; }
    if (!k) return renderPick();
    renderScene(k);
  };
  window.resetAbc = function () { curWorld = null; found = {}; openItem = null; };
})();
