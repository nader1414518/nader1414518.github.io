/* ============================================================
   👗 لبّس بوبو — الرسومات (SVG)
   بوبو شخصية كرتونية مقاس ٣٢٠×٤٧٠. دايمًا لابس: لو مفيش حاجة مختارة بيبقى لابس هدوم سادة (فوق وتحت وشرابات)،
   وأي قطعة بتتختار بتحلّ محل الهدوم السادة اللي في مكانها — فمفيش وقت بيظهر فيه من غير ملابس.
   الطبقات من ورا لقدّام: المشهد ← الظل ← الرجلين ← شراب ← بنطلون ← حذاء ← الدراعات ← الرقبة ← الجزء الفوقاني
   ← كوفية ← الراس ← نضارة ← جوانتي ← القبعة.
   كل قطعة: { id, cat, ar, en, fem, pl, where, svg, vb } — svg بإحداثيات الشخصية، و vb = حدود القطعة (للأيقونة اللي في الصينية).
   بيتحمّل قبل games.js ويحط window.DRESSUP_ART
   ============================================================ */
(function () {
  const INK = '#4b3b3f', SKIN = '#FFD3B5', HAIR = '#5A3A2E';
  const f = n => +n.toFixed(1);
  /* كل الرسم جوه <g> بإطار غامق مدوّر — الأشكال بتحدد اللون بس */
  const G = s => `<g stroke="${INK}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round">${s}</g>`;
  const P = (d, fill, x) => `<path d="${d}" fill="${fill}"${x ? ' ' + x : ''}/>`;
  const E = (cx, cy, rx, ry, fill, x) => `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${fill}"${x ? ' ' + x : ''}/>`;
  const C = (cx, cy, r, fill, x) => `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${fill}"${x ? ' ' + x : ''}/>`;
  const R = (x, y, w, h, rx, fill, xt) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}"${xt ? ' ' + xt : ''}/>`;
  const L = (d, w) => `<path d="${d}" fill="none"${w ? ` stroke-width="${w}"` : ''}/>`;
  const NS = 'stroke="none"';                                  /* بدون إطار */
  const mir = s => `<g transform="matrix(-1 0 0 1 320 0)">${s}</g>`;   /* نسخة معكوسة حوالين نص الشخصية */
  const both = fn => fn() + mir(fn());
  /* دراع من الكتف (x,y) بزاوية a: g بيتحط جواه شكل مرسوم لتحت من (0,0) */
  const armL = s => `<g transform="translate(116 228) rotate(16)">${s}</g>`;
  const armR = s => `<g transform="translate(204 228) rotate(-16)">${s}</g>`;
  const arms = fn => armL(fn()) + armR(fn());
  const star = (cx, cy, Ro, ri) => {
    let d = '';
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + i * Math.PI / 5, q = i % 2 ? ri : Ro;
      d += (i ? 'L' : 'M') + f(cx + q * Math.cos(a)) + ' ' + f(cy + q * Math.sin(a));
    }
    return d + 'Z';
  };

  /* ---------- الجسم ---------- */
  const TORSO = 'M116 246 Q116 210 150 208 H170 Q204 210 204 246 V312 Q204 326 190 326 H130 Q116 326 116 312 Z';
  const BASE_TOP = '#D9CFC2', BASE_BOT = '#B7BFCB';          /* هدوم سادة */

  const body = {
    shadow: `<ellipse cx="160" cy="462" rx="96" ry="11" fill="rgba(60,40,30,.16)"/>`,
    legs: G(R(124, 316, 32, 118, 16, SKIN) + R(164, 316, 32, 118, 16, SKIN)),
    socks: G(R(121, 412, 38, 30, 12, '#fff') + R(161, 412, 38, 30, 12, '#fff')),
    arms: G(arms(() => R(-15, -14, 30, 118, 15, SKIN)) + C(86, 338, 16, SKIN) + C(234, 338, 16, SKIN)),
    neck: G(R(144, 182, 32, 32, 9, SKIN)),
    /* هدوم سادة (لما مفيش قطعة مختارة) */
    baseTop: G(arms(() => R(-17, -14, 34, 112, 16, BASE_TOP)) + P(TORSO, BASE_TOP) + L('M140 210 Q160 224 180 210')),
    baseBottom: G(P('M116 316 H204 V428 H164 V356 H156 V428 H116 Z', BASE_BOT) + R(116, 316, 88, 14, 5, '#A5AEBB')),
    head: G(
      C(84, 136, 13, SKIN) + C(236, 136, 13, SKIN) +
      E(160, 122, 78, 70, SKIN) +
      P('M82 118 C78 64 126 40 160 42 C194 40 242 64 238 118 C228 98 208 88 186 84 C162 96 122 92 98 100 C90 104 84 112 82 118 Z', HAIR) +
      P('M150 44 C146 30 160 24 170 32 C164 32 162 38 166 44 Z', HAIR)) +
      /* الوش */
      `<g stroke="none">${E(132, 136, 8, 11, INK)}${E(188, 136, 8, 11, INK)}${C(129.5, 131, 3, '#fff')}${C(185.5, 131, 3, '#fff')}${C(112, 160, 13, 'rgba(255,120,140,.35)')}${C(208, 160, 13, 'rgba(255,120,140,.35)')}</g>` +
      `<g fill="none" stroke="${INK}" stroke-width="3.5" stroke-linecap="round"><path d="M120 116 Q132 109 144 115"/><path d="M176 115 Q188 109 200 116"/><path d="M155 150 Q160 154 165 150"/><path d="M141 162 Q160 180 179 162"/></g>`,
  };

  /* ---------- القطع ---------- */
  const SLEEVE_END = 104;
  const items = [
    /* ===== قبعات (على الراس) ===== */
    { id: 'cap', cat: 'hat', ar: 'كاب', en: 'Cap', fem: false, pl: false,
      svg: G(P('M88 106 C84 50 236 50 232 106 C206 98 114 98 88 106 Z', '#E8453C') + L('M160 56 V100', 3) +
        P('M96 104 C124 126 196 126 224 104 C198 112 122 112 96 104 Z', '#C0352E') + C(160, 56, 7, '#fff')) },
    { id: 'sunhat', cat: 'hat', ar: 'قبعة شمس', en: 'Sun hat', fem: true, pl: false,
      svg: G(E(160, 92, 128, 24, '#F5D58A') + P('M102 92 C102 30 218 30 218 92 Z', '#F5D58A') +
        P('M102 80 C130 90 190 90 218 80 L218 94 C190 104 130 104 102 94 Z', '#E8453C') + L('M132 44 Q160 34 188 44', 3) + L('M126 62 Q160 52 194 62', 3)) },
    { id: 'beanie', cat: 'hat', ar: 'طاقية صوف', en: 'Beanie', fem: true, pl: false,
      svg: G(P('M92 108 C84 36 236 36 228 108 Z', '#2F6FE0') + R(86, 92, 148, 28, 12, '#7FB0F5') + C(160, 40, 16, '#fff') +
        L('M112 94 V118 M130 94 V118 M148 94 V118 M166 94 V118 M184 94 V118 M202 94 V118', 3)) },

    /* ===== فوق (على الجسم) ===== */
    { id: 'tshirt', cat: 'top', ar: 'تيشيرت', en: 'T-shirt', fem: false, pl: false,
      svg: G(arms(() => R(-21, -16, 42, 54, 15, '#4DB8F5')) + P('M112 248 Q112 210 148 208 L160 220 L172 208 Q208 210 208 248 V318 Q208 332 194 332 H126 Q112 332 112 318 Z', '#4DB8F5') +
        L('M140 210 Q160 232 180 210') + P(star(160, 272, 21, 9), '#FFD43B', 'stroke-width="3"')) },
    { id: 'sweater', cat: 'top', ar: 'بلوفر', en: 'Sweater', fem: false, pl: false,
      svg: G(arms(() => R(-19, -16, 38, 122, 16, '#FB8C1D') + R(-19, 90, 38, 16, 7, '#C9650B')) +
        P(TORSO, '#FB8C1D') + `<g ${NS}>${R(117, 256, 86, 9, 0, '#FFE9C7')}${R(117, 282, 86, 9, 0, '#FFE9C7')}</g>` +
        R(114, 312, 92, 18, 8, '#C9650B') + L('M140 210 Q160 226 180 210') + R(142, 202, 36, 12, 6, '#C9650B')) },
    { id: 'coat', cat: 'top', ar: 'جاكيت شتوي', en: 'Winter coat', fem: false, pl: false,
      svg: G(arms(() => R(-22, -16, 44, 124, 20, '#7B61D9') + R(-22, 92, 44, 16, 8, '#5B43B8')) +
        P('M104 250 Q104 210 146 208 H174 Q216 210 216 250 V324 Q216 338 200 338 H120 Q104 338 104 324 Z', '#7B61D9') +
        L('M160 214 V338') + L('M106 252 Q160 262 214 252', 3) + L('M106 284 Q160 294 214 284', 3) + L('M106 316 Q160 326 214 316', 3) +
        R(134, 198, 52, 20, 10, '#5B43B8') + C(160, 244, 5, '#FFD43B')) },
    { id: 'raincoat', cat: 'top', ar: 'معطف مطر', en: 'Raincoat', fem: false, pl: false,
      svg: G(arms(() => R(-20, -16, 40, 122, 16, '#FFD43B') + R(-20, 92, 40, 14, 7, '#E0B000')) +
        P('M110 250 Q110 210 148 208 H172 Q210 210 210 250 L222 334 Q222 346 208 346 H112 Q98 346 98 334 Z', '#FFD43B') +
        P('M116 224 Q118 192 160 188 Q202 192 204 224 Q160 214 116 224 Z', '#E0B000') +
        L('M160 216 V346') + C(160, 252, 5, '#fff') + C(160, 284, 5, '#fff') + C(160, 316, 5, '#fff') + L('M122 300 H146 M174 300 H198', 3)) },

    /* ===== تحت (على الرجلين) ===== */
    { id: 'pants', cat: 'bottom', ar: 'بنطلون', en: 'Pants', fem: false, pl: true,
      svg: G(P('M116 316 H204 V430 H164 V358 H156 V430 H116 Z', '#2F6FE0') + R(116, 316, 88, 14, 5, '#2455B0') +
        L('M116 420 H156 M164 420 H204', 3) + L('M126 334 Q136 344 148 336', 3) + L('M172 336 Q184 344 194 334', 3)) },
    { id: 'shorts', cat: 'bottom', ar: 'شورت', en: 'Shorts', fem: false, pl: true,
      svg: G(P('M116 316 H204 V374 H164 V358 H156 V374 H116 Z', '#F7B538') + R(116, 316, 88, 14, 5, '#D9921A') + L('M126 334 Q136 344 148 336', 3)) },
    { id: 'skirt', cat: 'bottom', ar: 'جيبة', en: 'Skirt', fem: true, pl: false,
      svg: G(P('M118 316 H202 L228 380 Q205 392 182 382 Q160 394 138 382 Q115 392 92 380 Z', '#FF86B5') + R(116, 316, 88, 14, 5, '#E0568F') +
        L('M140 332 L128 380 M160 332 V386 M180 332 L192 380', 3)) },

    /* ===== حذاء (في القدمين) ===== */
    { id: 'sneakers', cat: 'shoes', ar: 'كوتشي', en: 'Sneakers', fem: false, pl: true,
      svg: G(both(() => P('M100 438 Q100 416 128 414 H150 Q166 414 166 436 V448 Q166 462 150 462 H116 Q100 462 100 448 Z', '#fff') +
        P('M100 450 H166 V454 Q166 462 150 462 H116 Q100 462 100 454 Z', '#E8453C') +
        L('M122 422 H146 M120 430 H148', 3) + P('M100 438 Q100 424 112 420 L112 446 Q100 446 100 438 Z', '#E8453C', NS))) },
    { id: 'rainboots', cat: 'shoes', ar: 'جزمة مطر', en: 'Rain boots', fem: true, pl: true,
      svg: G(both(() => R(120, 376, 40, 70, 8, '#2FA84F') + E(138, 448, 33, 17, '#2FA84F') + R(116, 372, 48, 12, 6, '#7BD389') +
        L('M126 392 V430', 3) + E(138, 456, 33, 6, '#1F7A38', NS))) },
    { id: 'winterboots', cat: 'shoes', ar: 'بوت شتوي', en: 'Winter boots', fem: false, pl: true,
      svg: G(both(() => R(120, 392, 40, 54, 8, '#9A6234') + E(138, 448, 33, 17, '#9A6234') + R(112, 380, 56, 20, 10, '#fff') +
        L('M128 408 H148 M128 420 H148 M128 432 H148', 3))) },

    /* ===== زيادة (نضارة / كوفية / جوانتي) ===== */
    { id: 'sunglasses', cat: 'extra', ar: 'نضارة شمس', en: 'Sunglasses', fem: true, pl: true, where: 'eyes',
      svg: G(L('M110 134 L90 132 M210 134 L230 132', 4) + E(132, 136, 25, 19, '#2E2A2B') + E(188, 136, 25, 19, '#2E2A2B') + L('M157 134 Q160 130 163 134', 4) +
        `<g ${NS}>${E(122, 129, 7, 4, 'rgba(255,255,255,.45)', 'transform="rotate(-20 122 129)"')}${E(178, 129, 7, 4, 'rgba(255,255,255,.45)', 'transform="rotate(-20 178 129)"')}</g>`) },
    { id: 'scarf', cat: 'extra', ar: 'كوفية', en: 'Scarf', fem: true, pl: false, where: 'neck',
      svg: G(P('M172 232 L204 238 L214 308 L180 312 Z', '#E8453C') + L('M176 296 L212 292 M178 304 L214 300', 3) +
        P('M116 204 Q160 236 204 204 L210 228 Q160 258 110 228 Z', '#E8453C') + `<g ${NS}>${P('M128 214 L124 236 L134 238 L138 220 Z', '#fff')}${P('M158 224 L156 246 L166 246 L168 224 Z', '#fff')}${P('M188 220 L192 240 L200 236 L196 216 Z', '#fff')}</g>`) },
    { id: 'gloves', cat: 'extra', ar: 'جوانتي', en: 'Gloves', fem: false, pl: true, where: 'hands',
      svg: G(both(() => R(68, 312, 38, 20, 8, '#C9650B') + E(86, 344, 19, 22, '#FB8C1D') + E(104, 336, 8, 12, '#FB8C1D', 'transform="rotate(-24 104 336)"') + L('M74 322 H100', 3))) },
  ];

  /* مكان لبس كل قطعة (بالحرف الجر: بتتحط في جملة "... بيتلبس على الراس") */
  const WHERE = {
    hat: { ar: 'على الراس', en: 'on the head' },
    top: { ar: 'على الجسم', en: 'on the body' },
    bottom: { ar: 'على الرجلين', en: 'on the legs' },
    shoes: { ar: 'في القدمين', en: 'on the feet' },
    eyes: { ar: 'على العينين', en: 'on the eyes' },
    neck: { ar: 'حوالين الرقبة', en: 'around the neck' },
    hands: { ar: 'في الإيدين', en: 'on the hands' },
  };
  items.forEach(it => { it.where = WHERE[it.where || it.cat]; });
  /* حدود كل قطعة (للأيقونة): [x, y, عرض, طول] */
  const VB = {"cap":[80,41,160,88],"sunhat":[24,31,272,93],"beanie":[78,16,164,112],"tshirt":[77,199,165,141],"sweater":[61,194,199,149],"coat":[57,190,206,156],"raincoat":[60,180,201,174],"pants":[108,308,104,130],"shorts":[108,308,104,74],"skirt":[84,308,152,88],"sneakers":[92,406,136,64],"rainboots":[97,364,126,109],"winterboots":[97,372,126,101],"sunglasses":[82,109,156,54],"scarf":[102,196,120,124],"gloves":[59,304,202,70]};
  items.forEach(it => { it.vb = VB[it.id]; });

  /* ---------- مشاهد الخلفية (الألوان الأساسية بتيجي من الـCSS) ---------- */
  const cloud = (x, y, k, fill) => `<path transform="translate(${x} ${y}) scale(${k})" d="M-52 22 C-80 22 -80 -12 -52 -14 C-52 -42 -10 -50 6 -28 C22 -52 64 -40 62 -8 C88 -6 88 22 62 22 Z" fill="${fill}"/>`;
  const hill = (fill, y) => `<path d="M0 ${y} Q80 ${y - 18} 160 ${y - 4} T320 ${y - 8} V470 H0 Z" fill="${fill}"/>`;
  const drops = Array.from({ length: 16 }, (_, i) => {
    const x = 14 + (i * 41) % 300, y = 70 + (i * 53) % 120;
    return `<line class="dr-rain" x1="${x}" y1="${y}" x2="${x - 4}" y2="${y + 15}" style="animation-delay:-${(i * .19).toFixed(2)}s;animation-duration:${(.85 + (i % 3) * .18).toFixed(2)}s"/>`;
  }).join('');
  const flakes = Array.from({ length: 18 }, (_, i) => {
    const x = 10 + (i * 37) % 300, y = 20 + (i * 59) % 200, r = 2 + (i % 3) * 1.1;
    return `<circle class="dr-snow" cx="${x}" cy="${y}" r="${r}" style="animation-delay:-${(i * .55).toFixed(2)}s;animation-duration:${(6 + (i % 4)).toFixed(0)}s"/>`;
  }).join('');
  let rays = '';
  for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6; rays += `<line x1="${f(252 + 44 * Math.cos(a))}" y1="${f(78 + 44 * Math.sin(a))}" x2="${f(252 + 58 * Math.cos(a))}" y2="${f(78 + 58 * Math.sin(a))}"/>`; }
  const scenes = {
    free: `<circle cx="64" cy="96" r="48" fill="rgba(255,255,255,.5)"/><circle cx="268" cy="168" r="36" fill="rgba(255,255,255,.45)"/>` +
      `<g fill="#fff" opacity=".85" stroke="none">${P(star(40, 200, 11, 5), '#fff')}${P(star(284, 74, 9, 4), '#fff')}${P(star(250, 258, 7, 3), '#fff')}</g>` +
      hill('#F4C7A6', 438) + `<ellipse cx="160" cy="458" rx="120" ry="14" fill="#EFB690"/>`,
    sun: `<g stroke="#FFC107" stroke-width="5" stroke-linecap="round">${rays}</g>${C(252, 78, 34, '#FFD43B')}` +
      cloud(76, 76, .9, '#fff') + cloud(212, 168, .6, '#fff') + hill('#7BD389', 432) + hill('#5CC171', 448) +
      `<g stroke="none">${C(34, 446, 7, '#FF86B5')}${C(34, 446, 3, '#FFD43B')}${C(288, 440, 7, '#fff')}${C(288, 440, 3, '#FFD43B')}${C(262, 458, 6, '#FF86B5')}${C(262, 458, 2.5, '#FFD43B')}</g>`,
    rain: cloud(78, 60, 1.15, '#8E9BAE') + cloud(204, 46, 1.25, '#9BA7B8') + cloud(290, 104, .8, '#8794A8') +
      `<g stroke="#5E9BE0" stroke-width="3" stroke-linecap="round">${drops}</g>` + hill('#8FB59A', 436) +
      `<ellipse cx="62" cy="456" rx="38" ry="7" fill="#8FB9E0"/><ellipse cx="262" cy="458" rx="32" ry="6" fill="#8FB9E0"/>`,
    cold: cloud(92, 62, .95, '#fff') + cloud(252, 122, .7, '#fff') +
      `<g fill="#fff" stroke="none">${flakes}</g>` + `<path d="M0 424 Q60 402 120 418 T240 414 T320 416 V470 H0 Z" fill="#fff"/><path d="M0 446 Q90 432 180 446 T320 442 V470 H0 Z" fill="#E4EEF8"/>` +
      `<g stroke="${INK}" stroke-width="3" stroke-linejoin="round">${C(44, 418, 20, '#fff')}${C(44, 390, 14, '#fff')}<path d="M44 390 L62 394 L44 396 Z" fill="#FB8C1D"/></g><g stroke="none">${C(39, 386, 2, INK)}${C(49, 386, 2, INK)}</g>`,
  };

  /* بيركّب بوبو لابس القطع ids (قطعة واحدة لكل مكان: قبعة/فوق/تحت/حذاء — والزيادة (نضارة/كوفية/جوانتي) تتجمع) */
  function compose(ids) {
    const by = cat => items.find(it => it.cat === cat && ids.includes(it.id));
    const one = id => items.find(it => it.id === id && ids.includes(id));
    const top = by('top'), bottom = by('bottom'), shoes = by('shoes'), hat = by('hat');
    const sc = one('scarf'), sg = one('sunglasses'), gl = one('gloves');
    const w = it => (it ? `<g class="dr-it" data-it="${it.id}">${it.svg}</g>` : '');
    return [
      body.shadow, body.legs, body.socks,
      bottom ? w(bottom) : body.baseBottom,
      w(shoes),
      body.arms, body.neck,
      top ? w(top) : body.baseTop,
      w(sc),
      body.head,
      w(sg), w(gl), w(hat),
    ].join('');
  }

  window.DRESSUP_ART = { vb: [0, 0, 320, 470], items, body, WHERE, scenes, compose };
})();
