/* ============================================================
   مولّد جداول الوجبات — 32 عمر × 30 يوم (عربي + English)
   الجداول بتتولد بشكل ثابت (deterministic): نفس العمر ونفس اليوم
   بيطلعوا نفس الجدول دايمًا، مع تنويع مضمون ومفيش أكلة تتكرر
   في نفس اليوم ولا قريب من نفس الوجبة.
   كل النصوص بتطلع {ar, en} والواجهة بتختار حسب اللغة.
   ============================================================ */

/* بذرة عشوائية ثابتة (mulberry32) */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffleWith(arr, seed) {
  const a = [...arr], rng = mulberry32(seed);
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ترتيب الأكلة في كل وجبة: دورة ثابتة لكل (عمر، وجبة) => تنويع بدون تكرار قريب */
const slotOrderCache = new Map();
function slotOrder(m, slotKey, pool) {
  const key = `${m}:${slotKey}:${pool.map(f => f.id).join(',')}`;
  if (!slotOrderCache.has(key)) slotOrderCache.set(key, shuffleWith(pool, m * 131 + slotKey.length * 7 + pool.length));
  return slotOrderCache.get(key);
}

/* كمية الأكل حسب العمر */
function portionFor(m, food) {
  const p = (ar, en) => ({ ar, en });
  if (food.c === 'milk') return food.id === 'milk' ? p('حسب طلب البيبي', 'As baby needs') : p('200-250 مل', '200–250 ml');
  if (food.id === 'bananacake') return p('قطعة صغيرة أو اتنين', 'One small slice or two');
  if (m <= 5) return p('ملعقتين-3 صغيرة (زوّدي تدريجيًا)', '2–3 small spoons (increase gradually)');
  if (m === 6) return p('3-5 ملاعق صغيرة', '3–5 small spoons');
  if (m <= 8) return p('4-6 ملاعق / نص كوب صغير', '4–6 spoons / half a small cup');
  if (m <= 11) return p('نص كوب تقريبًا', 'About half a cup');
  if (m <= 17) return p('طبق طفل صغير', 'A small toddler plate');
  return p('حسب شهية البيبي (طبق طفل كامل تقريبًا)', 'As much as baby wants (almost a full toddler plate)');
}

/* ملاحظة القوام حسب العمر */
function textureFor(m) {
  if (m <= 5) return { ar: 'قوام سايل ناعم جدًا (زي اللبن)', en: 'Very smooth, runny purée (like milk)' };
  if (m === 6) return { ar: 'قوام كريمي ناعم زي الزبادي', en: 'Smooth, creamy purée like yogurt' };
  if (m === 7) return { ar: 'مهروس خشن فيه تكتلات بسيطة', en: 'Mashed with soft little lumps' };
  if (m === 8) return { ar: 'قطع ناعمة صغيرة تمسك بإيده', en: 'Soft pieces baby can grab' };
  if (m <= 11) return { ar: 'قطع ناعمة صغيرة — سيبيه ياكل بإيده', en: 'Small soft pieces — let baby self-feed' };
  if (m <= 17) return { ar: 'أكل عادي مقطع صغير', en: 'Regular food cut small' };
  return { ar: 'أكل عادي مقطع مناسب لعمره', en: 'Regular food cut to size' };
}

/* ترتيب وجبات اليوم — الشهر السابع من غير عشا، ومن سنتين من غير رضاعة الصحيان */
function slotsFor(m, day) {
  return [
    { k: 'wake', label: { ar: 'الصباح الباكر (الصحيان)', en: 'Early morning (waking)' }, time: { ar: '٧:٠٠ ص', en: '7:00 AM' } },
    { k: 'b',   label: { ar: 'الفطار',        en: 'Breakfast' },       time: { ar: '٩:٠٠ ص',  en: '9:00 AM' } },
    { k: 's1',  label: { ar: 'الضحى (قبل القيلولة)', en: 'Mid-morning (before nap)' }, time: { ar: '١١:٣٠ ص', en: '11:30 AM' } },
    { k: 'l',   label: { ar: 'الغدا',         en: 'Lunch' },           time: { ar: '١:٠٠ م',  en: '1:00 PM' } },
    { k: 's2',  label: { ar: 'العصر',         en: 'Afternoon' },       time: { ar: '٤:٠٠ م',  en: '4:00 PM' } },
    { k: 'd',   label: { ar: 'العشا (قبل النوم بساعتين)', en: 'Dinner (2h before bed)' }, time: { ar: '٦:٣٠ م', en: '6:30 PM' } },
    { k: 'bed', label: { ar: 'قبل النوم',     en: 'Bedtime' },         time: { ar: '٨:٠٠ م',  en: '8:00 PM' } },
  ].filter(s => !(m === 7 && s.k === 'd')       /* الشهر السابع: الوجبتين بس من غير عشا — بعدهم رضاعات */
             && !(m >= 24 && s.k === 'wake'));  /* من سنتين: مفيش رضاعة الصحيان — اليوم بيبدأ بالفطار */
}

/* أي وجبة في اليوم دي تبقى أكل صلب وحاجة إيه — منطق التدرج بالعمر واليوم */
function mealTypeFor(m, slotKey, day) {
  if (slotKey === 'wake') return 'milk';                  /* أول حاجة تنشّط البيبي */
  if (slotKey === 'bed') return m < 12 ? 'milk' : 'milkcup';

  if (m === 6) {
    if (slotKey === 'b') return 'food';                   /* وجبة اليوم الوحيدة: الفطار (مخطط مامي) */
    if (slotKey === 's2') return 'water';
    return 'milk';
  }
  if (m === 7) {
    if (slotKey === 'b' || slotKey === 'l') return 'food';
    return 'milk';                                        /* الضحى والعصر رضاعة — ومفيش عشا */
  }
  /* من الثامن: 3 وجبات متكاملة (فطار + غدا + عشا).
     قبل السنة مفيش سناك — الضحى والعصر رضعات. بعد السنة سناك بين الوجبات من قايمة مامي (snackPool) */
  if (m <= 11 && (slotKey === 's1' || slotKey === 's2')) return 'milk';
  return 'food';
}

/* بناء حمّالة الأكلات لكل نوع وجبة (الأكلات المكمّلة زي التوم والبقدونس بتظهر في البدايل بس) */
function poolFor(m, slotKey, forSwap) {
  return FOODS.filter(f => {
    if (f.m > m) return false;
    if (f.side && !forSwap) return false;
    if (typeof foodAllowed === 'function' && !foodAllowed(f)) return false;
    if (slotKey === 'b') return f.s.includes('b');
    if (slotKey === 'l') return f.s.includes('l');
    if (slotKey === 'd') return f.s.includes('d');
    if (slotKey === 's1' || slotKey === 's2') return f.s.includes('s');
    return false;
  });
}


/* ============================================================
   الوجبة الكاملة 🍽️ = نص خضار غير نشوي أو فاكهة + ربع بروتين + ربع نشويات
   مجموعات البدايل (تقسيم مامي): f فاكهة | v خضار غير نشوي | p بروتين (والألبان منه) | s نشويات (والخضار النشوي منها)
   أي أكلة بتتبدل بس بأكلة من نفس مجموعتها
   ============================================================ */
const GROUP_BY_ID = {
  /* الخضار النشوي ← نشويات */
  potato: 's', sweetpotato: 's', carrot: 's', peas: 's', pumpkin: 's', corn: 's', 'm8-corn': 's',
  greenbeans: 's', taro: 's', artichoke: 's', beetroot: 's',
  /* الأفوكادو ← خضار غير نشوي */
  avocado: 'v',
  /* أكلات متخلّطة أو حلويات ← مش بتتبدل بمجموعة */
  bananacake: 'x', smoothie: 'x', mahalabia: 'x', potatodill: 'x',
};
const GROUP_BY_CAT = { fruit: 'f', veg: 'v', grain: 's', protein: 'p', dairy: 'p', snack: 'x', dish: 'x', milk: 'm' };
const roleOf = f => (f && (GROUP_BY_ID[f.id] || GROUP_BY_CAT[f.c])) || 'x';

const ROLE_LABEL = {
  p: { ar: 'بروتين', en: 'Protein' },
  v: { ar: 'خضار', en: 'Veggie' },
  s: { ar: 'نشويات', en: 'Starch' },
  f: { ar: 'فاكهة', en: 'Fruit' },
  d: { ar: 'ألبان', en: 'Dairy' },
};

/* السناك بعد السنة (قايمة مامي): فاكهة، خيار أو طماطم، بسكوت بيتي، شيبسي خضار، كوب لبن + فاكهة،
   دانيت بيتي، آيس كريم بيتي، أو رضعة — وبدايل السناك من نفس القايمة */
const SNACK_IDS = ['cucumber', 'snack-tomato', 'homebiscuit', 'vegchips', 'milkfruit', 'homedanette', 'homeicecream', 'snack-milk'];
const isSnackSlot = k => k === 's1' || k === 's2';
function snackPool(m) {
  return FOODS.filter(f => f.m <= m && (roleOf(f) === 'f' || SNACK_IDS.includes(f.id))
    && (typeof foodAllowed === 'function' ? foodAllowed(f) : true));
}

function poolRole(m, slotKey, role, forSwap) {
  const letter = slotKey === 'b' ? 'b' : slotKey === 'l' ? 'l' : slotKey === 'd' ? 'd' : 's';
  return FOODS.filter(f => f.m <= m && roleOf(f) === role && f.s.includes(letter) && (forSwap || !f.side)
    && (typeof foodAllowed === 'function' ? foodAllowed(f) : true));
}

/* اختيار دوري ثابت لكل (عمر، وجبة، دور، يوم) => تنويع بدون تكرار */
function pickRole(m, day, slotKey, role, used) {
  const ovId = (globalThis.MEAL_OVERRIDES || {})[`${m}-${day}-${slotKey}-${role}`];
  const ov = ovId && FOOD_MAP[ovId];
  /* اختيار المامي بيمشي حتى لو الأكلة اتكررت في وجبة تانية النهارده (زي الوجبات المفردة) — غير كده كان البديل بيتجاهل */
  if (ov && ov.m <= m && roleOf(ov) === role && ov.s.includes(slotKey === 'b' ? 'b' : slotKey === 'l' ? 'l' : slotKey === 'd' ? 'd' : 's')) {
    used.add(ov.id);
    return ov;
  }
  let pool = poolRole(m, slotKey, role).filter(f => !used.has(f.id));
  /* النشويات اتخلصت؟ البطاطس والبطاطا بيشتغلوا نشويات في الوجبة */
  if (!pool.length && role === 's') {
    pool = FOODS.filter(f => ['potato', 'sweetpotato'].includes(f.id) && f.m <= m && !used.has(f.id));
  }
  if (!pool.length) return null;
  const order = shuffleWith(pool, m * 131 + slotKey.length * 7 + day * 3 + role.charCodeAt(0));
  const pick = order[(day - 1) % order.length];
  used.add(pick.id);
  return pick;
}

function buildCombo(m, day, slotKey, usedToday) {
  const plan = slotKey === 'b' ? ['p', 's', 'f'] : ['p', 'v', 's']; /* الفطار كامل برضه: بروتين + نشويات + فاكهة */
  const parts = [];
  for (const role of plan) {
    const food = pickRole(m, day, slotKey, role, usedToday);
    if (food) parts.push({ role, food });
  }
  /* فطار بدون فاكهة متاحة؟ خضار غير نشوي مكانها (نص الطبق) */
  if (slotKey === 'b' && !parts.some(p => p.role === 'f')) {
    const alt = pickRole(m, day, slotKey, 'v', usedToday);
    if (alt) parts.push({ role: 'v', food: alt });
  }
  return parts;
}

/* ============================================================
   🍽️ تنسيق الوجبات على الطريقة المصرية + تباعد التكرار (من الشهر التاسع)
   - كل وجبة (فطار/غدا/عشا) بتتبني بالترتيب: بروتين ← خضار ← نشويات، والاختيار بيراعي اللي بيمشي مع بعض
     (مفيش مكرونة ولا سميد مع الملوخية، والكرنب مع الرز بس، والفول مع العيش…).
   - كل أكلة ليها "وزن" (الفراخ أكتر من المشروم مثلًا) والاختيار بيفضّل اللي بعد عهده بالأكل أطول — فالمكرر بيتباعد
   ============================================================ */
const FAMILY = {
  rice: 'rice', bread: 'bread', oatbread: 'bread', toast: 'bread', pasta: 'pasta', noodles: 'pasta',
  couscous: 'grain', bulgur: 'grain', freekeh: 'grain', quinoa: 'grain', wholewheat: 'grain',
  potato: 'potato', sweetpotato: 'potato',
};
const mkSet = (...a) => new Set(a);
const MEATS = ['chicken', 'beef', 'kofta'];
const EGGS = ['omelet', 'vegomelet', 'eggyolk'];
const DAIRY_P = ['yogurt', 'labneh', 'areesh', 'whitecheese', 'pb'];

/* الخضار: كل خضار بيمشي مع أنهي نشويات (عائلات) ومع أنهي بروتين */
const VEG_STARCH = {
  'm8-molokhia': mkSet('rice', 'bread'), okra: mkSet('rice', 'bread'), spinach: mkSet('rice', 'bread'),
  zucchini: mkSet('rice', 'bread', 'potato'), eggplant: mkSet('rice', 'bread', 'pasta', 'potato'),
  cauliflower: mkSet('rice', 'bread', 'pasta', 'potato'), broccoli: mkSet('rice', 'pasta', 'potato', 'bread', 'grain'),
  bellpepper: mkSet('rice', 'pasta', 'bread', 'potato', 'grain'), cucumber: null, 'snack-tomato': null,
  vegsoup: mkSet('rice', 'bread'),
};
const VEG_PROT = {
  'm8-molokhia': mkSet('chicken', 'beef'), okra: mkSet(...MEATS),
  spinach: mkSet(...MEATS, 'lentil', 'chickpea', 'omelet', 'vegomelet'),
  vegsoup: mkSet('chicken', 'omelet', 'vegomelet'),
  'snack-tomato': mkSet('chicken', 'beef', 'kofta', 'liver', 'foul', 'omelet', 'vegomelet', 'eggyolk', 'yogurt', 'labneh', 'areesh', 'whitecheese', 'pb'),
};
const EGG_VEG = mkSet('cucumber', 'snack-tomato', 'zucchini', 'spinach', 'broccoli', 'cauliflower', 'bellpepper', 'eggplant', 'vegsoup');
const PROT_VEG = {
  foul: mkSet('cucumber', 'snack-tomato', 'eggplant', 'bellpepper'),
  omelet: EGG_VEG, vegomelet: EGG_VEG, eggyolk: EGG_VEG,
  lentil: mkSet('cucumber', 'snack-tomato', 'spinach', 'zucchini', 'cauliflower', 'eggplant'),
  beans: mkSet('cucumber', 'snack-tomato'), chickpea: mkSet('cucumber', 'snack-tomato', 'spinach'),
  liver: mkSet('cucumber', 'snack-tomato', 'bellpepper', 'spinach'),
  fish: mkSet('cucumber'), localsweet: mkSet('cucumber'), shrimp: mkSet('cucumber'),      /* قرار مامي: السمك والجمبري بخيار */
};
['yogurt', 'labneh', 'areesh', 'whitecheese', 'pb'].forEach(k => { PROT_VEG[k] = mkSet('cucumber', 'snack-tomato'); });
/* البروتين: بيمشي مع أنهي نشويات (الشوربات والبقوليات برز أو عيش بس) */
const PROT_STARCH = {
  chicken: mkSet('rice', 'pasta', 'bread', 'potato', 'grain'), beef: mkSet('rice', 'bread', 'potato', 'pasta', 'grain'),
  kofta: mkSet('rice', 'potato', 'bread', 'pasta', 'grain'), liver: mkSet('rice', 'bread', 'potato'),
  lentil: mkSet('rice', 'bread'), beans: mkSet('rice', 'bread'), chickpea: mkSet('rice', 'bread'),
  foul: mkSet('bread'),
  omelet: mkSet('bread', 'potato'), vegomelet: mkSet('bread', 'potato'), eggyolk: mkSet('bread', 'potato'),
  yogurt: mkSet('bread', 'potato'), labneh: mkSet('bread', 'potato'), areesh: mkSet('bread', 'potato'),
  whitecheese: mkSet('bread', 'potato'), pb: mkSet('bread'),
  fish: mkSet('rice'), localsweet: mkSet('rice'), shrimp: mkSet('pasta', 'bread'),          /* قرار مامي */
};
/* الخبز الشوفان والتوست = ساندوتشات: مع الفول والبيض والجبنة والجمبري والكفتة (والفراخ على العشا) بس */
const SANDWICH_OK = mkSet('foul', 'omelet', 'vegomelet', 'eggyolk', 'yogurt', 'labneh', 'areesh', 'whitecheese', 'pb', 'shrimp', 'kofta');
/* وزن تكرار كل أكلة (أكبر = بتتاكل أكتر) */
const PLAN_W = {
  chicken: 3, beef: 2, kofta: 2, fish: .6, localsweet: .5, shrimp: .4, liver: .5, lentil: .9, beans: .7, chickpea: .6,
  foul: .8, omelet: 1.2, vegomelet: 1.1, eggyolk: .5, yogurt: 1.2, labneh: .5, areesh: .8, whitecheese: .8, pb: .5,
  'm8-molokhia': 1.2, okra: 1, spinach: 1, zucchini: 1.2, eggplant: .8, cauliflower: .9, broccoli: 1, bellpepper: .8,
  cucumber: 1.2, 'snack-tomato': .9, vegsoup: .5,
  rice: 2.5, pasta: 2, bread: 1.2, potato: 2.2, sweetpotato: .6, bulgur: .6, freekeh: .6, couscous: .5,
  oatbread: .8, toast: .6,
};
/* اللي مش مصري/مش مألوف مش بيتولّد في الوجبات: الكرنب (بيتاكل محشي بس)، الكرات، المشروم، الشعيرية كنشويات، الكينوا */
const LD_VEG = ['m8-molokhia', 'okra', 'spinach', 'zucchini', 'eggplant', 'cauliflower', 'broccoli', 'bellpepper', 'cucumber', 'snack-tomato', 'vegsoup'];
const LD_STARCH = ['rice', 'pasta', 'bread', 'oatbread', 'toast', 'potato', 'sweetpotato', 'bulgur', 'freekeh', 'couscous'];
/* الفطار: بروتين ← نشويات ← خضار أو فاكهة */
const BF_STARCH = {
  foul: ['bread', 'oatbread', 'toast'],
  omelet: ['bread', 'oatbread', 'toast', 'potato'], vegomelet: ['bread', 'oatbread', 'toast', 'potato'], eggyolk: ['bread', 'oatbread', 'toast', 'potato'],
  yogurt: ['oat', 'wholewheat', 'pancake', 'waffle', 'wheatcereal', 'barleycereal', 'ricecereal'],       /* الزبادي مع الشوفان والوافل مش العيش */
  labneh: ['bread', 'oatbread', 'toast'], areesh: ['bread', 'oatbread', 'toast'], whitecheese: ['bread', 'oatbread', 'toast'],
  pb: ['toast', 'oatbread', 'bread', 'pancake', 'waffle', 'oat'],
};
/* الفاكهة اللي تمشي مع البروتين على الفطار: البيض والفول خضار بس، والجبنة مع تفاح/كمثرى/شمام، والزبادي والزبدة مع كل الفاكهة */
const BF_FRUIT = { foul: [], omelet: [], vegomelet: [], eggyolk: [], labneh: ['apple', 'pear', 'melon'], areesh: ['apple', 'pear', 'melon'], whitecheese: ['apple', 'pear', 'melon'] };
const BF_SAVORY = mkSet('foul', 'omelet', 'vegomelet', 'eggyolk', 'labneh', 'areesh', 'whitecheese');
const BF_VEG = ['cucumber', 'snack-tomato', 'avocado'];
const BF_W = { oat: 1, wholewheat: .5, pancake: .8, waffle: .7, wheatcereal: .4, barleycereal: .3, ricecereal: .3, potato: .6 };

function okVegStarch(v, fam) { const a = VEG_STARCH[v]; return !a || a.has(fam); }
function okVegProt(v, p) { const a = VEG_PROT[v], b = PROT_VEG[p]; return (!a || a.has(p)) && (!b || b.has(v)); }
const LIGHT_VEG = mkSet('cucumber', 'snack-tomato', 'bellpepper');       /* ساندوتش: خيار/طماطم/فلفل بس مش يخنة */
/* الغدا/العشا: البروتين + الخضار + النشويات يمشوا مع بعض (الخبز الشوفان والتوست مع خضار خفيف بس) */
function okTriple(p, v, s) {
  if (!okProtStarch(p, s)) return false;
  if (v && !okVegStarch(v, FAMILY[s] || s)) return false;
  if (v && !okVegProt(v, p)) return false;
  if (v && (s === 'oatbread' || s === 'toast') && !LIGHT_VEG.has(v)) return false;
  if (v === 'snack-tomato' && s === 'pasta') return false;              /* المكرونة بصلصة طماطم — مفيش طماطم تانية جنبها */
  if (v && s === 'sweetpotato' && ['carrot', 'peas', 'beetroot', 'taro', 'artichoke', 'greenbeans'].includes(v)) return false;   /* بطاطا مع خضار نشوي = تكرار نشويات */
  return true;
}
function okProtStarch(p, s) {
  const fam = FAMILY[s] || s, a = PROT_STARCH[p];
  if (a && !a.has(fam)) return false;
  if ((s === 'oatbread' || s === 'toast') && !SANDWICH_OK.has(p) && !(p === 'chicken')) return false;
  if (s === 'toast' && p === 'shrimp') return false;                  /* الجمبري: مكرونة أو عيش أو خبز شوفان (قرار مامي) */
  if (s === 'freekeh' && p !== 'chicken') return false;               /* الفريك بيتطبخ مع الفراخ */
  if ((s === 'bulgur' || s === 'couscous') && !['chicken', 'beef', 'kofta'].includes(p)) return false;
  if (s === 'sweetpotato' && !['chicken', 'kofta', 'beef', 'liver'].includes(p)) return false;
  return true;
}

/* اختيار الأنسب: الأكتر وزنًا والأبعد عهدًا — وبرطوبة صغيرة ثابتة (بدل العشوائية) عشان الأعمار تختلف عن بعض */
const SEAFOOD = mkSet('fish', 'localsweet', 'shrimp');
/* "نفس البروتين": السمك بأنواعه واحد، واللحمة والكفتة واحد، والبيض بأنواعه واحد — الغدا والعشا ميتشابهوش فيه */
const PGROUP = { fish: 'seafood', localsweet: 'seafood', shrimp: 'seafood', beef: 'redmeat', kofta: 'redmeat', omelet: 'egg', vegomelet: 'egg', eggyolk: 'egg' };
const pgroup = id => PGROUP[id] || id;
const gid = id => SEAFOOD.has(id) ? 'seafood' : id;                 /* السمك والجمبري صنف واحد في التباعد */
const NEEDS = { fish: ['rice', 'cucumber'], localsweet: ['rice', 'cucumber'], shrimp: ['cucumber'] };   /* قرار مامي */
function pickBest(cands, last, day, rng, usedToday, avoid) {
  let best = null, bs = -1;
  for (const f of cands) {
    const lo = last[f.id];
    const gap = lo === undefined ? 40 : day - lo;
    let sc = gap * (PLAN_W[f.id] || BF_W[f.id] || 1) * (0.88 + 0.24 * rng());
    const g = gid(f.id), lg = g !== f.id ? last[g] : undefined;        /* سمك قريب (حتى لو نوع تاني) ⇒ نبعّد */
    if (lg !== undefined && day - lg < 3) sc *= 0.08;
    if (usedToday.has(f.id)) sc *= 0.02;
    if (avoid && avoid.has(f.id)) sc *= 0.25;
    if (sc > bs) { bs = sc; best = f; }
  }
  return best;
}

const planCache = new Map();
function planMonth(m) {
  const dairy = globalThis.DIET && globalThis.DIET.dairyFree ? 1 : 0;
  const key = m + '|' + dairy;
  if (planCache.has(key)) return planCache.get(key);
  const okFood = id => { const f = FOOD_MAP[id]; return f && f.m <= m && (typeof foodAllowed !== 'function' || foodAllowed(f)) ? f : null; };
  const last = {}, lastPair = {};
  const days = [];
  for (let day = 1; day <= 30; day++) {
    const rng = mulberry32(m * 7919 + day * 104729);
    const usedToday = new Set(), plan = {};
    let lunchGroup = null, lunchIds = new Set();
    for (const slotKey of ['l', 'd', 'b']) {      /* الغدا والعشا الأول (السمك له شروط)، والفطار بيتكيّف مع الغدا بس */
      /* الفطار والعشا ممكن يتشابهوا أحيانًا — فالفطار بيتجنّب أكلات الغدا بس، مش العشا */
      const parts = slotKey === 'b' ? planBreakfast(m, day, rng, last, lunchIds, okFood, lastPair)
        : planMain(m, day, slotKey, rng, last, usedToday, okFood, lastPair, slotKey === 'd' ? lunchGroup : null);
      plan[slotKey] = parts;
      for (const p of parts) { last[p.food.id] = day; last[gid(p.food.id)] = day; usedToday.add(p.food.id); }
      if (slotKey === 'l') { lunchIds = new Set(parts.map(p => p.food.id)); const lp = parts.find(x => x.role === 'p'); lunchGroup = lp ? pgroup(lp.food.id) : null; }
      const pp = parts.find(x => x.role === 'p'), ss = parts.find(x => x.role === 's');
      if (pp && ss) lastPair[pp.food.id + '|' + ss.food.id] = day;
    }
    days.push(plan);
  }
  planCache.set(key, days);
  return days;
}

function planMain(m, day, slotKey, rng, last, usedToday, okFood, lastPair, notGroup) {
  let prots = poolRole(m, slotKey, 'p').filter(f => f.id !== 'mushroom' && !(EGGS[2] === f.id && m >= 12));
  /* العشا مش بنفس بروتين الغدا (قرار مامي) */
  if (notGroup) { const other = prots.filter(f => pgroup(f.id) !== notGroup); if (other.length) prots = other; }
  if (!prots.length) return [];
  /* بروتين النهارده مش نفس بروتين الوجبة اللي قبلها (usedToday بيتعاقب عليه) */
  const free = prots.filter(f => !(NEEDS[f.id] || []).some(id => usedToday.has(id)));   /* مفيش سمكتين برز/خيار في نفس اليوم */
  /* بروتين ملوش غير خضار واحدة (زي الزبادي: خيار/طماطم) مننقيهوش لو الخضار دي اتاكلت النهارده */
  const viable = (free.length ? free : prots).filter(pr => LD_VEG.some(v => okFood(v) && !usedToday.has(v) && okVegProt(v, pr.id)));
  const p = pickBest(viable.length ? viable : (free.length ? free : prots), last, day, rng, usedToday);
  const stOk = s => s && (slotKey === 'd' || (s.id !== 'oatbread' && s.id !== 'toast') || p.id === 'shrimp');
  /* الخضار اللي ليها نشويات متاحة (متتاكلش النهارده) الأول — عشان الرز والعيش ميتكررش في اليوم */
  const vegFor = sids => LD_VEG.map(okFood).filter(v => v && sids.some(sid => stOk(okFood(sid)) && okTriple(p.id, v.id, sid)));
  let vegs = vegFor(LD_STARCH.filter(sid => !usedToday.has(sid)));
  if (!vegs.length) vegs = vegFor(LD_STARCH);
  const v = vegs.length ? pickBest(vegs, last, day, rng, usedToday) : null;
  const allSt = LD_STARCH.map(okFood).filter(s => stOk(s) && okTriple(p.id, v && v.id, s.id));
  const starches = allSt.some(s => !usedToday.has(s.id)) ? allSt.filter(s => !usedToday.has(s.id)) : allSt;
  /* الأكلة اللي بتتكرر مع نفس البروتين قريب بتتأخر */
  const recent = new Set(starches.filter(s => lastPair[p.id + '|' + s.id] && day - lastPair[p.id + '|' + s.id] < 8).map(s => s.id));
  const s = starches.length ? pickBest(starches, last, day, rng, usedToday, recent) : null;
  const parts = [{ role: 'p', food: p }];
  if (v) parts.push({ role: 'v', food: v });
  if (s) parts.push({ role: 's', food: s });
  return parts;
}

function planBreakfast(m, day, rng, last, usedToday, okFood, lastPair) {
  const prots = poolRole(m, 'b', 'p').filter(f => BF_STARCH[f.id] && !(f.id === 'eggyolk' && m >= 12));
  if (!prots.length) return [];
  const p = pickBest(prots, last, day, rng, usedToday);
  const starches = BF_STARCH[p.id].map(okFood).filter(s => s && !(['ricecereal', 'barleycereal', 'wheatcereal'].includes(s.id) && m >= 15));
  const freshSt = starches.filter(s => !usedToday.has(s.id));          /* العيش/التوست اللي اتاكل النهارده نتجنبه */
  const pool = freshSt.length ? freshSt : starches;
  const recent = new Set(pool.filter(s => lastPair[p.id + '|' + s.id] && day - lastPair[p.id + '|' + s.id] < 8).map(s => s.id));
  const s = pool.length ? pickBest(pool, last, day, rng, usedToday, recent) : null;
  const parts = [{ role: 'p', food: p }];
  if (s) parts.push({ role: 's', food: s });
  /* ثالث الطبق: خضار (للفول والبيض والجبنة أغلب الأيام) أو فاكهة */
  const vegs = (p.id === 'foul' ? ['cucumber', 'snack-tomato'] : BF_VEG).map(okFood).filter(Boolean);   /* الفول: خيار/طماطم بس */
  const okFruit = BF_FRUIT[p.id];                                    /* undefined = كل الفاكهة */
  const fruits = poolRole(m, 'b', 'f').filter(f => (!okFruit || okFruit.includes(f.id)) && !(f.id === 'banana' && s && s.id === 'pancake'));   /* البان كيك موز وشوفان — مفيش موز جنبه */
  const wantVeg = !fruits.length || (BF_SAVORY.has(p.id) && rng() < .6);
  if (wantVeg && vegs.length) parts.push({ role: 'v', food: pickBest(vegs, last, day, rng, usedToday) });
  else if (fruits.length) parts.push({ role: 'f', food: pickBest(fruits, last, day, rng, usedToday) });
  else if (vegs.length) parts.push({ role: 'v', food: pickBest(vegs, last, day, rng, usedToday) });
  return parts;
}

/* خطة اليوم من المخطط الشهري + بدائل المامي (🔄) فوقها */
function plannedParts(m, day, slotKey) {
  const base = (planMonth(m)[day - 1] || {})[slotKey];
  if (!base || !base.length) return null;
  const ovs = globalThis.MEAL_OVERRIDES || {};
  return base.map(({ role, food }) => {
    const ov = FOOD_MAP[ovs[`${m}-${day}-${slotKey}-${role}`]];
    if (ov && ov.m <= m && roleOf(ov) === role && (typeof foodAllowed !== 'function' || foodAllowed(ov))) return { role, food: ov };
    return { role, food };
  });
}

function comboPortion(m) {
  const p = (ar, en) => ({ ar, en });
  if (m <= 8) return p('من كل مكوّن: 2-3 ملاعق صغيرة', 'Of each part: 2–3 small spoons');
  if (m <= 11) return p('من كل مكوّن: نص كوب صغير تقريبًا', 'Of each part: about half a small cup');
  if (m <= 17) return p('من كل مكوّن: ملعقتين-3 كبار', 'Of each part: 2–3 big spoons');
  return p('من كل مكوّن: حسب شهية البيبي', 'Of each part: as baby wants');
}

/* الوجبات اللي بتتحول لتركيبة كاملة حسب العمر */
function isComboSlot(m, slotKey) {
  if (m >= 6 && slotKey === 'l') return true;        /* الوجبة الرئيسية المتكاملة */
  if (m >= 7 && slotKey === 'b') return true;        /* فطار متكامل من 7 شهور */
  if (slotKey === 'd') return m >= 8;                /* السابع: من غير عشا | من الثامن: العشا وجبة متكاملة */
  return false;
}

/* أجزاء وجبة ثابتة من الجدول: بتشيل اللي فيها ألبان لو الفلتر شغال وتبدّلها ببروتين تاني اتجرّب.
   دور كل جزء من مجموعة الأكلة نفسها، وبديل المامي (🔄) بيتطبّق على الجزء برقمه (ovPrefix-رقم الجزء) */
function fixedPartsFrom(specs, newId, ovPrefix, short) {
  const parts = [];
  const taken = new Set();
  const ovs = globalThis.MEAL_OVERRIDES || {};
  specs.forEach(([role, ids, amt, label], idx) => {
    let foods = ids.map(id => FOOD_MAP[id]).filter(f => f && foodAllowed(f));
    if (!foods.length && (role === 'd' || role === 'p')) {
      const alt = ['eggyolk', 'beans', 'liver'].map(id => FOOD_MAP[id]).find(f => f && foodAllowed(f) && !taken.has(f.id));
      if (alt) foods = [alt];
    }
    if (!foods.length) return;
    const ov = ovPrefix && FOOD_MAP[ovs[`${ovPrefix}-${idx}`]];
    if (ov && roleOf(ov) === roleOf(foods[0]) && foodAllowed(ov)) foods = [ov];
    foods.forEach(f => taken.add(f.id));
    const g = roleOf(foods[0]);
    const isNew = !!newId && foods.some(f => (newId instanceof Set ? newId.has(f.id) : f.id === newId));
    parts.push({ role: 'fvps'.includes(g) ? g : role, food: foods[0], foods, idx, isNew,
      amt: (amt != null && typeof PLAN_AMT !== 'undefined' && PLAN_AMT[amt]) || null, short: short || null, label: label || null, orig: ids[0] });
  });
  return parts.length ? parts : null;
}

/* أي وجبة السمك فيها بروتين: النشويات رز بالمرق (والجمبري: مكرونة/عيش/خبز شوفان) والخضار خيار (قرار مامي).
   اللي المامي بدّلته بنفسها (🔄) بنسيبه زي ما هو. ovKey(part) ⇒ مفتاح الاستبدال بتاع الجزء */
const isFishFood = f => !!(f && (f.tags || []).includes('سمك'));
function fishify(parts, ovKey, m, day) {
  if (!parts || !parts.some(p => (p.foods || [p.food]).some(isFishFood))) return parts;
  const ovs = globalThis.MEAL_OVERRIDES || {};
  const cuc = FOOD_MAP.cucumber;
  /* الجمبري: نشويته مكرونة أو عيش أو خبز شوفان (بالتناوب حسب اليوم)، والسمك: رز بالمرق */
  const shrimp = parts.some(p => (p.foods || [p.food]).some(f => f && f.id === 'shrimp'));
  const starches = (shrimp ? ['pasta', 'bread', 'oatbread'] : ['rice']).map(id => FOOD_MAP[id]).filter(f => f && (typeof foodAllowed !== 'function' || foodAllowed(f)));
  const rice = starches.length ? starches[((m || 0) + (day || 0)) % starches.length] : null;
  const done = { s: false, v: false };
  const out = [];
  for (const part of parts) {
    const g = part.role === 's' || part.role === 'v' ? part.role : roleOf(part.food);
    const swappable = (g === 's' && rice) || (g === 'v' && cuc);
    if (!swappable || ovs[ovKey(part)]) { out.push(part); continue; }
    if (done[g]) continue;                       /* باقي النشويات/الخضار بيتشالوا */
    done[g] = true;
    const f = g === 's' ? rice : cuc;
    out.push({ ...part, role: g, food: f, foods: [f], orig: f.id, isNew: false });
  }
  return out;
}

const dayCache = new Map();

/* استرجاع جدول يوم كامل */
function getDay(m, day) {
  const ck = `${m}:${day}`;
  if (dayCache.has(ck)) return dayCache.get(ck);

  const meals = [];
  const usedToday = new Set();
  /* من التاسع: الفطار والغدا والعشا اتحددوا في المخطط الشهري — السناك يتجنّب أكلاتهم */
  if (m >= 9) for (const k of ['b', 'l', 'd']) for (const pt of plannedParts(m, day, k) || []) usedToday.add(pt.food.id);
  const slotNote = m === 7
    ? { ar: '📈 الشهر السابع: وجبتين في اليوم (فطار + غدا) بالكميات اللي في الجدول، ومفيش عشا — بعد الوجبتين رضاعات بس. الصنف الجديد عليه 🆕 أول يوم يظهر فيه — راقبي استجابة البيبي 💛',
        en: '📈 Month seven: TWO meals a day (breakfast + lunch) with the amounts in the plan, and no dinner — just milk feeds after the two meals. A new food is marked 🆕 the first day it appears — watch how baby responds 💛' }
    : m === 8
    ? { ar: '🎉 يوم الشهر الثامن: رضاعة الصحيان → 🍽️ 3 وجبات متكاملة (فطار + غدا + عشا — كل واحدة: خضار/فاكهة + بروتين + نشويات) → ورضعات الضحى والعصر والنوم. مفيش سناك قبل السنة 💛',
        en: '🎉 A day at 8 months: wake milk → 🍽️ THREE complete meals (breakfast + lunch + dinner — each: veg/fruit + protein + starch) → plus mid-morning, afternoon & bedtime milk. No snacks before age one 💛' }
    : m === 6
    ? { ar: '📋 الشهر السادس: وجبة واحدة في اليوم (الفطار) + مية بين الرضعات + رضاعة براحته. الكميات بالمعلقة الصغيرة، وكل يوم مكتوب طريقة التحضير (على البخار / مسلوقة / مشوية). من غير عسل أو ملح أو سكر. لو ظهرت أعراض حساسية وقفي الأكل واسألي الدكتور 💛',
        en: '📋 Month six: ONE meal a day (breakfast) + water between feeds + nursing on demand. Amounts are in small spoons, and each day shows how to cook it (steamed / boiled / roasted). No honey, salt or sugar. If allergy symptoms appear, stop the food and ask your doctor 💛' }
    : null;

  for (const slot of slotsFor(m, day)) {
    let type = mealTypeFor(m, slot.k, day);
    /* الشهر السادس والسابع: وجبات من جدول ثابت (فلتر الألبان بيشيل/يبدّل الأكلة اللي فيها ألبان) */
    const m6row = m === 6 ? MONTH6_BY_DAY[day] : null;
    const m7row = m === 7 ? MONTH7_BY_DAY[day] : null;
    const m8row = m === 8 ? MONTH8_BY_DAY[day] : null;   /* الثامن: الفطار والغدا والعشا من قايمة وجبات مامي */
    let fixedParts = null;
    const ovPrefix = `${m}-${day}-${slot.k}`;
    if (m6row && slot.k === 'b') fixedParts = fixedPartsFrom(m6row.parts, null, ovPrefix, PLAN_SHORT);
    if (m7row && (slot.k === 'b' || slot.k === 'l')) fixedParts = fixedPartsFrom(m7row[slot.k], MONTH7_NEW[`${day}-${slot.k}`], ovPrefix, PLAN_SHORT);
    if (m8row && m8row[slot.k]) fixedParts = fixedPartsFrom(m8row[slot.k], null, ovPrefix);
    if (fixedParts) {
      fixedParts = fishify(fixedParts, p => `${ovPrefix}-${p.idx}`, m, day);
      const lab = m7row ? (slot.k === 'b' ? { ar: 'الوجبة الأولى (الفطار)', en: 'First meal (breakfast)' } : { ar: 'الوجبة التانية (الغدا)', en: 'Second meal (lunch)' }) : slot.label;
      meals.push({ ...slot, label: lab, type: 'combo', parts: fixedParts, fixed: true, portion: (m6row || m7row) ? null : comboPortion(m), note: (m6row && m6row.note) || (m7row && m7row.note && m7row.note.k === slot.k ? m7row.note : null), tags: [...new Set(fixedParts.flatMap(p => p.foods.flatMap(f => f.tags || [])))] });
      continue;
    }
    if (type === 'food' && isComboSlot(m, slot.k)) type = 'combo';

    if (type === 'combo') {
      /* من التاسع: الوجبة من المخطط الشهري (فيه قواعد السمك والجمبري جواه) — قبل كده بنطبّق قاعدة السمك بعد البناء */
      const parts = (m >= 9 && plannedParts(m, day, slot.k)) || fishify(buildCombo(m, day, slot.k, usedToday), p => `${m}-${day}-${slot.k}-${p.role}`, m, day);
      if (parts.length >= 2) {
        meals.push({ ...slot, type, parts, portion: comboPortion(m), tags: [...new Set(parts.flatMap(p => p.food.tags || []))] });
        continue;
      }
      /* لو مفيش مكونات كفاية للتركيبة نرجع لوجبة مفردة */
      type = 'food';
    }

    if (type === 'milk') {
      meals.push({ ...slot, type, food: MILK, portion: portionFor(m, MILK), tags: [] });
      continue;
    }
    if (type === 'water') {
      meals.push({ ...slot, type, food: WATER, portion: { ar: 'رشفات بين الوجبات', en: 'Sips between meals' }, tags: [] });
      continue;
    }
    if (type === 'milkcup') {
      const cup = (globalThis.DIET.dairyFree && typeof MILK_ALT !== 'undefined') ? MILK_ALT : MILKCUP;
      meals.push({ ...slot, type, food: cup, portion: portionFor(m, cup), tags: cup.tags });
      continue;
    }

    const base = isSnackSlot(slot.k) ? snackPool(m) : poolFor(m, slot.k);
    const pool = base.filter(f => !usedToday.has(f.id));
    if (!pool.length) {
      meals.push({ ...slot, type, food: MILK, portion: portionFor(m, MILK), tags: [] });
      continue;
    }
    /* السناك: ترتيب واحد للضحى والعصر مع بعض (من غير تكرار في نفس اليوم ولا في اليوم اللي بعده) —
       كل يوم بياخد خانتين ورا بعض من نفس الدورة، فالأكلة متتكررش إلا بعد ما الدورة كلها تخلص */
    const snack = isSnackSlot(slot.k);
    const order = slotOrder(m, snack ? 'snack' : slot.k, base);
    const start = snack ? (day - 1) * 2 + (slot.k === 's2' ? 1 : 0) : day - 1;
    let pick = null;
    /* لو الأكلة الطبيعية اتاكلت النهارده في وجبة تانية، بنجيب بدالها من نص الدورة التانية (بعيدة عن مكانها الطبيعي) */
    const jump = snack ? Math.floor(order.length / 2) : 0;
    for (let step = 0; step < order.length; step++) {
      const c = order[(start + (step ? jump : 0) + step) % order.length];
      if (!usedToday.has(c.id)) { pick = c; break; }
    }
    if (!pick) pick = pool[(day - 1) % pool.length];

    /* استبدال يدوي من المستخدم (زر البدائل) */
    const SLOT_LETTER = { b: 'b', l: 'l', d: 'd', s1: 's', s2: 's' };
    const ovId = (globalThis.MEAL_OVERRIDES || {})[`${m}-${day}-${slot.k}`];
    const ov = ovId && FOOD_MAP[ovId];
    if (ov && ov.m <= m && (isSnackSlot(slot.k) ? base.includes(ov) : ov.s.includes(SLOT_LETTER[slot.k]))) pick = ov;

    usedToday.add(pick.id);

    meals.push({ ...slot, type, food: pick, portion: portionFor(m, pick), tags: pick.tags || [] });
  }

  const result = { m, day, meals, texture: textureFor(m), note: slotNote };
  dayCache.set(ck, result);
  return result;
}

/* تفريغ الكاش بعد أي تغيير في الاستبدالات */
function invalidateDayCache() { dayCache.clear(); planCache.clear(); }

/* ============================================================
   أسماء و أرقام بالعربي والإنجليزي
   ============================================================ */
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const toAr = n => String(n).replace(/\d/g, d => AR_DIGITS[d]);

function ageLabel(m) {
  const ar = m < 1 ? 'أقل من شهر'
    : m === 1 ? 'شهر'
    : m === 2 ? 'شهرين'
    : m < 12 ? `${toAr(m)} شهور`
    : m === 12 ? 'سنة'
    : m < 24 ? `سنة و ${toAr(m - 12)} ${m - 12 === 1 ? 'شهر' : 'شهور'}`
    : m === 24 ? 'سنتين'
    : m < 36 ? `سنتين و ${toAr(m - 24)} ${m - 24 === 1 ? 'شهر' : 'شهور'}`
    : '٣ سنين';
  const en = m < 1 ? 'under 1 month'
    : m === 1 ? '1 month'
    : m < 12 ? `${m} months`
    : m === 12 ? '1 year'
    : m < 24 ? `1y ${m - 12}m`
    : m === 24 ? '2 years'
    : m < 36 ? `2y ${m - 24}m`
    : '3 years';
  return { ar, en };
}

/* أيقونة كل عمر = إيموجي الأكلة الأكثر تكرارًا في جدوله — مع ضمان التفرّد
   (أول ما يوم بيتبني بيتحسب تلقائيًا، والشهور اللي بعده بتاخد التالي الأكثر شيوعًا) */
const AGE_EMOJI_CACHE = {};
function ageEmoji(m) {
  if (AGE_EMOJI_CACHE[m]) return AGE_EMOJI_CACHE[m];
  if (!AGES.includes(m)) return '🍼';
  /* أعياد الميلاد: السنة والسنتين وال٣ سنين تورتة 🎂 دايمًا */
  if (m === 12 || m === 24 || m === 36) { AGE_EMOJI_CACHE[m] = '🎂'; return '🎂'; }

  const wasDairy = globalThis.DIET && globalThis.DIET.dairyFree;
  if (globalThis.DIET) globalThis.DIET.dairyFree = false; /* الأيقونة ثابتة مهما الفلتر */
  const count = {};
  for (let d = 1; d <= 30; d++) {
    for (const x of getDay(m, d).meals) {
      if (x.type !== 'food' && x.type !== 'combo') continue;
      const foods = x.type === 'combo' ? x.parts.map(p => p.food) : [x.food];
      for (const f of foods) count[f.id] = (count[f.id] || 0) + 1;
    }
  }
  if (globalThis.DIET) globalThis.DIET.dairyFree = wasDairy;
  invalidateDayCache();

  const used = new Set(Object.values(AGE_EMOJI_CACHE));
  const ranked = Object.entries(count).sort((a, b) => b[1] - a[1]);
  let emo = '🍼';
  for (const [id, n] of ranked) {
    const f = FOOD_MAP[id];
    if (f && !used.has(f.e)) { emo = f.e; break; }
  }
  AGE_EMOJI_CACHE[m] = emo;
  return emo;
}

const AGES = Array.from({ length: 31 }, (_, i) => i + 6); /* من اتمام 6 شهور لـ 3 سنين — حسب توصية WHO/AAP */
