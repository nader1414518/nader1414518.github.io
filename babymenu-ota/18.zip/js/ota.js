/* ============================================================
   ☁️ تحديث الكود على الهوا (OTA) — زي Shorebird
   التطبيق بينزّل نسخة الويب الجديدة (HTML/CSS/JS) من GitHub Pages
   من غير ما يعدّي على المتجر، وتشتغل من أول فتحة بعدها.
   - المصدر: https://nader1414518.github.io/babymenu-ota.json
   - النشر: scripts/ota-publish.sh (بيعمل zip لـ www ويرفعه)
   - أمان: لو النسخة الجديدة مارسمتش الصفحة خلال 10 ثواني، المكتبة بترجع للنسخة اللي قبلها لوحدها.
   - تغييرات الكود الأصلي (plugins/أذونات/أيقونات) لسه محتاجة المتجر — الـ OTA للويب بس.
   ============================================================ */
(function () {
  const MANIFEST_URL = 'https://nader1414518.github.io/babymenu-ota.json';
  const WEB_VERSION = window.BB_WEB_VERSION || 0;

  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const Updater = () => (isNative() && window.Capacitor.Plugins.CapacitorUpdater) || null;

  /* نقول للمكتبة إن النسخة شغالة — بس لما الصفحة الرئيسية تترسم فعلًا.
     لو نسخة OTA بايظة ومارسمتش، مش هنبعت الإشارة ⇒ رجوع تلقائي للنسخة السليمة */
  function confirmHealthy(up) {
    let tries = 0;
    const tick = () => {
      const app = document.getElementById('app');
      if (app && app.children.length) {
        up.notifyAppReady().catch(() => {});
        return;
      }
      if (++tries < 40) setTimeout(tick, 200);
    };
    tick();
  }

  async function fetchManifest() {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 6000);
    try {
      const res = await fetch(MANIFEST_URL + '?t=' + Date.now(), { cache: 'no-store', signal: ctrl.signal });
      return res.ok ? await res.json() : null;
    } catch { return null; } finally { clearTimeout(t); }
  }

  let checking = false;
  async function checkForUpdate() {
    const up = Updater();
    if (!up || checking) return;
    checking = true;
    try {
      const m = await fetchManifest();
      if (!m || !m.version || !m.url) return;
      const plat = window.Capacitor.getPlatform();
      const target = parseInt(m.version, 10);
      if (!(target > WEB_VERSION)) return;                       /* شغالين على نفس النسخة أو أحدث */

      /* نسخة الويب دي محتاجة تطبيق أصلي (native build) مش أقل من كده */
      const info = await window.Capacitor.Plugins.App.getInfo();
      const build = parseInt(info && info.build, 10);
      const minNative = m.minNative && m.minNative[plat];
      if (minNative && !(build >= minNative)) return;

      /* اتنزّلت قبل كده؟ */
      const list = (await up.list()).bundles || [];
      let bundle = list.find(b => b.version === String(target) && b.status !== 'error');
      if (!bundle) {
        bundle = await up.download({ url: m.url, version: String(target), checksum: m.checksum || undefined });
      }
      /* immediate: نطبّقها دلوقتي (إعادة تحميل) — غير كده تتطبّق أول ما التطبيق يروح للخلفية */
      if (m.immediate) await up.set({ id: bundle.id });
      else await up.next({ id: bundle.id });

      /* تنضيف النسخ القديمة اللي مش مستخدمة */
      const cur = await up.current();
      for (const b of list) {
        if (b.id !== bundle.id && b.id !== cur.bundle.id && b.id !== 'builtin') up.delete({ id: b.id }).catch(() => {});
      }
    } catch (e) {
      console.warn('[ota]', e && e.message);
    } finally {
      checking = false;
    }
  }

  function start() {
    const up = Updater();
    if (!up) return;
    confirmHealthy(up);
    setTimeout(checkForUpdate, 3000);  /* بعد ما التطبيق يفتح ويستقر */
    try {
      window.Capacitor.Plugins.App.addListener('resume', checkForUpdate);
    } catch {}
  }

  window.BeebyOTA = { check: checkForUpdate, webVersion: WEB_VERSION };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
