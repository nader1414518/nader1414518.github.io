/* ============================================================
   ☁️ تحديث الكود على الهوا (OTA) — زي Shorebird
   التطبيق بينزّل نسخة الويب الجديدة (HTML/CSS/JS) من GitHub Pages
   من غير ما يعدّي على المتجر.
   - المصدر: https://nader1414518.github.io/babymenu-ota.json
   - النشر: scripts/ota-publish.sh (بيعمل zip لـ www ويرفعه)
   - أمان: لو النسخة الجديدة مارسمتش الصفحة خلال 10 ثواني، المكتبة بترجع للنسخة اللي قبلها لوحدها.
   - تغييرات الكود الأصلي (plugins/أذونات/أيقونات) لسه محتاجة المتجر — الـ OTA للويب بس.

   إمتى النسخة الجديدة بتتطبّق؟ (v3)
   - أول ما التطبيق يفتح من الأول، لو فيه نسخة متنزّلة وأحدث ⇒ نطبّقها على طول.
   - رجعت للتطبيق بعد غياب ٣٠ ثانية أو أكتر ⇒ نطبّقها (التطبيق كده كده بيرجع للرئيسية).
   - غير كده: شريط "في تحديث جديد جاهز" بزرار "حدّثي دلوقتي".
   - iOS بس: كمان بتتطبّق لوحدها لما التطبيق يروح للخلفية (next).
     أندرويد لأ — التطبيق في الخلفية على موبايلات حقيقية مكانش بيطبّقها، فبنطبّقها واحنا قدّام المستخدمة.
   ============================================================ */
(function () {
  const MANIFEST_URL = 'https://nader1414518.github.io/babymenu-ota.json';
  const WEB_VERSION = window.BB_WEB_VERSION || 0;
  const AWAY_MS = 30000;

  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const Updater = () => (isNative() && window.Capacitor.Plugins.CapacitorUpdater) || null;
  const plat = () => (window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform()) || 'web';
  const vnum = b => parseInt(b && b.version, 10) || 0;
  const usable = b => b && b.id !== 'builtin' && (b.status === 'pending' || b.status === 'success');

  /* ---------- سجل صغير للتشخيص (آخر 40 حدث) — بيظهر بـ ٥ ضغطات على "رقم التحديث" ---------- */
  const LOG_KEY = 'bb_ota_log';
  function log(msg) {
    try {
      const a = JSON.parse(localStorage.getItem(LOG_KEY) || '[]');
      const d = new Date();
      const t = `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
      a.push(`${t} w${WEB_VERSION} ${msg}`);
      localStorage.setItem(LOG_KEY, JSON.stringify(a.slice(-40)));
    } catch {}
  }

  /* نقول للمكتبة إن النسخة شغالة — بس لما الصفحة الرئيسية تترسم فعلًا.
     لو نسخة OTA بايظة ومارسمتش، مش هنبعت الإشارة ⇒ رجوع تلقائي للنسخة السليمة */
  function confirmHealthy(up) {
    let tries = 0;
    const tick = () => {
      const app = document.getElementById('app');
      if (app && app.children.length) {
        up.notifyAppReady().catch(() => {});
        return;
      }
      if (++tries < 40) setTimeout(tick, 200);
    };
    tick();
  }

  async function fetchManifest() {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 6000);
    try {
      const res = await fetch(MANIFEST_URL + '?t=' + Date.now(), { cache: 'no-store', signal: ctrl.signal });
      return res.ok ? await res.json() : null;
    } catch { return null; } finally { clearTimeout(t); }
  }

  /* أحدث نسخة متنزّلة وسليمة وأحدث من اللي شغالة دلوقتي */
  async function readyBundle(up) {
    const list = (await up.list()).bundles || [];
    let best = null;
    for (const b of list) {
      if (usable(b) && vnum(b) > WEB_VERSION && (!best || vnum(b) > vnum(best))) best = b;
    }
    return best;
  }

  /* مش وقت إعادة تحميل؟ (إعلان شغال/لسه مقفول، منتقي صور، أو فتحت من إشعار بيودّي لصفحة) */
  function busy() {
    const now = Date.now();
    return !!(window.__AD_ACTIVE ||
      now - (window.__LAST_AD_CLOSE || 0) < 4000 ||
      (window.__PICKER_UNTIL && now < window.__PICKER_UNTIL) ||
      (window.__PUSH_ROUTE_UNTIL && now < window.__PUSH_ROUTE_UNTIL));
  }

  /* ---------- تطبيق نسخة متنزّلة (إعادة تحميل على النسخة الجديدة) ---------- */
  const TRY_KEY = 'bb_ota_try';
  let applying = false;
  async function apply(b, why, force) {
    const up = Updater();
    if (!up || !b || applying) return false;
    /* حماية من اللف: لو جرّبنا نفس النسخة من شوية ولسه على القديمة، مانعيدش لوحدنا (الزرار بس) */
    if (!force) {
      try {
        const t = JSON.parse(localStorage.getItem(TRY_KEY) || 'null');
        if (t && t.id === b.id && Date.now() - t.at < 10 * 60000) { log(`skip-retry ${b.version}`); return false; }
      } catch {}
    }
    try { localStorage.setItem(TRY_KEY, JSON.stringify({ id: b.id, at: Date.now() })); } catch {}
    applying = true;
    log(`apply ${b.version} (${why})`);
    try {
      await up.set({ id: b.id });   /* الصفحة بتتحمّل من جديد على النسخة الجديدة */
      return true;
    } catch (e) {
      applying = false;
      log(`set-fail ${b.version} ${e && e.message}`);
      return false;
    }
  }

  let pending = null;   /* نسخة اتنزّلت ومستنية تتطبّق */

  /* ---------- التحقق من نسخة جديدة وتنزيلها ---------- */
  let checking = false;
  async function checkForUpdate() {
    const up = Updater();
    if (!up || checking) return;
    checking = true;
    try {
      const m = await fetchManifest();
      if (!m || !m.version || !m.url) { log('manifest ✗'); return; }
      const target = parseInt(m.version, 10);
      if (!(target > WEB_VERSION)) return;                       /* شغالين على نفس النسخة أو أحدث */

      /* نسخة الويب دي محتاجة تطبيق أصلي (native build) مش أقل من كده */
      const info = await window.Capacitor.Plugins.App.getInfo();
      const build = parseInt(info && info.build, 10);
      const minNative = m.minNative && m.minNative[plat()];
      if (minNative && !(build >= minNative)) { log(`needs native ${minNative} (have ${build})`); return; }

      /* اتنزّلت قبل كده؟ */
      const list = (await up.list()).bundles || [];
      let bundle = list.find(b => b.version === String(target) && usable(b));
      if (!bundle) {
        log(`download ${target}`);
        bundle = await up.download({ url: m.url, version: String(target), checksum: m.checksum || undefined });
        log(`downloaded ${target}`);
      }
      /* m.immediate بقى للنسخ القديمة بس (ota.js v1/v2 مكانتش بتطبّق في أندرويد غير بيه) — v3 بيتجاهله */
      /* iOS: تتطبّق لوحدها لما التطبيق يروح للخلفية. أندرويد: إحنا اللي بنطبّقها (فتح/رجوع/الزرار) */
      if (plat() === 'ios') await up.next({ id: bundle.id });
      pending = bundle;
      showReady();

      /* تنضيف النسخ القديمة اللي مش مستخدمة */
      const cur = await up.current();
      for (const b of list) {
        if (b.id !== bundle.id && b.id !== cur.bundle.id && b.id !== 'builtin') up.delete({ id: b.id }).catch(() => {});
      }
    } catch (e) {
      log(`err ${e && e.message}`);
      console.warn('[ota]', e && e.message);
    } finally {
      checking = false;
    }
  }

  /* ---------- شريط "في تحديث جديد جاهز" ---------- */
  const isAr = () => document.documentElement.lang !== 'en';
  function showReady() {
    if (document.getElementById('ota-bar')) return;
    const el = document.createElement('div');
    el.id = 'ota-bar';
    el.setAttribute('role', 'status');
    const t = document.createElement('span');
    t.textContent = isAr() ? '✨ في تحديث جديد جاهز' : '✨ A new update is ready';
    const go = document.createElement('button');
    go.type = 'button';
    go.className = 'ota-go';
    go.textContent = isAr() ? 'حدّثي دلوقتي' : 'Update now';
    go.addEventListener('click', async () => {
      go.disabled = true;
      const up = Updater();
      const b = pending || (up && await readyBundle(up).catch(() => null));
      if (!(await apply(b, 'button', true))) go.disabled = false;
    });
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'ota-x';
    x.textContent = '✕';
    x.setAttribute('aria-label', isAr() ? 'بعدين' : 'Later');
    x.addEventListener('click', () => el.remove());
    el.append(t, go, x);
    document.body.appendChild(el);
  }

  /* ---------- فتح التطبيق من الأول ---------- */
  async function onLaunch(up) {
    try {
      const b = await readyBundle(up);
      if (b) {
        if (!busy() && await apply(b, 'launch')) return;
        pending = b;
        showReady();
      }
    } catch (e) { log(`launch-err ${e && e.message}`); }
    setTimeout(checkForUpdate, 300);
  }

  /* ---------- الرجوع للتطبيق ---------- */
  let pausedAt = 0;
  async function onResume() {
    const away = pausedAt ? Date.now() - pausedAt : 0;
    pausedAt = 0;
    const up = Updater();
    if (!up) return;
    if (away >= AWAY_MS) {
      try {
        const b = await readyBundle(up);
        if (b) {
          /* استنّي ثانية ونص: لو راجعة من إعلان/منتقي/إشعار، العلامات بتاعتهم تكون اتسجّلت */
          await new Promise(r => setTimeout(r, 1500));
          if (!busy() && await apply(b, `resume ${Math.round(away / 1000)}s`)) return;
          pending = b;
          showReady();
        }
      } catch (e) { log(`resume-err ${e && e.message}`); }
    }
    checkForUpdate();
  }

  /* ---------- شاشة التشخيص: ٥ ضغطات على "رقم التحديث" تحت الرئيسية ---------- */
  let taps = [];
  async function showDiag() {
    const up = Updater();
    const lines = [`web ${WEB_VERSION} · ${plat()}`];
    try {
      const info = await window.Capacitor.Plugins.App.getInfo();
      lines.push(`app ${info.version} (${info.build})`);
    } catch {}
    if (up) {
      try { const c = await up.current(); lines.push(`current: ${c.bundle.version} ${c.bundle.status} ${c.bundle.id}`); } catch {}
      try { const n = await up.getNextBundle(); lines.push(`next: ${n ? `${n.version} ${n.status}` : '-'}`); } catch {}
      try { const l = (await up.list()).bundles || []; lines.push(`list: ${l.map(b => `${b.version}:${b.status}`).join(', ') || '-'}`); } catch {}
      try { const f = await up.getFailedUpdate(); if (f && f.bundle) lines.push(`failed: ${f.bundle.version}`); } catch {}
    }
    try { lines.push('', ...JSON.parse(localStorage.getItem(LOG_KEY) || '[]').slice(-15)); } catch {}
    alert(lines.join('\n'));
  }
  document.addEventListener('click', e => {
    if (!e.target.closest || !e.target.closest('.app-ver')) return;
    const now = Date.now();
    taps = taps.filter(t => now - t < 3000);
    taps.push(now);
    if (taps.length >= 5) { taps = []; showDiag(); }
  });

  function start() {
    const up = Updater();
    if (!up) return;
    log('open');
    confirmHealthy(up);
    try {
      Promise.resolve(up.addListener('updateFailed', s => log(`rolled back ${s && s.bundle && s.bundle.version}`))).catch(() => {});
      Promise.resolve(up.addListener('downloadFailed', s => log(`download failed ${s && s.version}`))).catch(() => {});
    } catch {}
    setTimeout(() => onLaunch(up), 400);
    try {
      window.Capacitor.Plugins.App.addListener('pause', () => { pausedAt = Date.now(); });
      window.Capacitor.Plugins.App.addListener('resume', onResume);
    } catch {}
  }

  window.BeebyOTA = { check: checkForUpdate, apply: () => apply(pending, 'manual', true), showReady, showDiag, webVersion: WEB_VERSION };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
