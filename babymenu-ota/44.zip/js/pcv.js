/* ============================================================
   🫁 حاسبة جرعات المكورات الرئوية (Prevenar 13) — دالة نقية من غير DOM
   مرجع مبدئي: قواعد CDC للجرعات التعويضية للأطفال الأصحاء (من شهرين لأقل من 17 سنة)
   مش جدول مصري معتمد — لازم مراجعة طبيب الأطفال والنشرة المحلية قبل الاعتماد.

   الدخل : تاريخ الميلاد + تواريخ الجرعات المأخوذة فعليًا + تاريخ النهارده (YYYY-MM-DD)
   الخرج : حالة كل جرعة مسجّلة (محتسبة / غير محتسبة + السبب) + الجرعات المتبقية ومواعيدها

   قواعد الاحتساب (للأصحاء):
   - أقل عمر لأول جرعة: 6 أسابيع. تاريخ مستقبلي أو قبل الميلاد = مش محتسب.
   - جرعة 1 -> 2 : 4 أسابيع لو الأولى قبل 12 شهر، و8 أسابيع لو الأولى من 12 شهر فأكتر.
   - جرعة 2 -> 3 : 4 أسابيع لو التانية قبل 7 شهور والتالتة قبل 12 شهر؛
                   غير كده 8 أسابيع وبعد عمر 12 شهر (جرعة نهائية).
   - جرعة 3 -> 4 : 8 أسابيع وبعد عمر 12 شهر (جرعة نهائية).
   - أي جرعة من عمر 24 شهر فأكتر = الجدول اتكمل.
   - لو أول جرعة من 12 شهر فأكتر: جرعتين (أو جرعة لو من 24 شهر).
   - لو أول جرعة قبل 12 شهر: الجدول بيكتمل بعد 3 جرعات على الأقل، وآخر واحدة بعد عمر 12 شهر.
   التأخير مش بيزوّد جرعات ولا بيرجّع الجدول من الصفر.
   ============================================================ */
(function (root) {
  const DAY = 864e5;
  const MIN_AGE_DAYS = 42;          // 6 أسابيع
  const MAX_DOSES = 6;              // أقصى عدد خانات
  const USUAL_MONTHS = [2, 4, 6, 15]; // المواعيد المعتادة للجرعة 1..4

  const parse = s => { const [y, m, d] = String(s).split('-').map(Number); return new Date(y, m - 1, d); };
  const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  const addMonths = (d, n) => {
    const t = new Date(d.getFullYear(), d.getMonth() + n, 1);
    const last = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
    t.setDate(Math.min(d.getDate(), last));
    return t;
  };
  const diffDays = (a, b) => Math.round((b - a) / DAY);
  const maxD = (a, b) => (a > b ? a : b);

  function analyze(birthIso, dateStrs, todayIso, opts) {
    opts = opts || {};
    const out = { scope: 'ok', doses: [], next: [], complete: false, doctor: [], extra: 0 };
    const B = parse(birthIso);
    const T = parse(todayIso);
    if (!birthIso || isNaN(B) || isNaN(T)) { out.scope = 'nobirth'; return out; }
    if (T < B) { out.scope = 'doctor'; out.doctor.push('birthFuture'); return out; }
    if (opts.risk) { out.scope = 'risk'; return out; }

    const at = m => addMonths(B, m);
    const ageMonths = d => {
      let m = (d.getFullYear() - B.getFullYear()) * 12 + d.getMonth() - B.getMonth();
      if (d.getDate() < B.getDate()) m -= 1;
      return m;
    };

    const isComplete = list => {
      const n = list.length;
      if (!n) return false;
      if (list.some(x => x.date >= at(24))) return true;
      if (list[0].date >= at(12)) return n >= 2;
      return n >= 3 && list[n - 1].date >= at(12);
    };

    // هل الجرعة e بتحقق الشروط بعد الجرعات المحتسبة؟ بترجع null لو سليمة أو {reason,...}
    const check = (valid, e) => {
      const n = valid.length;
      if (!n) return null;
      const gap = diffDays(valid[n - 1].date, e);
      const old = e >= at(12);
      let need;
      if (n === 1) {
        need = valid[0].date < at(12) ? 28 : 56;
      } else if (n === 2) {
        if (old) need = 56;
        else if (valid[1].date >= at(7)) return { reason: 'needs12' };
        else need = 28;
      } else {
        if (!old) return { reason: 'needs12' };
        need = 56;
      }
      return gap < need ? { reason: 'interval', need, gap } : null;
    };

    const entries = (dateStrs || []).slice(0, MAX_DOSES)
      .map((s, slot) => (s ? { slot, iso: s, date: parse(s) } : null))
      .filter(x => x && !isNaN(x.date))
      .sort((a, b) => a.date - b.date || a.slot - b.slot);

    const valid = [];
    let prevIso = null;
    for (const e of entries) {
      const rec = { slot: e.slot, iso: e.iso, date: e.date, ageMonths: ageMonths(e.date), valid: false, reason: null };
      let bad = null;
      if (e.date > T) bad = { reason: 'future' };
      else if (e.date < B) bad = { reason: 'beforeBirth' };
      else if (diffDays(B, e.date) < MIN_AGE_DAYS) bad = { reason: 'minAge' };
      else if (e.iso === prevIso) bad = { reason: 'sameDate' };
      else if (isComplete(valid)) bad = { reason: 'extra' };
      else bad = check(valid, e.date);
      prevIso = e.iso;
      if (bad) Object.assign(rec, bad);
      else { rec.valid = true; valid.push(rec); }
      out.doses.push(rec);
    }

    out.extra = out.doses.filter(d => d.reason === 'extra').length;
    if (out.doses.some(d => !d.valid && d.reason !== 'extra')) out.doctor.push('invalidDose');

    if (T >= at(204)) { out.scope = 'tooOld'; out.doctor.push('tooOld'); out.complete = isComplete(valid); return out; }

    out.complete = isComplete(valid);
    if (out.complete) return out;

    // الجرعات المتبقية: كل جرعة في أبكر ميعاد مسموح (مش قبل النهارده)
    const earliestOf = (list, floor) => {
      const n = list.length;
      let c;
      if (n === 0) c = addDays(B, MIN_AGE_DAYS);
      else if (n === 1) c = addDays(list[0].date, list[0].date < at(12) ? 28 : 56);
      else if (n === 2) {
        const d2 = list[1].date;
        if (d2 >= at(12)) c = addDays(d2, 56);
        else if (d2 >= at(7)) c = maxD(addDays(d2, 56), at(12));
        else {
          c = addDays(d2, 28);
          if (c >= at(12)) c = maxD(addDays(d2, 56), at(12));
        }
      } else c = maxD(addDays(list[n - 1].date, 56), at(12));
      return maxD(c, floor);
    };

    const list = valid.slice();
    let floor = T;
    let guard = 0;
    while (!isComplete(list) && guard++ < MAX_DOSES) {
      const k = list.length;
      const earliest = earliestOf(list, floor);
      const usual = at(USUAL_MONTHS[Math.min(k, USUAL_MONTHS.length - 1)]);
      let status = 'planned';
      if (guard === 1) {
        if (earliest > T) status = 'upcoming';
        else status = T > usual ? 'overdue' : 'due';
      }
      out.next.push({
        number: k + 1, earliest, usual, status,
        lateDays: status === 'overdue' ? diffDays(usual, T) : 0,
        final: false,
      });
      list.push({ date: earliest });
      floor = earliest;
    }
    if (out.next.length) out.next[out.next.length - 1].final = true;
    return out;
  }

  const api = { analyze, parse, iso, addDays, addMonths, diffDays, MAX_DOSES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.PCV = api;
})(typeof window !== 'undefined' ? window : globalThis);
