/* ============================================================
   إعلانات AdMob — بيبي منيو
   ✅ كل المعرّفات حقيقية من حساب pub-3567826294799039 على apps.admob.com
   ============================================================ */
(function () {
  const CONFIG = {
    /* ✅ معرّفات حقيقية من AdMob (حساب pub-3567826294799039) */
    banner: {
      android: 'ca-app-pub-3567826294799039/8395661967', /* 🎯 بانر أندرويد */
      ios: 'ca-app-pub-3567826294799039/2704351589',     /* 🎯 بانر iOS */
    },
    interstitial: {
      android: 'ca-app-pub-3567826294799039/4539131259', /* 🎬 فيديو بيني أندرويد */
      ios: 'ca-app-pub-3567826294799039/8507342603',     /* 🎬 فيديو بيني iOS */
    },
    interstitialEveryMin: 1, /* أقصى إعلان واحد كل دقيقة مهما فتح المستخدم صفحات كتير */
    waitForLoadMs: 10000,    /* أقصى انتظار للتحميل بعد فتح الصفحة قبل الاستسلام */
  };

  const native = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const Admob = native ? (window.Capacitor.Plugins.AdMob || window.Capacitor.Plugins.Admob) : null;
  let ready = false;

  /* 🎯 أحداث الإعلان الرسمية: القفل الحقيقي هو اللي بيطفي الحماية
     (await showInterstitial بيرجع عند العرض مش عند القفل!) */
  function listenAdLifecycle() {
    if (!Admob || !Admob.addListener) return;
    try {
      Admob.addListener('interstitialAdDismissed', () => {
        window.__AD_ACTIVE = false;
        window.__LAST_AD_CLOSE = Date.now();
      });
      Admob.addListener('interstitialAdFailedToShow', () => {
        window.__AD_ACTIVE = false;
        window.__LAST_AD_CLOSE = Date.now();
      });
    } catch (e) {}
  }
  let lastInter = 0;
  let lastInterDay = '';
  const startedAt = Date.now();   /* أول دقيقة من فتح التطبيق مفيش إعلان عند التنقل (جوجل مش بتسمح بإعلان بيني أول ما التطبيق يفتح) */
  const isAidPage = () => /^#\/aid/.test(location.hash || '');   /* إسعافات الطوارئ: مفيش إعلانات أبدًا */

  /* حالة الإعلان البيني:
     - الصفحة الأولى في السيشن بتفتح قبل ما الإعلان يخلص تحميله (ATT + initialize + تحميل)
     - فبنعلّق الصفحة ونعرض أول ما يوصل خلال نافذة قصيرة بدل ما نضيّع الطلب من غير انطباع */
  let interLoaded = false;  /* في إعلان متحمّل وجاهز للعرض */
  let interLoading = false; /* في طلب تحميل شغّال حالًا */
  let pendingDayKey = null; /* صفحة مستنية الإعلان يتحمّل */
  let pendingTimer = null;
  let retryTimer = null;
  let retryCount = 0;

  async function init() {
    console.log('ADS DEBUG: native=' + native + ' Admob=' + !!Admob);
    if (!Admob) return;
    try {
      /* ATT — لازم يظهر الإذن قبل initialize. iOS بيتجاهل الطلب بصمت لو التطبيق
         لسه مش active (أول لحظة بعد الفتح)، فنستنى الصفحة تبقى ظاهرة وبعدين نعيد المحاولة */
      if (window.Capacitor.getPlatform() === 'ios' && Admob.requestTrackingAuthorization) {
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        const status = async () => {
          try { return (await Admob.trackingAuthorizationStatus()).status; } catch (e) { return 'unknown'; }
        };
        for (let i = 0; i < 6 && (await status()) === 'notDetermined'; i++) {
          if (document.visibilityState !== 'visible') {
            await new Promise((r) => document.addEventListener('visibilitychange', r, { once: true }));
          }
          await sleep(1000 + i * 500);
          try { await Admob.requestTrackingAuthorization(); } catch (e) {}
        }
      }
      await Admob.initialize({
        initializeForTesting: false, /* وضع الإنتاج — إعلانات حقيقية */
        maxAdContentRating: 'General',
        tagForChildDirectedTreatment: false,
      });

      /* الأحداث قبل أي تحميل — هي اللي بتحرّك الحالة كلها */
      await Admob.addListener('interstitialAdLoaded', () => {
        interLoaded = true;
        interLoading = false;
        retryCount = 0;
        flushPending();
      });
      await Admob.addListener('interstitialAdFailedToLoad', () => {
        interLoaded = false;
        interLoading = false;
        scheduleReload();
      });
      await Admob.addListener('interstitialAdDismissed', () => {
        interLoaded = false;
        prepareInterstitial();
      });
      await Admob.addListener('interstitialAdFailedToShow', () => {
        interLoaded = false;
        dropPending();
        prepareInterstitial();
      });
      document.addEventListener('visibilitychange', () => { if (ready) flushPending(); });

      ready = true;
      listenAdLifecycle();
      document.body.classList.add('ads-on');
      showBanner();
      prepareInterstitial();
      flushPending(); /* صفحة ممكن تكون فتحت قبل ما التهيئة تخلص */
    } catch (e) {
      /* أوفلاين أو خطأ — التطبيق يشتغل عادي من غير إعلان */
      /* لو مفيش نت أو حصل خطأ — التطبيق شغال عادي من غير إعلان */
    }
  }

  async function showBanner() {
    return; /* البانر اتلغى — الإعلان البيني بس شغال */
  }
  async function _showBanner() {
    if (!ready) return;
    try {
      const platform = window.Capacitor.getPlatform();
      await Admob.showBanner({
        adId: CONFIG.banner[platform] || CONFIG.banner.android,
        adSize: 'ADAPTIVE_BANNER',
        position: 'BOTTOM_CENTER',
      });
    } catch (e) {
    }
  }

  async function prepareInterstitial() {
    if (!ready || interLoading || interLoaded) return;
    interLoading = true;
    try {
      const platform = window.Capacitor.getPlatform();
      await Admob.prepareInterstitial({
        adId: CONFIG.interstitial[platform] || CONFIG.interstitial.android,
      });
      interLoaded = true; /* الـ resolve بيحصل بس بعد التحميل يخلص */
      interLoading = false;
      retryCount = 0;
      flushPending();
    } catch (e) {
      interLoading = false;
      scheduleReload();
    }
  }

  /* إعادة تحميل متدرّجة بعد فشل (مفيش فل / نت ضعيف) — 5ث ثم 10ث ثم 20ث بحد أقصى 30ث
     عشان السيشن ما تفضلش كاملة من غير إعلان جاهز */
  function scheduleReload() {
    if (retryTimer || !ready) return;
    const delay = Math.min(30000, 5000 * Math.pow(2, retryCount++));
    retryTimer = setTimeout(() => { retryTimer = null; prepareInterstitial(); }, delay);
  }

  function dropPending() {
    pendingDayKey = null;
    clearTimeout(pendingTimer);
  }

  function flushPending() {
    if (!pendingDayKey || !interLoaded) return;
    if (isAidPage()) { dropPending(); return; } /* لو المستخدم راح على الإسعافات قبل ما الإعلان يتحمّل */
    if (document.visibilityState !== 'visible') return; /* مؤقت النافذة هيعمل الاستسلام لو التطبيق مقفول */
    if (Date.now() - lastInter > CONFIG.interstitialEveryMin * 60000 + 5000) { dropPending(); return; } /* طلب قديم عدّى وقته */
    showInterstitialNow();
  }

  async function showInterstitialNow() {
    dropPending();
    interLoaded = false;
    window.__AD_ACTIVE = true;        /* يفضل شغال — حدث القفل الرسمي هو اللي يطفيه */
    try {
      await Admob.showInterstitial();
    } catch (e) {
      window.__AD_ACTIVE = false;
      window.__LAST_AD_CLOSE = Date.now();
    }
    /* مهلة أمان: لو حدث القفل ماوصلش لمدة 60 ثانية نطفي احتياطيًا */
    setTimeout(() => {
      if (window.__AD_ACTIVE) { window.__AD_ACTIVE = false; window.__LAST_AD_CLOSE = Date.now(); }
    }, 60000);
    /* حدث الإغلاق هو اللي بيعيد التحميل عادة — ده احتياطي لو الحدث ما وصّلش */
    setTimeout(prepareInterstitial, 1500);
  }

  /* إعلان فيديو بيني عند فتح صفحة يوم أو قائمة التسوق
     (بيحصل إعادة عرض لو نفس الصفحة اتعادت رسمها — تعليم وجبة مثلًا — من غير إعلان جديد)
     لو الإعلان لسه بيتحمّل (أو التهيئة لسه شغّالة بسبب إذن ATT في أول تشغيل)
     بنعلّق الصفحة ونعرضه أول ما يوصل خلال waitForLoadMs */
  function maybeInterstitial(dayKey) {
    if (dayKey === lastInterDay) return;
    if (CONFIG.interstitialEveryMin > 0 && Date.now() - lastInter < CONFIG.interstitialEveryMin * 60000) return;
    lastInter = Date.now();
    lastInterDay = dayKey;
    if (ready && interLoaded) {
      showInterstitialNow();
    } else {
      pendingDayKey = dayKey;
      clearTimeout(pendingTimer);
      pendingTimer = setTimeout(dropPending, CONFIG.waitForLoadMs);
      prepareInterstitial();
    }
  }

  /* إعلان عند الانتقال لأي صفحة (فوق إعلان صفحات الأيام والتسوق):
     بحد أقصى مرة كل دقيقة (interstitialEveryMin)، وعند تغيير الصفحة بس — مش وهو بيقرا في نفس الصفحة،
     ومش في أول دقيقة من فتح التطبيق، ومش في صفحة إسعافات الطوارئ */
  function onNavigate(hash) {
    if (isAidPage()) return;
    if (Date.now() - startedAt < CONFIG.interstitialEveryMin * 60000) return;
    maybeInterstitial('nav:' + (hash || '#/'));
  }

  window.BeebyAds = { init, showBanner, maybeInterstitial, onNavigate };
  init();
})();
