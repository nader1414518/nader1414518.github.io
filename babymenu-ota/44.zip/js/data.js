/* ============================================================
   بيبي منيو 🍼 — قاعدة بيانات الأكلات (عربي + English)
   كل أكلة: الاسم، الإيموجي (صورة الوجبة)، التصنيف، أقل عمر مناسب،
   الوجبات المناسبة ليها، المكونات، طريقة التحضير، ومحتويات الحساسية.
   s: b=فطار/breakfast, l=غدا/lunch, d=عشا/dinner, s=سناك/snack
   ============================================================ */

/* [lightPair, darkPair] لكل تصنيف */
const CAT_COLORS = {
  fruit:  [['#FFE0E9', '#FFF3D6'], ['#4A2836', '#443122']],
  veg:    [['#E1F5DE', '#F0FFE9'], ['#253A28', '#2C3E22']],
  grain:  [['#FFF0D2', '#FFE6BC'], ['#43321A', '#402D1C']],
  protein:[['#FFE2D2', '#FFD4C4'], ['#44291D', '#402E24']],
  dairy:  [['#DFEDFF', '#EAF6FF'], ['#22304A', '#263A45']],
  snack:  [['#EEE2FF', '#FFE6F2'], ['#372A4A', '#402A38']],
  dish:   [['#FFE7D0', '#FFF4DE'], ['#452E1B', '#443420']],
  milk:   [['#E4EFFE', '#F3F8FF'], ['#243448', '#2A3A4A']],
};

/* لوحة ألوان كروت الأعمار [light, dark] */
const AGE_PALETTES = [
  ['#FFE1D6', '#FFE7EF', '#FFF3D6', '#E3F4DE', '#E4EEFF', '#EFE4FF', '#FFE4E4', '#E0F5F1'],
  ['#4A332A', '#462A33', '#46401F', '#28402C', '#28374A', '#362B4A', '#462B2B', '#24403A'],
];

const ALLERGEN_LABEL = {
  'ألبان':   { ar: '🥛 ألبان',   en: '🥛 Dairy' },
  'بيض':    { ar: '🥚 بيض',    en: '🥚 Egg' },
  'جلوتين':  { ar: '🌾 جلوتين',  en: '🌾 Gluten' },
  'سمك':    { ar: '🐟 سمك',    en: '🐟 Fish' },
  'مكسرات':  { ar: '🥜 مكسرات',  en: '🥜 Nuts' },
};

/* حليب (رضاعة) — بنستخدمه في الفترات اللي مفيهاش أكل صلب */
const MILK = {
  id: 'milk', e: '🍼', c: 'milk', m: 5,
  n: 'رضاعة طبيعية أو حليب صناعي', en_n: 'Breast milk or formula',
  ing: 'حسب طلب البيبي', en_ing: 'As baby needs',
  prep: ['الرضاعة (طبيعية أو صناعي) تفضل هي الأساس في تغذية البيبي قبل السنة.',
         'الأكل الصلب قبل السنة مكمّل مش بديل — كمّلي رضاعة عادي.'],
  en_prep: ['Breast milk or formula stays the base of baby\u2019s nutrition before 12 months.',
            'Solids before one are extra, not a replacement — keep nursing on demand.'],
  tags: [], note: null, en_note: null,
};

const MILKCUP = {
  id: 'milkcup', e: '🥛', c: 'milk', m: 12,
  n: 'كوب حليب بقري كامل الدسم', en_n: 'Cup of whole cow\u2019s milk',
  ing: '200 – 250 مل حليب كامل الدسم', en_ing: '200–250 ml whole milk',
  prep: ['من عمر سنة الحليب البقري العادي يبقى شرابه الأساسي (350–500 مل في اليوم كحد أقصى).',
         'متديشيش حليب بالزبيب أو المنكّه — طبيعي كامل الدسم بس.'],
  en_prep: ['From age one, plain whole cow\u2019s milk becomes the main drink (350–500 ml/day max).',
            'No flavored or sweetened milk — plain whole milk only.'],
  tags: ['ألبان'], note: null, en_note: null,
};

const FOODS = [
/* ================= فواكه / Fruits ================= */
{ id:'apple', e:'🍎', c:'fruit', m:5, s:['b','s','l'],
  n:'تفاح مسلوق مهروس', en_n:'Stewed apple purée', ing:'تفاح أحمر: حبة كبيرة', en_ing:'1 large red apple',
  prep:['قشري التفاح وشيلي القلب والبذور.','اسلقيه في شوية مياه على نار هادية لين يقع تمام.','اهرسيه بالشوكة أو الخلاط لحد ما يبقى ناعم جدًا من غير أي تكتلات.'],
  en_prep:['Peel, core and remove the seeds.','Simmer in a little water over low heat until very soft.','Mash or blend until completely lump-free.'], tags:[] },
{ id:'pear', e:'🍐', c:'fruit', m:5, s:['b','s','l'],
  n:'إجاص (كمثرى) مهروس', en_n:'Pear purée', ing:'إجاص ناضج: حبة', en_ing:'1 ripe pear',
  prep:['قشري الإجاص وشيلي اللي بيوصل للبذور.','اسلقيه أو اتبخريه لين يقع.','اهرسيه كويس لحد قوام الزبادي.'],
  en_prep:['Peel and remove the core.','Boil or steam until soft.','Mash well until yogurt-like.'], tags:[] },
{ id:'banana', e:'🍌', c:'fruit', m:5, s:['b','s'],
  n:'موز مهروس', en_n:'Mashed banana', ing:'موزة ناضجة كويس', en_ing:'1 ripe banana',
  prep:['اهرسي الموزة بالشوكة من غير طبخ.','لو طلع قوامه تقيل، ضيفي شوية لبن أم أو صناعي لحد ما يبقى زي الزبادي.'],
  en_prep:['Mash with a fork — no cooking needed.','If too thick, add a little breast milk or formula until yogurt-like.'],
  tags:[], note:'مش محتاجة طبخ — اختاري موز ناضج من غير خيوط.', en_note:'No cooking needed — pick a soft, ripe banana.' },
{ id:'avocado', e:'🥑', c:'fruit', m:6, s:['b','s'],
  n:'أفوكادو مهروس', en_n:'Avocado mash', ing:'نص حبة أفوكادو ناضج', en_ing:'½ ripe avocado',
  prep:['قطعي الأفوكادو نصين وشيلي النواة والقشرة.','اهرسيه بالشوكة (ده ناعم بطبيعته).','لو عايزاه أخف، خلطيه بشوية موز مهروس.'],
  en_prep:['Halve and remove the pit and skin.','Mash with a fork — naturally smooth.','For a lighter texture, mix with mashed banana.'],
  tags:[], note:'دهب صحية مهمة لمخ البيبي — حطي الباقي في التلاجة مغطي.', en_note:'Healthy fats for baby\u2019s brain — refrigerate the rest covered.' },
{ id:'peach', e:'🍑', c:'fruit', m:6, s:['s','b'],
  n:'خوخ مهروس', en_n:'Peach purée', ing:'خوخة ناضجة', en_ing:'1 ripe peach',
  prep:['اغسلي الخوخة وقطعيها نص.','اتبعخري أو اسلقيها دقيقتين عشان تقشر بسهولة.','اهرسيها بعد ما تبردي شوية.'],
  en_prep:['Wash and halve.','Blanch or boil 2 minutes so the skin slips off.','Mash once slightly cooled.'], tags:[] },
{ id:'mango', e:'🥭', c:'fruit', m:6, s:['s','b'],
  n:'مانجا مهروسة', en_n:'Mango purée', ing:'قطعة مانجا ناضجة', en_ing:'A piece of ripe mango',
  prep:['قشري المانجا وقطعيها مكعبات.','اهرسيها بالشوكة (لو ناضجة هتبقى ناعمة على طول).'],
  en_prep:['Peel and cube.','Mash with a fork — ripe mango is naturally silky.'],
  tags:[], note:'مانجا ناضجة سكرها طبيعي — كمية صغيرة تكفي كسناك.', en_note:'Naturally sweet — a small amount makes a perfect snack.' },
{ id:'watermelon', e:'🍉', c:'fruit', m:6, s:['s'],
  n:'بطيخ مكعبات صغيرة', en_n:'Watermelon cubes', ing:'شريحة بطيخ', en_ing:'A slice of watermelon',
  prep:['قشري البطيخ وقطعيه مكعبات صغيرة من غير بذور.','قدميه في درجة حرارة عادية أو باردة خفيف.'],
  en_prep:['Peel and cube, removing every seed.','Serve at room temperature or slightly chilled.'],
  tags:[], note:'من غير بذور خالص.', en_note:'No seeds at all.' },
{ id:'cantaloupe', e:'🍈', c:'fruit', m:6, s:['s'],
  n:'كنتالوب مقطع', en_n:'Cantaloupe pieces', ing:'شريحة كنتالوب', en_ing:'A slice of cantaloupe',
  prep:['قشريه وشيلي البذور.','قطعيه مكعبات صغيرة ناعمة ينفع البيبي يمسكها بإيده.'],
  en_prep:['Peel and deseed.','Cut into small soft cubes baby can pick up.'], tags:[] },
{ id:'orange', e:'🍊', c:'fruit', m:6, s:['s'],
  n:'يوسفي (برتقال) مقشر', en_n:'Mandarin segments', ing:'يوسفي أو برتقالة', en_ing:'1 mandarin or orange',
  prep:['قشريه كويس وشيلي القشور البيضا والغشاء اللي حوالين الفصوص.','قطعيه قطع صغيرة وقدميه من غير عرق.'],
  en_prep:['Peel well; remove all the white pith and membranes.','Cut into small pieces with no stringy parts.'],
  tags:[], note:'ابدئي بكمية صغيرة — الحمضيات ممكن تعمل احمرار حوالين البق، ده عادي.', en_note:'Start small — citrus can cause mild redness around the mouth, which is normal.' },
{ id:'kiwi', e:'🥝', c:'fruit', m:6, s:['s'],
  n:'كيوي ناضج', en_n:'Ripe kiwi', ing:'حبة كيوي ناضجة', en_ing:'1 ripe kiwi',
  prep:['قشري الكيوي وقطعيه حلقات أو مكعبات صغيرة.'],
  en_prep:['Peel and slice into rounds or small cubes.'],
  tags:[], note:'اختريه ناضج (يلمس بيدك وهو ناعم).', en_note:'Choose one that gives slightly when pressed.' },
{ id:'strawberry', e:'🍓', c:'fruit', m:6, s:['s'],
  n:'فراولة مقطعة', en_n:'Sliced strawberries', ing:'4-5 حبات فراولة', en_ing:'4–5 strawberries',
  prep:['اغسلي الفراولة كويس بمياه وشيلي الورق.','قطعيةها قطع صغيرة أو شرائح رقيقة.'],
  en_prep:['Wash well and remove the tops.','Cut into small pieces or thin slices.'],
  tags:[], note:'قدميها أول مرة الصبح وراقبي أي حساسية.', en_note:'Offer in the morning the first time and watch for reactions.' },
{ id:'cauliflower', e:'🥦', c:'veg', m:6, s:['l','d'],
  n:'قرنبيط مطبوخ مهروس', en_n:'Cauliflower purée', ing:'زهرتين قرنبيط', en_ing:'2 cauliflower florets',
  prep:['اغسلي الزهريات.','اسلقيها أو اتبخريها لين تبقى طرية جدًا.','اهرسيها ناعم أو اتركيها تكتلات صغيرة لو بيمضغ.'],
  en_prep:['Wash the florets.','Boil or steam until very tender.','Mash smooth or leave soft lumps if chewing.'], tags:[] },
{ id:'eggplant', e:'🍆', c:'veg', m:6, s:['l','d'],
  n:'باذنجان مشوي مهروس', en_n:'Roasted eggplant purée', ing:'نصف باذنجان صغير', en_ing:'½ small eggplant',
  prep:['اشوي الباذنجان أو اطبخيه بالبخار لين يقع.','اهرسيه بملعقة زيت زيتون صغيرة.'],
  en_prep:['Roast or steam until collapsed.','Mash with a tiny drizzle of olive oil.'], tags:[] },
{ id:'mushroom', e:'🍄', c:'protein', m:6, s:['l'],
  n:'مشروم مطبوخ مفروم', en_n:'Cooked chopped mushrooms', ing:'3 حبات مشروم', en_ing:'3 mushrooms',
  prep:['اغسلي المشروم وقطعيه صغير.','اطبخيه كويس بالبخار أو في طاسة (من غير زيت تقيل) لين ينضج تمام.','قدميه مفروم أو مضيف للشوربة.'],
  en_prep:['Wash and chop small.','Cook through — steamed or dry pan, no heavy oil.','Serve chopped or blended into soup.'], tags:[] },
{ id:'freekeh', e:'🌾', c:'grain', m:6, s:['l','d'],
  n:'فريك مطبوخ ناعم', en_n:'Freekeh', ing:'3 ملاعق فريك', en_ing:'3 tbsp freekeh',
  prep:['اغسلي الفريك واطبخيه في مية أو مرق خفيف لين يقع تمام.','قدميه لوحده أو مع خضار الوجبة.'],
  en_prep:['Rinse and simmer in water or light broth until very soft.','Serve alone or with the meal’s veggies.'], tags:[] },
{ id:'quinoa', e:'🌾', c:'grain', m:6, s:['l','d'],
  n:'كينوا مطبوخة', en_n:'Quinoa', ing:'3 ملاعق كينوا', en_ing:'3 tbsp quinoa',
  prep:['اغسلي الكينوا كويس.','اطبخيها بنسبة كوب مية لكل نصف كوب كينوا لين تتفتح.','حلوة مع خضار مهروس.'],
  en_prep:['Rinse well.','Simmer 2:1 water to quinoa until the tails pop.','Great mixed into puréed veggies.'], tags:[] },
{ id:'plum', e:'🍑', c:'fruit', m:6, s:['s','b'],
  n:'برقوق مطبوخ مهروس', en_n:'Cooked plum purée', ing:'برقوقتان ناضجتان', en_ing:'2 ripe plums',
  prep:['انزعي النواة.','اسلقي دقيقتين أو اتبخري.','اهرسي ناعم.'],
  en_prep:['Pit them.','Simmer 2 minutes or steam.','Mash smooth.'], tags:[] },
{ id:'persimmon', e:'🍊', c:'fruit', m:6, s:['s','b'],
  n:'كاكا ناضجة مهروسة', en_n:'Ripe persimmon purée', ing:'نصف كاكا ناضجة جدًا', en_ing:'½ very ripe persimmon',
  prep:['اختاري الناضجة اللينة جدًا.','اهرسيها بالشوكة من غير طبخ.'],
  en_prep:['Pick a very soft ripe one.','Mash with a fork — no cooking needed.'],
  tags:[], note:'لازم تكون ناضجة تمامًا — القابطة طعمها قابض وبتزعّج البيبي.', en_note:'Must be fully ripe — firm ones are astringent and unpleasant.' },
{ id:'berries', e:'🫐', c:'fruit', m:8, s:['s','b'],
  n:'توت أزرق مهروس', en_n:'Mashed blueberries', ing:'حبات توت أزرق', en_ing:'A handful of blueberries',
  prep:['اغسلي التوت كويس.','اهرسيه بالشوكة أو اتركيه حبات طرية لو بياكل بأصابعه.'],
  en_prep:['Rinse well.','Mash with a fork, or serve whole soft berries for finger food.'],
  tags:[], note:'غني بمضادات الأكسدة — لون البنفسجي الطبيعي عادي في الحفاض 😄', en_note:'Antioxidant-rich — purple diapers are normal 😄' },
{ id:'pineapple', e:'🍍', c:'fruit', m:8, s:['s'],
  n:'أناناس ناضج مهروس', en_n:'Ripe pineapple purée', ing:'قطعة أناناس ناضجة', en_ing:'A piece of ripe pineapple',
  prep:['اختاري الناضج الحلو.','اهرسيه ناعم أو قطعيه أصابع طرية.'],
  en_prep:['Pick a sweet ripe one.','Mash smooth or cut soft fingers.'],
  tags:[], note:'الحمضي ممكن يهرش منطقة الحفاض — كميات صغيرة في البداية.', en_note:'Acidity may irritate the diaper area — start small.' },
{ id:'localsweet', e:'🐟', c:'protein', m:8, s:['l','d'],
  n:'بلطي/سمك بلدي مسلوق مهروس', en_n:'Local tilapia purée', ing:'فيليه بلطي صغير', en_ing:'A small tilapia fillet',
  prep:['اسلقي الفيليه كويس.','افحصي الشوك حبة حبة — بلدي بغني بالشوك الصغير.','اهرسيه بالخضار أو لوحده.'],
  en_prep:['Poach the fillet through.','Check bone by bone — local fish has tiny bones.','Mash with veggies or alone.'],
  tags:['سمك'], note:'سمك بلدي غني بأوميغا 3 — الشوك هو التحدي الوحيد.', en_note:'Local fish is omega-3 rich — bones are the only challenge.' },
{ id:'shrimp', e:'🦐', c:'protein', m:8, s:['l'],
  n:'جمبري مجروش', en_n:'Crushed shrimp', ing:'3 حبات جمبري صغيرة', en_ing:'3 small shrimp',
  prep:['اسلقي الجمبري كويس وقشريه بالكامل.','اطحنيه أو اهرسيه مجروش مع الخضار.'],
  en_prep:['Boil through and peel completely.','Crush or chop into veggies.'],
  tags:['سمك'], note:'من القشريات — أول مرة كمية صغيرة جدًا وراقبي أي حساسية.', en_note:'Shellfish — first time tiny amount, watch closely.' },
{ id:'oatbread', e:'🍞', c:'grain', m:8, s:['b','s','d'],
  n:'خبز شوفان / توست', en_n:'Oat bread / toast', ing:'شريحة خبز شوفان أو توست', en_ing:'A slice of oat bread or toast',
  prep:['قطعيه أصابع طرية من غير القشرة الصلبة.','ممكن غمسه في زبادي أو أفوكادو.'],
  en_prep:['Cut soft fingers, no hard crust.','Nice dipped in yogurt or avocado.'],
  tags:['جلوتين'], note:'مثالي لأكل الأصابع — بيتحمل البيبي يمضغه براحته.', en_note:'Perfect for self-feeding — easy to gum and chew.' },
{ id:'guava', e:'🍏', c:'fruit', m:6, s:['s','b'],
  n:'جوافة مطبوخة مهروسة', en_n:'Cooked guava purée', ing:'جوافة ناضجة: حبة', en_ing:'1 ripe guava',
  prep:['قشري الجوافة وشيلي البذور.','اسلقيها أو اتبخريها دقيقتين لين تلين.','اهرسيها ناعم.'],
  en_prep:['Peel and remove the seeds.','Steam or simmer 2 minutes until soft.','Mash smooth.'],
  tags:[], note:'غنية بفيتامين C — بتساعد امتصاص الحديد.', en_note:'Rich in vitamin C — helps iron absorption.' },
{ id:'pomegranate', e:'🍎', c:'fruit', m:12, s:['s'],
  n:'رمان حبوب', en_n:'Pomegranate seeds', ing:'نصف رمانة', en_ing:'½ pomegranate',
  prep:['فصلي الحبوب واتأكدي إنها نضيفة.','قدميها حبوب صغيرة ينفع يمسكها.'],
  en_prep:['Remove the seeds and rinse well.','Serve as tiny pick-up seeds.'],
  tags:[], note:'الحبوب صغيرة فبتذوب في البق — قدميها تحت المراقبة.', en_note:'Seeds are tiny — serve supervised.' },
{ id:'quince', e:'🍈', c:'fruit', m:9, s:['s','b'],
  n:'سفرجل مسلوق مهروس', en_n:'Cooked quince purée', ing:'سفرجلة', en_ing:'1 quince',
  prep:['قشري السفرجل وقطعيه وشيلي البذور.','اسلقيه بمياه و شوية سكر نباتي؟ لأ — من غير سكر، لين يقع تمام.','اهرسيه ناعم.'],
  en_prep:['Peel, core and chop.','Simmer in plain water until very soft.','Mash smooth.'],
  tags:[], note:'قاسيه نيء ولازم سلق كويس.', en_note:'Hard when raw — must be well cooked.' },
{ id:'apricot', e:'🍑', c:'fruit', m:6, s:['s','b'],
  n:'مشمش مطبوخ مهروس', en_n:'Cooked apricot purée', ing:'مشمش ناضج: 3 حبات', en_ing:'3 ripe apricots',
  prep:['اغسلي المشمش وقطعيه نصين وشيلي النواة.','اسلقيه دقيقتين أو اتبخريه.','اهرسيه ناعم.'],
  en_prep:['Wash, halve and pit.','Simmer 2 minutes or steam.','Mash smooth.'],
  tags:[], note:'من أغنى الفواكه بفيتامين A.', en_note:'One of the richest fruit sources of vitamin A.' },
{ id:'bellpepper', e:'🫑', c:'veg', m:6, s:['l','d'],
  n:'فلفل رومي مطبوخ', en_n:'Cooked bell pepper', ing:'نصف فلفلة ملونة', en_ing:'½ bell pepper',
  prep:['شيلي البذور والغطاء.','اطبخيه بالبخار أو في شوربة لين يبقى طري جدًا.','قطعيه شرائح رقيقة أو اهرسيه مع الشوربة.'],
  en_prep:['Desseed and core.','Steam or simmer in soup until very tender.','Slice thin or blend into the soup.'],
  tags:[], note:'فيتامين C عالي — رفيق الحديد المثالي.', en_note:'High vitamin C — iron’s best friend.' },
{ id:'grapes', e:'🍇', c:'fruit', m:6, s:['s'],
  n:'عنب مقطع أرباع', en_n:'Quartered grapes', ing:'5-6 حبات عنب', en_ing:'5–6 grapes',
  prep:['اغسلي العنب كويس.','اقطعي كل حبة 4 قطع طولية رقيقة — أبداً حبة كاملة.'],
  en_prep:['Wash well.','Quarter each grape lengthwise — never serve whole.'],
  tags:[], note:'⚠️ العنب الكامل من أخطر أسباب الاختناق عند الأطفال — دايمًا أرباع رقيقة.', en_note:'⚠️ Whole grapes are a serious choking hazard — always serve quarters.' },

/* ================= خضار / Veggies ================= */
{ id:'carrot', e:'🥕', c:'veg', m:5, s:['b','l'],
  n:'جزر مسلوق مهروس', en_n:'Carrot purée', ing:'جزرتين صغيرات', en_ing:'2 small carrots',
  prep:['اغسلي الجزر وقطعيه حلقات.','اسلقيه في مياه مغطى حوالي 15 دقيقة لين يقع تمام.','اهرسيه بالخلاط — لازم ناعم جدًا من غير أي حبة.'],
  en_prep:['Wash, peel and slice.','Boil covered about 15 minutes until very soft.','Blend until completely lump-free.'],
  tags:[], note:'غني بفيتامين A مفيد للنظر والمناعة.', en_note:'Rich in vitamin A for eyesight and immunity.' },
{ id:'potato', e:'🥔', c:'veg', m:5, s:['l','b'],
  n:'بطاطس مهروسة', en_n:'Mashed potatoes', ing:'بطاطسة متوسطة', en_ing:'1 medium potato',
  prep:['قشري البطاطس وقطعيها رباع.','اسلقيها لين توقع.','اهرسيها مع مغرفة من مياه سلقها لحد قوام كريمي.'],
  en_prep:['Peel and quarter.','Boil until soft.','Mash with a spoon of the cooking water until creamy.'], tags:[] },
{ id:'zucchini', e:'🥒', c:'veg', m:5, s:['l','d'],
  n:'كوسة مطبوخة', en_n:'Cooked zucchini', ing:'كوسة صغيرة', en_ing:'1 small zucchini',
  prep:['اغسلي الكوسة وقشريها وقطعيها.','اسلقيها أو اتبخريها لين توقع (10 دقايق تقريبًا).','اهرسيها بالشوكة أو الخلاط.'],
  en_prep:['Wash, peel and slice.','Boil or steam about 10 minutes until soft.','Mash or blend.'],
  tags:[], note:'خفيفة على المعدة — مناسبة جدًا للأيام اللي الببي معده مش مرتاحة.', en_note:'Gentle on the tummy — great for fussy days.' },
{ id:'pumpkin', e:'🎃', c:'veg', m:5, s:['l','b'],
  n:'قرع عسلي (يقطين)', en_n:'Pumpkin purée', ing:'قطعة قرع عسلي', en_ing:'A piece of pumpkin',
  prep:['قشري القرع وقطعيه مكعبات.','اسلقيه أو اتبخريه لين يقع تمام.','اهرسيه — بيبقى ناعم وحلو بطعمه من غير سكر.'],
  en_prep:['Peel and cube.','Boil or steam until very soft.','Mash — naturally sweet, no sugar needed.'], tags:[] },
{ id:'sweetpotato', e:'🍠', c:'veg', m:6, s:['l','b'],
  n:'بطاطا (بطاطس حلوة) مشوية', en_n:'Roasted sweet potato', ing:'بطاطا متوسطة', en_ing:'1 medium sweet potato',
  prep:['اقلفي البطاطا في الفور لين توقع (أو اسلقيها).','قشريها واهرسيها أو قطعيها أصابع ناعمة ينفع يمسكها بنفسه.'],
  en_prep:['Bake until soft (or boil).','Peel, then mash or cut into soft fingers baby can hold.'],
  tags:[], note:'من أحسن أول أكلات — حلوة ومحبوبة عند البيبي.', en_note:'A favorite first food — naturally sweet.' },
{ id:'peas', e:'🫛', c:'veg', m:6, s:['l'],
  n:'بسلة (بازلاء) مهروسة', en_n:'Mashed peas', ing:'نص كوب بسلة (مفرزة أو مجمدة)', en_ing:'½ cup peas (fresh or frozen)',
  prep:['اسلقي البسلة لين توقع تمام (10 دقايق).','اهرسيها بالخلاط كويس وبعدين صفّيها من القشور.'],
  en_prep:['Boil about 10 minutes until very soft.','Blend well, then press through a sieve to remove the skins.'],
  tags:[], note:'غنية بالبروتين النباتي — قشرها صعب الهضم فالتصفية مهمة.', en_note:'Plant protein — the skins are hard to digest, so sieving matters.' },
{ id:'spinach', e:'🥬', c:'veg', m:7, s:['l','d'],
  n:'سبانخ مطبوخة', en_n:'Cooked spinach', ing:'حزمة سبانخ صغيرة', en_ing:'1 small bunch of spinach',
  prep:['اغسلي السبانخ كويس وقطعيها.','اطبخيها مع شوية جزر وبصل لين توقع.','اهرسيها بالخلاط وقدميها مع شوية رز أو عيش.'],
  en_prep:['Wash well and chop.','Cook with a little carrot and onion until soft.','Blend and serve with rice or bread.'],
  tags:[], note:'غنية بالحديد — قدميها مع فاكهة فيها فيتامين C عشان الامتصاص.', en_note:'Iron-rich — serve with a vitamin-C fruit for better absorption.' },
{ id:'broccoli', e:'🥦', c:'veg', m:6, s:['l','d'],
  n:'بروكلي مسلوق (زهريتين)', en_n:'Steamed broccoli florets', ing:'زهريتين بروكلي', en_ing:'2 broccoli florets',
  prep:['اغسلي الزهريات واطبخيها بخار أو مياه لين تبقى طرية جدًا.','قدميها لين على شكلها — تنفع أصابع الأكل الذاتي.'],
  en_prep:['Steam or boil until very tender.','Serve soft as-is — a perfect finger food.'],
  tags:[], note:'القاعدة (الساق) أسهل إن البيبي يمسكها.', en_note:'The stem is the easiest handle for little hands.' },
{ id:'vegsoup', e:'🥣', c:'veg', m:7, s:['l','d'],
  n:'شوربة خضار', en_n:'Vegetable soup', ing:'جزر + كوسة + بطاطس + بصلة صغيرة', en_ing:'Carrot + zucchini + potato + small onion',
  prep:['قطعي الخضار صغيرة واطبخيها في مرق خفيف لين توقع.','اهرسيها بالخلاط حسب عمر البيبي (ناعم أو خشن).','من غير ملح ولا مكعبات مرق.'],
  en_prep:['Chop small and simmer in a light broth until soft.','Blend to the texture for baby\u2019s age (smooth or coarse).','No salt and no stock cubes.'],
  tags:[], note:'طريقة ممتازة لتقديم أكثر من خضار في وجبة واحدة.', en_note:'A great way to serve several veggies at once.' },
{ id:'cucumber', e:'🥒', c:'veg', m:6, s:['s'],
  n:'خيار مقشر شرائح', en_n:'Peeled cucumber sticks', ing:'نص حبة خيار', en_ing:'½ cucumber',
  prep:['قشري الخيار (القشرة صعبة) وقطعيه شرائح رقيقة أو أصابع.'],
  en_prep:['Peel (the skin is tough) and slice into thin sticks.'],
  tags:[], note:'منعش في الصيف — متسيبيهوش كبير عشان الاختناق.', en_note:'Refreshing in summer — keep the pieces small to avoid choking.' },
{ id:'corn', e:'🌽', c:'veg', m:24, s:['s'],
  n:'ذرة مسلوقة', en_n:'Boiled corn', ing:'كوز ذرة', en_ing:'1 corn cob',
  prep:['اسلقي الذرة لين تنضج.','انتر الحب بالسكينة وقطّع كل حبة نصين قبل التقديم.'],
  en_prep:['Boil until cooked.','Cut the kernels off and halve each one before serving.'],
  tags:[], note:'⚠️ حب الذرة الكامل ممكن يسبب اختناق — دايمًا نص حبة لحد ما يكبر.', en_note:'⚠️ Whole kernels can cause choking — always halve until older.' },

/* ================= حبوب ونشويات / Grains ================= */
{ id:'ricecereal', e:'🥣', c:'grain', m:5, s:['b'],
  n:'حبوب أرز مدعمة بالحديد', en_n:'Iron-fortified rice cereal', ing:'3-4 ملاعق حبوب أرز أطفال + لبن أم أو صناعي', en_ing:'3–4 tbsp baby rice cereal + breast milk or formula',
  prep:['حضّريها باللبن الأم أو الصناعي حسب طريقة العلبة.','خليها سايلة شوية في الأول وبعدين كثفي القوام تدريجيًا.'],
  en_prep:['Prepare with breast milk or formula as the box says.','Start runny, then thicken gradually.'],
  tags:[], note:'أفضل بداية: الحديد فيها مهم جدًا بعد 6 شهور.', en_note:'One of the best first foods: iron is exactly what babies need now.' },
{ id:'barleycereal', e:'🌾', c:'grain', m:6, s:['b'],
  n:'حبوب شعير مدعمة بالحديد', en_n:'Iron-fortified barley cereal', ing:'3-4 ملاعق حبوب شعير أطفال + لبن أم أو صناعي', en_ing:'3–4 tbsp baby barley cereal + breast milk or formula',
  prep:['حضّريها باللبن حسب طريقة العلبة.','ابدئي بقوام سايل وكثفي تدريجيًا.'],
  en_prep:['Prepare with milk as the box says.','Start runny and thicken gradually.'],
  tags:['جلوتين'], note:'من الحبوب المدعمة بالحديد الموصى بها رسميًا.', en_note:'One of the officially recommended iron-fortified cereals.' },
{ id:'wheatcereal', e:'🌾', c:'grain', m:6, s:['b'],
  n:'حبوب قمح مدعمة بالحديد', en_n:'Iron-fortified wheat cereal', ing:'3-4 ملاعق حبوب قمح أطفال + لبن أم أو صناعي', en_ing:'3–4 tbsp baby wheat cereal + breast milk or formula',
  prep:['حضّريها باللبن حسب طريقة العلبة.','ابدئي بقوام سايل وكثفي تدريجيًا.'],
  en_prep:['Prepare with milk as the box says.','Start runny and thicken gradually.'],
  tags:['جلوتين'], note:'تدخل تدريجيًا لو فيه حساسية جلوتين في العيلة.', en_note:'Introduce gradually if gluten allergy runs in the family.' },
{ id:'oat', e:'🌾', c:'grain', m:6, s:['b','s'],
  n:'شوفان باللبن (بوريدج)', en_n:'Oat porridge with milk', ing:'3 ملاعق شوفان فاخر + نص كوب لبن الطفل', en_ing:'3 tbsp oats + ½ cup breast milk or formula',
  prep:['اطحني الشوفان في الكتانة لحد ما يبقى ناعم.','اطبخيه بمياه على نار هادية 5 دقايق وبعدين ضيفي لبن الطفل (ومن 8 شهور ينفع لبن عادي في الطبخ).','كثفي أو خففي بالمياه حسب عمر البيبي.'],
  en_prep:['Grind the oats to a fine flour.','Cook in water 5 minutes on low, then stir in breast milk or formula (regular milk is fine in cooking from 8 months).','Adjust thickness with liquid for baby\u2019s age.'],
  tags:[], note:'فيبر ممتاز — ممكن تخلطيه بفواكه مهروسة.', en_note:'Great fiber — mix in fruit purées.' },
{ id:'bread', e:'🫓', c:'grain', m:8, s:['b','s','d'],
  n:'عيش بلدي طرية', en_n:'Soft baladi bread (inner part)', ing:'ربع رغيف عيش بلدي', en_ing:'¼ baladi loaf',
  prep:['شيلي القشرة الصلبة وقدمي الجزء الداخلي الطري قطع صغيرة.','تنفع مغموسة في شوربة أو مهلبية خفيفة.'],
  en_prep:['Remove the hard crust; serve small soft pieces of the inside.','Nice dipped in a light soup.'],
  tags:['جلوتين'], note:'العيش البلدي أساسي عندنا — بس قشرة الصاج صلبة فانتبهي.', en_note:'Baladi crust is tough — inner part only.' },
{ id:'toast', e:'🍞', c:'grain', m:8, s:['b','s','d'],
  n:'توست بالزبدة', en_n:'Buttered toast', ing:'توست + قليل من الزبدة', en_ing:'Toast + a little butter',
  prep:['دهني التوست بطبقة رقيقة من الزبدة.','قطعيه أصابع أو مربعات صغيرة.'],
  en_prep:['Spread a thin layer of butter.','Cut into fingers or small squares.'],
  tags:['جلوتين','ألبان'], note:'الأصابع دي بتحبها البيبي اللي بيبدأ ياكل بإيده. مع حساسية الألبان: زبدة نباتية أو زيت زيتون.', en_note:'Little fingers baby loves to hold. With dairy allergy: plant butter or olive oil.' },
{ id:'pasta', e:'🍝', c:'grain', m:7, s:['l','d'],
  n:'معكرونة صغيرة بالصلصة', en_n:'Little pasta with tomato sauce', ing:'مكرونة أرق صغيرة (أو بجانروس) + طماطم مطبوخة', en_ing:'Small pasta shapes + cooked tomato sauce',
  prep:['اسلقي المكرونة لين تبقى طرية جدًا.','حضّري صلصة طماطم مطبوخة كويس من غير ملح.','اخلطيهم وقطعي المكرونة لو لازمة.'],
  en_prep:['Boil the pasta until very soft.','Make a no-salt cooked tomato sauce.','Mix together and cut the pasta if needed.'],
  tags:['جلوتين'], note:'الطماطم المطبوخة أخف على المعدة من النية.', en_note:'Cooked tomato is gentler on little tummies than raw.' },
{ id:'rice', e:'🍚', c:'grain', m:6, s:['l','d'],
  n:'رز بالمرق (مطبوخ ناعم)', en_n:'Rice with broth', ing:'3 ملاعق رز مطبوخ + مرق خضار خفيف', en_ing:'3 tbsp cooked rice + light vegetable broth',
  prep:['اطبخي الرز لين يقع تمام في شوية مرق خضار من غير ملح (ومن 7 شهور ينفع مرق فراخ أو لحمة).','هرسيه بالشوكة أو سيبيه حبيباته حسب عمر البيبي.'],
  en_prep:['Cook the rice until very soft in unsalted vegetable broth (chicken or meat broth from 7 months).','Mash or serve whole grains depending on age.'], tags:[],
  note:'الأرز الأبيض مناسب بس مش حبوب كاملة — نوّعي بالأرز البني أو البسمتي.', en_note:'White rice is fine but not a whole grain — alternate with brown or basmati rice.' },
{ id:'bulgur', e:'🥘', c:'grain', m:6, s:['l','d'],
  n:'برغل مطبوخ', en_n:'Cooked bulgur', ing:'3 ملاعق برغل ناعم', en_ing:'3 tbsp fine bulgur',
  prep:['اطبخي البرغل في شوية مرق أو مياه لين يقع.','قدميه مع خضار مطبوخة أو زبادي.'],
  en_prep:['Simmer in broth or water until soft.','Serve with cooked veggies or yogurt.'],
  tags:['جلوتين'], note:'غني بالفبر وبطيء الهضم — شبع أكتر من الرز.', en_note:'Fiber-rich and slow to digest — more filling than rice.' },
{ id:'ricecracker', e:'🍘', c:'grain', m:8, s:['s'],
  n:'بسكويت أرز (أصابع)', en_n:'Rice crackers (teething wafers)', ing:'بسكويت أرز للأطفال', en_ing:'Baby rice crackers',
  prep:['قدميه على شكله — البيبي يمسكه ويلعمه بنفسه.'],
  en_prep:['Serve as-is — baby holds it and gums it.'],
  tags:[], note:'حيلة ناجعة وقت التسنين — اختاري نوع مخصص للأطفال من غير سكر.', en_note:'A teething lifesaver — choose no-added-sugar baby kinds.' },
{ id:'pancake', e:'🥞', c:'grain', m:10, s:['b','s'],
  n:'بان كيك موز وشوفان', en_n:'Banana-oat pancakes', ing:'موزة + بيضة + 3 ملاعق شوفان مطحون', en_ing:'1 banana + 1 egg + 3 tbsp ground oats',
  prep:['اهرسي الموزة واخلطيها بالبيضة والشوفان.','اقلي مغرف صغيرة في طاسة غير لاصقة على نار هادية من غير زيت تقيل.','قطعيه أصابع أو دوائر صغيرة.'],
  en_prep:['Mash the banana; mix in the egg and ground oats.','Cook small spoonfuls on a non-stick pan over low heat.','Cut into little fingers or rounds.'],
  tags:['بيض'], note:'فطار صحي من غير سكر ولا دقيق أبيض — بيجنن الأطفال.', en_note:'No sugar, no white flour — a toddler hit.' },
{ id:'waffle', e:'🧇', c:'grain', m:12, s:['b','s'],
  n:'وافل صغير', en_n:'Mini waffle', ing:'وافل من دقيق كامل أو عيش وافل', en_ing:'A whole-grain waffle',
  prep:['قدميه قطع صغيرة بدون شوكولاتة أو سكاكر.','تنفع عليه طبقة رقيقة زبادي أو فواكه.'],
  en_prep:['Cut into small pieces, no chocolate or candy.','Top with a thin layer of yogurt or fruit.'],
  tags:['جلوتين'], note:'اختاري نوع سكره قليل — أو حضّريه في البيت ببان كيك موز.', en_note:'Pick low-sugar kinds — or make banana pancakes in a waffle iron.' },
{ id:'couscous', e:'🥘', c:'grain', m:12, s:['l','d'],
  n:'كسكسي بالخضار', en_n:'Couscous with vegetables', ing:'كسكسي + خضار مشكل مطبوخ', en_ing:'Couscous + cooked mixed veggies',
  prep:['بللي الكسكسي في مرق ساخن لين يتشرب وينضج.','اخلطيه بخضار مطبوخة مقطعة صغيرة.'],
  en_prep:['Steep the couscous in hot broth until fluffed and cooked.','Mix with small-cut cooked veggies.'],
  tags:['جلوتين'], note:'وجبة سريعة وخفيفة — تتحضر في دقايق.', en_note:'Quick and light — ready in minutes.' },
{ id:'noodles', e:'🍜', c:'grain', m:10, s:['d','l'],
  n:'شوربة شعيرية بالمرق', en_n:'Vermicelli broth soup', ing:'شعيرية صغيرة + مرق فراخ أو لحمة خفيف', en_ing:'Small vermicelli + light chicken/beef broth',
  prep:['اطبخي الشعيرية في المرق لين توقع.','قطعيها قصار بالملعقة قبل التقديم.'],
  en_prep:['Simmer the vermicelli in broth until soft.','Cut it short with a spoon before serving.'],
  tags:['جلوتين'], note:'مرق بيتي من غير مكعبات مرق ولا ملح زيادة.', en_note:'Homemade broth only — no stock cubes or extra salt.' },

/* ================= بروتين وألبان / Protein & Dairy ================= */
{ id:'chicken', e:'🍗', c:'protein', m:7, s:['l','d'],
  n:'فراخ مسلوقة مهروسة', en_n:'Boiled chicken purée', ing:'قطعة صدور فراخ صغيرة', en_ing:'A small chicken breast piece',
  prep:['اسلقي الفراخ كويس في مياه من غير ملح لين تنضج تمام.','اطحنيها أو اهرسيها مع مغرفة من مياه سلقها.','قدميها لوحدها أو مخلوطة بخضار مهروس.'],
  en_prep:['Poach thoroughly in unsalted water.','Grind or mash with some of the cooking liquid.','Serve alone or mixed into veggie purée.'],
  tags:[], note:'البروتين مهم من 7 شهور — ابدئي بملعقة وزيدي تدريجيًا.', en_note:'Protein matters from 7 months — start with one spoon and build up.' },
{ id:'beef', e:'🍖', c:'protein', m:7, s:['l'],
  n:'لحمة بقري مهروسة', en_n:'Beef purée', ing:'قطعة لحمة طرية (وردة أو ربحة)', en_ing:'A tender beef cut (rump/shoulder)',
  prep:['اسلقي اللحمة كويس أو اطبخها بالضغط لين توقع جدًا.','اطحنيها في الكتانة مع شوية مرق لحد ما تبقى ناعمة.','قدميها مع خضار أو رز مهروس.'],
  en_prep:['Boil or pressure-cook until very tender.','Blend with a little broth until smooth.','Serve with veggies or soft rice.'],
  tags:[], note:'أغنى مصدر للحديد — مهم جدًا بعد 6 شهور عشان مخزون الحديد بيقل.', en_note:'The richest iron source — important after 6 months as baby\u2019s stores drop.' },
{ id:'eggyolk', e:'🥚', c:'protein', m:6, s:['b','l'],
  n:'صفار بيض مسلوق', en_n:'Hard-boiled egg yolk', ing:'صفار بيضة مسلوقة', en_ing:'1 cooked egg yolk',
  prep:['اسلقي البيضة 12 دقيقة كويس.','فصلي الصفار بس واهرسيه مع شوية لبن أم أو صناعي أو زبادي.'],
  en_prep:['Boil the egg for 12 minutes.','Separate the yolk and mash it with a little breast milk, formula or yogurt.'],
  tags:['بيض'], note:'ابدئي بربع صفار أول مرة (الصبح) وراقبي أي حساسية. البياض بيدخل في الشهر السابع، وبعدها البيضة الكاملة عادي.', en_note:'Start with a quarter yolk in the morning and watch for reactions. The white comes in during month 7; after that the whole egg is fine.' },
{ id:'omelet', e:'🍳', c:'protein', m:8, s:['b','d'],
  n:'أومليت (بيض كامل)', en_n:'Plain omelet (whole egg)', ing:'بيضة كاملة + شوية لبن', en_ing:'1 egg + a splash of milk',
  prep:['اخفقي البيضة مع شوية لبن.','اقليها في طاسة غير لاصقة من غير زيادة زيت.','قطعيها أصابع صغيرة ينفع يمسكها.'],
  en_prep:['Beat the egg with the milk.','Cook on a non-stick pan with no extra oil.','Cut into little fingers.'],
  tags:['بيض','ألبان'], note:'فطار سريع ومشبع — البيضة الكاملة بعد ما البياض يتجرّب، واللبن في الطبخ من 8 شهور. مع حساسية الألبان: اعمليه بمياه بدل اللبن.', en_note:'A quick, filling breakfast — whole egg once the white has been tried, and milk in cooking from 8 months. Dairy allergy: make it with water instead of milk.' },
{ id:'vegomelet', e:'🍳', c:'protein', m:8, s:['b','d'],
  n:'أومليت خضار', en_n:'Veggie omelet', ing:'بيضة + جزر مبشور + كوسة مبشورة', en_ing:'1 egg + grated carrot + grated zucchini',
  prep:['اخفقي البيضة وضيفي لها الخضار المبشور الناعم.','اقليها على نار هادية لين تنضج من الطرفين.','قطعيها مربعات صغيرة.'],
  en_prep:['Beat the egg; stir in the finely grated veggies.','Cook over low heat until set on both sides.','Cut into small squares.'],
  tags:['بيض'], note:'طريقة ذكية لإدخال الخضار — مستخبية جوا البيضة 😄', en_note:'A clever way to sneak veggies in 😄' },
{ id:'lentil', e:'🍲', c:'protein', m:7, s:['l','d'],
  n:'شوربة عدس بالكمون', en_n:'Cumin lentil soup', ing:'نص كوب عدس أصفر + جزر + بصلة', en_ing:'½ cup red lentils + carrot + onion',
  prep:['اغسلي العدس واطبخيه مع الخضار لين يقع.','اهرسيها بالخلاط وضيفي كمون ناعم خفيف.','من غير ملح — وقدميها متوسطة الكثافة.'],
  en_prep:['Rinse the lentils and simmer with the veggies until soft.','Blend and season with a little ground cumin.','No salt — serve medium-thick.'],
  tags:[], note:'بروتين وحديد نباتي رائع ورخيص — طبق أسبوعي ثابت.', en_note:'Cheap plant protein and iron — a weekly staple.' },
{ id:'beans', e:'🫘', c:'protein', m:7, s:['l','s'],
  n:'فاصوليا بيضاء/حمراء مهروسة', en_n:'Mashed white/red beans', ing:'ربع كوب فاصوليا مسلوقة', en_ing:'¼ cup cooked beans',
  prep:['اسلقي الفاصوليا (أو استخدمي مجمدة) لين توقع تمام.','اهرسيها بالشوكة — مش لازم تتبقى ناعمة جدًا.'],
  en_prep:['Boil until very soft (frozen works).','Lightly mash — a few soft lumps are good.'], tags:[] },
{ id:'chickpea', e:'🫘', c:'protein', m:7, s:['l','s'],
  n:'حمص مسلوق مهروس', en_n:'Mashed chickpeas', ing:'ربع كوب حمص مسلوق', en_ing:'¼ cup boiled chickpeas',
  prep:['اسلقي الحمص لين يقع تمام.','اهرسيه بالشوكة مع شوية زبادي أو عصرة ليمون خفيفة.'],
  en_prep:['Boil until very soft.','Mash with a little yogurt or a squeeze of lemon.'],
  tags:[], note:'بروتين مشبع — وينفع كمان حمص بالطحينة.', en_note:'A filling protein — hummus with tahini works too.' },
{ id:'fish', e:'🐟', c:'protein', m:8, s:['l','d'],
  n:'سمك أبيض', en_n:'White fish', ing:'فيليه سمك أبيض (بوري أو دنيس)', en_ing:'A white fish fillet (mullet/bream)',
  prep:['اطبخي الفيليه ببخار أو في شوية مياه لين ينضج.','افحصيه حبة حبة وشيلي أي شوك مهما كان صغير.','اهرسيه أو فتته قطع صغيرة.'],
  en_prep:['Steam or poach until cooked through.','Check flake by flake — remove every bone, however small.','Mash or flake into small pieces.'],
  tags:['سمك'], note:'⚠️ اتأكدي 100% من نزع الشوك — وابدئي بسمك أبيض قبل الدهني.', en_note:'⚠️ 100% bone-free — start with white fish before oily kinds.' },
{ id:'kofta', e:'🧆', c:'protein', m:10, s:['l','d'],
  n:'كفتة فرن مفرمة ناعم', en_n:'Oven-baked kofta fingers', ing:'لحمة مفرومة ناعم + بصلة مبشورة', en_ing:'Fine ground beef + grated onion',
  prep:['اخلطي اللحمة بالبصلة المبشورة من غير ملح.','شكليها أصابع صغيرة واشويها في الفرن لين تنضج تمام.','اتأكدي إنها مطبوخة من جوه كويس.'],
  en_prep:['Mix the beef with grated onion, no salt.','Shape little fingers and bake until fully cooked.','Make sure the inside is done.'],
  tags:[], note:'أصابع الكفتة من أحب الأكلات للبيبي اللي بيأكل بنفسه.', en_note:'Kofta fingers are a favorite for self-feeding babies.' },
{ id:'liver', e:'🍖', c:'protein', m:6, s:['l'],
  n:'كبدة فراخ مهروسة', en_n:'Mashed chicken liver', ing:'قطعة كبدة فراخ صغيرة', en_ing:'A small piece of chicken liver',
  prep:['اغسليها كويس واطبخيها لحد ما تستوي تمامًا.','اهرسيها أو اطحنيها ناعم وقدميها مع خضار أو رز.'],
  en_prep:['Rinse well and cook through completely.','Mash or grind smooth; serve with veggies or rice.'],
  tags:[], note:'صاروخ الحديد — مرة واحدة في الأسبوع يكفي. الكبدة البلدي (البقري) من بعد السنة.', en_note:'An iron powerhouse — once a week is plenty. Beef liver comes after age one.' },
{ id:'foul', e:'🫘', c:'protein', m:7, s:['b','l'],
  n:'فول مدمس مهروس', en_n:'Mashed foul (stewed fava)', ing:'نص كوب فول', en_ing:'½ cup fava beans',
  prep:['اطبخي الفول لين يقع تمام.','اهرسيه بالشوكة مع كمون وليمون خفيف وزيت زيتون.','القشرة تنفع بعد ما البيبي يتعود المضغ.'],
  en_prep:['Simmer until very soft.','Mash with cumin, a little lemon and olive oil.','Skins are fine once baby chews well.'],
  tags:[], note:'فطار مصري أصيل — بروتين وحديد ورخيص.', en_note:'A classic Egyptian breakfast — protein, iron and budget-friendly.' },
{ id:'yogurt', e:'🥛', c:'dairy', m:6, s:['b','s','d'],
  n:'زبادي طبيعي كامل الدسم', en_n:'Plain full-fat yogurt', ing:'كوب زبادي طبيعي', en_ing:'1 cup plain yogurt',
  prep:['قدميه زي ما هو، أو اخلطيه بموز أو فواكه مهروسة.'],
  en_prep:['Serve as-is, or swirl in mashed banana or fruit.'],
  tags:['ألبان'], note:'طبيعي من غير سكر ولا نكهات — الزبادي بالفواكه الجاهز سكره زيادة.', en_note:'Plain, no sugar or flavors — ready fruit yogurt has too much sugar.' },
{ id:'areesh', e:'🧀', c:'dairy', m:6, s:['b','s'],
  n:'جبنة قريش', en_n:'Areesh (ricotta-style) cheese', ing:'3-4 ملاعق جبنة قريش', en_ing:'3–4 tbsp areesh cheese',
  prep:['قدميها مع قطع فواكه أو على عيش طرية.'],
  en_prep:['Serve with fruit pieces or on soft bread.'],
  tags:['ألبان'], note:'بروتين وكالسيوم وسكرها قليل — من أحسن الألبان للأطفال.', en_note:'Protein and calcium with little sugar — one of the best cheeses for kids.' },
{ id:'whitecheese', e:'🧀', c:'dairy', m:12, s:['b','s'],
  n:'جبنة بيضاء قليلة الملح', en_n:'Low-salt white cheese', ing:'قطعة جبنة بيضاء', en_ing:'A piece of white cheese',
  prep:['انقعي الجبنة في مياه نص ساعة عشان يقل ملحها.','قطعيها مكعبات صغيرة أو ادهنيها على عيش.'],
  en_prep:['Soak in water ~30 minutes to reduce the salt.','Cube small or spread on bread.'],
  tags:['ألبان'], note:'الجبن العادي ملحه عالي — النقع والكمية الصغيرة مهمين.', en_note:'Regular white cheese is salty — soaking and small amounts matter.' },
{ id:'pb', e:'🥜', c:'protein', m:7, s:['b','s'],
  n:'زبدة فول سوداني مخففة', en_n:'Diluted peanut butter', ing:'ملعقة صغيرة زبدة فول سوداني', en_ing:'1 tsp peanut butter',
  prep:['فكّي الزبدة بمية دافية أو لبن الطفل لحد ما تبقى سايلة.','اخلطيها في الشوفان أو الزبادي — ومن 8 شهور ادهني طبقة رقيقة على عيش أو توست.'],
  en_prep:['Loosen with warm water or breast milk/formula until runny.','Stir into oatmeal or yogurt — from 8 months, spread thinly on bread or toast.'],
  tags:['مكسرات'], note:'⚠️ أول مرة الصبح وكمية صغيرة وراقبي أي حساسية (طفح، تورم). ممنوع المكسرات الكاملة لحد ما يكبر.', en_note:'⚠️ First time: morning, tiny amount, watch closely (rash, swelling). Whole nuts stay forbidden while little.' },
{ id:'smoothie', e:'🥤', c:'dairy', m:12, s:['b','s'],
  n:'سموذي موز وزبادي', en_n:'Banana-yogurt smoothie', ing:'موزة + كوب زبادي + فواكه موسم', en_ing:'1 banana + 1 cup yogurt + seasonal fruit',
  prep:['اخلطي كل حاجة في الخلاط لحد ما تبقى ناعمة.','قدميه في كوب بماسحة.'],
  en_prep:['Blend everything until smooth.','Serve in a cup with a straw.'],
  tags:['ألبان'], note:'حل مثالي للبيبي اللي مش بياكل فواكه 😄', en_note:'Perfect for fruit-refusing toddlers 😄' },
{ id:'sandwich', e:'🥙', c:'grain', m:15, s:['b','s'],
  n:'ساندوتش جبنة', en_n:'Cheese sandwich', ing:'عيش فينو أو توست + جبنة قريش/بيضاء', en_ing:'Soft roll or toast + areesh/white cheese',
  prep:['ادهني الجبنة على العيش.','قطعيه أصابع صغيرة أو مربعات ينفع يمسكها بنفسه.'],
  en_prep:['Spread the cheese on the bread.','Cut into little fingers or squares baby can hold.'],
  tags:['جلوتين','ألبان'], note:'سناك سريع بين اللعب — قدميه مقطوع مش صحيح كامل.', en_note:'A quick playtime snack — serve cut, never whole hard bread.' },

/* ================= أطباق مركبة / Dishes ================= */
{ id:'chickstew', e:'🍲', c:'dish', m:8, s:['l'],
  n:'يخنة فراخ بالخضار', en_n:'Chicken & veggie stew', ing:'فراخ + جزر + كوسة + بطاطس + بصلة', en_ing:'Chicken + carrot + zucchini + potato + onion',
  prep:['اطبخي قطع الفراخ مع الخضار في مياه لين كل حاجة توقع.','اهرسي أو افرم حسب عمر البيبي (من 9 شهور سيبيه قطع صغيرة).','قدميه بمرق خفيف مع رز أو عيش.'],
  en_prep:['Simmer the chicken pieces with the veggies until tender.','Mash or shred by age (small pieces from 9 months).','Serve soupy with rice or bread.'],
  tags:[], note:'أشهر طبق غدا عندنا — متوازن وسهل التحضير.', en_note:'The classic Egyptian lunch — balanced and easy.' },
{ id:'beefstew', e:'🍲', c:'dish', m:10, s:['l'],
  n:'يخنة لحمة بالخضار', en_n:'Beef & veggie stew', ing:'لحمة + جزر + بطاطس + طماطم مطبوخة', en_ing:'Beef + carrot + potato + cooked tomato',
  prep:['اطبخي اللحمة مع الخضار والطماطم المطبوخة لين توقع.','فرمي أو هرسي حسب عمر البيبي.','قدميه مع رز مطبوخ ناعم.'],
  en_prep:['Simmer the beef with the veggies and cooked tomato until tender.','Mince or mash by age.','Serve with soft rice.'],
  tags:[], note:'حديد + فيتامين C من الطماطم = امتصاص أحسن للحديد.', en_note:'Iron + tomato vitamin C = better iron absorption.' },
{ id:'chickrice', e:'🍛', c:'dish', m:12, s:['l'],
  n:'رز بالفراخ والخضار', en_n:'Chicken, rice & veggies', ing:'رز + فراخ مقطعة + خضار مشكل', en_ing:'Rice + cut chicken + mixed veggies',
  prep:['اطبخي الرز في شوية مرق فراخ من غير ملح.','اخلطي الفراخ المقطعة والخضار المطبوخة.','قطعي كل حاجة صغيرة وتقدميها في طبق بيبي.'],
  en_prep:['Cook the rice in light chicken broth, no salt.','Mix in the cut chicken and cooked veggies.','Cut small and serve on a toddler plate.'],
  tags:[], note:'وجبة كاملة البيبي يقدر ياكلها بإيده بالملعقة.', en_note:'A complete meal baby can spoon up alone.' },
{ id:'pastachick', e:'🍝', c:'dish', m:12, s:['l','d'],
  n:'معكرونة بالفراخ المفرومة', en_n:'Pasta with minced chicken', ing:'مكرونة + فراخ مفروم + صلصة طماطم', en_ing:'Pasta + minced chicken + tomato sauce',
  prep:['اسلقي المكرونة طرية وحضّري الصلصة بالفراخ المفروم.','اخلطيهم كويس وقدميها فورًا.'],
  en_prep:['Boil the pasta soft; make the sauce with the minced chicken.','Mix well and serve right away.'],
  tags:['جلوتين'], note:'بيبي فافوريت مضمون 🤍', en_note:'Guaranteed kid favorite 🤍' },
{ id:'mahalabia', e:'🍮', c:'dish', m:12, s:['s','d'],
  n:'مهلبية بالحليب (سكر قليل جدًا)', en_n:'Milk mahalabia pudding (very little sugar)', ing:'كوبين حليب + ملعقتين نشا + ملعقة صغيرة سكر (أو بدون)', en_ing:'2 cups milk + 2 tbsp cornstarch + 1 tsp sugar (optional)',
  prep:['سخّني الحليب وضيفي النشا مع التقليب لحد ما يكثف.','صبي في كوبايات صغيرة وبرديها.','قدميها فوقها شوية فواكه مقطعة.'],
  en_prep:['Warm the milk; whisk in the cornstarch until thick.','Pour into small cups and chill.','Top with cut fruit.'],
  tags:['ألبان'], note:'حلى طبيعي بسيط — السكر اختياري خالص.', en_note:'A simple natural dessert — sugar is totally optional.' },
{ id:'potatodill', e:'🥔', c:'dish', m:12, s:['l','d'],
  n:'بطاطس بالشبت والزبادي', en_n:'Potato with dill & yogurt', ing:'بطاطس مسلوقة + زبادي + شبت', en_ing:'Boiled potatoes + yogurt + dill',
  prep:['اهرسي البطاطس المسلوقة وخلطيها بزبادي وشبت ناعم.','قدميها دافية.'],
  en_prep:['Mash the boiled potatoes; fold in yogurt and finely chopped dill.','Serve warm.'],
  tags:['ألبان'], note:'بديل صحي عن البطاطس المقلي — نكهة بتحبها الأطفال.', en_note:'A healthy swap for fried potatoes — kids love the flavor.' },
{ id:'bananacake', e:'🍰', c:'snack', m:18, s:['s','b'],
  n:'كيك الموز الصحي', en_n:'Healthy banana cake', ing:'موزتين + بيضتين + كوب شوفان مطحون', en_ing:'2 bananas + 2 eggs + 1 cup ground oats',
  prep:['اخلطي كل حاجة في الخلاط.','اطبخيه في الفرن على حرارة 180 لمدة 20 دقيقة تقريبًا.','قطعيه مربعات صغيرة.'],
  en_prep:['Blend everything together.','Bake at 180°C for about 20 minutes.','Cut into small squares.'],
  tags:['بيض'], note:'بدون سكر ولا زبدة — حلاوة الموز تكفي، وحلى مثالي للعيال.', en_note:'No sugar, no butter — banana sweetness is enough.' },
{ id:'shawarma', e:'🌯', c:'dish', m:18, s:['l','d'],
  n:'شاورما فراخ بيتي', en_n:'Home-style chicken shawarma', ing:'فراخ شرائح رقيقة + عيش صاج + زبادي بالخيار', en_ing:'Thin chicken strips + baladi bread + cucumber yogurt',
  prep:['تبّلي الفراخ بزبادي وكمون وباريكا من غير ملح زيادة واشويها.','لفيها في عيش صاج مع شوية زبادي بالخيار.','قطعيةها أصابع أو سيبيها لفة صغيرة.'],
  en_prep:['Marinate the chicken in yogurt, cumin and paprika (little salt); roast.','Wrap in baladi bread with cucumber yogurt.','Cut into fingers or serve mini wraps.'],
  tags:['جلوتين','ألبان'], note:'نسخة بيبي من الشاورما — صح وبدقة مضمونة.', en_note:'Baby-approved shawarma — light and sure to be devoured.' },
{ id:'burger', e:'🍔', c:'dish', m:24, s:['l'],
  n:'برجر صغير بيتي', en_n:'Mini homemade burger', ing:'لحمة مفرومة + عيش برجر صغير + خس وطماطم', en_ing:'Ground beef + mini bun + lettuce & tomato',
  prep:['شكلي أقراص لحمة صغيرة واشويها في الفرن أو التستيرة.','ركبيها في عيش صغير مع خس مفروم وطماطم.','من صوص: زبادي مخلوط بشوية صلصة خفيفة.'],
  en_prep:['Shape small patties and bake or dry-pan them.','Build in a mini bun with chopped lettuce and tomato.','Sauce: plain yogurt with a light ketchup touch.'],
  tags:['جلوتين'], note:'نسخة بيتية صح بدل المطاعم — والبيبي هياكلها بفرحة 😄', en_note:'A homemade fast-food night — joy guaranteed 😄' },
{ id:'koshari', e:'🍛', c:'dish', m:24, s:['l'],
  n:'كشري بيبي', en_n:'Baby koshari', ing:'رز + مكرونة صغيرة + عدس + صلصة طماطم + بصل مقرمش خفيف', en_ing:'Rice + small pasta + lentils + tomato sauce + crispy onion',
  prep:['اطبخي الرز والعدس والمكرونة كل على حدة لين يقعوا.','حضّري صلصة طماطم بيتي خفيفة من غير شطة.','اخلطي كل حاجة وقدميها في طبق صغير.'],
  en_prep:['Cook the rice, lentils and pasta separately until soft.','Make a light homemade tomato sauce, no chili.','Mix and serve in a small bowl.'],
  tags:['جلوتين'], note:'مصرية 100% 😂 — نسخة خفيفة مش حارّة تنفع للعيال.', en_note:'100% Egyptian 😂 — a gentle, non-spicy toddler version.' },
{ id:'mahshi', e:'🫑', c:'dish', m:24, s:['l'],
  n:'محشي كوسة بالرز واللحمة', en_n:'Zucchini stuffed with rice & beef', ing:'كوسة صغيرة + رز + لحمة مفرومة + طماطم', en_ing:'Small zucchini + rice + ground beef + tomato',
  prep:['فرّغي الكوسة واملإيها برز مخلوط باللحمة.','اطبخيها في صلصة طماطم خفيفة لين تنضج.','قدميها مقطعة — بسهلة المضغ كفاية.'],
  en_prep:['Core the zucchini and fill with the rice-beef mix.','Simmer in a light tomato sauce until done.','Serve cut — soft enough to chew.'],
  tags:[], note:'الأكل البيتي بالمصري من أول عمره — عادة جميلة.', en_note:'Real Egyptian home food from the start — a lovely habit.' },
];


/* ============================================================
   شارات غذائية: الحديد 🩸 وفيتامين C 🍊 (حسب الدليل الرسمي —
   حديد في كل وجبة + اقترانه بفيتامين C لامتصاص أفضل)
   ============================================================ */
const IRON_FOODS = ['ricecereal','oat','barleycereal','wheatcereal','beef','chicken','lentil','liver','kofta','chickpea','beans','foul','eggyolk','omelet','vegomelet','spinach','bulgur','fish','beefstew','chickstew'];
const VITC_FOODS = ['mango','kiwi','strawberry','orange','avocado','broccoli','bellpepper','sweetpotato','cantaloupe','peach','watermelon','guava','apricot','tomato'];
FOODS.forEach(f => {
  if (IRON_FOODS.includes(f.id)) f.iron = true;
  if (VITC_FOODS.includes(f.id)) f.vitC = true;
});

/* رشفات المية — تذكير بكوب التدريب */
const WATER = {
  id: 'water', e: '🥤', c: 'milk', m: 6,
  n: 'رشفات مياه بكوب تدريب', en_n: 'Sips of water from a training cup',
  ing: 'مية نضيفة', en_ing: 'Clean water',
  prep: ['مع بداية الأكل الصلب: عرضي المية بكوب تدريب بعد الوجبة وبين الرضعات.','شوية رشفات كفاية — الحليب هو الأساس لحد السنة.'],
  en_prep: ['With solids starting: offer water in a training cup after meals and between feeds.','A few sips are enough — milk stays the main drink until one.'],
  tags: [], note: null, en_note: null,
};

/* وصول سريع بالـ id */
const FOOD_MAP = {};
[...FOODS, MILK, MILKCUP, WATER].forEach(f => FOOD_MAP[f.id] = f);

/* ============================================================
   جدول الشهر السادس 🥣 — مخطط مامي يوم بيوم (30 يوم)
   وجبة واحدة في اليوم: الفطار (الساعة 9) — والغدا والعشا رضاعة.
   الكميات بالمعلقة الصغيرة زي جدولها بالظبط، والملاحظة = طريقة التحضير (على البخار / مسلوقة / مشوية) ولون الفلفل.
   ============================================================ */
/* السميد مش في جدول السادس الجديد — بس لسه بيستخدم في الشهر السابع */
const MONTH6_SEMOLINA = { id:'m6-semolina', e:'🥣', c:'grain', m:6, s:['l'],
  n:'سميد مطبوخ', en_n:'Cooked semolina',
  ing:'سميد ناعم + ماء أو لبن الطفل', en_ing:'Fine semolina + water or baby’s milk',
  prep:['اطبخي السميد على نار هادية مع التقليب لحد ما يتماسك.','قدّميه بقوام ناعم ومن غير سكر.'],
  en_prep:['Cook semolina over low heat, stirring, until thick.','Serve smooth with no sugar.'],
  tags:['جلوتين'], note:null, en_note:null };
FOOD_MAP[MONTH6_SEMOLINA.id] = MONTH6_SEMOLINA;
/* الكمية في جداول مامي (السادس والسابع): 1 ملعقة، 2 ملعقتين، q ربع، h نصف، w كامل (بتتكتب بعد الاسم) — والاسم المختصر زي جدولها */
const PLAN_AMT = {
  1: { ar: 'ملعقة', en: '1 spoon' }, 2: { ar: 'ملعقتين', en: '2 spoons' },
  q: { ar: 'ربع', en: '¼' }, h: { ar: 'نصف', en: '½' }, w: { ar: 'كامل', en: 'whole', arAfter: true },
};
const PLAN_SHORT = {
  zucchini: { ar: 'كوسة', en: 'zucchini' }, carrot: { ar: 'جزر', en: 'carrot' }, bellpepper: { ar: 'فلفل', en: 'bell pepper' },
  potato: { ar: 'بطاطس', en: 'potato' }, sweetpotato: { ar: 'بطاطا', en: 'sweet potato' }, broccoli: { ar: 'بروكلي', en: 'broccoli' },
  pumpkin: { ar: 'قرع عسلي', en: 'pumpkin' }, beetroot: { ar: 'بنجر', en: 'beetroot' }, apple: { ar: 'تفاح', en: 'apple' },
  rice: { ar: 'أرز', en: 'rice' }, eggyolk: { ar: 'صفار', en: 'egg yolk' }, yogurt: { ar: 'زبادي', en: 'yogurt' },
  spinach: { ar: 'سبانخ', en: 'spinach' }, beef: { ar: 'لحم', en: 'meat' }, strawberry: { ar: 'فراولة', en: 'strawberry' },
  lentil: { ar: 'عدس', en: 'lentils' }, 'm7-egg': { ar: 'بيض', en: 'egg' }, banana: { ar: 'موز', en: 'banana' },
  'm8-molokhia': { ar: 'ملوخية', en: 'molokhia' },
};
const MONTH6_SCHEDULE = [
  { days:[1, 1],   parts:[['v',['zucchini'],1]],                            note:{ ar:'على البخار', en:'Steamed' } },
  { days:[2, 2],   parts:[['v',['zucchini'],1]],                            note:{ ar:'مسلوقة', en:'Boiled' } },
  { days:[3, 3],   parts:[['v',['zucchini'],1]],                            note:{ ar:'مشوية', en:'Roasted' } },
  { days:[4, 4],   parts:[['v',['zucchini'],2], ['s',['carrot'],1]],        note:{ ar:'على البخار', en:'Steamed' } },
  { days:[5, 5],   parts:[['v',['zucchini'],2], ['s',['carrot'],1]],        note:{ ar:'مسلوقة', en:'Boiled' } },
  { days:[6, 6],   parts:[['v',['zucchini'],2], ['s',['carrot'],1]],        note:{ ar:'مشوية', en:'Roasted' } },
  { days:[7, 7],   parts:[['s',['carrot'],1], ['v',['bellpepper'],2]],      note:{ ar:'الفلفل مشوي ومقشر', en:'Pepper roasted and peeled' } },
  { days:[8, 8],   parts:[['s',['carrot'],1], ['v',['bellpepper'],2]],      note:{ ar:'الفلفل مشوي', en:'Pepper roasted' } },
  { days:[9, 9],   parts:[['s',['potato'],1], ['v',['zucchini'],2]],        note:{ ar:'على البخار', en:'Steamed' } },
  { days:[10, 10], parts:[['s',['potato'],1], ['v',['zucchini'],2]],        note:{ ar:'مسلوق', en:'Boiled' } },
  { days:[11, 11], parts:[['s',['potato'],1], ['v',['zucchini'],2]],        note:{ ar:'مشوي', en:'Roasted' } },
  { days:[12, 12], parts:[['s',['sweetpotato'],1], ['v',['bellpepper'],2]], note:{ ar:'الفلفل برتقالي مشوي', en:'Orange pepper, roasted' } },
  { days:[13, 13], parts:[['s',['potato'],1], ['v',['bellpepper'],2]],      note:{ ar:'الفلفل أصفر على البخار', en:'Yellow pepper, steamed' } },
  { days:[14, 14], parts:[['s',['carrot'],1], ['v',['bellpepper'],2]],      note:{ ar:'الفلفل أحمر مشوي', en:'Red pepper, roasted' } },
  { days:[15, 15], parts:[['s',['potato'],1], ['v',['broccoli'],2]] },
  { days:[16, 16], parts:[['s',['sweetpotato'],1], ['v',['broccoli'],2]] },
  { days:[17, 17], parts:[['s',['carrot'],1], ['v',['broccoli'],2]] },
  { days:[18, 18], parts:[['s',['pumpkin'],1], ['v',['zucchini'],2]] },
  { days:[19, 19], parts:[['s',['pumpkin'],1], ['v',['bellpepper'],2]],     note:{ ar:'الفلفل أصفر مشوي', en:'Yellow pepper, roasted' } },
  { days:[20, 20], parts:[['s',['pumpkin'],1], ['v',['broccoli'],2]] },
  { days:[21, 21], parts:[['s',['beetroot'],1], ['v',['bellpepper'],2]],    note:{ ar:'الفلفل أحمر مشوي', en:'Red pepper, roasted' } },
  { days:[22, 22], parts:[['s',['beetroot'],1], ['v',['bellpepper'],2]],    note:{ ar:'الفلفل أصفر مشوي', en:'Yellow pepper, roasted' } },
  { days:[23, 23], parts:[['s',['beetroot'],1], ['v',['bellpepper'],2]],    note:{ ar:'الفلفل أحمر مشوي', en:'Red pepper, roasted' } },
  { days:[24, 24], parts:[['s',['beetroot'],1], ['f',['apple'],2]] },
  { days:[25, 25], parts:[['s',['pumpkin'],1], ['f',['apple'],2]] },
  { days:[26, 26], parts:[['s',['carrot'],1], ['f',['apple'],2]] },
  { days:[27, 27], parts:[['s',['rice'],1], ['f',['apple'],2]] },
  { days:[28, 28], parts:[['s',['rice'],1], ['v',['broccoli'],2]] },
  { days:[29, 29], parts:[['s',['rice'],1], ['v',['bellpepper'],2]] },
  { days:[30, 30], parts:[['s',['rice'],1], ['p',['eggyolk'],'q'], ['v',['zucchini']]], note:{ ar:'الفلفل أحمر مشوي', en:'Red pepper, roasted' } },
];
const MONTH6_BY_DAY = {};
MONTH6_SCHEDULE.forEach(r => { for (let d = r.days[0]; d <= r.days[1]; d++) MONTH6_BY_DAY[d] = r; });

/* ============================================================
   جدول الشهر السابع 🍽️ — مخطط مامي يوم بيوم: فطار + غدا (ومفيش عشا — بعدهم رضاعات)
   الكميات زي جدولها بالظبط، وملاحظة كل يوم بتظهر على الوجبة اللي تخصها.
   الصنف الجديد بيتعلّم عليه 🆕 أول يوم يظهر فيه (بعد أكلات الشهر السادس).
   ============================================================ */
const MONTH7_EGG = { id:'m7-egg', e:'🥚', c:'protein', m:7, s:['b'],
  n:'بيضة كاملة (الصفار والبياض)', en_n:'Whole egg (yolk and white)',
  ing:'بيضة كاملة', en_ing:'1 whole egg',
  prep:['اسلقي البيضة جيدًا جدًا.','اهرسيها بقوام ناعم، وابدئي بكمية صغيرة.'],
  en_prep:['Hard-boil the egg very well.','Mash smooth and start with a small amount.'],
  tags:['بيض'], note:'البياض صنف جديد بعد الصفار — ابدئي بكمية صغيرة وراقبي أي حساسية. لو ظهرت أعراض وقفي وسألي الدكتور.',
  en_note:'The white is new after the yolk — start small and watch for reactions. If symptoms appear, stop and ask your doctor.' };
FOOD_MAP[MONTH7_EGG.id] = MONTH7_EGG;

/* الأكلات اللي اتجرّبت في الشهر السادس */
const MONTH6_TRIED = new Set();
MONTH6_SCHEDULE.forEach(r => {
  r.parts.forEach(([, ids]) => ids.forEach(i => MONTH6_TRIED.add(i)));
});
const M7_ROLE = { beetroot: 's', apple: 'f', eggyolk: 'p', potato: 's', bellpepper: 'v', pumpkin: 's', broccoli: 'v', zucchini: 'v', carrot: 's',
  sweetpotato: 's', rice: 's', yogurt: 'd', spinach: 'v', beef: 'p', strawberry: 'f', lentil: 'p', 'm7-egg': 'p', banana: 'f', 'm8-molokhia': 'v' };
/* P(صنف, كمية, اسم زي جدولها لو مختلف) */
const P = (id, amt, label) => [M7_ROLE[id], [id], amt || null, label || null];
const YOLK_EGG = { ar: 'صفار بيض', en: 'egg yolk' };
const RED_MEAT = { ar: 'لحم أحمر', en: 'red meat' };
const RED_LENTIL = { ar: 'عدس أحمر', en: 'red lentils' };
const N7 = (k, ar, en) => ({ k, ar, en });   /* ملاحظة اليوم + الوجبة اللي تخصها */
const MONTH7_PLAN = {
  1:  { b: [P('beetroot', 1), P('apple'), P('eggyolk', 'q', YOLK_EGG)], l: [P('potato'), P('bellpepper')], note: N7('b', 'بيض مسلوق', 'Boiled egg') },
  2:  { b: [P('pumpkin', 1), P('broccoli', 2)], l: [P('eggyolk', 'q'), P('zucchini'), P('carrot', 1)] },
  3:  { b: [P('sweetpotato', 1), P('apple', 2)], l: [P('rice', 1), P('eggyolk', 'h'), P('broccoli')], note: N7('l', 'يتم تسوية صفار البيض مع الأرز', 'Cook the egg yolk together with the rice') },
  4:  { b: [P('carrot', 1), P('yogurt'), P('apple', 2)], l: [P('zucchini', 2), P('carrot'), P('eggyolk', 'h')], note: N7('b', 'زبادي كامل الدسم', 'Full-fat yogurt') },
  5:  { b: [P('potato'), P('zucchini'), P('yogurt', 1)], l: [P('rice'), P('bellpepper'), P('eggyolk', 'w')] },
  6:  { b: [P('beetroot', 1), P('yogurt'), P('bellpepper', 2)], l: [P('potato'), P('zucchini'), P('eggyolk')], note: N7('b', 'زبادي كامل الدسم', 'Full-fat yogurt') },
  7:  { b: [P('potato', 1), P('yogurt'), P('zucchini', 2)], l: [P('rice', 1), P('spinach'), P('eggyolk')], note: N7('l', 'بيض مسلوق', 'Boiled egg') },
  8:  { b: [P('pumpkin', 1), P('apple'), P('yogurt')], l: [P('potato', 1), P('spinach'), P('eggyolk')] },
  9:  { b: [P('pumpkin', 1), P('spinach'), P('eggyolk', null, YOLK_EGG)], l: [P('yogurt'), P('zucchini'), P('carrot', 1)] },
  10: { b: [P('sweetpotato', 1), P('yogurt'), P('apple', 2)], l: [P('rice', 1), P('beef', 1), P('broccoli')], note: N7('l', 'لحم أحمر صافي بدون دهون', 'Lean red meat with no fat') },
  11: { b: [P('carrot', 1), P('yogurt'), P('apple', 2)], l: [P('zucchini', 2), P('potato'), P('beef', null, RED_MEAT)], note: N7('l', 'يسلق اللحم مع الخضراوات', 'Boil the meat with the vegetables') },
  12: { b: [P('potato'), P('zucchini'), P('yogurt', 1)], l: [P('rice', 1), P('bellpepper'), P('beef', 1)] },
  13: { b: [P('beetroot', 1), P('yogurt'), P('strawberry', 2)], l: [P('potato'), P('zucchini'), P('eggyolk')], note: N7('b', 'زبادي كامل الدسم', 'Full-fat yogurt') },
  14: { b: [P('sweetpotato', 1), P('yogurt'), P('strawberry', 2)], l: [P('rice', 1), P('spinach'), P('eggyolk')], note: N7('l', 'بيض مسلوق', 'Boiled egg') },
  15: { b: [P('pumpkin', 1), P('strawberry'), P('yogurt')], l: [P('potato', 1), P('spinach'), P('eggyolk')] },
  16: { b: [P('pumpkin', 1), P('spinach'), P('eggyolk', null, YOLK_EGG)], l: [P('yogurt'), P('zucchini'), P('carrot', 1)] },
  17: { b: [P('sweetpotato', 1), P('eggyolk'), P('apple', 2)], l: [P('rice', 1), P('lentil', 1), P('broccoli')], note: N7('l', 'ينقع العدس ليلة قبل طهيه', 'Soak the lentils overnight before cooking') },
  18: { b: [P('carrot', 1), P('yogurt'), P('apple', 2)], l: [P('zucchini', 2), P('potato'), P('lentil', null, RED_LENTIL)], note: N7('l', 'يسلق العدس مع الخضراوات', 'Boil the lentils with the vegetables') },
  19: { b: [P('potato'), P('zucchini'), P('m7-egg')], l: [P('carrot', 1), P('bellpepper'), P('lentil', 1)] },
  20: { b: [P('rice', 1), P('yogurt'), P('banana', 2)], l: [P('potato'), P('zucchini'), P('eggyolk')], note: N7('b', 'زبادي كامل الدسم', 'Full-fat yogurt') },
  21: { b: [P('sweetpotato', 1), P('yogurt'), P('banana', 2)], l: [P('rice', 1), P('spinach'), P('eggyolk')], note: N7('b', 'يهرس الموز بالشوكة', 'Mash the banana with a fork') },
  22: { b: [P('pumpkin', 1), P('banana'), P('yogurt')], l: [P('potato', 1), P('spinach'), P('eggyolk')] },
  23: { b: [P('pumpkin', 1), P('spinach'), P('eggyolk', null, YOLK_EGG)], l: [P('yogurt'), P('zucchini'), P('carrot', 1)] },
  24: { b: [P('sweetpotato', 1), P('eggyolk'), P('apple', 2)], l: [P('rice', 1), P('beef', 1), P('m8-molokhia')], note: N7('l', 'ينقع العدس ليلة قبل طهيه', 'Soak the lentils overnight before cooking') },
  25: { b: [P('carrot', 1), P('yogurt'), P('apple', 2)], l: [P('m8-molokhia', 2), P('rice'), P('lentil', null, RED_LENTIL)], note: N7('l', 'يسلق العدس مع الخضراوات', 'Boil the lentils with the vegetables') },
  26: { b: [P('potato'), P('zucchini'), P('m7-egg')], l: [P('m8-molokhia', 1), P('rice'), P('beef', 1)] },
};
/* أيام 27–30 مش في الصور اللي بعتتها — مؤقتًا بتتكرر من أيام 20–23 لحد ما تبعتهم */
for (let d = 27; d <= 30; d++) MONTH7_PLAN[d] = MONTH7_PLAN[d - 7];
const MONTH7_BY_DAY = {};
for (let d = 1; d <= 30; d++) MONTH7_BY_DAY[d] = MONTH7_PLAN[d];
/* 🆕 الصنف الجديد: أول يوم/وجبة يظهر فيها بعد أكلات الشهر السادس */
const MONTH7_NEW = {};
(function () {
  const seen = new Set(MONTH6_TRIED);
  for (let d = 1; d <= 30; d++) for (const k of ['b', 'l']) {
    const ids = MONTH7_BY_DAY[d][k].flatMap(([, x]) => x);
    MONTH7_NEW[`${d}-${k}`] = new Set(ids.filter(i => !seen.has(i)));
    ids.forEach(i => seen.add(i));
  }
})();

/* ============================================================
   وجبات الشهر الثامن 🍽️ — 3 وجبات في اليوم (فطار + غدا + عشا) من قايمة وجبات مامي (23 وجبة)
   الفطار: لفّة أسبوعية من الوجبات الخفيفة (بيض/زبادي/جبنة/شوفان/تمر/أفوكادو).
   الغدا والعشا: 8 أزواج بتلف — بروتين مختلف في الوجبتين ومن غير رز مرتين في نفس اليوم.
   ids: أكتر من واحد = "أو" (الأم تختار). الأكلات الجديدة هنا مش بتدخل في تشكيلة باقي الأعمار.
   ============================================================ */
const MONTH8_FOODS = [
  { id:'m8-corn', e:'🌽', c:'veg', m:6, s:['l','d'],
    n:'ذرة مهروسة (من غير القشر)', en_n:'Corn purée (skins strained)',
    ing:'ذرة طازة أو مجمدة', en_ing:'Fresh or frozen corn',
    prep:['اسلقي الذرة لحد ما تطرى.','اهرسيها في الخلاط وصفّيها من القشر — مفيش حبوب كاملة.'],
    en_prep:['Boil the corn until soft.','Blend and strain out the skins — no whole kernels.'],
    tags:[], note:'حبوب الذرة الكاملة ممكن تزوّر — مهروسة ومصفّاة بس.', en_note:'Whole kernels can choke — purée and strain only.' },
  { id:'m8-tomato', e:'🍅', c:'veg', m:6, s:['l','d'],
    n:'طماطم مطبوخة (عصير)', en_n:'Cooked tomato (juice)',
    ing:'طماطم ناضجة', en_ing:'Ripe tomatoes',
    prep:['قشّري الطماطم (غطّسيها في مية سخنة دقيقة) وشيلي البذر.','اطبخيها لحد ما تسيح وصفّيها، واستعملي العصير مع الأكل.'],
    en_prep:['Peel the tomatoes (dip in hot water for a minute) and remove the seeds.','Cook until soft, strain, and use the juice in the meal.'],
    tags:[], note:'حمضية — لو عملت احمرار خفيف حوالين البق ده غالبًا عادي ومش حساسية.', en_note:'Acidic — slight redness around the mouth is usually normal, not an allergy.' },
  { id:'m8-fig', e:'🫐', c:'fruit', m:8, s:['b','s'],
    n:'تين مهروس', en_n:'Mashed figs',
    ing:'تين ناضج (أو تين مجفف منقوع)', en_ing:'Ripe figs (or soaked dried figs)',
    prep:['قشّري التين الطازة — أو انقعي المجفف في مية سخنة 10 دقايق.','اهرسيه ناعم.'],
    en_prep:['Peel fresh figs — or soak dried figs in hot water for 10 minutes.','Mash until smooth.'],
    tags:[], note:'ملين طبيعي — مفيد لو في إمساك.', en_note:'A natural laxative — helpful with constipation.' },
  { id:'m8-dates', e:'🌰', c:'fruit', m:6, s:['b','s'],
    n:'تمر مسلوق مهروس', en_n:'Boiled mashed dates',
    ing:'تمر منزوع النوى', en_ing:'Pitted dates',
    prep:['شيلي النوى واسلقي التمر لحد ما يطرى.','اهرسيه ناعم وشيلي القشر.'],
    en_prep:['Remove the pits and boil the dates until soft.','Mash smooth and remove the skins.'],
    tags:[], note:'سكره طبيعي — مش محتاج سكر.', en_note:'Naturally sweet — no sugar needed.' },
  { id:'m8-peanut', e:'🥜', c:'protein', m:8, s:['b','l'],
    n:'فول سوداني مطحون ناعم', en_n:'Finely ground peanuts',
    ing:'فول سوداني محمص من غير ملح', en_ing:'Unsalted roasted peanuts',
    prep:['اطحني الفول السوداني لحد ما يبقى بودرة ناعمة جدًا.','رشّي كمية صغيرة على الأكل وقلّبي كويس.'],
    en_prep:['Grind the peanuts into a very fine powder.','Sprinkle a small amount over the food and mix well.'],
    tags:['مكسرات'], note:'ممنوع حبة فول سوداني كاملة (خطر شرقة). ابدئي بكمية صغيرة وراقبي أي حساسية — لو ظهرت أعراض وقفي واسألي الدكتور.',
    en_note:'Never whole peanuts (choking risk). Start small and watch for allergy — if symptoms appear, stop and ask your doctor.' },
  { id:'m8-wheatgerm', e:'🌾', c:'grain', m:8, s:['b'],
    n:'جنين القمح', en_n:'Wheat germ',
    ing:'جنين القمح', en_ing:'Wheat germ',
    prep:['رشّي ملعقة صغيرة على الأكل وقلّبي.','أو اطبخيه مع الأكل لحد ما يطرى.'],
    en_prep:['Sprinkle a teaspoon over the food and stir.','Or cook it into the meal until soft.'],
    tags:['جلوتين'], note:null, en_note:null },
  { id:'m8-mixedveg', e:'🥕', c:'veg', m:8, s:['l','d'],
    n:'خضار مشكل (كوسة، جزر، بروكلي، بطاطس)', en_n:'Mixed veg (zucchini, carrot, broccoli, potato)',
    ing:'كوسة + جزر + بروكلي + بطاطس', en_ing:'Zucchini + carrot + broccoli + potato',
    prep:['قطّعي الخضار مكعبات واسلقيه لحد ما يطرى.','اهرسيه بقوام خشن شوية.'],
    en_prep:['Dice the vegetables and boil until soft.','Mash to a slightly lumpy texture.'],
    tags:[], note:null, en_note:null },
  { id:'m8-couscous', e:'🥣', c:'grain', m:8, s:['b','l'],
    n:'كسكسي بلبن الطفل', en_n:'Couscous with baby’s milk',
    ing:'كسكسي + لبن الطفل (رضاعة أو صناعي)', en_ing:'Couscous + baby’s milk (breast or formula)',
    prep:['اطبخي الكسكسي لحد ما يطرى خالص.','اخلطيه بشوية من لبن الطفل لقوام ناعم.'],
    en_prep:['Cook the couscous until very soft.','Mix with a little of baby’s milk for a smooth texture.'],
    tags:['جلوتين'], note:'لبن الطفل بس — مش لبن بقري كامل قبل سنة.', en_note:'Baby’s milk only — no whole cow’s milk before age one.' },
  { id:'m8-garlic', e:'🧄', c:'veg', m:6, s:['l','d'],
    n:'توم مهروس (للطعم)', en_n:'Mashed garlic (for flavor)',
    ing:'فص توم صغير', en_ing:'1 small garlic clove',
    prep:['اهرسي فص صغير واطبخيه مع الأكل لحد ما يستوي.'],
    en_prep:['Mash a small clove and cook it into the food until done.'],
    tags:[], note:'كمية صغيرة للطعم — ومن غير ملح.', en_note:'A small amount for flavor — and no salt.' },
  { id:'m8-onion', e:'🧅', c:'veg', m:6, s:['l','d'],
    n:'بصل مفروم مطبوخ', en_n:'Minced cooked onion',
    ing:'بصل', en_ing:'Onion',
    prep:['افرمي البصل ناعم جدًا.','اطبخيه كويس مع الأكل لحد ما يطرى.'],
    en_prep:['Mince the onion very finely.','Cook it well with the food until soft.'],
    tags:[], note:null, en_note:null },
  { id:'m8-molokhia', e:'🥬', c:'veg', m:7, s:['l','d'],
    n:'ملوخية', en_n:'Molokhia',
    ing:'ملوخية خضرا مفرومة + مرقة من غير ملح', en_ing:'Minced green molokhia + unsalted broth',
    prep:['اطبخي الملوخية في مرقة من غير ملح.','التقلية خفيفة جدًا (توم بس) — وقدّميها مع الرز.'],
    en_prep:['Cook the molokhia in unsalted broth.','Keep the garlic fry very light — serve with rice.'],
    tags:[], note:'من غير ملح أو شطة أو مرقة جاهزة.', en_note:'No salt, chili, or stock cubes.' },
  { id:'m8-leek', e:'🌱', c:'veg', m:8, s:['l','d'],
    n:'كرات مطبوخ', en_n:'Cooked leek',
    ing:'كرات (الأبيض والأخضر الفاتح)', en_ing:'Leek (white and light-green parts)',
    prep:['اغسلي الكرات كويس من الرمل وافرميه ناعم.','اطبخيه لحد ما يطرى خالص.'],
    en_prep:['Wash the leek well to remove grit and chop finely.','Cook until completely soft.'],
    tags:[], note:null, en_note:null },
];
MONTH8_FOODS.forEach(f => { FOOD_MAP[f.id] = f; });

/* وجبات الفطار (لفّة أسبوعية) */
const MONTH8_BREAKFASTS = [
  [['f',['m8-dates']], ['s',['m6-semolina']], ['p',['eggyolk']]],                         /* تمر + سميد + صفار بيضة */
  [['v',['broccoli']], ['v',['carrot']], ['d',['yogurt']]],                               /* بروكلي + جزر + زبادي */
  [['v',['spinach']], ['s',['potato']], ['p',['eggyolk']]],                               /* سبانخ + بطاطس + صفار بيض */
  [['s',['sweetpotato','m6-semolina','rice','oat','bulgur','m8-wheatgerm']], ['f',['m8-fig']], ['f',['apricot']], ['p',['m8-peanut']]], /* بطاطا (أو سميد/رز/شوفان/برغل/جنين القمح) + تين + مشمش + سوداني */
  [['s',['pasta']], ['v',['carrot']], ['d',['areesh']]],                                  /* مكرونة + جزر + جبنة قريش */
  [['f',['avocado']], ['v',['spinach']], ['s',['m8-couscous']]],                          /* أفوكادو + سبانخ + كسكسي بلبن الطفل */
  [['s',['oat']], ['v',['zucchini']], ['p',['chicken']]],                                 /* شوفان + كوسة + فراخ */
];
/* الغدا والعشا: 8 أزواج [غدا، عشا] — كل يوم زوج */
const MONTH8_MAINS = [
  [[['s',['rice']], ['v',['m8-molokhia']], ['p',['beef']]],                               /* رز + ملوخية + لحمة */
   [['v',['broccoli']], ['v',['carrot']], ['p',['chicken']]]],                            /* بروكلي + جزر + فراخ */
  [[['s',['rice']], ['v',['carrot']], ['p',['fish']], ['v',['m8-tomato']]],               /* رز + جزر مبشور + سمك + عصير طماطم */
   [['s',['potato']], ['p',['chicken']], ['v',['m8-garlic']], ['v',['m8-leek']]]],        /* بطاطس + فراخ + توم + كرات */
  [[['s',['rice']], ['v',['cauliflower']], ['p',['beef']]],                               /* رز + قرنبيط + لحمة */
   [['v',['spinach']], ['v',['broccoli']], ['s',['pasta']], ['p',['chicken']], ['v',['m8-garlic']], ['v',['m8-onion']]]], /* سبانخ + بروكلي + مكرونة + دجاج مفروم + توم + بصل */
  [[['s',['rice']], ['p',['chicken']], ['p',['chickpea']], ['v',['m8-tomato']]],          /* رز + فراخ + حمص + طماطم */
   [['p',['fish']], ['v',['carrot']], ['v',['zucchini']], ['s',['sweetpotato']]]],       /* سمك فيليه + جزر + كوسة + بطاطا */
  [[['s',['rice']], ['p',['lentil']], ['v',['spinach']]],                                 /* رز + عدس + سبانخ */
   [['s',['potato']], ['v',['zucchini']], ['v',['cauliflower']], ['p',['chicken']]]],    /* بطاطس + كوسة + قرنبيط + فراخ */
  [[['v',['m8-mixedveg']], ['s',['rice']], ['p',['chicken','beef']]],                     /* خضار مشكل + رز + فراخ أو لحمة */
   [['v',['broccoli']], ['s',['m8-corn']], ['p',['fish']]]],                             /* بروكلي + ذرة + سمك */
  [[['v',['spinach']], ['s',['sweetpotato']], ['p',['beef']]],                            /* سبانخ + بطاطا + لحم */
   [['s',['rice']], ['p',['chicken']], ['s',['m8-corn']], ['f',['strawberry','apple']]]], /* رز + فراخ + ذرة + فراولة أو تفاح */
  [[['s',['potato']], ['v',['zucchini']], ['p',['beef']]],                                /* بطاطس + كوسة + لحمة */
   [['p',['chicken']], ['s',['rice']]]],                                                  /* صدر دجاج + رز */
];
const MONTH8_BY_DAY = {};
for (let day = 1; day <= 30; day++) {
  const [lunch, dinner] = MONTH8_MAINS[(day - 1) % MONTH8_MAINS.length];
  MONTH8_BY_DAY[day] = { b: MONTH8_BREAKFASTS[(day - 1) % MONTH8_BREAKFASTS.length], l: lunch, d: dinner };
}

/* ============================================================
   أكلات زيادة عشان البدايل تكمّل مجموعات مامي (فاكهة / خضار غير نشوي / بروتين / نشويات)
   side: true = أكلة مكمّلة (توم، بقدونس، بذور…) بتظهر في البدايل بس، والتطبيق مش بيختارها لوحده كجزء أساسي من الوجبة.
   المجموعة نفسها بتتحدد في generator.js (GROUP_BY_ID / GROUP_BY_CAT).
   ============================================================ */
const GROUP_FOODS = [
  { id:'melon', e:'🍈', c:'fruit', m:6, s:['b','s'],
    n:'شمام مهروس', en_n:'Mashed melon',
    ing:'شمام ناضج', en_ing:'Ripe melon',
    prep:['قشّري الشمام وشيلي البذر.','اهرسيه أو قطّعيه مكعبات صغيرة طرية.'],
    en_prep:['Peel the melon and remove the seeds.','Mash it or cut into small soft cubes.'],
    tags:[], note:null, en_note:null },
  { id:'parsley', e:'🌿', c:'veg', m:8, s:['l','d'], side:true, vitC:true,
    n:'بقدونس مفروم', en_n:'Chopped parsley',
    ing:'بقدونس', en_ing:'Parsley',
    prep:['اغسلي البقدونس وافرميه ناعم جدًا.','اطبخيه مع الأكل أو ضيفيه في الآخر بكمية صغيرة.'],
    en_prep:['Wash and chop the parsley very finely.','Cook it into the food or add a little at the end.'],
    tags:[], note:null, en_note:null },
  { id:'coriander', e:'🌿', c:'veg', m:8, s:['l','d'], side:true,
    n:'كزبرة خضرا مفرومة', en_n:'Chopped fresh coriander',
    ing:'كزبرة خضرا', en_ing:'Fresh coriander',
    prep:['اغسلي الكزبرة وافرميها ناعم جدًا.','اطبخيها مع الأكل بكمية صغيرة.'],
    en_prep:['Wash and chop the coriander very finely.','Cook a small amount into the food.'],
    tags:[], note:null, en_note:null },
  { id:'dill', e:'🌿', c:'veg', m:8, s:['l','d'], side:true,
    n:'شبت مفروم', en_n:'Chopped dill',
    ing:'شبت', en_ing:'Dill',
    prep:['اغسلي الشبت وافرميه ناعم جدًا.','ضيفيه للأكل بكمية صغيرة للطعم.'],
    en_prep:['Wash and chop the dill very finely.','Add a little to the food for flavor.'],
    tags:[], note:null, en_note:null },
  { id:'okra', e:'🥒', c:'veg', m:6, s:['l','d'],
    n:'بامية مطبوخة مهروسة', en_n:'Cooked mashed okra',
    ing:'بامية صغيرة + طماطم + مرقة خضار من غير ملح', en_ing:'Small okra + tomato + unsalted vegetable broth',
    prep:['اغسلي البامية وقطّعي الراس.','اطبخيها في طماطم ومرقة خضار من غير ملح لحد ما تطرى خالص، واهرسيها.'],
    en_prep:['Wash the okra and trim the tops.','Cook in tomato and unsalted vegetable broth until very soft, then mash.'],
    tags:[], note:null, en_note:null },
  { id:'cabbage', e:'🥬', c:'veg', m:7, s:['l','d'],
    n:'كرنب مطبوخ', en_n:'Cooked cabbage',
    ing:'كرنب', en_ing:'Cabbage',
    prep:['قطّعي الكرنب واسلقيه لحد ما يطرى خالص.','اهرسيه مع الأكل.'],
    en_prep:['Chop the cabbage and boil until very soft.','Mash it into the meal.'],
    tags:[], note:'ممكن يعمل غازات — ابدئي بكمية صغيرة.', en_note:'Can cause gas — start with a small amount.' },
  { id:'labneh', e:'🥛', c:'dairy', m:12, s:['b','s','d'],
    n:'لبنة بيتي (زبادي متصفّي)', en_n:'Homemade labneh (strained yogurt)',
    ing:'زبادي طبيعي مبستر', en_ing:'Plain pasteurized yogurt',
    prep:['صفّي الزبادي في قماشة نضيفة لحد ما يتقل.','قدّميها من غير ملح.'],
    en_prep:['Strain the yogurt in a clean cloth until thick.','Serve with no salt.'],
    tags:['ألبان'], note:'بيتي ومن غير ملح — اللبنة الجاهزة فيها ملح كتير.', en_note:'Homemade and unsalted — store-bought labneh is very salty.' },
  { id:'seeds', e:'🌻', c:'protein', m:7, s:['b','l','d'], side:true, iron:true,
    n:'بذور مطحونة (شيا أو قرع أو عباد الشمس أو سمسم)', en_n:'Ground seeds (chia, pumpkin, sunflower or sesame)',
    ing:'بذور من غير ملح', en_ing:'Unsalted seeds',
    prep:['اطحني البذور لحد ما تبقى بودرة ناعمة.','رشّي ملعقة صغيرة على الأكل وقلّبي.'],
    en_prep:['Grind the seeds into a fine powder.','Sprinkle a teaspoon over the food and stir.'],
    tags:['مكسرات'], note:'مطحونة بس — البذور الكاملة ممكن تزوّر. السمسم ممكن يعمل حساسية: ابدئي بكمية صغيرة وراقبي.',
    en_note:'Ground only — whole seeds can choke. Sesame can cause allergy: start small and watch.' },
  { id:'wholewheat', e:'🌾', c:'grain', m:6, s:['b','l'], iron:true,
    n:'قمح كامل مسلوق (بليلة من غير سكر)', en_n:'Boiled whole wheat (unsweetened)',
    ing:'قمح كامل', en_ing:'Whole wheat grains',
    prep:['انقعي القمح من الليل واسلقيه لحد ما يطرى خالص.','اهرسيه أو اطحنيه ناعم.'],
    en_prep:['Soak the wheat overnight and boil until very soft.','Mash or grind it smooth.'],
    tags:['جلوتين'], note:null, en_note:null },
  { id:'artichoke', e:'🥬', c:'veg', m:6, s:['l','d'],
    n:'خرشوف مطبوخ مهروس', en_n:'Cooked mashed artichoke',
    ing:'قلوب خرشوف', en_ing:'Artichoke hearts',
    prep:['اطبخي قلوب الخرشوف لحد ما تطرى خالص.','اهرسيها ناعم.'],
    en_prep:['Cook the artichoke hearts until very soft.','Mash smooth.'],
    tags:[], note:null, en_note:null },
  { id:'greenbeans', e:'🌱', c:'veg', m:6, s:['l','d'],
    n:'فاصوليا خضرا مطبوخة', en_n:'Cooked green beans',
    ing:'فاصوليا خضرا', en_ing:'Green beans',
    prep:['شيلي الأطراف والخيوط.','اسلقيها لحد ما تطرى خالص واهرسيها.'],
    en_prep:['Trim the ends and strings.','Boil until very soft and mash.'],
    tags:[], note:null, en_note:null },
  { id:'taro', e:'🥔', c:'veg', m:6, s:['l','d'],
    n:'قلقاس مطبوخ مهروس', en_n:'Cooked mashed taro',
    ing:'قلقاس', en_ing:'Taro',
    prep:['قشّري القلقاس (بجوانتي عشان بيهرش الإيد) وقطّعيه.','اسلقيه كويس جدًا لحد ما يستوي خالص واهرسيه.'],
    en_prep:['Peel the taro (wear gloves, it itches) and cut it up.','Boil very well until fully cooked, then mash.'],
    tags:[], note:'لازم يستوي كويس جدًا — ميتاكلش نيّ أو نص سوا.', en_note:'Must be fully cooked — never raw or undercooked.' },
  { id:'beetroot', e:'🍠', c:'veg', m:6, s:['l','d'],
    n:'بنجر مسلوق مهروس', en_n:'Boiled mashed beetroot',
    ing:'بنجر', en_ing:'Beetroot',
    prep:['اسلقي البنجر بقشره لحد ما يطرى، وبعدين قشّريه.','اهرسيه ناعم.'],
    en_prep:['Boil the beetroot in its skin until soft, then peel.','Mash smooth.'],
    tags:[], note:'ممكن يلوّن البول أو البراز أحمر — ده طبيعي.', en_note:'May turn urine or stool red — that’s normal.' },
];
GROUP_FOODS.forEach(f => { FOODS.push(f); FOOD_MAP[f.id] = f; });
/* أكلات الجداول الثابتة اللي في مجموعات مامي بتبقى بدايل لكل الأعمار كمان */
MONTH6_SEMOLINA.s = ['b', 'l', 'd'];
['m8-tomato', 'm8-garlic', 'm8-onion', 'm8-wheatgerm'].forEach(id => { FOOD_MAP[id].side = true; });
FOOD_MAP['m8-molokhia'].iron = true;
FOOD_MAP['m8-tomato'].vitC = true;
['m6-semolina', 'm8-dates', 'm8-fig', 'm8-tomato', 'm8-garlic', 'm8-onion', 'm8-leek', 'm8-molokhia', 'm8-corn', 'm8-wheatgerm']
  .forEach(id => FOODS.push(FOOD_MAP[id]));

/* ============================================================
   السناك بعد السنة 🍪 (قايمة مامي) — بين الوجبات الكاملة ومن السنة بس.
   الفاكهة والخيار موجودين فوق، ودول الباقي. بدايل السناك من نفس القايمة (generator.js: SNACK_IDS)
   ============================================================ */
const SNACK_FOODS = [
  { id:'snack-tomato', e:'🍅', c:'veg', m:12, s:['s'],
    n:'ثمرة طماطم صغيرة مقطعة', en_n:'Small tomato, cut up',
    ing:'طماطم صغيرة ناضجة', en_ing:'A small ripe tomato',
    prep:['اغسلي الطماطم وقطّعيها حتت صغيرة (أرباع لو شيري).'],
    en_prep:['Wash the tomato and cut it into small pieces (quarters if cherry).'],
    tags:[], note:'الطماطم الشيري لازم تتقطع أرباع — الحبة الكاملة ممكن تزوّر.', en_note:'Cherry tomatoes must be quartered — whole ones can choke.' },
  { id:'homebiscuit', e:'🍪', c:'snack', m:12, s:['s'],
    n:'بسكوت صحي بيتي (شوفان وموز)', en_n:'Healthy homemade biscuits (oat & banana)',
    ing:'موزة ناضجة + نص كوب شوفان (+ رشة قرفة)', en_ing:'1 ripe banana + ½ cup oats (+ a pinch of cinnamon)',
    prep:['اهرسي الموزة واخلطيها بالشوفان.','شكّليها أقراص صغيرة واخبزيها 15 دقيقة على 180 درجة.','سيبيها تبرد — هتبقى طرية من جوه.'],
    en_prep:['Mash the banana and mix with the oats.','Shape small rounds and bake 15 minutes at 180°C.','Let cool — they stay soft inside.'],
    tags:[], note:'من غير سكر أو ملح — البيتي أفيد بكتير من الجاهز.', en_note:'No sugar or salt — homemade beats store-bought.' },
  { id:'vegchips', e:'🍠', c:'snack', m:12, s:['s'],
    n:'شيبسي خضار بيتي (بطاطا أو جزر) في الفرن', en_n:'Homemade baked veggie chips (sweet potato or carrot)',
    ing:'بطاطا أو جزر + نقطة زيت زيتون', en_ing:'Sweet potato or carrot + a drop of olive oil',
    prep:['قطّعي البطاطا أو الجزر شرائح رفيعة.','ادهنيها بنقطة زيت واخبزيها لحد ما تحمر وتطرى.','قدّميها دافية من غير ملح.'],
    en_prep:['Slice the sweet potato or carrot thinly.','Brush with a drop of oil and bake until golden and tender.','Serve warm, without salt.'],
    tags:[], note:'خليها طرية شوية — الشرايح الناشفة أوي ممكن تزوّر. وخليكي جنبه وهو بياكل.', en_note:'Keep them a little soft — very dry crisps can choke. Stay with baby while eating.' },
  { id:'milkfruit', e:'🥛', c:'snack', m:12, s:['s'],
    n:'كوب لبن متوسط + ثمرة فاكهة كبيرة من الموسم', en_n:'Medium cup of milk + a large seasonal fruit',
    ing:'كوب لبن (أو رضعة) + فاكهة الموسم', en_ing:'A cup of milk (or a feed) + seasonal fruit',
    prep:['كوب لبن متوسط أو رضعة.','ومعاه ثمرة فاكهة كبيرة مقطعة حتت مناسبة.'],
    en_prep:['A medium cup of milk or a milk feed.','With a large seasonal fruit cut into safe pieces.'],
    tags:['ألبان'], note:null, en_note:null },
  { id:'homedanette', e:'🍮', c:'snack', m:12, s:['s'],
    n:'دانيت بيتي (بودينج لبن)', en_n:'Homemade pudding (Danette-style)',
    ing:'كوب لبن + ملعقة نشا + موز أو تمر للتحلية (+ كاكاو اختياري)', en_ing:'1 cup milk + 1 tbsp cornstarch + banana or dates to sweeten (+ optional cocoa)',
    prep:['قلّبي اللبن مع النشا على نار هادية لحد ما يتقل.','حلّيه بموز مهروس أو تمر بدل السكر.','سيبيه يبرد في التلاجة.'],
    en_prep:['Stir the milk with the starch over low heat until thick.','Sweeten with mashed banana or dates instead of sugar.','Chill in the fridge.'],
    tags:['ألبان'], note:'من غير سكر قبل سنتين — حلّيه بالفاكهة.', en_note:'No added sugar before age two — sweeten with fruit.' },
  { id:'homeicecream', e:'🍦', c:'snack', m:12, s:['s'],
    n:'آيس كريم بيتي (موز وزبادي)', en_n:'Homemade ice cream (banana & yogurt)',
    ing:'موز مجمد + شوية زبادي', en_ing:'Frozen banana + a little yogurt',
    prep:['جمّدي حتت موز.','اضربيها في الخلاط مع شوية زبادي لحد ما تبقى كريمي.','قدّميه على طول.'],
    en_prep:['Freeze banana pieces.','Blend with a little yogurt until creamy.','Serve right away.'],
    tags:['ألبان'], note:'من غير سكر.', en_note:'No added sugar.' },
  { id:'snack-milk', e:'🍼', c:'milk', m:12, s:['s'],
    n:'رضعة', en_n:'Milk feed',
    ing:'رضاعة طبيعية أو كوب لبن', en_ing:'Breastfeed or a cup of milk',
    prep:['رضعة أو كوب لبن بدل السناك.'],
    en_prep:['A milk feed or a cup of milk instead of the snack.'],
    tags:[], note:null, en_note:null },
];
SNACK_FOODS.forEach(f => { FOODS.push(f); FOOD_MAP[f.id] = f; });

/* ============================================================
   نصايح كل مرحلة عمرية (سلامة وتغذية) — عربي + English
   ============================================================ */
const TIPS = {
  start: {
    ar: [
      '🍼 الرضاعة (طبيعية أو صناعي) تفضل هي الأساس لحد سننة — الأكل الصلب مكمّل مش بديل.',
      '🩸 الأطعمة الأولى لازم تكون غنية بالحديد: حبوب أطفال مدعمة، لحوم، أو بدائل لحوم — حديد في كل وجبة.',
      '🍊 قدّمي جنب الأطعمة الغنية بالحديد فاكهة/خضار فيه فيتامين C (مانجو، كيوي، فلفل، بطاطا، بروكلي) — بتضاعف امتصاص الحديد.',
      '🚫 مفيش ملح ولا سكر ولا عسل — والعسل ممنوع تمامًا قبل السنة.',
      '👀 راقبي علامات التحسس: احمرار حوالين الفم، طفح، تقيؤ، إسهال، بكاء أكثر من المعتاد — ممكن تظهر فورًا أو بعد أيام.',
      '🧠 تقسيم المسؤولية: أنتي مسؤولة عن إيه يتقدم وإتى — والبيبي مسؤوله عن هل ياكل وكم. ماتغطريش عليه أبدًا.',
      '⚠️ التطبيق إرشادي مبني على إرشادات WHO والأكاديمية الأمريكية لطب الأطفال (AAP) — راجعي طبيب الأطفال قبل البدء.',
    ],
    en: [
      '🍼 Milk (breast or formula) stays the base until age one — solids complement, never replace.',
      '🩸 First foods must be iron-rich: iron-fortified baby cereal, meats, or meat alternatives — iron at every meal.',
      '🍊 Pair iron-rich foods with vitamin-C fruits/veg (mango, kiwi, bell pepper, sweet potato, broccoli) — it boosts iron absorption.',
      '🚫 No salt, no sugar, no honey — honey is strictly off before 12 months.',
      '👀 Watch for allergy signs: redness around the mouth, rash, vomiting, diarrhea, unusual crying — can appear right away or days later.',
      '🧠 Division of responsibility: you decide what and when is offered — baby decides whether and how much. Never force-feed.',
      '⚠️ This app follows WHO & American Academy of Pediatrics (AAP) guidance — still check with your pediatrician before starting.',
    ],
  },
  hunger: {
    ar: ['🤱 علامات الجوع: يميل للأمام أو يمد يده للطعام، يرضع شفتيه، يفتح فمه عند عرض الأكل، يضع قبضته في فمه.',
         '😊 علامات الشبع: يُشيح برأسه، يغلق فمه، يغطي فمه بإيده، يتهيج أو يبكي — احترميها وماتغطريش عليه.'],
    en: ['🤱 Hunger signs: leans forward or reaches for food, sucks lips, opens mouth when food offered, fists in mouth.',
         '😊 Fullness signs: turns head away, closes mouth, covers mouth with hand, gets fussy or cries — respect them, never force-feed.'],
  },
  drinks: {
    ar: ['🥤 المشروبات المسموحة قبل سنتين حاجتين بس: الحليب والماء.',
         '🚫 مشروبات ممنوعة قبل سنتين: العصائر (حتى الطبيعي)، الصويا والمشروبات النباتية (لوز/شوفان/أرز/جوز هند)، الحليب قليل الدسم (1-2%)، الغازيات، القهوة والشاي والمشروبات المنكهة والرياضية.',
         '🥛 الحليب البقري العادي كامل الدسم (3.25%) من عمر سنة كحد أقصى 500 مل.'],
    en: ['🥤 Before age two only two drinks: milk and water.',
         '🚫 Off-limits before two: juices (even fresh), soy and plant drinks (almond/oat/rice/coconut), low-fat milk (1-2%), pop, coffee, tea, flavored and sports drinks.',
         '🥛 Regular whole-fat (3.25%) cow milk from age one, up to 500 ml.'],
  },
  6: {
    ar: ['🥄 الشهر السادس: وجبة واحدة في اليوم (الفطار) — معالق صغيرة من الخضار والفاكهة، والباقي رضاعة.',
         '🔁 كل صنف جديد قدّميه مع صنف قديم مألوف لمدة 3 أيام قبل الجديد اللي بعده.',
         '🥚 أول بروتين في آخر يوم في الشهر: ربع صفار بيضة مع الأرز والكوسة.',
         '🥕 أكلات الشهر بالترتيب: كوسة، جزر، فلفل ألوان، بطاطس، بطاطا، بروكلي، قرع عسلي، بنجر، تفاح، وأرز.',
         '👩‍🍳 نفس الخضار بيتعمل بطرق مختلفة: على البخار، مسلوق، ومشوي — عشان البيبي يتعود على الطعم والقوام.',
         '🥤 المية طول اليوم بكوب تدريب — رشفات صغيرة، والحليب هو الأساس.'],
    en: ['🥄 Month six: one meal a day (breakfast) — small spoons of vegetables and fruit; everything else is milk.',
         '🔁 Pair every new food with a familiar one for 3 days before the next new food.',
         '🥚 The first protein comes on the last day: a quarter egg yolk with rice and zucchini.',
         '🥕 This month’s foods in order: zucchini, carrot, bell peppers, potato, sweet potato, broccoli, pumpkin, beetroot, apple and rice.',
         '👩‍🍳 The same vegetable is cooked different ways — steamed, boiled, roasted — so baby gets used to tastes and textures.',
         '🥤 Water all day from a training cup — little sips, milk stays the base.'],
  },
  7: {
    ar: ['🍽️ وجبتان متكاملتان يوميًا: الفطار (بروتين + نشويات + فاكهة) + الغدا (خضار + بروتين + نشويات).',
         '🍼 مفيش عشا — بعد الوجبتين الرضاعات بس: الضحى والعصر وقبل النوم.',
         '🥩 وقت اللحوم والبيض: لحم أحمر صافي، عدس، صفار بيض، والبيضة الكاملة — أغنى مصادر الحديد.',
         '🥄 القوام يتحول لمهروس خشن فيه تكتلات ناعمة — البيبي بيتعلم المضغ.',
         '🤲 خلّيه يمسك أصابع طعام لينة (بطاطا مسلوقة، موزة) — بداية الأكل الذاتي.'],
    en: ['🍽️ TWO complete meals daily: breakfast (protein + starch + fruit) + lunch (veg + protein + starch).',
         '🍼 No dinner — after the two meals it’s milk feeds only: mid-morning, afternoon and bedtime.',
         '🥩 Meat and egg time: lean red meat, lentils, egg yolk and the whole egg — the richest iron sources.',
         '🥄 Move to mashed with soft lumps — baby is learning to chew.',
         '🤲 Let baby grab soft finger foods (boiled sweet potato, banana) — self-feeding begins.'],
  },
  8: {
    ar: ['🍽️ ثلاث وجبات متكاملة يوميًا: فطار + غدا + عشا — كل واحدة (خضار/فاكهة + بروتين + نشويات).',
         '🍼 مفيش سناك قبل السنة — بين الوجبات رضعات: الضحى والعصر وقبل النوم.',
         '🥩 اللحوم الحمراء والدواجن والأسماك بقوا أساسيين: لحوم بلدية مفرومة، ريش وموزات، بلطي مسلوق، جمبري مجروش.',
         '👉 أطعمة أصابع ممتازة: بطاطا مسلوقة، موزة، أصابع عيش توست، مكرونة صغيرة، زهيرات بروكلي.',
         '🍓 فواكه جديدة: توت أزرق، أناناس، تين.',
         '🔁 صنف جديد كل 2-3 أيام مع صنف مألوف — وسيبيه يوسخ ويتعلم 😄'],
    en: ['🍽️ THREE complete meals daily: breakfast + lunch + dinner — each (veg/fruit + protein + starch).',
         '🍼 No snacks before age one — milk feeds between meals: mid-morning, afternoon and bedtime.',
         '🥩 Red meat, poultry and fish are now central: local minced beef, small chops, tilapia, crushed shrimp.',
         '👉 Great finger foods: boiled sweet potato, banana, toast fingers, small pasta, soft broccoli.',
         '🍓 New fruits: blueberries, pineapple, figs.',
         '🔁 One new food every 2-3 days alongside a familiar one — and let the mess happen 😄'],
  },
  9: {
    ar: ['🔪 القوام الرسمي الجديد: مفروم، مبشور، ومقطع مكعبات ناعمة — طالما بيقعد لوحده وبدأ يحرك فكه.',
         '👉 أطعمة بالإصبع ممتازة: مكرونة صغيرة مسلوقة، بيض مسلوق مقطع، أصابع بطاطا مسلوقة، تفاح مبشور أو مسلوق.',
         '🐟 السمك الأبيض من غير شوك يدخل الغدا.',
         '🍽️ 3 وجبات متكاملة (فطار + غدا + عشا) + رضعات — مفيش سناك قبل السنة.'],
    en: ['🔪 Official new textures: minced, grated, and soft cubes — once baby sits alone and starts chewing.',
         '👉 Great finger foods: small soft pasta, chopped boiled egg, boiled sweet-potato sticks, grated or cooked apple.',
         '🐟 Boneless white fish joins lunch.',
         '🍽️ 3 complete meals (breakfast + lunch + dinner) + milk feeds — no snacks before age one.'],
  },
  10: {
    ar: ['🌈 نوّعي الألوان في الطبق — كل لون مجموعة فيتامينات مختلفة.',
         '🍲 أكل البيت يبدأ يدخل مقطع صغير: يخنة، شوربة، رز بالخضار.',
         '🥤 كوب المياه بقى عادة مع كل وجبة.'],
    en: ['🌈 Vary plate colors — each color brings different vitamins.',
         '🍲 Family food enters, cut small: stews, soups, veggie rice.',
         '🥤 Water with every meal is now a habit.'],
  },
  11: {
    ar: ['🥄 سيبيه يجرب الملعقة لوحده حتى لو اتوسخ — المهارات أهم من النضافة.',
         '📅 روتين ثابت للوجبات بيرتب إحساس الجوع والهضم.',
         '🍼 الرضاعة بتقل تدريجيًا مع زيادة الأكل الصلب.'],
    en: ['🥄 Let baby try the spoon solo, mess included — skills over cleanliness.',
         '📅 A fixed meal rhythm organizes appetite and digestion.',
         '🍼 Milk feeds naturally taper as solids grow.'],
  },
  12: {
    ar: ['🎂 مبروك سنة! البيبي ياكل أكل العيلة المقطع تقريبًا كله.',
         '🥛 الحليب البقري كامل الدسم بقى الشراب الأساسي (350-500 مل/يوم كحد أقصى).',
         '🍯 العسل بقى مسموح، ومعاه اللبنة والجبنة الطبيعية.',
         '🍽️ 3 وجبات كاملة + سناكين بين الوجبات + حليب. السناك: فاكهة، خيار أو طماطم، بسكوت بيتي، شيبسي خضار، كوب لبن + فاكهة، دانيت أو آيس كريم بيتي، أو رضعة.'],
    en: ['🎂 Happy first year! Baby now eats almost all family food, cut small.',
         '🥛 Whole cow milk becomes the main drink (350–500 ml/day max).',
         '🍯 Honey is now allowed — and so are labneh and natural cheese.',
         '🍽️ 3 complete meals + 2 snacks between them + milk. Snacks: fruit, cucumber or tomato, homemade biscuits, veggie chips, milk + fruit, homemade pudding or ice cream, or a milk feed.'],
  },
  18: {
    ar: ['🤲 خلّيه يختار بين خيارين صحيين — الاختيار بيحسن الشهية.',
         '🌯 ساندوتشات وشاورما ولفات بيتي — الأطفال بيجننوا بالأكل اللي بيمسكوه.',
         '🧁 حلى طبيعي: كيك الموز، مهلبية، فواكه — بدل السكاكر الصناعية.'],
    en: ['🤲 Offer two healthy choices — choosing improves appetite.',
         '🌯 Sandwiches, wraps and homemade shawarma — toddlers love handheld food.',
         '🧁 Natural treats: banana cake, mahalabia, fruit — instead of candy.'],
  },
  24: {
    ar: ['🌅 من سنتين اليوم بيبدأ بالفطار على طول — من غير رضاعة الصحيان.',
      '👨‍👩‍👧 اقعدوا كلكم على السفرة — البيبي بيقلد الكبار أحسن من أي نصيحة.',
      '🍛 أكل العيلة الكامل: يخنة، محشي، كشري خفيف — مقطع مناسب.',
      '🥜 المكسرات مطحونة أو زبدة بس — الحبة الكاملة ممنوعة لسه.',
      '🚫 العصائر والمشروبات الغازية والمنكهة لسه ممنوعة — حليب وماء.'],
    en: ['🌅 From age two the day starts straight with breakfast — no wake-up milk feed.',
      '👨‍👩‍👧 Eat together — copying adults beats any advice.',
      '🍛 Full family food: stews, mahshi, light koshari — cut to size.',
      '🥜 Nuts only ground or as butter — whole nuts still forbidden.',
      '🚫 Juice, pop and flavored drinks stay off — milk and water only.'],
  },
};

function tipsFor(m) {
  let stage;
  if (m <= 6) stage = TIPS[6];
  else if (m <= 7) stage = TIPS[7];
  else if (m <= 8) stage = TIPS[8];
  else if (m <= 9) stage = TIPS[9];
  else if (m <= 10) stage = TIPS[10];
  else if (m <= 11) stage = TIPS[11];
  else if (m <= 17) stage = TIPS[12];
  else if (m <= 23) stage = TIPS[18];
  else stage = TIPS[24];
  return {
    ar: [...TIPS.start.ar, ...stage.ar, ...TIPS.hunger.ar, ...TIPS.drinks.ar],
    en: [...TIPS.start.en, ...stage.en, ...TIPS.hunger.en, ...TIPS.drinks.en],
  };
}





/* تصنيفات قائمة التسوق */
const CAT_LABEL = {
  fruit:   { ar: '🍎 فواكه',    en: '🍎 Fruits' },
  veg:     { ar: '🥬 خضار',     en: '🥬 Vegetables' },
  grain:   { ar: '🍞 حبوب ونشويات', en: '🍞 Grains' },
  protein: { ar: '🍗 بروتين',    en: '🍗 Protein' },
  dairy:   { ar: '🥛 ألبان',    en: '🥛 Dairy' },
  dish:    { ar: '🍲 أطباق',    en: '🍲 Dishes' },
  snack:   { ar: '🍰 سناكات',   en: '🍰 Snacks' },
  milk:    { ar: '🍼 حليب',     en: '🍼 Milk' },
};

/* منحنيات نمو استرشادية تقريبية (مستوحاة من منظمة الصحة العالمية) — نقاط كل 3 شهور من 0 لـ 36 */


/* ============================================================
   🍽️ مواصفات الوجبة الكاملة — جدول مامي: كل صنف من إمتى
   نص الوجبة خضار وفاكهة + ربع بروتين + ربع نشويات
   الألوان حسب الشهر: ٦ أصفر ← ٧ تحته ← ٨ آخر حاجة في الجدول
   (اللي من غير رقم في جدولها = من ٦ شهور، واللي تحت عنوان عليه رقم بياخد رقم العنوان)
   ============================================================ */
const MEAL_SPEC = {
  cols: [
    { k: 'p',  e: '🍗', ar: 'بروتين',      en: 'Protein',     share: { ar: 'ربع الوجبة', en: 'A quarter' } },
    { k: 'vf', e: '🥦', ar: 'خضار وفاكهة', en: 'Veg & fruit', share: { ar: 'نص الوجبة',  en: 'Half' } },
    { k: 's',  e: '🍠', ar: 'نشويات',      en: 'Starches',    share: { ar: 'ربع الوجبة', en: 'A quarter' } },
  ],
  months: [
    { m: 6,
      p: [
        { ar: 'حيواني', en: 'Animal', items: [['زبادي عادي ويوناني', 'Plain & Greek yogurt'], ['بيض', 'Eggs'], ['كبدة فراخ', 'Chicken liver'], ['جبنة قريش', 'Cottage cheese']] },
        { ar: 'نباتي', en: 'Plant', items: [['مشروم', 'Mushrooms']] },
      ],
      vf: [
        { ar: 'خضار', en: 'Vegetables', items: [['كوسة', 'Zucchini'], ['باذنجان', 'Eggplant'], ['خيار', 'Cucumber'], ['فلفل أخضر وألوان', 'Bell peppers'], ['بروكلي', 'Broccoli'], ['قرنبيط', 'Cauliflower'], ['بصل وثوم', 'Onion & garlic'], ['طماطم', 'Tomato'], ['بامية', 'Okra']] },
        { ar: 'فاكهة', en: 'Fruit', items: [['تفاح', 'Apple'], ['موز', 'Banana'], ['تمر', 'Dates'], ['بطيخ', 'Watermelon'], ['مشمش', 'Apricot'], ['برقوق', 'Plum'], ['خوخ', 'Peach'], ['مانجا', 'Mango'], ['فراولة', 'Strawberry'], ['عنب', 'Grapes'], ['جوافة', 'Guava'], ['كمثرى', 'Pear'], ['كيوي', 'Kiwi'], ['برتقال', 'Orange'], ['كنتالوب', 'Cantaloupe'], ['شمام', 'Melon'], ['فاكهة مجففة', 'Dried fruit']] },
      ],
      s: [
        { ar: 'خضار نشوي', en: 'Starchy veg', items: [['بطاطس', 'Potato'], ['بطاطا', 'Sweet potato'], ['جزر', 'Carrot'], ['قرع', 'Pumpkin'], ['قلقاس', 'Taro'], ['بنجر', 'Beetroot'], ['خرشوف', 'Artichoke'], ['بازلاء', 'Peas'], ['فاصوليا خضراء', 'Green beans']] },
        { ar: 'حبوب كاملة', en: 'Whole grains', items: [['شوفان', 'Oats'], ['أرز بني', 'Brown rice'], ['أرز بسمتي أصفر', 'Yellow basmati rice'], ['قمح كامل', 'Whole wheat'], ['فريك', 'Freekeh'], ['برغل', 'Bulgur'], ['سميد', 'Semolina'], ['كينوا', 'Quinoa'], ['دخن', 'Millet'], ['حنطة سوداء', 'Buckwheat'], ['ذرة صفرا وبيضا', 'Yellow & white corn']] },
      ] },
    { m: 7,
      p: [
        { ar: 'حيواني', en: 'Animal', items: [['لحمة من غير دهن', 'Lean meat'], ['فراخ', 'Chicken'], ['أرانب', 'Rabbit'], ['بط', 'Duck']] },
        { ar: 'نباتي', en: 'Plant', items: [['مكسرات مطحونة', 'Ground nuts'], ['بذور شيا', 'Chia seeds'], ['بذور قرع وعباد مطحونة', 'Ground pumpkin & sunflower seeds'], ['سمسم', 'Sesame']] },
        { ar: 'بقوليات', en: 'Legumes', items: [['لوبيا', 'Black-eyed peas'], ['فاصوليا بيضا وحمرا', 'White & red beans'], ['عدس', 'Lentils'], ['حمص', 'Chickpeas'], ['ترمس', 'Lupini beans'], ['فول', 'Fava beans']] },
      ],
      vf: [
        { ar: 'خضراوات ورقية', en: 'Leafy greens', items: [['ملوخية', 'Molokhia'], ['سبانخ', 'Spinach'], ['كرنب', 'Cabbage'], ['كابوتشا', 'Cappuccio cabbage']] },
      ],
      s: [
        { items: [['مكرونة', 'Pasta']] },
      ] },
    { m: 8,
      p: [
        { ar: 'حيواني', en: 'Animal', items: [['سمك', 'Fish'], ['جمبري وسبيط', 'Shrimp & squid'], ['لبن في الطبخ بس', 'Milk in cooking only']] },
      ],
      vf: [],
      s: [] },
  ],
  /* فوق السنة — برّه الجدول عشان الـ ٨ تفضل آخر حاجة فيه */
  overOne: {
    items: [['لبنة', 'Labneh'], ['جبنة طبيعية', 'Natural cheese'], ['كبدة بلدي', 'Beef liver'], ['لبن بدل الحليب الصناعي', 'Milk instead of formula'], ['سموذي', 'Smoothies']],
    note: { ar: 'منتجات الألبان لازم تكون مبسترة وكاملة الدسم وقصيرة الأجل.', en: 'Dairy must be pasteurized, full-fat and short shelf-life.' },
  },
  notes: [
    { e: '🧀', ar: 'الجبنة القريش من إتمام السادس، بعد ما البيبي يجرّب الخضار والفاكهة والحبوب الكاملة. لو جاهزة لازم تكون مبسترة كاملة الدسم وتتنقع في مية قبل الأكل، ولو مش متاحة كده اعمليها في البيت أو استخدمي زبادي يوناني وهتدي نفس النتيجة.',
      en: 'Cottage cheese comes after 6 months, once baby has tried vegetables, fruit and whole grains. Store-bought must be pasteurized and full-fat and soaked in water before eating; otherwise make it at home or use Greek yogurt for the same result.' },
    { e: '🫘', ar: 'البروتين النباتي يفضل دايمًا يتقدم مع حبوب كاملة عشان البيبي ياخد أكبر استفادة منه.', en: 'Serve plant protein with a whole grain so baby gets the most out of it.' },
    { e: '🍚', ar: 'الأرز الأبيض مناسب، بس مش من الحبوب الكاملة — يفضل منكترش منه.', en: 'White rice is fine but it is not a whole grain — keep it occasional.' },
    { e: '🍝', ar: 'المكرونة: أي نوع معمول من سيمولينا أو شوفان أو قمح كامل، ومن غير إضافات.', en: 'Pasta: any kind made from semolina, oats or whole wheat, with no additives.' },
    { e: '🌴', ar: 'الفاكهة المجففة: تمرة واحدة في اليوم كفاية، ومنكترش منها عشان فيها مواد حافظة.', en: 'Dried fruit: one date a day is enough — don’t overdo it, it has preservatives.' },
    { e: '🥜', ar: 'المكسرات والبذور تتقدم مطحونة أو زبدة بس، والعنب يتقطع أرباع — عشان الاختناق.', en: 'Nuts and seeds only ground or as butter, and grapes cut in quarters — to prevent choking.' },
    { e: '🍎', ar: 'أي فاكهة أو خضار مش مكتوبة في الجدول جربوها عادي، ولو حصل تحسس أجّليها شهر كامل وجربي تاني كمية بسيطة.', en: 'Any fruit or vegetable not in the table can be tried as usual; if a reaction happens, wait a full month and retry a small amount.' },
  ],
  /* 💡 نصايح هامة (من صورة مامي) — متظبطة على قواعد التطبيق: المكسرات مطحونة، والجبنة بعد السنة، ومفيش مشروبات منكهة قبل سنتين */
  tips: [
    { e: '🍲', ar: 'قدّمي الأكل اللي بيحبه جنب الأكل اللي كان بيرفضه قبل كده.', en: 'Serve a food your baby loves next to one they used to refuse.' },
    { e: '🥜', ar: 'زوّدي قيمة الوجبة بإضافات زي المكسرات المطحونة والزبادي والكريمة.', en: 'Boost a meal with extras like ground nuts, yogurt and cream.' },
    { e: '🐟', ar: 'لو رافض اللحمة، قدّميله فراخ أو ديك رومي أو سمك.', en: 'If beef is refused, offer chicken, turkey or fish.' },
    { e: '🥛', ar: 'لو رافض الحليب، قدّميله زبادي — ومن بعد السنة جبنة كمان.', en: 'If milk is refused, offer yogurt — and cheese too after age one.' },
    { e: '🥕', ar: 'لو رافض الأكل الأخضر، قدّميله أكل أصفر أو برتقاني زي الجزر والبطاطا.', en: 'If green foods are refused, offer yellow or orange ones like carrot and sweet potato.' },
    { e: '💗', ar: 'خليكي مرنة — متقلقيش لو رفض وجبة.', en: 'Stay flexible — don’t worry if a meal is refused.' },
    { e: '🛒', ar: 'اشتري أنواع كتير من الأكل اللي عاوزاه ياكله، ومتخافيش تجربي أصناف جديدة.', en: 'Buy a wide variety of the foods you want them to eat, and don’t be afraid to try new ones.' },
    { e: '😊', ar: 'زيّني الطبق: قطّعي الأكل أشكال حلوة أو اعملي منه وش بيضحك.', en: 'Make the plate fun: cut food into nice shapes or a smiley face.' },
    { e: '🥄', ar: 'خليه يشاركك في تحضير الأكل وتجهيز السفرة — ده بيخلّي الأكل وقت ممتع.', en: 'Let them help prepare food and set the table — it makes mealtime fun.' },
    { e: '🔁', ar: 'كرري تقديم الأكل اللي بيرفضه — ممكن يحتاج محاولات كتير قبل ما يتقبله.', en: 'Keep offering refused foods — it can take many tries before they’re accepted.' },
    { e: '🥗', ar: 'كوني قدوة ليه: كُلي قدامه أنواع مختلفة من الأكل الصحي.', en: 'Be the role model: eat a variety of healthy food in front of them.' },
    { e: '🍎', ar: 'سيبيه يختار بنفسه اللي عاوزه من الأكل الصحي.', en: 'Let them pick what they want from healthy foods.' },
  ],
  /* ⚖️ نصايح لغذاء متوازن (من نفس الصورة — رقم ٨ و٩ مش ظاهرين فيها) */
  balanced: [
    { ar: 'عشان أكله يبقى منتظم لازم نومه يبقى منتظم — مش أقل من 10 ساعات في اليوم.', en: 'Regular eating needs regular sleep — at least 10 hours a day.' },
    { ar: 'من سنة لسنتين: حوالي كوبين حليب في اليوم (مش أكتر من 500 مل).', en: 'From 1 to 2 years: about two cups of milk a day (no more than 500 ml).' },
    { ar: '3 وجبات أساسية في اليوم — ومن بعد السنة سناكين خفاف بين الوجبات.', en: '3 main meals a day — and from age one, two light snacks between them.' },
    { ar: 'خدي وقتك وهو بياكل، وأكّليه بهدوء ومن غير استعجال.', en: 'Take your time while they eat — feed calmly, never rushed.' },
    { ar: 'متتجاهليش الفطار بحجة إن الغدا قرّب أو إن مفيش وقت.', en: 'Don’t skip breakfast because lunch is close or time is short.' },
    { ar: 'متضغطيش عليه ياكل، ومتديلوش حلويات أو شيبسي قبل الوجبات.', en: 'Don’t pressure them to eat, and no sweets or chips before meals.' },
  ],
};
