/* ============================================================
   🥛❌ أكلات خالية من الألبان — حساسية الألبان / عدم تحمل اللاكتوز
   فكرة: أكل صحي وآمن.. وبدون تعب في تدوير البدائل!
   ============================================================ */

/* دليل المطبخ السريع — ممنوعات / بدائل / كالسيوم من غير ألبان */
const DAIRY_GUIDE = {
  banned: {
    t: { ar: '🔴 ممنوعات — البُدقة بتاعت الألبان', en: '🔴 Banned — the dairy list' },
    items: {
      ar: ['زبادي ولبن رائب', 'لبنة وقريش وجبنة بيضاء', 'حليب بقري (حتى كامل الدسم)', 'زبدة وسمن الحليب', 'مهلبية بالحليب', 'أي شوكولاتة بالحليب'],
      en: ['Yogurt & laban', 'Labneh, areesh, white cheese', 'Cow milk (even full-fat)', 'Butter & milk ghee', 'Milk-based puddings', 'Any milk chocolate'],
    },
  },
  swaps: {
    t: { ar: '🟢 بدائل البروتين الآمنة', en: '🟢 Safe protein swaps' },
    items: {
      ar: ['اللحوم والدجاج والكبدة', 'الأسماك', 'البيض (صفار ثم كامل — لو مفيش حساسية بيض)', 'العدس والحمص والفول المدمس', 'المكسرات المطحونة وزبدة الفول السوداني (حسب السن)', 'بذور الشيا والسمسم', 'المشروم (الفطر)'],
      en: ['Meat, chicken & liver', 'Fish', 'Egg (yolk then whole — if no egg allergy)', 'Lentils, chickpeas & foul', 'Ground nuts & peanut butter (by age)', 'Chia & sesame seeds', 'Mushrooms'],
    },
  },
  calcium: {
    t: { ar: '🦴 الكالسيوم من غير ألبان؟ ولا يهمكِ', en: '🦴 Calcium without dairy? Easy' },
    items: {
      ar: ['الطحينة (أقوى مصدر!)', 'السمسم المحموش المطحون', 'الخضار الورقي الداكن: سبانخ وملوخية', 'البروكلي', 'المكسرات المطحونة (لوز)', 'التين والبرتقال'],
      en: ['Tahini (the strongest source!)', 'Toasted ground sesame', 'Dark leafy greens: spinach & mulukhiyah', 'Broccoli', 'Ground nuts (almond)', 'Figs & oranges'],
    },
  },
};

/* حليب ما قبل النوم البديل — لو الفلتر مفعّل */
const MILK_ALT = {
  id: 'milkalt', e: '🍼', c: 'milk', m: 12,
  n: 'رضاعة أو حليب خالٍ من اللاكتوز (بإرشاد الطبيب)', en_n: 'Nursing or lactose-free formula (per doctor)',
  ing: 'حسب إرشاد طبيب الأطفال',
  en_ing: 'As guided by your pediatrician',
  prep: ['مع حساسية الألبان: الرضاعة الطبيعية غالبًا آمنة (لاكتوزها سهل الهضم).',
         'الحليب الصناعي/النباتي البديل بيتحدد مع الطبيب بس — مش كل البدائل تصلح.'],
  en_prep: ['With dairy allergy: breastfeeding is usually fine (its lactose is gentle).',
            'Alternative formula/plant milk must be chosen with your doctor — not all substitutes fit.'],
  tags: [], note: 'قلبي الكالسيوم من الطحينة والسمسم والخضار الورقي — القسم جاهز 🥛❌',
  en_note: 'Cover calcium from tahini, sesame & leafy greens — see the guide 🥛❌',
};

/* حالة الفلتر العامة — app.js بيضبطها من إعدادات البيبي */
globalThis.DIET = { dairyFree: false };

function foodAllowed(f) {
  if (globalThis.DIET.dairyFree && (f.tags || []).includes('ألبان')) return false;
  return true;
}
