/* ============================================================
   💉 متابعة التطعيمات الاختيارية
   minWeeks = أقل عمر لأول جرعة | firstBeforeWeeks = لازم تتاخد قبل العمر ده
   doneBeforeMonths = كل الجرعات تكتمل قبل العمر ده | gapDays = أقل فترة بين الجرعات
   types.at = المواعيد المعتادة بالشهور
   catchUp = خطة الجرعات حسب العمر عند أول جرعة (upTo بالشهور) | booster = الجرعة المنشطة
   الطبيب دايمًا القرار الأخير
   ============================================================ */

const VACCINES = [
{ id:'rota', e:'🦠', stackCount:true, minAge:{ days:42, label:{ ar:'شهر ونص', en:'6 weeks' } },
  n:'تطعيم الروتا', en_n:'Rotavirus vaccine',
  sub:'للوقاية من النزلات المعوية الشديدة عند الرضع', en_sub:'Protects babies against severe gastroenteritis',
  types:[
    { id:'rotarix', n:'Rotarix', count:{ ar:'2', en:'2' }, at:[2, 4] },
    { id:'rotateq', n:'RotaTeq', count:{ ar:'3', en:'3' }, at:[2, 4, 6] },
  ],
  minWeeks:6, firstBeforeWeeks:15, doneBeforeMonths:8, gapDays:28,
  tooLate:{
    ar:'عدّى معاد أول جرعة (قبل عمر 15 أسبوع)، فمينفعش يبدأ التطعيم دلوقتي. اسألي طبيب الأطفال.',
    en:'The first dose must be given before 15 weeks of age, so this vaccine can’t be started now. Ask your pediatrician.',
  },
  rules:{
    ar:['يتاخد عن طريق الفم، مش حقنة','يبدأ من عمر 6 أسابيع (شهر ونصف)','أول جرعة لازم تتاخد قبل عمر 15 أسبوع','الجرعات لازم تكتمل قبل عمر 8 شهور','لازم 4 أسابيع على الأقل بين الجرعات','ممكن يتاخد مع تطعيمات الشهرين والأربعة والستة شهور في نفس الزيارة','لا يُعطى للأطفال اللي عندهم تاريخ سابق لانغلاف الأمعاء (Intussusception)','استثناء مهم: لو الطفل أخد شلل الأطفال الفموي (OPV)، بعض التوصيات بتوصي بفاصل أسبوعين قبل الروتا لتجنب احتمال انخفاض الاستجابة المناعية'],
    en:['Given by mouth, not by injection','Starts from 6 weeks of age','The first dose must be given before 15 weeks of age','All doses must be finished before 8 months of age','At least 4 weeks between doses','Can be given at the same visit as the 2, 4 and 6 month vaccines','Not for babies with a history of intussusception','Important exception: if the child received oral polio vaccine (OPV), some recommendations advise a two-week gap before rotavirus to avoid a possible lower immune response'],
  } },
{ id:'pneumo', e:'🫁', calc:'pcv', minAge:{ days:42, label:{ ar:'شهر ونص', en:'6 weeks' } },
  n:'تطعيم المكورات الرئوية', en_n:'Pneumococcal vaccine',
  sub:'Prevenar 13 — للوقاية من الالتهاب الرئوي والتهاب الأذن الوسطى والتهاب السحايا وتسمم الدم', en_sub:'Prevenar 13 — protects against pneumonia, middle ear infections, meningitis and sepsis',
  rules:{
    ar:['الحساب هنا للأطفال الأصحاء من شهرين لحد 17 سنة','أقل عمر مسموح للجرعة الأولى: 6 أسابيع','المواعيد المعتادة: شهرين و4 و6 شهور + جرعة نهائية بعد عمر سنة','لو بدأ قبل 7 شهور: 3 جرعات بفاصل 4 أسابيع على الأقل، وبعدها جرعة نهائية بعد عمر 12 شهر وبفاصل 8 أسابيع على الأقل','لو بدأ من 7 لـ 11 شهر: جرعتين بفاصل 4 أسابيع على الأقل، وبعدها جرعة نهائية بعد عمر 12 شهر وبفاصل 8 أسابيع على الأقل','لو بدأ من 12 لـ 23 شهر: جرعتين بفاصل 8 أسابيع على الأقل','لو بدأ من 24 شهر لأقل من 17 سنة: جرعة واحدة','التأخير مش بيزوّد جرعات — الجدول بيكمّل من اللي اتاخد، مش من الصفر','الجرعة اللي مش مستوفية الفواصل أو العمر المطلوب مش بتتحسب','الأطفال اللي عندهم أمراض مزمنة أو ضعف مناعة أو عوامل خطورة بيحددلهم الطبيب الجدول','القواعد دي مرجع مبدئي من CDC مش جدول مصري معتمد — راجعي طبيب الأطفال والنشرة المحلية'],
    en:['Calculated here only for healthy children from 2 months up to 17 years','Minimum age for the first dose: 6 weeks','Usual schedule: 2, 4 and 6 months + a final dose after 1 year of age','Starting before 7 months: 3 doses at least 4 weeks apart, then a final dose after 12 months of age and at least 8 weeks after the last','Starting at 7 to 11 months: 2 doses at least 4 weeks apart, then a final dose after 12 months of age and at least 8 weeks after the last','Starting at 12 to 23 months: 2 doses at least 8 weeks apart','Starting at 24 months to under 17 years: 1 dose','Delay doesn’t add doses — the series continues from what was given, not from zero','A dose that doesn’t meet the spacing or age rules isn’t counted','Children with chronic conditions, weak immunity or risk factors follow a schedule set by the doctor','These rules are a preliminary CDC reference, not an approved Egyptian schedule — check with your pediatrician and the local leaflet'],
  } },
{ id:'acwy', e:'🧠',
  n:'تطعيم الالتهاب السحائي', en_n:'Meningococcal ACWY vaccine',
  sub:'للوقاية من التهاب السحايا وتسمم الدم (المجموعات A وC وW وY)', en_sub:'Protects against meningitis and sepsis (groups A, C, W and Y)',
  types:[
    { id:'nimenrix', n:'Nimenrix', count:{ ar:'جرعة واحدة', en:'1 dose' }, firstAt:12, minAge:{ months:12, label:{ ar:'سنة', en:'1 year' } },
      catchUp:[{ upTo:216, doses:1, gapMonths:0, booster:false }],
      rules:{
        ar:['تطعيم رباعي مقترن','حسب النشرة المعتمدة في مصر: يبدأ من عمر 12 شهرًا','جرعة واحدة من عمر سنة فأكتر في الجدول المعتاد','لا يحتاج عادةً جرعة تنشيطية للأطفال الأصحاء'],
        en:['Quadrivalent conjugate vaccine','Per the Egyptian leaflet: starts at 12 months of age','One dose from 1 year of age in the usual schedule','Healthy children usually don’t need a booster'],
      } },
    { id:'menactra', n:'Menactra', count:{ ar:'من جرعة لجرعتين', en:'1 to 2 doses' }, firstAt:9, minAge:{ months:9, label:{ ar:'9 شهور', en:'9 months' } },
      catchUp:[{ upTo:23, doses:2, gapMonths:3, booster:false }, { upTo:216, doses:1, gapMonths:0, booster:false }],
      rules:{
        ar:['تطعيم رباعي مقترن','يبدأ من عمر 9 شهور','من 9 لـ 23 شهر: جرعتين بينهم 3 شهور','لو عمره أكبر من 23 شهر: جرعة واحدة فقط في أي وقت، طالما ما أخدش التطعيم قبل كده'],
        en:['Quadrivalent conjugate vaccine','Starts at 9 months of age','From 9 to 23 months: 2 doses 3 months apart','Older than 23 months: 1 dose only, at any time, as long as the vaccine wasn’t given before'],
      } },
  ],
},
{ id:'flu', e:'🤧', brand:{ ar:'VAXIGIP أو INFLUVAC', en:'VAXIGIP or INFLUVAC' },
  n:'تطعيم الإنفلونزا الموسمية', en_n:'Seasonal flu vaccine',
  sub:'للوقاية من نزلات البرد والإنفلونزا', en_sub:'Protects against seasonal flu',
  seasonal:true,
  rules:{
    ar:['الحقنة كاملة (0.5 مل) لأي عمر فوق 6 شهور','بيتاخد سنويًا من سبتمبر أو أكتوبر لحد مارس، جرعة واحدة','من 6 شهور لـ 9 سنين: في أول مرة جرعتين بينهم شهر، وبعدين جرعة واحدة كل سنة','مينفعش قبل 6 شهور'],
    en:['Full 0.5 ml injection for any age over 6 months','Taken yearly from September or October until March, one dose','From 6 months to 9 years: the first time, 2 doses 1 month apart; then 1 dose each year','Not before 6 months of age'],
  } },
{ id:'varicella', e:'🌟', brand:{ ar:'Varilrix أو Varivax', en:'Varilrix or Varivax' }, minAge:{ months:12, label:{ ar:'سنة', en:'1 year' } },
  n:'تطعيم الجدري المائي', en_n:'Chickenpox vaccine',
  sub:'للوقاية من الجدري المائي', en_sub:'Protects against chickenpox',
  firstAt:12,
  catchUp:[{ upTo:155, doses:2, gapMonths:3, booster:false }, { upTo:216, doses:2, gapMonths:1, booster:false }],
  rules:{
    ar:['حقنة تحت الجلد','لا يؤخذ قبل سن سنة','لو عمره أقل من 13 سنة: جرعتين بينهم 3 شهور','لو عمره فوق 13 سنة: جرعتين بينهم شهر','اللي جاله جدري قبل كده مياخدش التطعيم','لازم يفصل شهر بينه وبين أي تطعيم حي زي الروتا ونقط شلل الأطفال وMMR'],
    en:['Injected under the skin','Not before 1 year of age','Under 13 years: 2 doses 3 months apart','Over 13 years: 2 doses 1 month apart','Not for children who already had chickenpox','Wait at least 1 month before or after a live vaccine such as rotavirus, polio drops or MMR'],
  } },
{ id:'hepa', e:'🛡️', brand:{ ar:'Havrix', en:'Havrix' }, minAge:{ months:12, label:{ ar:'سنة', en:'1 year' } },
  n:'تطعيم الالتهاب الكبدي الوبائي A', en_n:'Hepatitis A vaccine',
  sub:'للوقاية من الالتهاب الكبدي الوبائي A', en_sub:'Protects against hepatitis A',
  firstAt:12,
  catchUp:[{ upTo:216, doses:2, gapMonths:6, maxGapMonths:18, booster:false }],
  rules:{
    ar:['حقنة في العضل','لا يؤخذ قبل سن سنة','أي سن فوق سنة: جرعتين بينهم 6 شهور، وممكن لحد 18 شهر لو نسينا','جرعة الأطفال 0.5 مل'],
    en:['Intramuscular injection','Not before 1 year of age','Any age over 1 year: 2 doses 6 months apart, up to 18 months if the second is forgotten','Children’s dose is 0.5 ml'],
  } },
];
