/* ============================================================
   🌸 Mom Pro — ترقية "وقت راحتك يا مامي" (شراء مرة واحدة)
   السعر: ٤٩ ج.م (أو ما يعادلها ~$1) — مدى الحياة
   المجاني: نشاط واحد في كل مرحلة عمرية | Pro: كل الأنشطة + المؤقت
   الشراء مباشر من المتجر (StoreKit / Play Billing) — بدون وسيط
   ============================================================ */
(function () {
  const PRODUCT_ID = 'mom_pro_lifetime'; /* نفس الـ ID في App Store/Play Console */

  const store = {
    get(k, f) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : f; } catch { return f; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  };

  const state = {
    pro: store.get('bb_mompro', false),
    ready: false,        /* البلجن الأصلي شغّال؟ */
    webFallback: false,  /* ويب بدون شراء */
  };

  /* مراحل الأنشطة */
  function stageOf(m) {
    if (m <= 9) return 1;
    if (m <= 12) return 2;
    if (m <= 18) return 3;
    if (m <= 24) return 4;
    return 5;
  }

  /* الأنشطة المجانية: أول نشاط في كل مرحلة (بترتيب التعريف) */
  let FREE_IDS = null;
  function freeIds() {
    if (FREE_IDS) return FREE_IDS;
    const firstOf = {};
    for (const a of ACTIVITIES) {
      const st = stageOf(a.m);
      if (!firstOf[st]) firstOf[st] = a.id;
    }
    FREE_IDS = Object.values(firstOf);
    return FREE_IDS;
  }

  function isFreeAct(a) { return true; } // كل الأنشطة مجانية

  function iap() { return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Iap) || null; }

  /* تهيئة الشراء — على الويب نشتغل بوضع العرض */
  async function init() {
    if (typeof ACTIVITIES === 'undefined') return;
    if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform() && iap()) {
      state.ready = true;
      /* لو اشترت قبل كده على نفس الحساب — نستعيد تلقائيًا */
      try {
        const res = await iap().checkEntitlement({ productIds: [PRODUCT_ID] });
        if (res && res.entitled) setPro(true, false);
      } catch {}
    } else {
      state.webFallback = true;
    }
  }

  /* نعيد رسم صفحة مامي بس لو هي المفتوحة — من غير الشرط ده كانت بتخطف الرئيسية أول ما التطبيق يفتح
     (السعر أو الشراء القديم بيوصلوا من المتجر بعد الفتح بثانية) */
  function refreshMomtime() {
    if (window.renderMomtime && location.hash.replace(/^#\/?/, '').split('/')[0] === 'momtime') window.renderMomtime();
  }

  function setPro(v, toastIt) {
    state.pro = v;
    store.set('bb_mompro', v);
    if (toastIt && window.showToast) window.showToast(v
      ? (document.documentElement.lang === 'ar' ? 'مبروك! كل الأنشطة اتفتحت 🌸✨' : 'Unlocked! All activities are yours 🌸✨')
      : (document.documentElement.lang === 'ar' ? 'اتقفل الوصول Pro' : 'Pro access locked'));
    if (v) refreshMomtime();
  }

  async function purchase() {
    if (state.webFallback || !state.ready) {
      if (window.showToast) window.showToast(document.documentElement.lang === 'ar'
        ? 'الشراء بيتفعّل في نسخة المتجر بعد الإعداد — شوفي store/IAP-SETUP' : 'Purchase activates in the store build after setup — see store/IAP-SETUP');
      return false;
    }
    try {
      const res = await iap().purchase({ productId: PRODUCT_ID });
      if (res && res.state === 'purchased') {
        setPro(true, true);
        return true;
      }
      if (res && res.state === 'pending' && window.showToast) {
        window.showToast(document.documentElement.lang === 'ar'
          ? 'الشراء معلّق (دفع كاش مثلًا) — هيُفعّل تلقائيًا لما يكتمل 💛' : 'Purchase pending (e.g. cash payment) — it will unlock automatically 💛');
      }
      return false;
    } catch (e) {
      if (e && e.code !== 'USER_CANCELLED' && window.showToast) {
        window.showToast(document.documentElement.lang === 'ar' ? 'حصل خطأ في الشراء — جربي تاني' : 'Purchase error — try again');
      }
      return false;
    }
  }

  async function restore() {
    if (!state.ready) {
      if (window.showToast) window.showToast(document.documentElement.lang === 'ar' ? 'الاستعادة متاحة في نسخة المتجر' : 'Restore works in the store build');
      return;
    }
    try {
      const res = await iap().restore({ productIds: [PRODUCT_ID] });
      if (res && res.entitled) {
        setPro(true, true);
      } else if (window.showToast) {
        window.showToast(document.documentElement.lang === 'ar' ? 'مفيش شراء مسجل على الحساب ده' : 'No purchase found on this account');
      }
    } catch {
      if (window.showToast) window.showToast(document.documentElement.lang === 'ar' ? 'مفيش شراء مسجل على الحساب ده' : 'No purchase found on this account');
    }
  }

  const _origInit = init;
  init = async function () { await _origInit(); await fetchPrice(); };

  /* كشف وضع التطوير: قفلي/افتحي يدوي للتجربة */
  if (typeof URLSearchParams !== 'undefined' && location.search.includes('mompro-dev=')) {
    setPro(new URLSearchParams(location.search).get('mompro-dev') === '1', false);
  }

  /* السعر: 1$ في مصر، 3$ خارجها — ولو سعر المتجر الحقيقي متاح بنستخدمه */
  let storePrice = null;
  /* مصرية = أي لغة مفضلة في النظام ar-EG (حتى لو واجهة التطبيق إنجليزي) */
  function isEgypt() {
    const langs = [navigator.language, ...(navigator.languages || [])].filter(Boolean);
    return langs.some(l => /-EG/i.test(l));
  }
  function priceNum() { return isEgypt() ? 1 : 3; }
  function priceText() {
    if (storePrice) return storePrice;                 /* سعر المتجر الحقيقي بصيغته */
    const ar = document.documentElement.lang === 'ar';
    const n = priceNum();
    return ar ? `${n} دولار` : `$${n}`;
  }
  async function fetchPrice(attempt) {
    if (!state.ready) return;
    const retry = () => { if (!attempt || attempt < 3) setTimeout(() => fetchPrice((attempt || 1) + 1), 1500); };
    try {
      const res = await iap().getProducts({ productIds: [PRODUCT_ID] });
      const p = res && res.products && res.products[0];
      if (p && p.priceString) { storePrice = p.priceString; refreshMomtime(); }
      else retry(); /* المنتج لسه مش متفعّل في المتجر أو الاتصال بطيء — نحاول تاني */
    } catch { retry(); }
  }

  window.MomPro = { state, isFreeAct, stageOf, purchase, restore, freeIds, init, priceText, fetchPrice };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
