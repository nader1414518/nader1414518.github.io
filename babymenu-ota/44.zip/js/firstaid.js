/* ============================================================
   🚑 إسعافات الطوارئ السريعة — طوارئ المطبخ والبيت
   لكل حالة: ماذا تفعلين الآن؟ | ماذا لا تفعلين أبداً؟ | متى للطوارئ؟
   المحتوى إرشادي للمساعدة الفورية — الطوارئ/الطبيب دايمًا القرار الأخير
   ============================================================ */

const FIRSTAID = [
{ id:'choking', e:'🚨', tone:'red',
  n:'الاختناق والشرقة', en_n:'Choking',
  sub:'توقف عن الكحة، مفيش صوت أو بكاء، اللون بيزرق', en_sub:'Stopped coughing, no sound or cry, turning blue',
  do:{
    ar:['👶 **أقل من سنة:** اقلبيه على بطنكِ ووجهه لتحت ورأسه مائل للأسفل — 5 ضربات قوية بين الكتفين براحة يدك.',
        'اقلبيه على ظهره — 5 ضغطات على منتصف الصدر بإصبعين. كرري الدورتين حتى يخرج الجسم.',
        '👦 **أكبر من سنة:** قفي خلفه ولفي ذراعيك حول خصره — ضغطات بقوة للداخل وللأعلى (مناورة هايمليش) حتى يخرج ما في حلقه.'],
    en:['👶 **Under 1 year:** lay baby face-down along your forearm, head low — 5 firm back blows between the shoulder blades.',
        'Turn them face-up — 5 chest thrusts with two fingers. Repeat both until the object comes out.',
        '👦 **Over 1 year:** stand behind, wrap arms around the waist — forceful inward & upward thrusts (Heimlich) until it clears.'],
  },
  dont:{
    ar:['⚠️ لو بيقدر يكح بقوة — سيبيه يكح! الكحة أحسن وسيلة يطرد بيها الجسم بنفسه. متضربيش على ضهره وقتها.'],
    en:['⚠️ If they can cough strongly — let them cough! It\u2019s the best way out. Don\u2019t hit the back at that stage.'],
  },
  urgent:{
    ar:['مفيش أي تحسن بعد الدورتين، أو فقد الوعي، أو بيزرق — اتصلوا بالإسعاف فورًا مع الاستمرار في الخطوات.'],
    en:['No improvement after the cycles, loss of consciousness, or blueness — call an ambulance NOW and keep going.'],
  },
},
{ id:'fever', e:'🌡️', tone:'orange',
  n:'الحرارة والتشنجات', en_n:'Fever & convulsions',
  sub:'ارتفاع مفاجئ وشديد أو تشنج حراري', en_sub:'Sudden high fever or a febrile seizure',
  do:{
    ar:['خففي الملابس وكمادات فاترة على الجبهة وتحت الإبطين وبين الفخذين (مش مية مثلجة!).',
        'خافض حرارة مناسب لوزنه (الجرعة المعتادة بعد مراجعة الطبيب).',
        '🧠 **لو حدث تشنج:** حافظي هدوئك — ضعيه على جنبه فورًا، وأبعدي أي حاجات حادة حواليه.',
        'احسبي مدة التشنج بالثواني.'],
    en:['Remove clothes, lukewarm compresses on forehead, armpits and groin (never ice water).',
        'A weight-appropriate fever reducer (the usual dose, per your doctor).',
        '🧠 **If a seizure happens:** stay calm — lay them on their side at once, clear sharp objects away.',
        'Time the seizure in seconds.'],
  },
  dont:{
    ar:['ممنوع فتح فمه بقوة أو حط أي حاجة جواه أثناء التشنج.',
        'ممنوع الماء المثلج أو الكحول للكمادات.'],
    en:['Never force the mouth open or put anything inside during a seizure.',
        'No ice water or alcohol compresses.'],
  },
  urgent:{
    ar:['التشنج طويل أكثر من 3-5 دقايق، أو تكرر، أو بعد التشنج مش راجع لوعيه — طوارئ فورًا.'],
    en:['Seizure over 3–5 minutes, repeated seizures, or not waking after — emergency NOW.'],
  },
},
{ id:'bleeding', e:'🩸', tone:'red',
  n:'النزيف والجروح', en_n:'Bleeding & cuts',
  sub:'جرح قطعي أو نزيف من وقعة أو حاجة حادة', en_sub:'A cut or bleeding from a fall or sharp object',
  do:{
    ar:['اضغطي مباشرة على مكان النزيف بشاش أو قماش نضيف لعدة دقايق متواصلة حتى يقف الدم.',
        'نضّفي الجرح بمية فاترة أو محلول ملحي.'],
    en:['Press directly on the wound with clean gauze or cloth for several continuous minutes.',
        'Rinse with lukewarm water or saline.'],
  },
  dont:{
    ar:['متلصقيش القطن مباشرة على الجرح (بيلاصق فيه).',
        'متشيليش القماش المبلل بالدم فوق بعضه — ضيفي فوقه لو احتاجتي.'],
    en:['Don\u2019t press raw cotton onto the wound (it sticks).',
        'Don\u2019t remove a soaked dressing — add layers on top instead.'],
  },
  urgent:{
    ar:['الجرح عميق أو طويل أو النزيف مش واقف بعد 10 دقايق ضغط — مستشفى فورًا (ممكن يحتاج غرز).'],
    en:['Deep or gaping wound, or bleeding not stopping after 10 minutes of pressure — hospital now (may need stitches).'],
  },
},
{ id:'poison', e:'💧', tone:'red',
  n:'ابتلاع مواد خطيرة', en_n:'Poisoning & ingestion',
  sub:'دواء، منظف، أو بطارية أزرار!', en_sub:'Medicine, cleaner, or a button battery!',
  do:{
    ar:['احتفظي بالعبوة أو المادة في إيدك — الطوارئ هتسأل عليها.',
        'اتصلي بمركز السموم أو روحي المستشفى فورًا.'],
    en:['Keep the container or substance in hand — the ER will ask about it.',
        'Call poison control or head to hospital immediately.'],
  },
  dont:{
    ar:['ممنوع منعاً باتاً إجباره على القيء — المواد الكيميائية بتحرق المريء مرة تانية وهي راجعة.'],
    en:['NEVER force vomiting — chemicals burn the esophagus again on the way up.'],
  },
  urgent:{
    ar:['🚨 بطاريات الأزرار والأقراص المغناطيسية = طوارئ قصوى خلال دقايق (بتحرق الأنسجة بسرعة رهيبة).'],
    en:['🚨 Button batteries & magnet discs = extreme emergency within minutes (they burn tissue fast).'],
  },
},
{ id:'burns', e:'🔥', tone:'orange',
  n:'الحروق', en_n:'Burns',
  sub:'سطح سخن، مية سخنة، شاي أو قهوة', en_sub:'Hot surface, boiling water, tea or coffee',
  do:{
    ar:['حطي مكان الحرق تحت مية فاترة جارية 10-15 دقيقة كاملة لتبريد الأنسجة.',
        'انزعي أي إكسسوارات أو ملابس ضيقة بحذر قبل ما يحدث تورم.'],
    en:['Run cool (not cold) water over the burn for a full 10–15 minutes.',
        'Gently remove tight clothes or accessories before swelling starts.'],
  },
  dont:{
    ar:['ممنوع تماماً: معجون أسنان، ثلج، زيوت، دقيق، أو أي "وصفات بيتية" على الحرق.'],
    en:['Absolutely no: toothpaste, ice, oils, flour or any home remedies.'],
  },
  urgent:{
    ar:['ظهرت فقاعات مية، أو الحرق كبير أو في الوجه/اليدين/المنطقة الحساسة — طبيب فورًا.'],
    en:['Blisters appeared, or a large burn or on face/hands/groin — doctor immediately.'],
  },
},
{ id:'vomit', e:'🤢', tone:'orange',
  n:'القيء والجفاف', en_n:'Vomiting & dehydration',
  sub:'قيء متكرر أو إسهال مانعه من الأكل والشرب', en_sub:'Repeated vomiting or diarrhea keeping nothing in',
  do:{
    ar:['وقفي الأكل الصلب ساعة-اتنين لتهدية المعدة.',
        'سوائل بكميات صغيرة جدًا على فترات متقاربة: ملعقة صغيرة كل 5 دقايق (محلول معالجة الجفاف أو مياه).'],
    en:['Pause solids for 1–2 hours to settle the stomach.',
        'Tiny amounts of fluids at close intervals: a teaspoon every 5 minutes (ORS or water).'],
  },
  dont:{
    ar:['متعطيهوش كمية كبيرة مرة واحدة — هيرجعها فورًا.'],
    en:['Don\u2019t give a big amount at once — it will come right back up.'],
  },
  urgent:{
    ar:['🚨 علامات الخطر: جفاف الفم تمامًا، مفيش دموع مع البكاء، مفيش تبول 6-8 ساعات، أو خمول شديد — طوارئ فورًا.'],
    en:['🚨 Danger signs: completely dry mouth, no tears when crying, no pee for 6–8 hours, or extreme lethargy — ER now.'],
  },
},
{ id:'allergy', e:'🐝', tone:'red',
  n:'لدغات وحساسية مفاجئة', en_n:'Stings & sudden allergy',
  sub:'نحلة، طفح مفاجئ، تورم شفايف وعيون من أكل جديد', en_sub:'Bee sting, sudden rash, or swollen lips/eyes after new food',
  do:{
    ar:['لدغة نحلة: أزيلي "الشوكة" بحك بطاقة صلبة على الجلد — مش بالأصابع.',
        'كمادة باردة على مكان اللدغة لتقليل التورم.'],
    en:['Bee sting: scrape the stinger off with a hard card edge — never fingers.',
        'Cold compress on the sting to ease swelling.'],
  },
  dont:{
    ar:['متضغطيش على اللدغة بأصابعك — بتدفع السم لجوه.'],
    en:['Don\u2019t squeeze the sting with fingers — it pushes venom in.'],
  },
  urgent:{
    ar:['🚨 تورم في الحلق، صعوبة تنفس، أو طفح بيغطي الجسم بسرعة = صدمة تحسسية — طوارئ فورًا.'],
    en:['🚨 Throat swelling, trouble breathing, or a fast spreading body rash = anaphylaxis — ER NOW.'],
  },
},
];

/* ألوان درجة الخطورة */
const AID_TONES = {
  red:    { chip: '#FDEEEE', ink: '#B03A3A' },
  orange: { chip: '#FFF3E4', ink: '#B4713A' },
};
