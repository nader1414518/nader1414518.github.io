/* ============================================================
   🔔 تنبيهات مواعيد الوجبات — محلية بالكامل (بدون سيرفر)
   بتشتغل يوميًا بنفس المواعيد، ونصوص حنونة تختلف لكل وجبة
   ============================================================ */
(function () {
  const store = {
    get(k, f) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : f; } catch { return f; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  };
  let enabled = store.get('bb_notify', false);

  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const LN = () => (isNative() ? window.Capacitor.Plugins.LocalNotifications : null);

  /* أوقات ومواعيد فترات اليوم (نفس نظام الجداول) */
  const TIMES = [
    { key: 'wake', h: 7,  min: 0,  ar: '🍼 رضاعة الصحيان',      en: '🍼 Wake-up milk',    body: { ar: 'البيبي صاحي — أول رضاعة تنشّط يومه 💛', en: 'Baby is up — first milk to start the day 💛' } },
    { key: 'b',    h: 9,  min: 0,  ar: '🍳 وقت الفطار',          en: '🍳 Breakfast time',  body: { ar: 'فطار مشبع يفتح النهار — جهزي الصحن 🥣', en: 'A filling breakfast to open the day 🥣' } },
    { key: 's1',   h: 11, min: 30, ar: '🍼 رضاعة الضحى',         en: '🍼 Mid-morning milk', body: { ar: 'قبل القيلولة برضعة صغيرة وهادية 😴', en: 'A calm little feed before the nap 😴' } },
    { key: 'l',    h: 13, min: 0,  ar: '🍽️ الغدا الرئيسي',       en: '🍽️ Main lunch',     body: { ar: 'الوجبة الكاملة: خضار + بروتين + نشويات 💪', en: 'The complete meal: veg + protein + starch 💪' } },
    { key: 's2',   h: 16, min: 0,  ar: '🍎 سناك العصر',          en: '🍎 Afternoon snack', body: { ar: 'فاكهة، خيار أو طماطم، بسكوت بيتي، شيبسي خضار، أو رضعة 💛', en: 'Fruit, cucumber or tomato, homemade biscuits, veggie chips, or a milk feed 💛' } },
    { key: 'd',    h: 18, min: 30, ar: '🍽️ العشا',               en: '🍽️ Dinner',          body: { ar: 'وجبة متكاملة: خضار أو فاكهة + بروتين + نشويات 💛', en: 'A complete meal: veg or fruit + protein + starch 💛' } },
    { key: 'bed',  h: 20, min: 0,  ar: '💤 رضاعة النوم',         en: '💤 Bedtime milk',   body: { ar: 'رضعة مشبعة = نوم أطول ليلاً بإذن الله ✨', en: 'A full feed = longer night sleep ✨' } },
  ];

  /* أي الفترات بتنبيه حسب عمر البيبي (نفس منطق الجداول) */
  function keysFor(m) {
    if (m != null && m < 6) return [];                              /* أقل من ٦ شهور: مفيش تنبيهات خالص */
    if (!m || m <= 6) return ['wake', 'b', 's2', 'bed'];          /* أكلة واحدة الصبح (الفطار) + مية + رضاعات */
    if (m === 7) return ['wake', 'b', 's1', 'l', 's2', 'bed'];          /* وجبتين بس — من غير عشا */
    if (m >= 24) return ['b', 's1', 'l', 's2', 'd', 'bed'];        /* من سنتين: مفيش رضاعة الصحيان */
    return ['wake', 'b', 's1', 'l', 's2', 'd', 'bed'];            /* الكل — الجدولة نفسها */
  }

  async function requestPerm() {
    const ln = LN();
    if (!ln) return true; /* الويب */
    try {
      const cur = await ln.checkPermissions();
      if (cur.display === 'prompt') {
        const req = await ln.requestPermissions();
        return req.display === 'granted';
      }
      return cur.display === 'granted';
    } catch { return false; }
  }

  async function scheduleAll() {
    const ln = LN();
    if (!ln) return;
    try { await ln.cancelAllNotifications(); } catch {}

    /* عمر البيبي الحالي بالشهور الكاملة (نفس حساب الصفحة الرئيسية) — عشان التنبيهات على مقاسه */
    let m = null;
    try {
      const baby = JSON.parse(localStorage.getItem('bb_baby') || 'null');
      const b = baby && baby.birth ? new Date(baby.birth + 'T00:00:00') : null;
      const now = new Date();
      now.setHours(0, 0, 0, 0);
      if (b && !isNaN(b) && b <= now) {
        m = (now.getFullYear() - b.getFullYear()) * 12 + (now.getMonth() - b.getMonth());
        const probe = new Date(b);
        probe.setMonth(probe.getMonth() + m);
        if (probe > now) m -= 1;
      }
    } catch {}

    const lang = (document.documentElement.lang === 'en') ? 'en' : 'ar';
    const keys = keysFor(m);
    /* قبل السنة مفيش سناك: العصر رضعة — وفي الشهر السادس رشفات مية */
    const S2_BABY = m == null || m <= 6
      ? { ar: '💧 رشفات مية', en: '💧 Water sips', body: { ar: 'شوية رشفات مية بكوب التدريب بين الرضعات 💧', en: 'A few sips of water from a training cup between feeds 💧' } }
      : m < 12
      ? { ar: '🍼 رضاعة العصر', en: '🍼 Afternoon milk', body: { ar: 'رضعة العصر — مفيش سناك قبل السنة 💛', en: 'Afternoon milk feed — no snacks before age one 💛' } }
      : null;
    /* الشهر السادس: الأكلة الوحيدة الصبح — معالق صغيرة */
    const B_BABY = m == null || m <= 6
      ? { ar: '🥄 أكلة اليوم', en: '🥄 Today’s food', body: { ar: 'معالق صغيرة من أكلة النهارده — على مهلك 💛', en: 'A few small spoons of today’s food — no rush 💛' } }
      : null;
    /* بعد السنة الضحى سناك برضه (مش رضعة) */
    const S1_SNACK = m != null && m >= 12
      ? { ar: '🍎 سناك الضحى', en: '🍎 Mid-morning snack', body: { ar: 'فاكهة، خيار أو طماطم، بسكوت بيتي، شيبسي خضار، أو رضعة 💛', en: 'Fruit, cucumber or tomato, homemade biscuits, veggie chips, or a milk feed 💛' } }
      : null;
    const notes = TIMES.filter(t => keys.includes(t.key))
      .map(t => (t.key === 's2' && S2_BABY ? { ...t, ...S2_BABY } : t.key === 's1' && S1_SNACK ? { ...t, ...S1_SNACK } : t.key === 'b' && B_BABY ? { ...t, ...B_BABY } : t)).map(t => ({
      id: t.key.charCodeAt(0) * 100 + t.min,   /* id ثابت لكل فترة */
      title: t[lang],
      body: t.body[lang],
      schedule: { on: { hour: t.h, minute: t.min }, allowWhileIdle: true },
      smallIcon: 'ic_launcher', /* أيقونة التطبيق */
    }));
    if (notes.length) await ln.schedule({ notifications: notes });
  }

  async function enable() {
    const ok = await requestPerm();
    if (!ok) {
      if (window.showToast) window.showToast(document.documentElement.lang === 'ar'
        ? 'سمحي للإشعارات من إعدادات الموبايل الأول 🔔' : 'Allow notifications in phone settings first 🔔');
      return false;
    }
    enabled = true;
    store.set('bb_notify', true);
    await scheduleAll();
    return true;
  }

  async function disable() {
    enabled = false;
    store.set('bb_notify', false);
    const ln = LN();
    if (ln) { try { await ln.cancelAllNotifications(); } catch {} }
  }

  /* إعادة جدولة تلقائية عند فتح التطبيق (عشان لو الموبايل اطفى/اتشال البطارية) */
  async function boot() {
    if (enabled && isNative()) {
      const ok = await requestPerm();
      if (ok) await scheduleAll();
    }
  }

  /* reschedule: بعد ما تاريخ الميلاد يتغير — عشان التنبيهات تمشي على العمر الجديد على طول */
  window.MealAlerts = { enable, disable, boot, reschedule: boot, isEnabled: () => enabled, TIMES };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
