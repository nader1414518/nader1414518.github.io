/* ============================================================
   🚀 التحديث الإجباري — التطبيق يسأل عن أقل نسخة مسموح بها
   المصدر: https://nader1414518.github.io/babymenu.json (GitHub Pages) (سطر واحد = إجبار الكل بالتحديث)
   سياسة الأوفلاين: آخر فحص ناجح صالح 7 أيام — بعدها لازم يتأكد
   ============================================================ */
(function () {
  const CONFIG_URLS = [
    'https://nader1414518.github.io/babymenu.json',
  ];
  const GRACE_DAYS = 7;
  const store = {
    get(k, f) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : f; } catch { return f; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  };

  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

  function showForceScreen(storeUrl) {
    if (document.getElementById('force-update')) return;
    const ar = document.documentElement.lang !== 'en';
    const el = document.createElement('div');
    el.id = 'force-update';
    el.innerHTML = `
      <div class="fu-box">
        <div class="fu-emo">🌟</div>
        <h2>${ar ? 'في تحديث جديد ومهم!' : 'An important update is here!'}</h2>
        <p>${ar
          ? 'عملنا نسخة أحسن من <b>بيبي منيو</b> — لازم تحدّثي التطبيق الأول عشان يشتغل معاكي ونضمنلك كل الجديد 🌸'
          : 'We made a better version of <b>Baby Menu</b> — please update the app first to continue 🌸'}</p>
        <button class="fu-btn" id="fu-open">${ar ? '🔄 حدّثي دلوقتي' : '🔄 Update now'}</button>
        <button class="fu-retry" id="fu-retry">${ar ? 'إعادة المحاولة' : 'Retry'}</button>
        <small>${ar ? 'لو زر التحديث مش شغال — افتحي المتجر ودوّري على بيبي منيو' : 'If the button fails — open the store and search Baby Menu'}</small>
      </div>`;
    document.body.appendChild(el);
    document.getElementById('fu-open').addEventListener('click', () => {
      const ios = window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform() === 'ios';
      const url = storeUrl || (ios ? 'itms-apps://apps.apple.com/app/id6824734839' : 'market://details?id=com.beebymenu.app');
      window.open(url, '_system') || (window.location.href = url);
    });
    document.getElementById('fu-retry').addEventListener('click', () => location.reload());
  }

  async function fetchConfig() {
    for (const url of CONFIG_URLS) {
      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 4000);
        const res = await fetch(url + '?t=' + Date.now(), { cache: 'no-store', signal: ctrl.signal });
        clearTimeout(t);
        if (res.ok) return await res.json();
      } catch {}
    }
    return null;
  }

  async function check() {
    if (!isNative()) return; /* الويب في التطوير مبيتقفلش */

    let build = null;
    try {
      const App = window.Capacitor.Plugins.App;
      const info = await App.getInfo();
      build = parseInt(info && info.build, 10);
    } catch {}

    const cfg = await fetchConfig();
    if (cfg) {
      store.set('bb_lastOk', Date.now());
      const plat = window.Capacitor.getPlatform();
      const min = cfg.minVersionCode && cfg.minVersionCode[plat];
      if (min != null && build != null && !isNaN(build) && build < min) {
        showForceScreen((cfg.storeUrl || {})[plat]);
        return;
      }
      return; /* مسموح */
    }

    /* مفيش نت: نسمح لو فيه فحص ناجح خلال آخر 7 أيام — وإلا نقفل لحد ما يتأكد */
    const last = store.get('bb_lastOk', 0);
    if (Date.now() - last > GRACE_DAYS * 86400000 && last !== 0) {
      showForceScreen(null);
    } else if (last === 0) {
      /* أول مرة أوفلاين خالص ومفيش أي قرار — نسمح ونسجل عشان مهلة الأسبوع تبدأ */
      store.set('bb_lastOk', Date.now());
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', check);
  else check();
})();
