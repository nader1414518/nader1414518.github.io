/* ============================================================
   مولّد جداول الوجبات — 32 عمر × 30 يوم (عربي + English)
   الجداول بتتولد بشكل ثابت (deterministic): نفس العمر ونفس اليوم
   بيطلعوا نفس الجدول دايمًا، مع تنويع مضمون ومفيش أكلة تتكرر
   في نفس اليوم ولا قريب من نفس الوجبة.
   كل النصوص بتطلع {ar, en} والواجهة بتختار حسب اللغة.
   ============================================================ */

/* بذرة عشوائية ثابتة (mulberry32) */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffleWith(arr, seed) {
  const a = [...arr], rng = mulberry32(seed);
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ترتيب الأكلة في كل وجبة: دورة ثابتة لكل (عمر، وجبة) => تنويع بدون تكرار قريب */
const slotOrderCache = new Map();
function slotOrder(m, slotKey, pool) {
  const key = `${m}:${slotKey}:${pool.map(f => f.id).join(',')}`;
  if (!slotOrderCache.has(key)) slotOrderCache.set(key, shuffleWith(pool, m * 131 + slotKey.length * 7 + pool.length));
  return slotOrderCache.get(key);
}

/* كمية الأكل حسب العمر */
function portionFor(m, food) {
  const p = (ar, en) => ({ ar, en });
  if (food.c === 'milk') return food.id === 'milk' ? p('حسب طلب البيبي', 'As baby needs') : p('200-250 مل', '200–250 ml');
  if (food.id === 'bananacake') return p('قطعة صغيرة أو اتنين', 'One small slice or two');
  if (m <= 5) return p('ملعقتين-3 صغيرة (زوّدي تدريجيًا)', '2–3 small spoons (increase gradually)');
  if (m === 6) return p('3-5 ملاعق صغيرة', '3–5 small spoons');
  if (m <= 8) return p('4-6 ملاعق / نص كوب صغير', '4–6 spoons / half a small cup');
  if (m <= 11) return p('نص كوب تقريبًا', 'About half a cup');
  if (m <= 17) return p('طبق طفل صغير', 'A small toddler plate');
  return p('حسب شهية البيبي (طبق طفل كامل تقريبًا)', 'As much as baby wants (almost a full toddler plate)');
}

/* ملاحظة القوام حسب العمر */
function textureFor(m) {
  if (m <= 5) return { ar: 'قوام سايل ناعم جدًا (زي اللبن)', en: 'Very smooth, runny purée (like milk)' };
  if (m === 6) return { ar: 'قوام كريمي ناعم زي الزبادي', en: 'Smooth, creamy purée like yogurt' };
  if (m === 7) return { ar: 'مهروس خشن فيه تكتلات بسيطة', en: 'Mashed with soft little lumps' };
  if (m === 8) return { ar: 'قطع ناعمة صغيرة تمسك بإيده', en: 'Soft pieces baby can grab' };
  if (m <= 11) return { ar: 'قطع ناعمة صغيرة — سيبيه ياكل بإيده', en: 'Small soft pieces — let baby self-feed' };
  if (m <= 17) return { ar: 'أكل عادي مقطع صغير', en: 'Regular food cut small' };
  return { ar: 'أكل عادي مقطع مناسب لعمره', en: 'Regular food cut to size' };
}

/* ترتيب وجبات اليوم — الشهر السابع من غير عشا، ومن سنتين من غير رضاعة الصحيان */
function slotsFor(m, day) {
  return [
    { k: 'wake', label: { ar: 'الصباح الباكر (الصحيان)', en: 'Early morning (waking)' }, time: { ar: '٧:٠٠ ص', en: '7:00 AM' } },
    { k: 'b',   label: { ar: 'الفطار',        en: 'Breakfast' },       time: { ar: '٩:٠٠ ص',  en: '9:00 AM' } },
    { k: 's1',  label: { ar: 'الضحى (قبل القيلولة)', en: 'Mid-morning (before nap)' }, time: { ar: '١١:٣٠ ص', en: '11:30 AM' } },
    { k: 'l',   label: { ar: 'الغدا',         en: 'Lunch' },           time: { ar: '١:٠٠ م',  en: '1:00 PM' } },
    { k: 's2',  label: { ar: 'العصر',         en: 'Afternoon' },       time: { ar: '٤:٠٠ م',  en: '4:00 PM' } },
    { k: 'd',   label: { ar: 'العشا (قبل النوم بساعتين)', en: 'Dinner (2h before bed)' }, time: { ar: '٦:٣٠ م', en: '6:30 PM' } },
    { k: 'bed', label: { ar: 'قبل النوم',     en: 'Bedtime' },         time: { ar: '٨:٠٠ م',  en: '8:00 PM' } },
  ].filter(s => !(m === 7 && s.k === 'd')       /* الشهر السابع: الوجبتين بس من غير عشا — بعدهم رضاعات */
             && !(m >= 24 && s.k === 'wake'));  /* من سنتين: مفيش رضاعة الصحيان — اليوم بيبدأ بالفطار */
}

/* أي وجبة في اليوم دي تبقى أكل صلب وحاجة إيه — منطق التدرج بالعمر واليوم */
function mealTypeFor(m, slotKey, day) {
  if (slotKey === 'wake') return 'milk';                  /* أول حاجة تنشّط البيبي */
  if (slotKey === 'bed') return m < 12 ? 'milk' : 'milkcup';

  if (m === 6) {
    if (slotKey === 'b') return 'food';                   /* وجبة اليوم الوحيدة: الفطار (مخطط مامي) */
    if (slotKey === 's2') return 'water';
    return 'milk';
  }
  if (m === 7) {
    if (slotKey === 'b' || slotKey === 'l') return 'food';
    return 'milk';                                        /* الضحى والعصر رضاعة — ومفيش عشا */
  }
  /* من الثامن: 3 وجبات متكاملة (فطار + غدا + عشا).
     قبل السنة مفيش سناك — الضحى والعصر رضعات. بعد السنة سناك بين الوجبات من قايمة مامي (snackPool) */
  if (m <= 11 && (slotKey === 's1' || slotKey === 's2')) return 'milk';
  return 'food';
}

/* بناء حمّالة الأكلات لكل نوع وجبة (الأكلات المكمّلة زي التوم والبقدونس بتظهر في البدايل بس) */
function poolFor(m, slotKey, forSwap) {
  return FOODS.filter(f => {
    if (f.m > m) return false;
    if (f.side && !forSwap) return false;
    if (typeof foodAllowed === 'function' && !foodAllowed(f)) return false;
    if (slotKey === 'b') return f.s.includes('b');
    if (slotKey === 'l') return f.s.includes('l');
    if (slotKey === 'd') return f.s.includes('d');
    if (slotKey === 's1' || slotKey === 's2') return f.s.includes('s');
    return false;
  });
}


/* ============================================================
   الوجبة الكاملة 🍽️ = نص خضار غير نشوي أو فاكهة + ربع بروتين + ربع نشويات
   مجموعات البدايل (تقسيم مامي): f فاكهة | v خضار غير نشوي | p بروتين (والألبان منه) | s نشويات (والخضار النشوي منها)
   أي أكلة بتتبدل بس بأكلة من نفس مجموعتها
   ============================================================ */
const GROUP_BY_ID = {
  /* الخضار النشوي ← نشويات */
  potato: 's', sweetpotato: 's', carrot: 's', peas: 's', pumpkin: 's', corn: 's', 'm8-corn': 's',
  greenbeans: 's', taro: 's', artichoke: 's', beetroot: 's',
  /* الأفوكادو ← خضار غير نشوي */
  avocado: 'v',
  /* أكلات متخلّطة أو حلويات ← مش بتتبدل بمجموعة */
  bananacake: 'x', smoothie: 'x', mahalabia: 'x', potatodill: 'x',
};
const GROUP_BY_CAT = { fruit: 'f', veg: 'v', grain: 's', protein: 'p', dairy: 'p', snack: 'x', dish: 'x', milk: 'm' };
const roleOf = f => (f && (GROUP_BY_ID[f.id] || GROUP_BY_CAT[f.c])) || 'x';

const ROLE_LABEL = {
  p: { ar: 'بروتين', en: 'Protein' },
  v: { ar: 'خضار', en: 'Veggie' },
  s: { ar: 'نشويات', en: 'Starch' },
  f: { ar: 'فاكهة', en: 'Fruit' },
  d: { ar: 'ألبان', en: 'Dairy' },
};

/* السناك بعد السنة (قايمة مامي): فاكهة، خيار أو طماطم، بسكوت بيتي، شيبسي خضار، كوب لبن + فاكهة،
   دانيت بيتي، آيس كريم بيتي، أو رضعة — وبدايل السناك من نفس القايمة */
const SNACK_IDS = ['cucumber', 'snack-tomato', 'homebiscuit', 'vegchips', 'milkfruit', 'homedanette', 'homeicecream', 'snack-milk'];
const isSnackSlot = k => k === 's1' || k === 's2';
function snackPool(m) {
  return FOODS.filter(f => f.m <= m && (roleOf(f) === 'f' || SNACK_IDS.includes(f.id))
    && (typeof foodAllowed === 'function' ? foodAllowed(f) : true));
}

function poolRole(m, slotKey, role, forSwap) {
  const letter = slotKey === 'b' ? 'b' : slotKey === 'l' ? 'l' : slotKey === 'd' ? 'd' : 's';
  return FOODS.filter(f => f.m <= m && roleOf(f) === role && f.s.includes(letter) && (forSwap || !f.side)
    && (typeof foodAllowed === 'function' ? foodAllowed(f) : true));
}

/* اختيار دوري ثابت لكل (عمر، وجبة، دور، يوم) => تنويع بدون تكرار */
function pickRole(m, day, slotKey, role, used) {
  const ovId = (globalThis.MEAL_OVERRIDES || {})[`${m}-${day}-${slotKey}-${role}`];
  const ov = ovId && FOOD_MAP[ovId];
  /* اختيار المامي بيمشي حتى لو الأكلة اتكررت في وجبة تانية النهارده (زي الوجبات المفردة) — غير كده كان البديل بيتجاهل */
  if (ov && ov.m <= m && roleOf(ov) === role && ov.s.includes(slotKey === 'b' ? 'b' : slotKey === 'l' ? 'l' : slotKey === 'd' ? 'd' : 's')) {
    used.add(ov.id);
    return ov;
  }
  let pool = poolRole(m, slotKey, role).filter(f => !used.has(f.id));
  /* النشويات اتخلصت؟ البطاطس والبطاطا بيشتغلوا نشويات في الوجبة */
  if (!pool.length && role === 's') {
    pool = FOODS.filter(f => ['potato', 'sweetpotato'].includes(f.id) && f.m <= m && !used.has(f.id));
  }
  if (!pool.length) return null;
  const order = shuffleWith(pool, m * 131 + slotKey.length * 7 + day * 3 + role.charCodeAt(0));
  const pick = order[(day - 1) % order.length];
  used.add(pick.id);
  return pick;
}

function buildCombo(m, day, slotKey, usedToday) {
  const plan = slotKey === 'b' ? ['p', 's', 'f'] : ['p', 'v', 's']; /* الفطار كامل برضه: بروتين + نشويات + فاكهة */
  const parts = [];
  for (const role of plan) {
    const food = pickRole(m, day, slotKey, role, usedToday);
    if (food) parts.push({ role, food });
  }
  /* فطار بدون فاكهة متاحة؟ خضار غير نشوي مكانها (نص الطبق) */
  if (slotKey === 'b' && !parts.some(p => p.role === 'f')) {
    const alt = pickRole(m, day, slotKey, 'v', usedToday);
    if (alt) parts.push({ role: 'v', food: alt });
  }
  return parts;
}

function comboPortion(m) {
  const p = (ar, en) => ({ ar, en });
  if (m <= 8) return p('من كل مكوّن: 2-3 ملاعق صغيرة', 'Of each part: 2–3 small spoons');
  if (m <= 11) return p('من كل مكوّن: نص كوب صغير تقريبًا', 'Of each part: about half a small cup');
  if (m <= 17) return p('من كل مكوّن: ملعقتين-3 كبار', 'Of each part: 2–3 big spoons');
  return p('من كل مكوّن: حسب شهية البيبي', 'Of each part: as baby wants');
}

/* الوجبات اللي بتتحول لتركيبة كاملة حسب العمر */
function isComboSlot(m, slotKey) {
  if (m >= 6 && slotKey === 'l') return true;        /* الوجبة الرئيسية المتكاملة */
  if (m >= 7 && slotKey === 'b') return true;        /* فطار متكامل من 7 شهور */
  if (slotKey === 'd') return m >= 8;                /* السابع: من غير عشا | من الثامن: العشا وجبة متكاملة */
  return false;
}

/* أجزاء وجبة ثابتة من الجدول: بتشيل اللي فيها ألبان لو الفلتر شغال وتبدّلها ببروتين تاني اتجرّب.
   دور كل جزء من مجموعة الأكلة نفسها، وبديل المامي (🔄) بيتطبّق على الجزء برقمه (ovPrefix-رقم الجزء) */
function fixedPartsFrom(specs, newId, ovPrefix, short) {
  const parts = [];
  const taken = new Set();
  const ovs = globalThis.MEAL_OVERRIDES || {};
  specs.forEach(([role, ids, amt, label], idx) => {
    let foods = ids.map(id => FOOD_MAP[id]).filter(f => f && foodAllowed(f));
    if (!foods.length && (role === 'd' || role === 'p')) {
      const alt = ['eggyolk', 'beans', 'liver'].map(id => FOOD_MAP[id]).find(f => f && foodAllowed(f) && !taken.has(f.id));
      if (alt) foods = [alt];
    }
    if (!foods.length) return;
    const ov = ovPrefix && FOOD_MAP[ovs[`${ovPrefix}-${idx}`]];
    if (ov && roleOf(ov) === roleOf(foods[0]) && foodAllowed(ov)) foods = [ov];
    foods.forEach(f => taken.add(f.id));
    const g = roleOf(foods[0]);
    const isNew = !!newId && foods.some(f => (newId instanceof Set ? newId.has(f.id) : f.id === newId));
    parts.push({ role: 'fvps'.includes(g) ? g : role, food: foods[0], foods, idx, isNew,
      amt: (amt != null && typeof PLAN_AMT !== 'undefined' && PLAN_AMT[amt]) || null, short: short || null, label: label || null, orig: ids[0] });
  });
  return parts.length ? parts : null;
}

const dayCache = new Map();

/* استرجاع جدول يوم كامل */
function getDay(m, day) {
  const ck = `${m}:${day}`;
  if (dayCache.has(ck)) return dayCache.get(ck);

  const meals = [];
  const usedToday = new Set();
  const slotNote = m === 7
    ? { ar: '📈 الشهر السابع: وجبتين في اليوم (فطار + غدا) بالكميات اللي في الجدول، ومفيش عشا — بعد الوجبتين رضاعات بس. الصنف الجديد عليه 🆕 أول يوم يظهر فيه — راقبي استجابة البيبي 💛',
        en: '📈 Month seven: TWO meals a day (breakfast + lunch) with the amounts in the plan, and no dinner — just milk feeds after the two meals. A new food is marked 🆕 the first day it appears — watch how baby responds 💛' }
    : m === 8
    ? { ar: '🎉 يوم الشهر الثامن: رضاعة الصحيان → 🍽️ 3 وجبات متكاملة (فطار + غدا + عشا — كل واحدة: خضار/فاكهة + بروتين + نشويات) → ورضعات الضحى والعصر والنوم. مفيش سناك قبل السنة 💛',
        en: '🎉 A day at 8 months: wake milk → 🍽️ THREE complete meals (breakfast + lunch + dinner — each: veg/fruit + protein + starch) → plus mid-morning, afternoon & bedtime milk. No snacks before age one 💛' }
    : m === 6
    ? { ar: '📋 الشهر السادس: وجبة واحدة في اليوم (الفطار) + مية بين الرضعات + رضاعة براحته. الكميات بالمعلقة الصغيرة، وكل يوم مكتوب طريقة التحضير (على البخار / مسلوقة / مشوية). من غير عسل أو ملح أو سكر. لو ظهرت أعراض حساسية وقفي الأكل واسألي الدكتور 💛',
        en: '📋 Month six: ONE meal a day (breakfast) + water between feeds + nursing on demand. Amounts are in small spoons, and each day shows how to cook it (steamed / boiled / roasted). No honey, salt or sugar. If allergy symptoms appear, stop the food and ask your doctor 💛' }
    : null;

  for (const slot of slotsFor(m, day)) {
    let type = mealTypeFor(m, slot.k, day);
    /* الشهر السادس والسابع: وجبات من جدول ثابت (فلتر الألبان بيشيل/يبدّل الأكلة اللي فيها ألبان) */
    const m6row = m === 6 ? MONTH6_BY_DAY[day] : null;
    const m7row = m === 7 ? MONTH7_BY_DAY[day] : null;
    const m8row = m === 8 ? MONTH8_BY_DAY[day] : null;   /* الثامن: الفطار والغدا والعشا من قايمة وجبات مامي */
    let fixedParts = null;
    const ovPrefix = `${m}-${day}-${slot.k}`;
    if (m6row && slot.k === 'b') fixedParts = fixedPartsFrom(m6row.parts, null, ovPrefix, PLAN_SHORT);
    if (m7row && (slot.k === 'b' || slot.k === 'l')) fixedParts = fixedPartsFrom(m7row[slot.k], MONTH7_NEW[`${day}-${slot.k}`], ovPrefix, PLAN_SHORT);
    if (m8row && m8row[slot.k]) fixedParts = fixedPartsFrom(m8row[slot.k], null, ovPrefix);
    if (fixedParts) {
      const lab = m7row ? (slot.k === 'b' ? { ar: 'الوجبة الأولى (الفطار)', en: 'First meal (breakfast)' } : { ar: 'الوجبة التانية (الغدا)', en: 'Second meal (lunch)' }) : slot.label;
      meals.push({ ...slot, label: lab, type: 'combo', parts: fixedParts, fixed: true, portion: (m6row || m7row) ? null : comboPortion(m), note: (m6row && m6row.note) || (m7row && m7row.note && m7row.note.k === slot.k ? m7row.note : null), tags: [...new Set(fixedParts.flatMap(p => p.foods.flatMap(f => f.tags || [])))] });
      continue;
    }
    if (type === 'food' && isComboSlot(m, slot.k)) type = 'combo';

    if (type === 'combo') {
      const parts = buildCombo(m, day, slot.k, usedToday);
      if (parts.length >= 2) {
        meals.push({ ...slot, type, parts, portion: comboPortion(m), tags: [...new Set(parts.flatMap(p => p.food.tags || []))] });
        continue;
      }
      /* لو مفيش مكونات كفاية للتركيبة نرجع لوجبة مفردة */
      type = 'food';
    }

    if (type === 'milk') {
      meals.push({ ...slot, type, food: MILK, portion: portionFor(m, MILK), tags: [] });
      continue;
    }
    if (type === 'water') {
      meals.push({ ...slot, type, food: WATER, portion: { ar: 'رشفات بين الوجبات', en: 'Sips between meals' }, tags: [] });
      continue;
    }
    if (type === 'milkcup') {
      const cup = (globalThis.DIET.dairyFree && typeof MILK_ALT !== 'undefined') ? MILK_ALT : MILKCUP;
      meals.push({ ...slot, type, food: cup, portion: portionFor(m, cup), tags: cup.tags });
      continue;
    }

    const base = isSnackSlot(slot.k) ? snackPool(m) : poolFor(m, slot.k);
    const pool = base.filter(f => !usedToday.has(f.id));
    if (!pool.length) {
      meals.push({ ...slot, type, food: MILK, portion: portionFor(m, MILK), tags: [] });
      continue;
    }
    const order = slotOrder(m, slot.k, base);
    let pick = null;
    for (let step = 0; step < order.length; step++) {
      const c = order[(day - 1 + step) % order.length];
      if (!usedToday.has(c.id)) { pick = c; break; }
    }
    if (!pick) pick = pool[(day - 1) % pool.length];

    /* استبدال يدوي من المستخدم (زر البدائل) */
    const SLOT_LETTER = { b: 'b', l: 'l', d: 'd', s1: 's', s2: 's' };
    const ovId = (globalThis.MEAL_OVERRIDES || {})[`${m}-${day}-${slot.k}`];
    const ov = ovId && FOOD_MAP[ovId];
    if (ov && ov.m <= m && (isSnackSlot(slot.k) ? base.includes(ov) : ov.s.includes(SLOT_LETTER[slot.k]))) pick = ov;

    usedToday.add(pick.id);

    meals.push({ ...slot, type, food: pick, portion: portionFor(m, pick), tags: pick.tags || [] });
  }

  const result = { m, day, meals, texture: textureFor(m), note: slotNote };
  dayCache.set(ck, result);
  return result;
}

/* تفريغ الكاش بعد أي تغيير في الاستبدالات */
function invalidateDayCache() { dayCache.clear(); }

/* ============================================================
   أسماء و أرقام بالعربي والإنجليزي
   ============================================================ */
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const toAr = n => String(n).replace(/\d/g, d => AR_DIGITS[d]);

function ageLabel(m) {
  const ar = m < 1 ? 'أقل من شهر'
    : m === 1 ? 'شهر'
    : m === 2 ? 'شهرين'
    : m < 12 ? `${toAr(m)} شهور`
    : m === 12 ? 'سنة'
    : m < 24 ? `سنة و ${toAr(m - 12)} ${m - 12 === 1 ? 'شهر' : 'شهور'}`
    : m === 24 ? 'سنتين'
    : m < 36 ? `سنتين و ${toAr(m - 24)} ${m - 24 === 1 ? 'شهر' : 'شهور'}`
    : '٣ سنين';
  const en = m < 1 ? 'under 1 month'
    : m === 1 ? '1 month'
    : m < 12 ? `${m} months`
    : m === 12 ? '1 year'
    : m < 24 ? `1y ${m - 12}m`
    : m === 24 ? '2 years'
    : m < 36 ? `2y ${m - 24}m`
    : '3 years';
  return { ar, en };
}

/* أيقونة كل عمر = إيموجي الأكلة الأكثر تكرارًا في جدوله — مع ضمان التفرّد
   (أول ما يوم بيتبني بيتحسب تلقائيًا، والشهور اللي بعده بتاخد التالي الأكثر شيوعًا) */
const AGE_EMOJI_CACHE = {};
function ageEmoji(m) {
  if (AGE_EMOJI_CACHE[m]) return AGE_EMOJI_CACHE[m];
  if (!AGES.includes(m)) return '🍼';
  /* أعياد الميلاد: السنة والسنتين وال٣ سنين تورتة 🎂 دايمًا */
  if (m === 12 || m === 24 || m === 36) { AGE_EMOJI_CACHE[m] = '🎂'; return '🎂'; }

  const wasDairy = globalThis.DIET && globalThis.DIET.dairyFree;
  if (globalThis.DIET) globalThis.DIET.dairyFree = false; /* الأيقونة ثابتة مهما الفلتر */
  const count = {};
  for (let d = 1; d <= 30; d++) {
    for (const x of getDay(m, d).meals) {
      if (x.type !== 'food' && x.type !== 'combo') continue;
      const foods = x.type === 'combo' ? x.parts.map(p => p.food) : [x.food];
      for (const f of foods) count[f.id] = (count[f.id] || 0) + 1;
    }
  }
  if (globalThis.DIET) globalThis.DIET.dairyFree = wasDairy;
  invalidateDayCache();

  const used = new Set(Object.values(AGE_EMOJI_CACHE));
  const ranked = Object.entries(count).sort((a, b) => b[1] - a[1]);
  let emo = '🍼';
  for (const [id, n] of ranked) {
    const f = FOOD_MAP[id];
    if (f && !used.has(f.e)) { emo = f.e; break; }
  }
  AGE_EMOJI_CACHE[m] = emo;
  return emo;
}

const AGES = Array.from({ length: 31 }, (_, i) => i + 6); /* من اتمام 6 شهور لـ 3 سنين — حسب توصية WHO/AAP */
