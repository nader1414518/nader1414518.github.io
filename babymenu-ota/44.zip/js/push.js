/* ============================================================
   📣 إشعارات عامة من الأدمن (Firebase Cloud Messaging)
   كل الأجهزة مشتركة في topic اسمه "all" + topic باللغة ("lang_ar" أو "lang_en")
   فالأدمن يبعت للكل أو للعربي بس أو للإنجليزي بس — من Firebase Console أو scripts/send-push.js
   لو الإشعار فيه data.route (مثلًا "#/vaccines") الضغط عليه بيفتح الصفحة دي.
   ============================================================ */
(function () {
  const store = {
    get(k, f) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : f; } catch { return f; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  };
  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const FM = () => (isNative() && window.Capacitor.Plugins.FirebaseMessaging) || null;
  const lang = () => (document.documentElement.lang === 'en' ? 'en' : 'ar');

  function openRoute(data) {
    if (!data) return;
    if (data.route && /^#\//.test(data.route)) {
      /* app.js بيرجّع للرئيسية مع كل رجوع من الخلفية — نوقفه لحظة ونروح للصفحة بعده */
      window.__PUSH_ROUTE_UNTIL = Date.now() + 4000;
      setTimeout(() => { location.hash = data.route; }, 400);
    } else if (data.url && /^https:\/\//.test(data.url)) window.open(data.url, '_system');
  }

  /* الإشعار وصل والتطبيق مفتوح: iOS بيعرض البانر لوحده، وأندرويد لأ — فنعرضه جوه التطبيق */
  function showInApp(n) {
    if (!n || (!n.title && !n.body)) return;
    if (window.Capacitor.getPlatform() === 'ios') return;
    document.getElementById('push-banner')?.remove();
    const el = document.createElement('div');
    el.id = 'push-banner';
    el.setAttribute('role', 'alert');
    const b = document.createElement('b');
    b.textContent = n.title || '';
    const p = document.createElement('span');
    p.textContent = n.body || '';
    el.append(b, p);
    el.addEventListener('click', () => { el.remove(); openRoute(n.data); });
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 7000);
  }

  let syncing = null;
  function syncTopics(fm) {
    if (!syncing) syncing = doSyncTopics(fm).finally(() => { syncing = null; });
    return syncing;
  }
  async function doSyncTopics(fm) {
    const want = 'lang_' + lang();
    const had = store.get('bb_pushLang', null);
    if (had === want && store.get('bb_pushAll', false)) return;
    await fm.subscribeToTopic({ topic: 'all' });
    store.set('bb_pushAll', true);
    if (had && had !== want) await fm.unsubscribeFromTopic({ topic: had }).catch(() => {});
    await fm.subscribeToTopic({ topic: want });
    store.set('bb_pushLang', want);
  }

  async function init() {
    const fm = FM();
    if (!fm) return;

    fm.addListener('notificationActionPerformed', e => openRoute(e && e.notification && e.notification.data));
    fm.addListener('notificationReceived', e => showInApp(e && e.notification));
    /* توكن جديد/متجدد ⇒ نتأكد من الاشتراك في الـ topics */
    fm.addListener('tokenReceived', () => {
      store.set('bb_pushAll', false);
      syncTopics(fm).catch(() => {});
    });

    try {
      let perm = await fm.checkPermissions();
      /* بنسأل مرة واحدة بس — لو رفضت مش هنزهقها */
      if (perm.receive === 'prompt' && !store.get('bb_pushAsked', false)) {
        store.set('bb_pushAsked', true);
        perm = await fm.requestPermissions();
      }
      if (perm.receive !== 'granted') return;
      await registerWithRetry(fm);
    } catch (e) {
      console.warn('[push]', e && e.message);
    }
  }

  /* على iOS توكن APNs ساعات بيتأخر ثواني بعد الإذن ⇒ getToken بيفشل أول مرة — نحاول تاني */
  async function registerWithRetry(fm) {
    const waits = [0, 3000, 8000, 20000, 60000];
    for (const w of waits) {
      if (w) await new Promise(r => setTimeout(r, w));
      try {
        await fm.getToken();   /* بيسجّل الجهاز عند Firebase/APNs */
        await syncTopics(fm);
        return;
      } catch (e) {
        console.warn('[push] retry', e && e.message);
      }
    }
  }

  /* تغيير اللغة ⇒ نحدّث topic اللغة */
  new MutationObserver(() => {
    const fm = FM();
    if (fm && store.get('bb_pushAll', false)) syncTopics(fm).catch(() => {});
  }).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });

  window.BeebyPush = { init };
  /* بعد ما الصفحة تفتح بثانيتين — عشان طلب الإذن مايطلعش فوق شاشة البداية */
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(init, 2000));
  else setTimeout(init, 2000);
})();
