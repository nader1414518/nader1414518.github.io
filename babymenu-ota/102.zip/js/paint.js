/* ============================================================
   🎨 رسم وتلوين — بيبي منيو
   - "ارسم من خيالك": صفحة فاضية (كانفس) وألوان شمع تحتها — الطفل يختار لون ويرسم بصباعه
   - "لوّن الصور": رسومات جاهزة (SVG من paint-pages.js) وألوان تحتها — يختار لون وبعدين يدوس على الجزء اللي عاوز يلوّنه
   - الصفحات: #/games/paint (الاستوديو) · #/games/paint/draw (الرسم) · #/games/paint/<id> (تلوين صورة)
   - التقدّم بيتحفظ في الجهاز (bb_paint): الرسمة الأخيرة، وألوان كل صورة، والصور اللي خلصت
     (التطبيق بيرجع للرئيسية لما يتفتح تاني من الخلفية، فالحفظ بيمنع ضياع الرسمة)
   - بيتحمّل بعد paint-pages.js وقبل app.js، وبيستخدم دوال app.js (tx, num, isAr, esc, togglesHtml, baby, nameBlank) وقت الرسم بس
   - games.js بينادي window.renderPaint(sub) من صفحة الألعاب
   ============================================================ */
(function () {
  const PAGES = window.PAINT_PAGES || [];
  const KEY = 'bb_paint';
  const $ = () => document.getElementById('app');
  const sfx = n => { if (window.BeebySfx) window.BeebySfx.play(n); };
  const rnd = n => Math.floor(Math.random() * n);
  const nm = x => (isAr() ? x.ar : x.en);
  const qs = s => document.querySelector(s);

  /* ---------- الألوان ---------- */
  const COLORS = [
    { id: 'rainbow', ar: 'قوس قزح', en: 'Rainbow' },
    { id: 'maroon', hex: '#9E2229', ar: 'أحمر غامق', en: 'Dark red' },
    { id: 'red', hex: '#E8453C', ar: 'أحمر', en: 'Red' },
    { id: 'coral', hex: '#FF7A6B', ar: 'مرجاني', en: 'Coral' },
    { id: 'orange', hex: '#FB8C1D', ar: 'برتقاني', en: 'Orange' },
    { id: 'gold', hex: '#E3A400', ar: 'دهبي', en: 'Gold' },
    { id: 'yellow', hex: '#FFD43B', ar: 'أصفر', en: 'Yellow' },
    { id: 'lime', hex: '#9BD13B', ar: 'أخضر فاتح', en: 'Light green' },
    { id: 'green', hex: '#2FA84F', ar: 'أخضر', en: 'Green' },
    { id: 'forest', hex: '#1E6B3A', ar: 'أخضر غامق', en: 'Dark green' },
    { id: 'mint', hex: '#86DDB5', ar: 'نعناعي', en: 'Mint' },
    { id: 'teal', hex: '#1CB5A8', ar: 'تركواز', en: 'Teal' },
    { id: 'sky', hex: '#4DB8F5', ar: 'سماوي', en: 'Sky blue' },
    { id: 'blue', hex: '#2F6FE0', ar: 'أزرق', en: 'Blue' },
    { id: 'navy', hex: '#223C8C', ar: 'كحلي', en: 'Navy' },
    { id: 'lavender', hex: '#B9A3F2', ar: 'لافندر', en: 'Lavender' },
    { id: 'purple', hex: '#8B4FD8', ar: 'بنفسجي', en: 'Purple' },
    { id: 'magenta', hex: '#D63A9E', ar: 'فوشيا', en: 'Magenta' },
    { id: 'pink', hex: '#FF86B5', ar: 'وردي', en: 'Pink' },
    { id: 'peach', hex: '#FFC9A3', ar: 'خوخي', en: 'Peach' },
    { id: 'tan', hex: '#D9A066', ar: 'بيج', en: 'Tan' },
    { id: 'brown', hex: '#9A6234', ar: 'بني', en: 'Brown' },
    { id: 'gray', hex: '#A0A7B0', ar: 'رمادي', en: 'Gray' },
    { id: 'black', hex: '#2E2A2B', ar: 'أسود', en: 'Black' },
  ];
  const RAINBOW = ['#E8453C', '#FB8C1D', '#FFD43B', '#2FA84F', '#4DB8F5', '#2F6FE0', '#8B4FD8'];
  const RB_CSS = 'conic-gradient(#E8453C, #FB8C1D, #FFD43B, #2FA84F, #4DB8F5, #2F6FE0, #8B4FD8, #E8453C)';
  const SIZES = [6, 12, 22, 40];                   /* قُطر الفرشاة بالبكسل: رفيع · وسط · تخين · تخين جدًا */
  const SIZE_NAME = [{ ar: 'رفيع', en: 'Thin' }, { ar: 'وسط', en: 'Medium' }, { ar: 'تخين', en: 'Thick' }, { ar: 'تخين جدًا', en: 'Extra thick' }];
  const STK_PX = [44, 64, 96, 140];                /* حجم الاستيكر بالبكسل حسب سمك الفرشاة */
  /* استيكرز: حيوانات مرسومة (img/cut) + إيموجي */
  const STK_PICS = ['lion', 'elephant', 'panda', 'monkey', 'monkey2', 'cat', 'rabbit', 'cow', 'sheep', 'camel', 'frog', 'turtle', 'hen', 'duck', 'clownfish'];
  const STK_EMO = ['⭐', '❤️', '🌈', '☀️', '🌙', '☁️', '🌸', '🌻', '🌳', '🍎', '🍓', '🎈', '🎁', '🚗', '✈️', '🚀', '🦋', '🐶', '🐻', '🐯', '🦊', '🐴', '🐧', '🦄'];
  /* أشكال هندسية: بتتسحب بالإصبع من ركن لركن */
  const SHAPES = [
    { id: 'circle', ar: 'دايرة', en: 'Circle', sq: 1 }, { id: 'square', ar: 'مربع', en: 'Square', sq: 1 }, { id: 'triangle', ar: 'مثلث', en: 'Triangle', sq: 0 },
    { id: 'rect', ar: 'مستطيل', en: 'Rectangle', sq: 0 }, { id: 'oval', ar: 'بيضاوي', en: 'Oval', sq: 0 }, { id: 'star', ar: 'نجمة', en: 'Star', sq: 1 },
    { id: 'heart', ar: 'قلب', en: 'Heart', sq: 1 }, { id: 'diamond', ar: 'معين', en: 'Diamond', sq: 0 }, { id: 'pentagon', ar: 'خماسي', en: 'Pentagon', sq: 1 },
    { id: 'hexagon', ar: 'سداسي', en: 'Hexagon', sq: 1 }, { id: 'line', ar: 'خط مستقيم', en: 'Line', sq: 0 },
  ];
  const SHAPE_ICON = {
    circle: '<circle cx="12" cy="12" r="8.5"/>', square: '<rect x="4" y="4" width="16" height="16" rx="1.5"/>', triangle: '<path d="M12 4 21 20H3Z"/>',
    rect: '<rect x="2.5" y="6.5" width="19" height="11" rx="1.5"/>', oval: '<ellipse cx="12" cy="12" rx="10" ry="6.5"/>',
    star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9Z"/>',
    heart: '<path d="M12 20C5 15 3 11.5 3 8.7 3 6 5 4.5 7.2 4.5c1.9 0 3.5 1 4.8 3 1.3-2 2.9-3 4.8-3C19 4.5 21 6 21 8.7c0 2.8-2 6.3-9 11.3Z"/>',
    diamond: '<path d="M12 2.5 21.5 12 12 21.5 2.5 12Z"/>', pentagon: '<path d="m12 3 8.8 6.4-3.4 10.3H6.6L3.2 9.4Z"/>',
    hexagon: '<path d="M7.2 4h9.6L21.5 12l-4.7 8H7.2L2.5 12Z"/>', line: '<path d="M4 19 20 5"/>',
  };
  function shapePath(g, k, x0, y0, x1, y1) {
    const l = Math.min(x0, x1), r = Math.max(x0, x1), t = Math.min(y0, y1), b = Math.max(y0, y1), w = r - l, h = b - t, cx = (l + r) / 2, cy = (t + b) / 2;
    g.beginPath();
    const poly = (n, rot, inner) => { const m = inner ? n * 2 : n; for (let i = 0; i < m; i++) { const a = rot + i * Math.PI * 2 / m, f = inner && i % 2 ? inner : 1; g[i ? 'lineTo' : 'moveTo'](cx + Math.cos(a) * w / 2 * f, cy + Math.sin(a) * h / 2 * f); } g.closePath(); };
    if (k === 'circle' || k === 'oval') g.ellipse(cx, cy, Math.max(.5, w / 2), Math.max(.5, h / 2), 0, 0, 6.2832);
    else if (k === 'square' || k === 'rect') g.rect(l, t, w, h);
    else if (k === 'triangle') { g.moveTo(cx, t); g.lineTo(r, b); g.lineTo(l, b); g.closePath(); }
    else if (k === 'diamond') { g.moveTo(cx, t); g.lineTo(r, cy); g.lineTo(cx, b); g.lineTo(l, cy); g.closePath(); }
    else if (k === 'pentagon') poly(5, -Math.PI / 2);
    else if (k === 'hexagon') poly(6, 0);
    else if (k === 'star') poly(5, -Math.PI / 2, .45);
    else if (k === 'heart') {
      g.moveTo(cx, t + h * .3); g.bezierCurveTo(cx, t, l, t, l, t + h * .33); g.bezierCurveTo(l, t + h * .66, cx, t + h * .85, cx, b);
      g.bezierCurveTo(cx, t + h * .85, r, t + h * .66, r, t + h * .33); g.bezierCurveTo(r, t, cx, t, cx, t + h * .3); g.closePath();
    } else if (k === 'line') { g.moveTo(x0, y0); g.lineTo(x1, y1); }
  }
  function drawShape(env, st, k) {   /* k = وحدات الشاشة لكل ١٠٠٠ */
    const g = env.g, a = st.a;
    g.save(); g.lineJoin = 'round'; g.lineCap = 'round'; g.lineWidth = Math.max(1, st.s * k);
    let col = st.c;
    if (col === 'rb') { const gr = g.createLinearGradient(Math.min(a[0], a[2]) * k, 0, Math.max(a[0], a[2]) * k + 1, 0); RAINBOW.forEach((h, i) => gr.addColorStop(i / (RAINBOW.length - 1), h)); col = gr; }
    g.strokeStyle = col; g.fillStyle = col;
    shapePath(g, st.k, a[0] * k, a[1] * k, a[2] * k, a[3] * k);
    if (st.f && st.k !== 'line') g.fill(); else g.stroke();
    g.restore();
  }
  const STK_IMG = {};
  const stkImg = id => {
    if (!STK_IMG[id]) { const im = new Image(); im.onload = () => { if (V && V.kind === 'draw') replay(); }; im.src = `img/cut/${id}.webp`; STK_IMG[id] = im; }
    return STK_IMG[id];
  };

  /* ---------- الحفظ (الرسمة الأخيرة + ألوان الصور) ---------- */
  const okStroke = st => st && ((Array.isArray(st.p) && st.p.length >= 2 && typeof st.s === 'number' && typeof st.c === 'string') ||
    (st.t === 'h' && typeof st.k === 'string' && Array.isArray(st.a) && st.a.length === 4 && typeof st.s === 'number' && typeof st.c === 'string') ||
    (st.t === 'k' && typeof st.k === 'string' && st.k.length < 12 && typeof st.x === 'number' && typeof st.y === 'number' && typeof st.s === 'number'));
  function load() {
    let o = {};
    try { o = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) {}
    const d = o.draw || {};
    return {
      pick: COLORS.some(c => c.id === o.pick) ? o.pick : 'red',
      size: SIZES[o.size] ? o.size : 1,
      draw: { strokes: Array.isArray(d.strokes) ? d.strokes.filter(okStroke) : [], ar: +d.ar > 0.3 && +d.ar < 4 ? +d.ar : 1.3 },
      pages: cleanPages(o.pages),
    };
  }
  /* ألوان الصور المحفوظة: بنقبل ألوان hex بس (ولو التخزين اتبوّظ نتجاهله) */
  function cleanPages(src) {
    const out = {};
    if (!src || typeof src !== 'object') return out;
    Object.keys(src).forEach(id => {
      const r = src[id] || {}, f = {};
      Object.keys(r.f || {}).forEach(k => { if (/^\d+$/.test(k) && /^#[0-9a-fA-F]{6}$/.test(String(r.f[k]))) f[k] = r.f[k]; });
      out[id] = { f, d: r.d ? 1 : 0 };
    });
    return out;
  }
  let P = load();
  let saveT = 0;
  const flush = () => {
    clearTimeout(saveT); saveT = 0;
    try {
      let j = JSON.stringify(P);
      if (j.length > 2500000) {                                      /* رسمة ضخمة جدًا: نحفظ الألوان بس عشان مننكسرش على سعة التخزين */
        j = JSON.stringify(Object.assign({}, P, { draw: { strokes: [], ar: P.draw.ar } }));
      }
      localStorage.setItem(KEY, j);
    } catch (e) {}
  };
  const persist = () => { clearTimeout(saveT); saveT = setTimeout(flush, 400); };
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', flush);

  /* خطوات الرجوع (Undo) — في الذاكرة بس */
  const HIST = { draw: [], pages: {} };

  /* حالة الشاشة الحالية: { kind: 'studio' | 'draw' | 'color', tool: 'brush' | 'erase', ... } */
  let V = null;
  const colorOf = () => COLORS.find(c => c.id === P.pick) || COLORS[1];
  const curCss = () => (V && V.tool === 'erase' ? '#cfc4ba' : (colorOf().hex || RB_CSS));

  /* ============================================================
     ✏️ الرسم الحر — كانفس
     كل خط بيتحفظ كنقط (إحداثيات نسبية لعرض الصفحة) عشان نقدر نعيد رسمه (رجوع خطوة / تغيير حجم الشاشة)
     وبيترسم بأختام فرشاة (شمع) فيها حواف خشنة شوية
     ============================================================ */
  const D = { stamp: null, shape: null, cv: null, g: null, W: 0, H: 0, dpr: 1, dabs: new Map(), active: null, ro: null };

  function mulberry(a) {
    return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  }
  const hashStr = s => { let h = 7; for (let i = 0; i < s.length; i++) h = Math.imul(h, 31) + s.charCodeAt(i) | 0; return h; };

  /* ختم الفرشاة: دايرة صلبة بحواف خشنة وفيها حبيبات ورق — متحفوظ لكل (لون × حجم × نسخة) */
  function getDab(env, color, r, v) {
    const key = color + '|' + Math.round(r * 4) + '|' + v;
    let c = env.dabs.get(key);
    if (c) return c;
    const R = r * env.dpr, px = Math.ceil(R * 2.4) + 4;
    c = document.createElement('canvas'); c.width = c.height = px;
    const g = c.getContext('2d'), rand = mulberry(hashStr(color) + v * 977 + Math.round(R) * 31), m = px / 2;
    g.fillStyle = color;
    g.beginPath(); g.arc(m, m, R * .8, 0, 6.2832); g.fill();
    const N = Math.round(R * 6 + 14);
    for (let i = 0; i < N; i++) {
      const a = rand() * 6.2832, d = R * (.6 + .42 * Math.pow(rand(), .85)), rr = Math.max(.7, R * (.05 + .1 * rand()) * (1.2 - (d / R - .6)));
      g.beginPath(); g.arc(m + Math.cos(a) * d, m + Math.sin(a) * d, rr, 0, 6.2832); g.fill();
    }
    g.globalCompositeOperation = 'destination-out';
    g.fillStyle = '#000'; g.globalAlpha = .5;
    const H = Math.round(R * R * .22);
    for (let i = 0; i < H; i++) {
      const a = rand() * 6.2832, d = R * 1.05 * Math.sqrt(rand());
      g.beginPath(); g.arc(m + Math.cos(a) * d, m + Math.sin(a) * d, .5 + rand() * .9, 0, 6.2832); g.fill();
    }
    env.dabs.set(key, c);
    return c;
  }

  /* فرشاة: بتمشي على نقط الخط (منحنى ناعم بين نقط المنتصف) وبتختم على مسافات صغيرة */
  function Brush(env, st) {
    this.env = env; this.st = st; this.r = st.s * env.W / 2000;
    this.step = Math.max(.9, this.r * .3); this.n = 0; this.k = 0; this.dist = 0;
    this.px = 0; this.py = 0; this.mx = 0; this.my = 0;
  }
  /* قوس قزح: اللون بيمشي بين ألوان القوس نفسها (أحمر ← برتقاني ← أصفر ← أخضر ← سماوي ← أزرق ← بنفسجي) على حسب المسافة */
  const RB_RGB = RAINBOW.map(h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]);
  function rainbowAt(f) {
    const n = RB_RGB.length;
    f = ((f % n) + n) % n;
    const i = Math.floor(f), t = Math.round((f - i) * 4) / 4, a = RB_RGB[i], b = RB_RGB[(i + 1) % n];
    return `rgb(${[0, 1, 2].map(k => Math.round(a[k] + (b[k] - a[k]) * t)).join(',')})`;
  }
  Brush.prototype.color = function () {
    if (this.st.c === 'rb') return rainbowAt((this.st.h || 0) / 360 * RB_RGB.length + this.dist / (26 + this.r * 1.3));
    return this.st.c;
  };
  Brush.prototype.stamp = function (x, y) {
    const g = this.env.g;
    if (this.st.e) {                                          /* ممحاة */
      g.globalCompositeOperation = 'destination-out';
      g.beginPath(); g.arc(x, y, this.r, 0, 6.2832); g.fill();
      g.globalCompositeOperation = 'source-over';
      return;
    }
    const dab = getDab(this.env, this.color(), this.r, this.k++ & 3), s = dab.width / this.env.dpr;
    g.drawImage(dab, x - s / 2, y - s / 2, s, s);
  };
  Brush.prototype.seg = function (x0, y0, cx, cy, x1, y1) {
    const L = Math.hypot(cx - x0, cy - y0) + Math.hypot(x1 - cx, y1 - cy), n = Math.max(1, Math.ceil(L / this.step));
    let px = x0, py = y0;
    for (let i = 1; i <= n; i++) {
      const t = i / n, u = 1 - t, x = u * u * x0 + 2 * u * t * cx + t * t * x1, y = u * u * y0 + 2 * u * t * cy + t * t * y1;
      this.dist += Math.hypot(x - px, y - py); px = x; py = y;
      this.stamp(x, y);
    }
  };
  Brush.prototype.add = function (x, y) {
    if (this.n === 0) { this.stamp(x, y); this.mx = this.px = x; this.my = this.py = y; this.n = 1; return; }
    const mx = (this.px + x) / 2, my = (this.py + y) / 2;
    this.seg(this.mx, this.my, this.px, this.py, mx, my);
    this.mx = mx; this.my = my; this.px = x; this.py = y; this.n++;
  };
  Brush.prototype.end = function () {
    if (this.n > 1) this.seg(this.mx, this.my, (this.mx + this.px) / 2, (this.my + this.py) / 2, this.px, this.py);
  };
  /* استيكر: صورة حيوان (i:id) أو إيموجي (e:🦁) متمركز في (x,y) وحجمه px */
  function drawStamp(env, key, x, y, px) {
    const g = env.g;
    if (key.startsWith('i:')) {
      const im = stkImg(key.slice(2));
      if (im.complete && im.naturalWidth) g.drawImage(im, x - px / 2, y - px / 2, px, px);
    } else {
      g.save(); g.font = `${Math.round(px * .82)}px "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif`;
      g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#000';
      g.fillText(key.slice(2), x, y + px * .06); g.restore();
    }
  }
  /* بيرسم كل الخطوط على سطح (env) — نفس الدالة للشاشة وللمعاينة */
  function paintStrokes(env, strokes) {
    strokes.forEach(st => {
      if (st.t === 'h') { drawShape(env, st, env.W / 1000); return; }
      if (st.t === 'k') { drawStamp(env, st.k, st.x * env.W / 1000, st.y * env.W / 1000, st.s * env.W / 1000); return; }
      const b = new Brush(env, st), k = env.W / 1000;
      for (let i = 0; i + 1 < st.p.length; i += 2) b.add(st.p[i] * k, st.p[i + 1] * k);
      b.end();
    });
  }

  function fitCanvas() {
    if (!D.cv || !D.cv.isConnected) return;
    const r = D.cv.parentElement.getBoundingClientRect();
    const W = Math.max(1, Math.round(r.width)), H = Math.max(1, Math.round(r.height));
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    if (W === D.W && H === D.H && dpr === D.dpr && D.g) return;
    D.W = W; D.H = H; D.dpr = dpr;
    D.cv.width = Math.round(W * dpr); D.cv.height = Math.round(H * dpr);
    D.g = D.cv.getContext('2d');
    D.g.setTransform(dpr, 0, 0, dpr, 0, 0);
    D.dabs.clear();
    P.draw.ar = +(H / W).toFixed(3);
    replay();
  }
  function replay() {
    if (!D.g) return;
    D.g.save(); D.g.setTransform(1, 0, 0, 1, 0, 0); D.g.clearRect(0, 0, D.cv.width, D.cv.height); D.g.restore();
    paintStrokes(D, P.draw.strokes);
    const h = qs('#pt-hint'); if (h) h.classList.toggle('off', P.draw.strokes.length > 0 || !!D.active);
  }

  function startStroke(e) {
    const rc = D.cv.getBoundingClientRect(), erase = V.tool === 'erase', col = colorOf();
    const diam = SIZES[P.size] * (erase ? 2 : 1);
    const st = { c: erase ? '#000' : (col.hex || 'rb'), s: Math.round(diam / D.W * 1000), p: [] };
    if (erase) st.e = 1; else if (!col.hex) st.h = rnd(360);
    D.active = { id: e.pointerId, st, brush: new Brush(D, st), lx: -99, ly: -99 };
    const h = qs('#pt-hint'); if (h) h.classList.add('off');
    addPoint(e.clientX - rc.left, e.clientY - rc.top, true);
  }
  function addPoint(x, y, first) {
    const a = D.active; if (!a) return;
    if (!first && Math.hypot(x - a.lx, y - a.ly) < .8) return;
    a.lx = x; a.ly = y;
    a.st.p.push(Math.round(x / D.W * 1000), Math.round(y / D.W * 1000));
    a.brush.add(x, y);
  }
  function endStroke() {
    const a = D.active; if (!a) return;
    D.active = null;
    a.brush.end();
    P.draw.strokes.push(a.st);
    HIST.draw.push({ t: 's' });
    if (HIST.draw.length > 60) HIST.draw.shift();
    persist(); syncTools();
  }
  function shapeSt() {
    const t = D.shape, def = SHAPES.find(x => x.id === V.shp) || SHAPES[0];
    let { x0, y0, x1, y1 } = t;
    if (def.sq) { const m = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)); x1 = x0 + m * (x1 >= x0 ? 1 : -1); y1 = y0 + m * (y1 >= y0 ? 1 : -1); }
    const col = colorOf(), n = v => Math.round(v / D.W * 1000);
    return { t: 'h', k: V.shp, c: col.hex || 'rb', f: V.fill ? 1 : 0, s: Math.max(2, Math.round(SIZES[P.size] / D.W * 1000)), a: [n(x0), n(y0), n(x1), n(y1)] };
  }
  function shapeGhost() { replay(); if (D.shape) drawShape(D, shapeSt(), D.W / 1000); }
  function endShape() {
    const t = D.shape; D.shape = null; if (!t) return;
    if (Math.hypot(t.x1 - t.x0, t.y1 - t.y0) < 6) { replay(); return; }
    P.draw.strokes.push(shapeSt());
    HIST.draw.push({ t: 's' }); if (HIST.draw.length > 60) HIST.draw.shift();
    replay(); persist(); syncTools(); sfx('flip');
  }
  const stampPx = () => STK_PX[P.size] || 64;
  function stampGhost() { replay(); const t = D.stamp; if (t) drawStamp(D, V.stk, t.x, t.y, stampPx()); }
  function endStamp() {
    const t = D.stamp; D.stamp = null; if (!t || !V || !V.stk) return;
    P.draw.strokes.push({ t: 'k', k: V.stk, x: Math.round(t.x / D.W * 1000), y: Math.round(t.y / D.W * 1000), s: Math.round(stampPx() / D.W * 1000) });
    HIST.draw.push({ t: 's' }); if (HIST.draw.length > 60) HIST.draw.shift();
    replay(); persist(); syncTools(); sfx('flip');
  }
  function bindCanvas() {
    const cv = D.cv;
    cv.addEventListener('pointerdown', e => {
      if (!V || V.kind !== 'draw' || (e.pointerType === 'mouse' && e.button !== 0)) return;
      if (D.active) { if (!e.isPrimary) return; endStroke(); }   /* إصبع تاني أو كف: بيتجاهل — لمسة أساسية جديدة: الخط القديم خلص */
      e.preventDefault();
      try { cv.setPointerCapture(e.pointerId); } catch (_) {}
      if (V.tool === 'shape' && V.shp) {                         /* شكل: بنسحب من ركن لركن */
        const rc = cv.getBoundingClientRect(), x = e.clientX - rc.left, y = e.clientY - rc.top;
        D.shape = { id: e.pointerId, x0: x, y0: y, x1: x, y1: y };
        const h = qs('#pt-hint'); if (h) h.classList.add('off');
        return;
      }
      if (V.tool === 'sticker' && V.stk) {                       /* استيكر: نوريه مكانه ونثبّته لما الإصبع يتشال */
        const rc = cv.getBoundingClientRect();
        D.stamp = { id: e.pointerId, x: e.clientX - rc.left, y: e.clientY - rc.top };
        stampGhost(); return;
      }
      startStroke(e);
    });
    cv.addEventListener('pointermove', e => {
      if (D.shape && e.pointerId === D.shape.id) { e.preventDefault(); const rc = cv.getBoundingClientRect(); D.shape.x1 = e.clientX - rc.left; D.shape.y1 = e.clientY - rc.top; shapeGhost(); return; }
      if (D.stamp && e.pointerId === D.stamp.id) { e.preventDefault(); const rc = cv.getBoundingClientRect(); D.stamp.x = e.clientX - rc.left; D.stamp.y = e.clientY - rc.top; stampGhost(); return; }
      const a = D.active; if (!a || e.pointerId !== a.id) return;
      e.preventDefault();
      const rc = cv.getBoundingClientRect(), list = e.getCoalescedEvents ? e.getCoalescedEvents() : null;
      (list && list.length ? list : [e]).forEach(ev => addPoint(ev.clientX - rc.left, ev.clientY - rc.top, false));
    });
    const up = e => { if (D.shape && e.pointerId === D.shape.id) return endShape(); if (D.stamp && e.pointerId === D.stamp.id) return endStamp(); if (D.active && e.pointerId === D.active.id) endStroke(); };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up); cv.addEventListener('lostpointercapture', up);
    cv.addEventListener('contextmenu', e => e.preventDefault());
  }
  function initCanvas() {
    if (D.ro) { D.ro.disconnect(); D.ro = null; }
    D.cv = document.getElementById('pt-cv'); D.g = null; D.W = D.H = 0; D.active = null; D.stamp = null; D.shape = null;
    if (!D.cv) return;
    fitCanvas();
    bindCanvas();
    if (window.ResizeObserver) { D.ro = new ResizeObserver(() => fitCanvas()); D.ro.observe(D.cv.parentElement); }
  }
  window.addEventListener('resize', () => { if (V && V.kind === 'draw') fitCanvas(); });

  function undoDraw() {
    const h = HIST.draw.pop();
    if (!h) return;
    if (h.t === 's') P.draw.strokes.pop(); else P.draw.strokes = h.prev;
    replay(); persist(); syncTools(); sfx('untick');
  }
  function clearDraw() {
    if (!P.draw.strokes.length) return;
    HIST.draw.push({ t: 'c', prev: P.draw.strokes });
    P.draw.strokes = [];
    replay(); persist(); syncTools(); sfx('untick');
  }

  /* صورة الرسمة (على خلفية بيضا) — للمعاينة */
  function snapshot(maxW) {
    const k = Math.min(1, maxW / D.cv.width), c = document.createElement('canvas');
    c.width = Math.round(D.cv.width * k); c.height = Math.round(D.cv.height * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(D.cv, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', .85);
  }
  /* معاينة الرسمة المحفوظة (لكارت الاستوديو) من غير ما تفتح الكانفس */
  let prevCache = { n: -1, last: null, ar: 0, url: '' };
  function savedPreview() {
    const st = P.draw.strokes;
    if (!st.length) return '';
    if (prevCache.n === st.length && prevCache.last === st[st.length - 1] && prevCache.ar === P.draw.ar) return prevCache.url;
    try {
      const w = 260, h = Math.round(w * P.draw.ar), a = document.createElement('canvas');
      a.width = w; a.height = h;
      paintStrokes({ g: a.getContext('2d'), W: w, dpr: 1, dabs: new Map() }, st);
      const b = document.createElement('canvas'); b.width = w; b.height = h;
      const g = b.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.drawImage(a, 0, 0);
      prevCache = { n: st.length, last: st[st.length - 1], ar: P.draw.ar, url: b.toDataURL('image/jpeg', .8) };
      return prevCache.url;
    } catch (e) { return ''; }
  }

  /* ============================================================
     🖍️ التلوين — SVG
     ============================================================ */
  const svgOf = (pg, fills) => {
    const body = pg.svg.replace(/data-r="(\d+)"/g, (m, i) => (fills && fills[i] ? `${m} style="fill:${fills[i]}"` : m));
    return `<svg class="pt-svg${pg.ras ? ' ras' : ''}" viewBox="${pg.vb || '0 0 400 400'}" role="img" aria-label="${esc(nm(pg))}">${body}</svg>`;
  };
  const recOf = id => (P.pages[id] = P.pages[id] || { f: {}, d: 0 });

  function setFill(id, col) {
    if (col) V.fills[id] = col; else delete V.fills[id];
    const el = qs(`#pt-paper .r[data-r="${id}"]`);
    if (el) el.style.fill = col || '';
    persist();
  }
  /* رشّة ألوان صغيرة مكان الدوسة */
  function splash(ev, col) {
    const box = document.getElementById('pt-paper'); if (!box) return;
    const rc = box.getBoundingClientRect(), x = ev && ev.clientX ? ev.clientX - rc.left : rc.width / 2, y = ev && ev.clientY ? ev.clientY - rc.top : rc.height / 2;
    for (let i = 0; i < 7; i++) {
      const a = (i / 7 + Math.random() * .12) * 6.2832, d = 26 + rnd(30), s = document.createElement('i');
      s.className = 'pt-spl';
      s.style.cssText = `left:${x}px;top:${y}px;--c:${col};--dx:${Math.round(Math.cos(a) * d)}px;--dy:${Math.round(Math.sin(a) * d)}px;--sz:${6 + rnd(6)}px`;
      box.appendChild(s);
      setTimeout(() => s.remove(), 650);
    }
  }
  function fillRegion(el, ev) {
    if (!V || V.kind !== 'color') return;
    const id = el.getAttribute('data-r'), cur = V.fills[id] || null;
    const col = V.tool === 'erase' ? null : (colorOf().hex || RAINBOW[V.rb++ % RAINBOW.length]);
    el.classList.remove('pop'); void el.getBoundingClientRect(); el.classList.add('pop');
    if (col === cur) { sfx(col ? 'flip' : 'tap'); return; }
    (HIST.pages[V.page.id] = HIST.pages[V.page.id] || []).push({ id, prev: cur });
    if (HIST.pages[V.page.id].length > 80) HIST.pages[V.page.id].shift();
    setFill(id, col);
    if (col) { splash(ev, col); sfx('pop'); } else sfx('untick');
    syncTools();
  }
  function undoColor() {
    const h = (HIST.pages[V.page.id] || []).pop();
    if (!h) return;
    if (h.all) {
      Object.keys(V.fills).forEach(k => delete V.fills[k]);
      Object.assign(V.fills, h.all);
      document.querySelectorAll('#pt-paper .r').forEach(el => { el.style.fill = V.fills[el.getAttribute('data-r')] || ''; });
      persist();
    } else setFill(h.id, h.prev);
    syncTools(); sfx('untick');
  }
  function resetColor() {
    if (!Object.keys(V.fills).length) return;
    (HIST.pages[V.page.id] = HIST.pages[V.page.id] || []).push({ all: Object.assign({}, V.fills) });
    Object.keys(V.fills).forEach(k => delete V.fills[k]);
    recOf(V.page.id).d = 0;
    document.querySelectorAll('#pt-paper .r').forEach(el => { el.style.fill = ''; });
    persist(); syncTools(); sfx('untick');
  }

  /* ============================================================
     🧰 أدوات + 🎨 ألوان (HTML)
     ============================================================ */
  const IC = {
    undo: '<svg viewBox="0 0 24 24" aria-hidden="true"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>',
    eraser: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21"/><path d="M22 21H7"/><path d="m5 11 9 9"/></svg>',
    trash: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><path d="M10 11v6M14 11v6"/></svg>',
    smile: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8 14.2c1 1.5 2.4 2.3 4 2.3s3-.8 4-2.3"/><path d="M9 9.5h.01M15 9.5h.01"/></svg>',
    shapes: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3.5 13.5 12h-11Z"/><circle cx="16.5" cy="16.5" r="4.5"/></svg>',
    save: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12M7 10.5l5 5 5-5"/><path d="M4 20h16"/></svg>',
    check: '<svg viewBox="0 0 24 24" aria-hidden="true" class="ok"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  };
  const dark = hex => { const n = parseInt(hex.slice(1), 16), r = n >> 16, g = n >> 8 & 255, b = n & 255; return (r * .299 + g * .587 + b * .114) < 120; };

  /* قلم شمع (للرسم) */
  function crayon(c) {
    const body = c.hex ? c.hex : 'url(#ptrbc)', st = 'stroke="rgba(0,0,0,.22)" stroke-width="1"';
    const defs = c.hex ? '' : '<defs><linearGradient id="ptrbc" x1="0" y1="0" x2="1" y2="0">' + RAINBOW.map((h, i) => `<stop offset="${(i / 6).toFixed(2)}" stop-color="${h}"/>`).join('') + '</linearGradient></defs>';
    return `<svg viewBox="0 0 34 64" aria-hidden="true">${defs}<path d="M7 22 Q9 11 15 4.5 Q17 2 19 4.5 Q25 11 27 22 Z" fill="${body}" ${st} stroke-linejoin="round"/><rect x="5" y="21" width="24" height="43" rx="3" fill="${body}" ${st}/><rect x="5" y="31" width="24" height="5" fill="rgba(25,18,20,.8)"/><rect x="5" y="49" width="24" height="5" fill="rgba(25,18,20,.8)"/><rect x="9" y="24" width="3.4" height="37" rx="1.7" fill="#fff" opacity=".3"/></svg>`;
  }
  /* نقطة ألوان بوش مبتسم (للتلوين) */
  function drop(c) {
    const body = c.hex ? c.hex : 'url(#ptrbd)', face = c.hex && !dark(c.hex) ? 'rgba(60,30,30,.75)' : '#fff';
    const defs = c.hex ? '' : '<defs><linearGradient id="ptrbd" x1="0" y1="0" x2="0" y2="1">' + RAINBOW.map((h, i) => `<stop offset="${(i / 6).toFixed(2)}" stop-color="${h}"/>`).join('') + '</linearGradient></defs>';
    return `<svg viewBox="0 0 40 50" aria-hidden="true">${defs}<path d="M20 3 C20 3 5 21 5 32 a15 15 0 0 0 30 0 C35 21 20 3 20 3 Z" fill="${body}" stroke="rgba(0,0,0,.2)" stroke-width="1" stroke-linejoin="round"/><ellipse cx="12.5" cy="27" rx="2.6" ry="5" fill="#fff" opacity=".42" transform="rotate(18 12.5 27)"/><circle cx="15" cy="34" r="1.9" fill="${face}"/><circle cx="25" cy="34" r="1.9" fill="${face}"/><path d="M16 39.5 Q20 43.2 24 39.5" stroke="${face}" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg>`;
  }
  function palHtml(kind) {
    const on = V.tool !== 'erase' ? P.pick : null;
    return `<div class="pt-pal pt-pal-${kind}" role="group" aria-label="${isAr() ? 'الألوان' : 'Colors'}">${COLORS.map((c, i) =>
      `<button class="pt-sw ${c.id === on ? 'on' : ''}" data-act="ptcolor" data-i="${i}" data-sfx="off" aria-pressed="${c.id === on}" aria-label="${esc(nm(c))}">${kind === 'crayon' ? crayon(c) : drop(c)}</button>`).join('')}</div>`;
  }
  function toolsHtml() {
    const er = V.tool === 'erase', ar = isAr();
    const eraser = `<button class="pt-tb" data-act="pterase" data-sfx="off" aria-pressed="${er}" aria-label="${ar ? 'ممحاة' : 'Eraser'}">${IC.eraser}</button>`;
    const undo = `<button class="pt-tb" id="pt-undo" data-act="ptundo" data-sfx="off" aria-label="${ar ? 'رجوع خطوة' : 'Undo'}" disabled>${IC.undo}</button>`;
    const trash = `<button class="pt-tb" id="pt-trash" data-act="${V.kind === 'draw' ? 'ptclear' : 'ptreset'}" data-sfx="off" aria-label="${V.kind === 'draw' ? (ar ? 'صفحة جديدة' : 'New page') : (ar ? 'ابدأ من الأول' : 'Start over')}">${IC.trash}</button>`;
    const ok = `<button class="pt-tb pt-ok" data-act="ptdone" data-sfx="off" aria-label="${ar ? 'خلصت' : 'Done'}">${IC.check}</button>`;
    const sizes = V.kind === 'draw'
      ? `<div class="pt-sizes" role="group" aria-label="${ar ? 'حجم الفرشاة' : 'Brush size'}">${SIZES.map((s, i) => `<button class="pt-tb pt-sz ${i === P.size ? 'on' : ''}" data-act="ptsize" data-i="${i}" data-sfx="off" aria-pressed="${i === P.size}" aria-label="${esc(nm(SIZE_NAME[i]))}"><i style="--d:${6 + i * 5}px"></i></button>`).join('')}</div>`
      : '<span class="pt-chip" aria-hidden="true"><i></i><span><b></b><em dir="ltr"></em></span></span>';
    return `<div class="pt-tools">${sizes}${eraser}<span class="pt-sp"></span>${undo}${trash}${ok}</div>`;
  }
  /* شريط صفحة الرسم (صفين): فوق = رجوع/تراجع/حذف/حفظ/خلصت · تحت = سمك/ممحاة/استيكرز/أشكال */
  function drawBarHtml() {
    const ar = isAr(), er = V.tool === 'erase';
    const b = (act, ic, label, extra) => `<button class="pt-tb ${extra || ''}" data-act="${act}" data-sfx="off" aria-label="${label}">${ic}</button>`;
    return `
      <div class="pt-fbar">
        <a class="pt-tb pt-back" href="#/games/paint" aria-label="${ar ? 'رجوع' : 'Back'}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${ar ? 'M5 12h14M13 6l6 6-6 6' : 'M19 12H5M11 6l-6 6 6 6'}"/></svg></a>
        <span class="pt-sp"></span>
        ${b('ptdone', IC.check, ar ? 'خلصت' : 'Done', 'pt-ok')}
      </div>
      <div class="pt-side">
        <div class="pt-sizes" role="group" aria-label="${ar ? 'سمك الخط' : 'Line thickness'}">${SIZES.map((s, i) => `<button class="pt-tb pt-sz ${i === P.size ? 'on' : ''}" data-act="ptsize" data-i="${i}" data-sfx="off" aria-pressed="${i === P.size}" aria-label="${esc(nm(SIZE_NAME[i]))}"><i style="--d:${5 + i * 5}px"></i></button>`).join('')}</div>
        <span class="pt-sep"></span>
        <button class="pt-tb" data-act="pterase" data-sfx="off" aria-pressed="${er}" aria-label="${ar ? 'ممحاة' : 'Eraser'}">${IC.eraser}</button>
        <button class="pt-tb" data-act="ptstk" data-sfx="off" aria-pressed="false" aria-label="${ar ? 'استيكرز' : 'Stickers'}">${IC.smile}</button>
        <button class="pt-tb" data-act="ptshp" data-sfx="off" aria-pressed="false" aria-label="${ar ? 'أشكال' : 'Shapes'}">${IC.shapes}</button>
        <span class="pt-sep"></span>
        <button class="pt-tb" id="pt-undo" data-act="ptundo" data-sfx="off" aria-label="${ar ? 'رجوع خطوة' : 'Undo'}" disabled>${IC.undo}</button>
        <button class="pt-tb" id="pt-trash" data-act="ptclear" data-sfx="off" aria-label="${ar ? 'حذف الرسمة' : 'Delete drawing'}">${IC.trash}</button>
        ${b('ptsave', IC.save, ar ? 'حفظ الصورة' : 'Save image')}
      </div>
      <div class="pt-pan" id="pt-pan" hidden></div>`;
  }
  function panelHtml() {
    const ar = isAr();
    if (V.panel === 'stk') {
      return `<div class="pt-pgrid">${STK_PICS.map(id => `<button class="pt-pk ${V.stk === 'i:' + id ? 'on' : ''}" data-act="ptpick" data-k="i:${id}" data-sfx="off"><img src="img/cut/${id}.webp" alt="" draggable="false"></button>`).join('')}
        ${STK_EMO.map(e => `<button class="pt-pk ${V.stk === 'e:' + e ? 'on' : ''}" data-act="ptpick" data-k="e:${e}" data-sfx="off">${e}</button>`).join('')}</div>`;
    }
    return `<div class="pt-fillrow"><button class="pt-fill ${V.fill ? '' : 'on'}" data-act="ptfill" data-v="0" data-sfx="off">${ar ? 'شكل فاضي' : 'Outline'}</button><button class="pt-fill ${V.fill ? 'on' : ''}" data-act="ptfill" data-v="1" data-sfx="off">${ar ? 'شكل ملوّن' : 'Filled'}</button></div>
      <div class="pt-pgrid">${SHAPES.map(sh => `<button class="pt-pk pt-pks ${V.shp === sh.id ? 'on' : ''}" data-act="ptshape" data-k="${sh.id}" data-sfx="off" aria-label="${esc(nm(sh))}"><svg viewBox="0 0 24 24" aria-hidden="true">${SHAPE_ICON[sh.id]}</svg></button>`).join('')}</div>`;
  }
  function syncPanel() {
    const pan = document.getElementById('pt-pan'); if (!pan) return;
    pan.hidden = !V.panel; if (V.panel) pan.innerHTML = panelHtml();
  }
  /* حفظ الصورة: ملف PNG على خلفية بيضا — بيفتح مشاركة الموبايل (فيها "حفظ الصورة") أو بيتنزّل */
  function saveImage() {
    if (!D.cv || !P.draw.strokes.length) return;
    const c = document.createElement('canvas'); c.width = D.cv.width; c.height = D.cv.height;
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(D.cv, 0, 0);
    c.toBlob(async blob => {
      if (!blob) return;
      const name = 'beeby-drawing-' + Date.now() + '.png', file = new File([blob], name, { type: 'image/png' });
      try {
        if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: isAr() ? 'رسمتي' : 'My drawing' }); sfx('yay'); return; }
      } catch (e) { if (e && e.name === 'AbortError') return; }
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000); sfx('yay');
    }, 'image/png');
  }
  /* بيحدّث حالة الأزرار من غير ما يرسم الشاشة تاني */
  function syncTools() {
    if (!V || V.kind === 'studio') return;
    const root = document.getElementById('pt-root'); if (!root) return;
    root.style.setProperty('--cur', curCss());
    const er = V.tool === 'erase';
    const eb = root.querySelector('[data-act="pterase"]');
    if (eb) { eb.classList.toggle('on', er); eb.setAttribute('aria-pressed', er); }
    [['ptstk', 'sticker'], ['ptshp', 'shape']].forEach(([a, t]) => { const bb = root.querySelector(`[data-act="${a}"]`); if (bb) { bb.setAttribute('aria-pressed', V.tool === t); bb.classList.toggle('on', V.tool === t); } });
    root.querySelectorAll('.pt-sz').forEach(b => { const on = +b.dataset.i === P.size; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
    root.querySelectorAll('.pt-sw').forEach(b => { const on = !er && V.tool !== 'sticker' && COLORS[+b.dataset.i].id === P.pick; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
    const chip = root.querySelector('.pt-chip');                       /* اسم اللون الحالي (بالعربي والإنجليزي) */
    if (chip) {
      const c = er ? { ar: 'ممحاة', en: 'Eraser' } : colorOf();
      chip.querySelector('b').textContent = isAr() ? c.ar : c.en;
      chip.querySelector('em').textContent = isAr() ? c.en : '';
      chip.classList.toggle('er', er);
    }
    const u = document.getElementById('pt-undo');
    if (u) u.disabled = !(V.kind === 'draw' ? HIST.draw.length : (HIST.pages[V.page.id] || []).length);
    const t = document.getElementById('pt-trash');
    if (t) t.disabled = V.kind === 'draw' ? !P.draw.strokes.length : !Object.keys(V.fills).length;
  }

  /* ============================================================
     🖼️ الشاشات
     ============================================================ */
  const topbar = (back, logo, title, small) => `
    <div class="topbar">
      <a class="backbtn" href="${back}" aria-label="${isAr() ? 'رجوع' : 'Back'}">←</a>
      <div class="logo">${logo}</div>
      <h1 class="gm-h1">${title}<small>${small}</small></h1>
      ${togglesHtml()}
    </div>`;

  /* رسمة صغيرة على كارت "ارسم" (لما مفيش رسمة محفوظة) */
  const DOODLE = `<svg class="pt-doodle" viewBox="0 0 120 90" aria-hidden="true"><rect x="1.5" y="1.5" width="117" height="87" rx="13" fill="#fff"/>
    <path d="M16 64 C26 28 40 30 46 52 S66 78 78 46 S96 30 106 42" stroke="#F25C78" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="34" cy="26" r="9" stroke="#3DB9A5" stroke-width="6" fill="none"/>
    <path d="M82 70 q10 -16 20 0" stroke="#FFC93C" stroke-width="6" fill="none" stroke-linecap="round"/>
    <path d="M20 78 H58" stroke="#7B61D9" stroke-width="6" stroke-linecap="round"/></svg>`;

  let studioY = 0, lastKind = null;
  function renderStudio() {
    const back = lastKind === 'color' || lastKind === 'draw';
    V = { kind: 'studio' };
    const prev = savedPreview(), ar = isAr();
    const doneN = PAGES.filter(p => (P.pages[p.id] || {}).d).length;
    $().innerHTML = `
      ${topbar('#/games', '🎨', ar ? 'رسم وتلوين' : 'Draw & color', ar ? 'الإبداع والألوان' : 'Creativity & colors')}
      <div class="pt-studio" id="pt-root">
        <a class="pt-drawcard ac-cream rise" style="--i:0" href="#/games/paint/draw">
          ${prev ? `<img class="pt-doodle pt-doodle-img" src="${prev}" alt="">` : DOODLE}
          <span class="pt-dc-txt">
            <b>${ar ? 'ارسم من خيالك' : 'Draw anything'}</b>
            <small>${prev ? (ar ? 'كمّل رسمتك أو ابدأ صفحة جديدة' : 'Keep going or start a new page') : (ar ? 'صفحة فاضية وألوان — ارسم أي حاجة تحبها' : 'A blank page and colors — draw anything you like')}</small>
            <span class="pt-go">${prev ? (ar ? 'كمّل الرسم' : 'Keep drawing') : (ar ? 'يلا نرسم' : 'Let’s draw')} ✏️</span>
          </span>
        </a>
        <h2 class="pt-sec"><span>🖍️</span><b>${ar ? 'لوّن الصور' : 'Color the pictures'}</b>${doneN ? `<em>${ar ? `${num(doneN)} من ${num(PAGES.length)}` : `${doneN} / ${PAGES.length}`} ✓</em>` : ''}</h2>
        <div class="pt-grid">
          ${PAGES.map((p, i) => {
            const rec = P.pages[p.id] || {}, d = rec.d;
            return `<a class="pt-card rise" style="--i:${i + 1}" href="#/games/paint/${p.id}">
              <span class="pt-thumb" aria-hidden="true">${svgOf({ id: p.id, ar: p.ar, en: p.en, svg: p.svg, vb: p.vb, ras: p.ras }, rec.f).replace('role="img"', 'aria-hidden="true"')}</span>
              ${d ? '<i class="pt-badge" aria-hidden="true">✓</i>' : ''}
              <b>${esc(nm(p))}${ar ? ` <span class="gm-en" dir="ltr">${esc(p.en)}</span>` : ''}</b>
            </a>`;
          }).join('')}
        </div>
        <p class="gm-how">${ar ? 'اختار صورة، واختار لون، ودوس على الجزء اللي عاوز تلوّنه' : 'Pick a picture, pick a color, and tap the part you want to color'}</p>
      </div>`;
    if (back && studioY) {                                       /* راجع من صورة: نرجع لنفس المكان في القايمة (من غير حركة تمرير) */
      const el = document.documentElement;
      el.style.scrollBehavior = 'auto'; window.scrollTo(0, studioY); el.style.scrollBehavior = '';
    }
  }

  function renderDraw() {
    V = { kind: 'draw', tool: 'brush', panel: '', stk: 'i:lion', shp: 'circle', fill: 0 };
    const ar = isAr();
    $().innerHTML = `
      <div class="pt-fit pt-full" id="pt-root" style="--cur:${curCss()}">
        <div class="pt-paper pt-cvbox" id="pt-box">
          <canvas id="pt-cv" role="img" aria-label="${ar ? 'صفحة الرسم' : 'Drawing page'}"></canvas>
          <div class="pt-hint" id="pt-hint"><span>${ar ? 'ارسم هنا ✏️' : 'Draw here ✏️'}</span></div>
        </div>
        ${drawBarHtml()}
        ${palHtml('crayon')}
      </div>`;
    initCanvas();
    syncTools();
  }

  function renderColor(pg) {
    const rec = recOf(pg.id), ar = isAr();
    V = { kind: 'color', page: pg, tool: 'brush', fills: rec.f, rb: 0 };
    $().innerHTML = `
      ${topbar('#/games/paint', '🖍️', esc(nm(pg)), ar ? `${esc(pg.en)} · لوّن الصورة` : 'Color the picture')}
      <div class="pt-fit pt-color" id="pt-root" style="--cur:${curCss()}">
        <div class="pt-paper pt-svgbox" id="pt-paper" data-act="ptpaper" data-sfx="off">${svgOf(pg, rec.f)}</div>
        ${toolsHtml()}
        ${palHtml('drop')}
        <p class="pt-tip">${ar ? 'اختار لون من تحت 👇 وبعدين دوس على الجزء اللي عاوز تلوّنه' : 'Pick a color below 👇 then tap the part you want to color'}</p>
      </div>`;
    syncTools();
  }

  /* ============================================================
     🏆 "خلصت" — بطاقة تهنئة بمعاينة الرسمة
     ============================================================ */
  function celebrate() {
    const app = $();
    if (!app || app.querySelector('.gm-win')) return;
    const ar = isAr(), draw = V.kind === 'draw';
    const empty = draw ? !P.draw.strokes.length : !Object.keys(V.fills).length;
    if (empty) {                                         /* لسه ملمسش حاجة */
      const box = document.getElementById(draw ? 'pt-box' : 'pt-paper');
      if (box) { box.classList.remove('no'); void box.offsetWidth; box.classList.add('no'); }
      sfx('nope');
      return;
    }
    let prev, next = null;
    if (draw) prev = `<img class="pt-prev-img" src="${snapshot(520)}" alt="">`;
    else {
      recOf(V.page.id).d = 1; persist();
      prev = svgOf(V.page, V.fills).replace('role="img"', 'aria-hidden="true"');
      const i = PAGES.findIndex(p => p.id === V.page.id);
      for (let k = 1; k <= PAGES.length; k++) { const p = PAGES[(i + k) % PAGES.length]; if (p.id !== V.page.id && !(P.pages[p.id] || {}).d) { next = p; break; } }
    }
    const name = (typeof baby !== 'undefined' && baby && typeof nameBlank === 'function' && !nameBlank(baby.name)) ? baby.name : '';
    const title = name ? (ar ? `برافو يا ${esc(name)}! 🎉` : `Bravo, ${esc(name)}! 🎉`) : (ar ? 'برافو! 🎉' : 'Bravo! 🎉');
    const PAL = ['#FF8FA3', '#FFB88C', '#FFD66B', '#7FD4B0', '#8FB8F5', '#C3A6EE'];
    const confetti = Array.from({ length: 34 }, (_, i) =>
      `<i style="left:${rnd(100)}%;background:${PAL[i % PAL.length]};animation-delay:${(rnd(90) / 100).toFixed(2)}s;animation-duration:${(2.2 + rnd(140) / 100).toFixed(2)}s;--r:${rnd(360)}deg"></i>`).join('');
    const box = document.createElement('div');
    box.className = 'gm-win pt-win';
    box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', ar ? 'برافو' : 'Bravo');
    box.innerHTML = `
      <div class="gm-confetti" aria-hidden="true">${confetti}</div>
      <div class="gm-win-card">
        <div class="pt-prev ${draw ? '' : 'is-svg'}">${prev}</div>
        <h2>${title}</h2>
        <p>${draw ? (ar ? 'رسمة جميلة أوي! 🎨' : 'What a beautiful drawing! 🎨') : (ar ? 'إيه الألوان الحلوة دي! 🎨' : 'What lovely colors! 🎨')}</p>
        ${draw
          ? `<button class="gm-btn" data-act="ptnew" data-sfx="off">✨ ${ar ? 'ارسم رسمة جديدة' : 'Draw something new'}</button>
             <button class="gm-btn ghost" data-act="ptkeep" data-sfx="off">✏️ ${ar ? 'كمّل رسم' : 'Keep drawing'}</button>
             <a class="gm-btn ghost" href="#/games/paint">🖍️ ${ar ? 'لوّن صور' : 'Color pictures'}</a>`
          : `${next ? `<a class="gm-btn" href="#/games/paint/${next.id}">🖍️ ${ar ? 'لوّن صورة تانية' : 'Color another picture'}</a>` : `<a class="gm-btn" href="#/games/paint">🖍️ ${ar ? 'الصور' : 'Pictures'}</a>`}
             <button class="gm-btn ghost" data-act="ptkeep" data-sfx="off">🎨 ${ar ? 'كمّل تلوين' : 'Keep coloring'}</button>
             <a class="gm-btn ghost" href="#/games/paint/draw">✏️ ${ar ? 'ارسم من خيالك' : 'Draw anything'}</a>`}
      </div>`;
    app.appendChild(box);
    sfx('win'); setTimeout(() => sfx('yay'), 450);
  }
  const closeWin = () => { const w = document.querySelector('.pt-win'); if (w) w.remove(); };

  /* ============================================================
     🖱️ الأزرار
     ============================================================ */
  document.getElementById('app').addEventListener('click', e => {
    if (!V || !document.getElementById('pt-root')) return;
    const t = e.target;
    const reg = t.closest && t.closest('#pt-paper .r');
    if (reg) return fillRegion(reg, e);
    const btn = t.closest && t.closest('[data-act^="pt"]');
    if (!btn || btn.disabled) return;
    const act = btn.dataset.act;
    if (act === 'ptcolor') {
      const c = COLORS[+btn.dataset.i]; if (!c) return;
      P.pick = c.id; if (V.tool === 'erase' || V.tool === 'sticker') V.tool = 'brush'; persist(); syncTools(); sfx('flip');
    } else if (act === 'ptsize') {
      P.size = +btn.dataset.i; persist(); syncTools(); sfx('flip');
    } else if (act === 'pterase') {
      V.tool = V.tool === 'erase' ? 'brush' : 'erase'; V.panel = ''; syncPanel(); syncTools(); sfx('flip');
    } else if (act === 'ptstk' || act === 'ptshp') {
      const w = act === 'ptstk' ? 'stk' : 'shp';
      V.panel = V.panel === w ? '' : w; if (V.panel && V.tool === 'erase') V.tool = 'brush'; syncPanel(); sfx('flip');
    } else if (act === 'ptpick') { V.stk = btn.dataset.k; V.tool = 'sticker'; V.panel = ''; syncPanel(); syncTools(); sfx('flip'); }
    else if (act === 'ptshape') { V.shp = btn.dataset.k; V.tool = 'shape'; V.panel = ''; syncPanel(); syncTools(); sfx('flip'); }
    else if (act === 'ptfill') { V.fill = +btn.dataset.v; syncPanel(); sfx('flip'); }
    else if (act === 'ptsave') saveImage(); else if (act === 'ptundo') { if (V.kind === 'draw') undoDraw(); else undoColor(); }
    else if (act === 'ptclear') clearDraw();
    else if (act === 'ptreset') resetColor();
    else if (act === 'ptdone') celebrate();
    else if (act === 'ptkeep') closeWin();
    else if (act === 'ptnew') { closeWin(); clearDraw(); }
  });

  /* خروج من الصفحة: نخلّص أي خط شغّال ونحفظ */
  window.addEventListener('hashchange', () => {
    if (D.active) endStroke();
    flush();
    if (D.ro) { D.ro.disconnect(); D.ro = null; }
    if (V && V.kind === 'studio') studioY = window.scrollY || 0;      /* قبل ما app.js يرجّع الصفحة لفوق */
    lastKind = V ? V.kind : null;
    V = null;
  });

  /* بيتنادي من games.js */
  window.renderPaint = function (sub) {
    const a = sub && sub[0];
    if (a === 'draw') return renderDraw();
    const pg = a && PAGES.find(p => p.id === a);
    if (pg) return renderColor(pg);
    return renderStudio();
  };
  window.BeebyPaint = { pages: PAGES, colors: COLORS, state: () => ({ P, V, D }), flush, replay: () => replay() };
})();
