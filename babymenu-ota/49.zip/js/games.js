/* ============================================================
   🧩 ألعاب تعليمية — بيبي منيو
   ٦ ألعاب بالصور للأطفال من سنتين:
     ⭐ الذاكرة · 🐘 الظل · 🎨 الألوان · 🔢 عدّ معايا · 🤔 مين مختلف؟ · 🔤 الحروف
   - كل الرسومات إيموجي (من غير صور)، والأصوات من sfx.js
   - في الوضع العربي أسامي الصور بتظهر بالإنجليزي كمان عشان يتعلم الاتنين
   - الحروف: عربي في الوضع العربي، وإنجليزي في الوضع الإنجليزي
   - الصفحات: #/games و #/games/<id> — ومفيش إعلانات جوه الألعاب (ads.js)
   - بيتحمّل قبل app.js، وبيستخدم دوال app.js (tx, num, isAr, esc, togglesHtml, baby) وقت الرسم بس
   ============================================================ */
(function () {
  const it = (e, ar, en, g) => ({ e, ar, en, g });

  /* ---------- البيانات ---------- */
  const GAMES = [
    { id: 'memory', e: '⭐', color: 'blue', age: 2,
      ar: 'لعبة الذاكرة', en: 'Memory match',
      skill: { ar: 'الذاكرة والتركيز', en: 'Memory & focus' },
      how: { ar: 'اقلب كارتين ودوّر على الاتنين اللي شبه بعض', en: 'Flip two cards and find the matching pairs' } },
    { id: 'shadow', e: '🐘', color: 'lav', age: 2,
      ar: 'لعبة الظل', en: 'Shadow match',
      skill: { ar: 'الأشكال والملاحظة', en: 'Shapes & observation' },
      how: { ar: 'مين صاحب الظل ده؟ اختار الصورة الصح', en: 'Whose shadow is this? Pick the right picture' } },
    { id: 'colors', e: '🎨', color: 'pink', age: 2,
      ar: 'الألوان', en: 'Colors',
      skill: { ar: 'أسامي الألوان', en: 'Learning colors' },
      how: { ar: 'إيه الحاجة اللي لونها زي البقعة دي؟', en: 'Which thing is the same color as the splash?' } },
    { id: 'count', e: '🔢', color: 'cream', age: 3,
      ar: 'عدّ معايا', en: 'Count with me',
      skill: { ar: 'الأرقام والعد', en: 'Numbers & counting' },
      how: { ar: 'عدّ الصور واختار الرقم الصح', en: 'Count the pictures and pick the right number' } },
    { id: 'odd', e: '🤔', color: 'mint', age: 3,
      ar: 'مين مختلف؟', en: 'Odd one out',
      skill: { ar: 'التصنيف والتفكير', en: 'Sorting & thinking' },
      how: { ar: 'فيه صورة مش زي الباقيين.. لاقيها!', en: 'One picture doesn’t belong.. find it!' } },
    { id: 'letters', e: '✏️', color: 'green', age: 4,
      ar: 'الحروف', en: 'Letters',
      skill: { ar: 'أول حرف في الكلمة', en: 'First letter sounds' },
      how: { ar: 'إيه الصورة اللي اسمها بيبدأ بالحرف ده؟', en: 'Which picture starts with this letter?' } },
  ];

  const MEM_THEMES = [
    { id: 'sea', e: '🐬', ar: 'البحر', en: 'Sea', color: 'blue', items: [
      it('🐬', 'دولفين', 'Dolphin'), it('🦀', 'كابوريا', 'Crab'), it('🐢', 'سلحفاية', 'Turtle'), it('🐙', 'أخطبوط', 'Octopus'),
      it('🐠', 'سمكة', 'Fish'), it('🐳', 'حوت', 'Whale'), it('🦈', 'قرش', 'Shark'), it('🐧', 'بطريق', 'Penguin')] },
    { id: 'farm', e: '🐮', ar: 'المزرعة', en: 'Farm', color: 'green', items: [
      it('🐮', 'بقرة', 'Cow'), it('🐑', 'خروف', 'Sheep'), it('🐔', 'فرخة', 'Hen'), it('🐴', 'حصان', 'Horse'),
      it('🐐', 'معزة', 'Goat'), it('🦆', 'بطة', 'Duck'), it('🐰', 'أرنب', 'Rabbit'), it('🐫', 'جمل', 'Camel')] },
    { id: 'fruit', e: '🍓', ar: 'الفاكهة', en: 'Fruit', color: 'pink', items: [
      it('🍎', 'تفاحة', 'Apple'), it('🍌', 'موزة', 'Banana'), it('🍇', 'عنب', 'Grapes'), it('🍓', 'فراولة', 'Strawberry'),
      it('🍉', 'بطيخة', 'Watermelon'), it('🍊', 'برتقانة', 'Orange'), it('🥝', 'كيوي', 'Kiwi'), it('🍍', 'أناناس', 'Pineapple')] },
    { id: 'go', e: '🚗', ar: 'المواصلات', en: 'Vehicles', color: 'cream', items: [
      it('🚗', 'عربية', 'Car'), it('🚌', 'أتوبيس', 'Bus'), it('🚲', 'عجلة', 'Bicycle'), it('✈️', 'طيارة', 'Airplane'),
      it('🚀', 'صاروخ', 'Rocket'), it('🚂', 'قطر', 'Train'), it('🚁', 'هليكوبتر', 'Helicopter'), it('⛵', 'مركب', 'Sailboat')] },
  ];
  /* عدد الأزواج وعدد الأعمدة لكل مستوى */
  const MEM_LEVELS = [
    { n: 3, cols: 3, ar: 'سهل', en: 'Easy' },
    { n: 6, cols: 3, ar: 'وسط', en: 'Medium' },
    { n: 8, cols: 4, ar: 'صعب', en: 'Hard' },
  ];

  /* الظل: كل جولة ٣ اختيارات من مجموعات أشكال مختلفة عشان الظلال متتلخبطش في بعض */
  const SHADOWS = [
    it('🐘', 'فيل', 'Elephant', 'quad'), it('🦒', 'زرافة', 'Giraffe', 'quad'), it('🐎', 'حصان', 'Horse', 'quad'),
    it('🐕', 'كلب', 'Dog', 'quad'), it('🐪', 'جمل', 'Camel', 'quad'), it('🐇', 'أرنب', 'Rabbit', 'quad'),
    it('🐓', 'ديك', 'Rooster', 'bird'), it('🦆', 'بطة', 'Duck', 'bird'),
    it('🐟', 'سمكة', 'Fish', 'sea'), it('🐙', 'أخطبوط', 'Octopus', 'sea'), it('🦀', 'كابوريا', 'Crab', 'sea'), it('🐢', 'سلحفاية', 'Turtle', 'sea'),
    it('🦋', 'فراشة', 'Butterfly', 'bug'), it('🐌', 'حلزونة', 'Snail', 'bug'),
    it('🍎', 'تفاحة', 'Apple', 'fruit'), it('🍌', 'موزة', 'Banana', 'fruit'), it('🍇', 'عنب', 'Grapes', 'fruit'), it('🍓', 'فراولة', 'Strawberry', 'fruit'),
    it('🚗', 'عربية', 'Car', 'ride'), it('🚲', 'عجلة', 'Bicycle', 'ride'), it('✈️', 'طيارة', 'Airplane', 'ride'), it('🚀', 'صاروخ', 'Rocket', 'ride'), it('⛵', 'مركب', 'Sailboat', 'ride'),
    it('🎈', 'بلونة', 'Balloon', 'thing'), it('☂️', 'شمسية', 'Umbrella', 'thing'), it('⭐', 'نجمة', 'Star', 'thing'),
    it('🌙', 'قمر', 'Moon', 'thing'), it('🏠', 'بيت', 'House', 'thing'), it('🔑', 'مفتاح', 'Key', 'thing'),
  ];

  /* الألوان: إيموجي لونها واحد على آيفون وأندرويد */
  const COLORS = [
    { id: 'red', hex: '#E5484D', ar: 'أحمر', en: 'Red', items: [it('🍎', 'تفاحة', 'Apple'), it('🍓', 'فراولة', 'Strawberry'), it('🍒', 'كريز', 'Cherries'), it('🚒', 'عربية مطافي', 'Fire truck')] },
    { id: 'yellow', hex: '#F2C200', ar: 'أصفر', en: 'Yellow', items: [it('🍌', 'موزة', 'Banana'), it('🌻', 'عباد الشمس', 'Sunflower'), it('🐥', 'كتكوت', 'Chick'), it('🍋', 'ليمونة', 'Lemon')] },
    { id: 'green', hex: '#3FA34D', ar: 'أخضر', en: 'Green', items: [it('🥦', 'بروكلي', 'Broccoli'), it('🥒', 'خيارة', 'Cucumber'), it('🐸', 'ضفدع', 'Frog'), it('🍀', 'ورقة برسيم', 'Clover')] },
    { id: 'blue', hex: '#3B7DDD', ar: 'أزرق', en: 'Blue', items: [it('🐳', 'حوت', 'Whale'), it('💧', 'نقطة مية', 'Water drop'), it('🧢', 'كاب', 'Cap'), it('🫐', 'توت', 'Blueberries')] },
    { id: 'orange', hex: '#F7811E', ar: 'برتقاني', en: 'Orange', items: [it('🍊', 'برتقانة', 'Orange'), it('🥕', 'جزرة', 'Carrot'), it('🎃', 'قرع', 'Pumpkin'), it('🏀', 'كورة سلة', 'Basketball')] },
    { id: 'purple', hex: '#8E5BD8', ar: 'بنفسجي', en: 'Purple', items: [it('🍇', 'عنب', 'Grapes'), it('🍆', 'بتنجان', 'Eggplant'), it('💜', 'قلب', 'Heart')] },
    { id: 'brown', hex: '#8A5A33', ar: 'بني', en: 'Brown', items: [it('🐻', 'دبدوب', 'Teddy bear'), it('🍪', 'بسكوتة', 'Cookie'), it('🌰', 'أبو فروة', 'Chestnut'), it('🥔', 'بطاطساية', 'Potato')] },
  ];

  const COUNT_ITEMS = ['🍎', '🍓', '🍌', '⭐', '🎈', '🐥', '🚗', '🐟', '🌸', '🧁'];
  /* "مخلوطين": يعدّ نوع واحد بس وسط حاجات تانية */
  const COUNT_LEVELS = [
    { max: 5, ar: '١ – ٥', en: '1 – 5' },
    { max: 10, ar: '١ – ١٠', en: '1 – 10' },
    { max: 6, mix: true, ar: 'مخلوطين', en: 'Mixed' },
  ];

  const ODD_CATS = [
    { id: 'fruit', ar: 'فاكهة', en: 'fruit', one: { ar: 'دي فاكهة', en: 'a fruit' }, items: ['🍎', '🍌', '🍇', '🍓', '🍉', '🍊', '🍍', '🍒'] },
    { id: 'animal', ar: 'حيوانات', en: 'animals', one: { ar: 'ده حيوان', en: 'an animal' }, items: ['🐶', '🐱', '🐮', '🐰', '🐻', '🐵', '🦁', '🐸'] },
    { id: 'ride', ar: 'مواصلات', en: 'vehicles', one: { ar: 'دي وسيلة مواصلات', en: 'a vehicle' }, items: ['🚗', '🚌', '🚲', '✈️', '🚀', '🚂', '🚁', '⛵'] },
    { id: 'wear', ar: 'هدوم', en: 'clothes', one: { ar: 'ده لبس', en: 'clothing' }, items: ['👕', '👖', '🧦', '👟', '🧢', '👗', '🧤', '🧣'] },
    { id: 'veg', ar: 'خضار', en: 'veggies', one: { ar: 'ده خضار', en: 'a vegetable' }, items: ['🥕', '🥒', '🌽', '🥦', '🫑', '🧅', '🥔', '🍆'] },
  ];
  /* فاكهة وخضار مع بعض صعبة على السن ده — منحطهمش في نفس الجولة */
  const ODD_SKIP = [['fruit', 'veg']];

  /* الحروف: حرف + كلمة بتبدأ بيه + صورة (L = الحرف زي ما بيتعرض) */
  const L = (l, w, e, en) => ({ l, w, e, en });
  const AR_LETTERS = [
    L('أ', 'أرنب', '🐰', 'Rabbit'), L('ب', 'بطة', '🦆', 'Duck'), L('ت', 'تفاحة', '🍎', 'Apple'), L('ث', 'ثعلب', '🦊', 'Fox'),
    L('ج', 'جمل', '🐫', 'Camel'), L('ح', 'حصان', '🐴', 'Horse'), L('خ', 'خروف', '🐑', 'Sheep'), L('د', 'دب', '🐻', 'Bear'),
    L('ذ', 'ذرة', '🌽', 'Corn'), L('ر', 'ريشة', '🪶', 'Feather'), L('ز', 'زرافة', '🦒', 'Giraffe'), L('س', 'سمكة', '🐟', 'Fish'),
    L('ش', 'شمس', '☀️', 'Sun'), L('ص', 'صاروخ', '🚀', 'Rocket'), L('ض', 'ضفدع', '🐸', 'Frog'), L('ط', 'طيارة', '✈️', 'Airplane'),
    L('ظ', 'ظرف', '✉️', 'Envelope'), L('ع', 'عنب', '🍇', 'Grapes'), L('غ', 'غزالة', '🦌', 'Deer'), L('ف', 'فيل', '🐘', 'Elephant'),
    L('ق', 'قطة', '🐱', 'Cat'), L('ك', 'كلب', '🐶', 'Dog'), L('ل', 'ليمونة', '🍋', 'Lemon'), L('م', 'موزة', '🍌', 'Banana'),
    L('ن', 'نحلة', '🐝', 'Bee'), L('هـ', 'هدية', '🎁', 'Gift'), L('و', 'وردة', '🌹', 'Rose'), L('ي', 'يد', '✋', 'Hand'),
  ];
  const EN_LETTERS = [
    L('A', 'Apple', '🍎'), L('B', 'Ball', '⚽'), L('C', 'Cat', '🐱'), L('D', 'Dog', '🐶'), L('E', 'Egg', '🥚'), L('F', 'Fish', '🐟'),
    L('G', 'Grapes', '🍇'), L('H', 'Hat', '🎩'), L('I', 'Ice cream', '🍦'), L('J', 'Juice', '🧃'), L('K', 'Key', '🔑'), L('L', 'Lion', '🦁'),
    L('M', 'Moon', '🌙'), L('N', 'Nose', '👃'), L('O', 'Orange', '🍊'), L('P', 'Pizza', '🍕'), L('Q', 'Queen', '👸'), L('R', 'Rabbit', '🐰'),
    L('S', 'Sun', '☀️'), L('T', 'Tree', '🌳'), L('U', 'Umbrella', '☂️'), L('V', 'Violin', '🎻'), L('W', 'Whale', '🐳'), L('Y', 'Yo-yo', '🪀'),
    L('Z', 'Zebra', '🦓'),
  ];
  /* الحروف اللي مبتتوصلش باللي بعدها — من غيرها بنلزق أول حرف ملوّن بباقي الكلمة (ZWJ) */
  const NOJOIN = 'اأإآدذرزوؤة';

  const ROUNDS = 8;

  /* ---------- أدوات ---------- */
  const $ = () => document.getElementById('app');
  const sfx = n => { if (window.BeebySfx) window.BeebySfx.play(n); };
  const rnd = n => Math.floor(Math.random() * n);
  const shuffle = a => { const b = a.slice(); for (let i = b.length - 1; i > 0; i--) { const j = rnd(i + 1); [b[i], b[j]] = [b[j], b[i]]; } return b; };
  const take = (a, k) => shuffle(a).slice(0, k);
  const nm = x => (isAr() ? x.ar : x.en);
  /* الاسم + الإنجليزي جنبه في الوضع العربي (عشان يتعلم الاتنين) */
  const nm2 = x => `<b>${esc(nm(x))}</b>${isAr() && x.en ? ` <span class="gm-en" dir="ltr">${esc(x.en)}</span>` : ''}`;
  /* أول حرف ملوّن: "فيل" ⇒ ف ملوّنة ومتوصلة بباقي الكلمة */
  function firstLetter(w) {
    const ch = w[0], rest = w.slice(1);
    if (!isAr()) return `<i>${esc(ch)}</i>${esc(rest)}`;
    const zwj = NOJOIN.includes(ch) ? '' : '&zwj;';
    return `<i>${ch}${zwj}</i>${zwj}${esc(rest)}`;
  }

  const PREF_KEY = 'bb_games';
  function prefs() {
    let p = {};
    try { p = JSON.parse(localStorage.getItem(PREF_KEY) || '{}') || {}; } catch (e) {}
    return {
      theme: MEM_THEMES.some(t => t.id === p.theme) ? p.theme : 'sea',
      level: MEM_LEVELS[p.level] ? p.level : 0,
      cmax: COUNT_LEVELS[p.cmax] ? p.cmax : 0,
    };
  }
  function savePref(k, v) {
    const p = prefs();
    p[k] = v;
    try { localStorage.setItem(PREF_KEY, JSON.stringify(p)); } catch (e) {}
  }

  /* اللعبة اللي على الشاشة وحالتها — بتتصفّر لما تدخل لعبة من صفحة تانية،
     وبتفضل زي ما هي لو الصفحة اترسمت تاني (تغيير اللغة أو الوضع أو الصوت) */
  let cur = null;
  let S = null;
  let gen = 0;                       /* بيزيد مع كل لعبة جديدة — المؤقتات القديمة بتتجاهل نفسها */
  const later = (fn, ms) => { const g = gen; setTimeout(() => { if (g === gen && S) fn(); }, ms); };
  /* خرج من صفحة اللعبة؟ نلغي المؤقتات، ولما يرجع تبدأ لعبة جديدة
     (الـ listener ده قبل بتاع app.js لأن الملف بيتحمّل قبله) */
  window.addEventListener('hashchange', () => {
    if (cur && location.hash !== '#/games/' + cur) { cur = null; S = null; gen++; }
  });

  function newGame(id) {
    gen++;
    if (id === 'memory') {
      const p = prefs();
      const th = MEM_THEMES.find(t => t.id === p.theme);
      const lv = MEM_LEVELS[p.level];
      const picks = take(th.items, lv.n);
      const cards = shuffle(picks.concat(picks)).map((x, i) => ({ i, x, up: false, done: false }));
      return { id, th, lv, cards, open: [], moves: 0, found: 0, lock: false, miss: null, won: false };
    }
    return { id, round: 0, miss: 0, used: [], q: null, lock: false, won: false };
  }

  /* ---------- صفحة الألعاب ---------- */
  function renderHub() {
    const ageTxt = a => (isAr() ? (a === 2 ? 'من سنتين' : `من ${num(a)} سنين`) : `Age ${a}+`);
    const ico = g => g.id === 'shadow' ? `<i>${g.e}</i>${g.e}`
      : g.id === 'memory' ? `<span class="gm-mini"><i class="b">${STAR_SVG}</i><i class="f">🐬</i></span>`
      : g.id === 'letters' ? `<span class="gm-abc">${isAr() ? 'أ ب' : 'A B'}</span>`
      : g.e;
    const tips = [
      ['💛', 'العبي معاه وقولي أسامي الحاجات بصوت عالي — كده بيتعلم كلمات جديدة أسرع.', 'Play together and say the names out loud — it helps them learn new words faster.'],
      ['🌍', 'أسامي الصور مكتوبة بالعربي والإنجليزي عشان يتعلم الاتنين.', null],
      ['⏱️', 'من سنتين لـ ٥ سنين: ساعة شاشة في اليوم بالكتير (الأكاديمية الأمريكية لطب الأطفال) — وأقل من سنة ونص بلاش شاشات.', 'Ages 2–5: no more than 1 hour of screen time a day (American Academy of Pediatrics) — and no screens under 18 months.'],
      ['🚫', 'مفيش إعلانات جوه الألعاب.', 'No ads inside the games.'],
    ].filter(t => isAr() || t[2]);
    $().innerHTML = `
      <div class="topbar">
        <a class="backbtn" href="#/">←</a>
        <div class="logo">🧩</div>
        <h1 class="gm-h1">${isAr() ? 'ألعاب تعليمية' : 'Learning games'}<small>${isAr() ? 'العب واتعلم بالصور' : 'Play & learn with pictures'}</small></h1>
        ${togglesHtml()}
      </div>

      <div class="gm-hub">
        ${GAMES.map((g, i) => `
        <a class="gm-tile ac-${g.color} rise" style="--i:${i}" href="#/games/${g.id}">
          <span class="gm-tile-ico ${g.id === 'shadow' ? 'is-shadow' : ''}" aria-hidden="true">${ico(g)}</span>
          <b>${nm(g)}</b>
          <small>${tx(g.skill)}</small>
          <span class="gm-age">${ageTxt(g.age)}</span>
        </a>`).join('')}
      </div>

      <div class="tips">
        ${tips.map((t, i) => `<div class="tip rise" style="--i:${i + 6}"><span class="ic">${t[0]}</span><span>${isAr() ? t[1] : t[2]}</span></div>`).join('')}
      </div>
    `;
  }

  /* ---------- صفحة اللعبة ---------- */
  function renderGame() {
    const g = GAMES.find(x => x.id === S.id);
    $().innerHTML = `
      <div class="topbar">
        <a class="backbtn" href="#/games">←</a>
        <div class="logo">${g.e}</div>
        <h1 class="gm-h1">${nm(g)}<small>${tx(g.skill)}</small></h1>
        ${togglesHtml()}
      </div>
      <div class="gm-play gm-p-${S.id}">
        ${optsHtml()}
        ${S.id === 'memory' ? `<p class="gm-how">${tx(g.how)}</p>` : ''}
        <div class="gm-bar" id="gm-bar"></div>
        <div id="gm-stage"></div>
      </div>
    `;
    paintBar();
    if (S.id === 'memory') paintBoard();
    else {
      /* الحروف بتتغير مع اللغة — لو اللغة اتغيرت في النص نبدأ جولة بحروف اللغة الجديدة */
      if (!S.q || (S.id === 'letters' && S.q.lang !== lang)) S.q = makeQ();
      paintRound();
    }
    if (S.won) showWin(true);
  }

  function optsHtml() {
    const chip = (act, v, label, sel) => `<button class="wk-chip ${sel ? 'sel' : ''}" data-act="${act}" data-v="${v}">${label}</button>`;
    if (S.id === 'memory') {
      const p = prefs();
      return `
        <div class="week-chips gm-chips">${MEM_THEMES.map(t => chip('gmtheme', t.id, `${t.e} ${nm(t)}`, t.id === p.theme)).join('')}</div>
        <div class="gm-seg">${MEM_LEVELS.map((l, i) => chip('gmlevel', i, `${nm(l)} <small>${num(l.n * 2)}</small>`, i === p.level)).join('')}</div>`;
    }
    if (S.id === 'count') {
      const p = prefs();
      return `<div class="gm-seg">${COUNT_LEVELS.map((l, i) => chip('gmcmax', i, nm(l), i === p.cmax)).join('')}</div>`;
    }
    return '';
  }

  function paintBar() {
    const bar = document.getElementById('gm-bar');
    if (!bar) return;
    const again = `<button class="gm-again" data-act="gmrestart" aria-label="${isAr() ? 'من الأول' : 'Restart'}">🔄</button>`;
    if (S.id === 'memory') {
      bar.innerHTML = `
        <span>${isAr() ? 'الأزواج' : 'Pairs'} <b>${isAr() ? `${num(S.found)} من ${num(S.lv.n)}` : `${S.found} / ${S.lv.n}`}</b></span>
        <span>${isAr() ? 'المحاولات' : 'Tries'} <b>${num(S.moves)}</b></span>
        ${again}`;
      return;
    }
    const dots = Array.from({ length: ROUNDS }, (_, i) => `<i class="${i < S.round ? 'on' : i === S.round ? 'now' : ''}"></i>`).join('');
    bar.innerHTML = `<span class="gm-dots" aria-label="${isAr() ? `سؤال ${num(Math.min(S.round + 1, ROUNDS))} من ${num(ROUNDS)}` : `Question ${Math.min(S.round + 1, ROUNDS)} of ${ROUNDS}`}">${dots}</span>${again}`;
  }

  /* ---------- ⭐ الذاكرة ---------- */
  const STAR_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.9 6 6.5.8-4.8 4.5 1.2 6.5L12 17.2l-5.8 3.2 1.2-6.5L2.6 9.4l6.5-.8z"/></svg>';

  const cardLabel = c => (c.up || c.done ? nm(c.x) : (isAr() ? `كارت ${num(c.i + 1)}` : `Card ${c.i + 1}`));
  function cardHtml(c) {
    return `
      <button class="mem-card ${c.up || c.done ? 'up' : ''} ${c.done ? 'done' : ''}" data-act="gmflip" data-i="${c.i}" data-sfx="off" aria-label="${esc(cardLabel(c))}">
        <span class="mem-in">
          <span class="mem-back">${STAR_SVG}</span>
          <span class="mem-face"><span class="mem-emo">${c.x.e}</span><small class="mem-name">${esc(nm(c.x))}${isAr() ? `<em dir="ltr">${esc(c.x.en)}</em>` : ''}</small></span>
        </span>
      </button>`;
  }

  function paintBoard() {
    const st = document.getElementById('gm-stage');
    if (!st) return;
    st.innerHTML = `<div class="mem-board ac-${S.th.color}" style="--cols:${S.lv.cols}">${S.cards.map(cardHtml).join('')}</div>`;
  }

  function paintCard(c) {
    const el = document.querySelector(`.mem-card[data-i="${c.i}"]`);
    if (!el) return;
    el.classList.toggle('up', c.up || c.done);
    el.classList.toggle('done', c.done);
    el.setAttribute('aria-label', cardLabel(c));
  }

  /* الكارتين اللي مش شبه بعض بيرجعوا يتقلبوا — ولو الطفل داس على كارت تالت قبلها بنقلبهم فورًا */
  function closeMiss() {
    if (!S.miss) return;
    clearTimeout(S.miss);
    S.miss = null;
    S.open.forEach(k => { S.cards[k].up = false; paintCard(S.cards[k]); });
    S.open = [];
  }

  function memFlip(i) {
    const c = S.cards[i];
    if (!c || S.lock || S.won || c.done || c.up) return;
    closeMiss();
    c.up = true;
    paintCard(c);
    sfx('flip');
    S.open.push(i);
    if (S.open.length < 2) return;

    S.moves++;
    const [a, b] = S.open.map(k => S.cards[k]);
    if (a.x.e === b.x.e) {
      S.lock = true;
      later(() => {
        a.done = b.done = true;
        S.open = [];
        S.found++;
        S.lock = false;
        paintCard(a); paintCard(b);
        sfx('pop');
        paintBar();
        if (S.found === S.lv.n) { S.won = true; later(() => showWin(), 650); }
      }, 420);
    } else {
      const g = gen;
      S.miss = setTimeout(() => { if (g === gen && S) closeMiss(); }, 1100);
    }
    paintBar();
  }

  /* ---------- جولات: الظل / الألوان / العد / مين مختلف / الحروف ---------- */
  /* كل سؤال فيه opts (الاختيارات) و ok (الإجابة الصح من جوه opts) */
  function makeQ() {
    if (S.id === 'shadow') {
      const groups = shuffle([...new Set(SHADOWS.map(s => s.g))]).slice(0, 3);
      const fresh = SHADOWS.filter(s => !S.used.includes(s.e));
      const inG = fresh.filter(s => s.g === groups[0]);
      const target = take(inG.length ? inG : fresh, 1)[0];
      const others = groups.filter(g => g !== target.g).slice(0, 2).map(g => take(SHADOWS.filter(s => s.g === g), 1)[0]);
      while (others.length < 2) others.push(take(SHADOWS.filter(s => s.g !== target.g && !others.includes(s)), 1)[0]);
      S.used.push(target.e);
      return { ok: target, opts: shuffle([target, ...others]) };
    }
    if (S.id === 'colors') {
      const fresh = COLORS.filter(c => S.used.filter(u => u === c.id).length < 2);   /* كل لون بحد أقصى مرتين في الجولة */
      const col = take(fresh.length ? fresh : COLORS, 1)[0];
      S.used.push(col.id);
      const ok = take(col.items, 1)[0];
      /* المشتتات من ألوان تانية، ومن غير نفس الإيموجي (العنب في البنفسجي بس) */
      const others = take(COLORS.filter(c => c.id !== col.id), 2).map(c => take(c.items.filter(x => x.e !== ok.e), 1)[0]);
      return { col, ok, opts: shuffle([ok, ...others]) };
    }
    if (S.id === 'count') {
      const lv = COUNT_LEVELS[prefs().cmax];
      let n;
      const lo = lv.mix ? 2 : 1;   /* في المخلوطين: على الأقل ٢ عشان يبقى فيه عدّ */
      do { n = lo + rnd(lv.max - lo + 1); } while (S.q && S.q.n === n);
      const [e, d1, d2] = take(COUNT_ITEMS.filter(x => !S.q || x !== S.q.e), 3);
      let items = Array.from({ length: n }, () => ({ e, t: true }));
      if (lv.mix) {
        const total = Math.max(n + 3, 8 + rnd(3));
        const extra = Array.from({ length: total - n }, (_, i) => ({ e: i % 2 ? d1 : d2, t: false }));
        items = shuffle(items.concat(extra));
      }
      const near = [n - 2, n - 1, n + 1, n + 2].filter(v => v >= 1 && v <= Math.max(lv.max, 5));
      return { n, e, items, ok: n, opts: shuffle([n, ...take(near, 2)]) };
    }
    if (S.id === 'letters') {
      const set = isAr() ? AR_LETTERS : EN_LETTERS;
      const fresh = set.filter(x => !S.used.includes(x.l));
      const ok = take(fresh.length ? fresh : set, 1)[0];
      S.used.push(ok.l);
      const others = take(set.filter(x => x !== ok), 2);
      return { lang, ok, opts: shuffle([ok, ...others]) };
    }
    /* odd */
    let A, B;
    do { [A, B] = take(ODD_CATS, 2); } while (ODD_SKIP.some(p => p.includes(A.id) && p.includes(B.id)));
    const odd = take(B.items, 1)[0];
    return { A, B, ok: odd, opts: shuffle([...take(A.items, 3), odd]) };
  }

  const SPLASH = hex => `<svg class="gm-splash" viewBox="0 0 120 120" aria-hidden="true">
    <path fill="${hex}" d="M60 8c10 0 14 10 22 12s20-4 25 6-4 18-2 26 13 15 7 25-18 6-25 11-8 20-21 20-14-13-22-16-22 2-26-9 7-16 6-25S6 41 13 32s19-1 26-8S48 8 60 8z"/>
    <ellipse cx="44" cy="40" rx="13" ry="8" fill="#fff" opacity=".28" transform="rotate(-30 44 40)"/>
    <circle cx="104" cy="98" r="6" fill="${hex}"/><circle cx="16" cy="96" r="4.5" fill="${hex}"/><circle cx="108" cy="18" r="4" fill="${hex}"/>
  </svg>`;

  function paintRound() {
    const st = document.getElementById('gm-stage');
    if (!st || !S.q) return;
    const q = S.q;
    const btn = (i, inner, label, cls) => `<button class="gm-opt ${cls || ''}" data-act="gmpick" data-i="${i}" data-sfx="off"${label ? ` aria-label="${esc(label)}"` : ''}>${inner}</button>`;
    let top = '', opts = '', say = '';
    if (S.id === 'shadow') {
      top = `<div class="gm-q"><span class="gm-sil" aria-label="${isAr() ? 'ظل' : 'shadow'}">${q.ok.e}</span></div>`;
      opts = q.opts.map((o, i) => btn(i, o.e, nm(o))).join('');
      say = isAr() ? 'مين صاحب الظل ده؟ 🤔' : 'Whose shadow is this? 🤔';
    } else if (S.id === 'colors') {
      top = `<div class="gm-q">${SPLASH(q.col.hex)}</div>`;
      opts = q.opts.map((o, i) => btn(i, o.e, nm(o))).join('');
      say = isAr() ? 'إيه اللي لونه كده؟ 🎨' : 'What is this color? 🎨';
    } else if (S.id === 'count') {
      let k = 0;
      const size = q.items.length <= 3 ? 'lg' : q.items.length <= 6 ? 'md' : 'sm';
      top = `<div class="gm-q gm-count gm-${size}">${q.items.map(x => x.t
        ? `<span class="gm-it" data-n="${num(++k)}" style="--d:${k - 1}">${x.e}</span>`
        : `<span class="gm-it gm-x">${x.e}</span>`).join('')}</div>`;
      opts = q.opts.map((v, i) => btn(i, num(v), '', 'gm-num')).join('');
      say = isAr() ? `كام ${q.e} هنا؟` : `How many ${q.e}?`;
    } else if (S.id === 'letters') {
      top = `<div class="gm-q"><span class="gm-letter" dir="auto">${q.ok.l}</span></div>`;
      opts = q.opts.map((o, i) => btn(i, o.e, o.w)).join('');
      say = isAr() ? 'إيه اللي اسمه بيبدأ بالحرف ده؟ 🤔' : 'What starts with this letter? 🤔';
    } else {
      opts = q.opts.map((o, i) => btn(i, o)).join('');
      say = isAr() ? 'مين مش زي الباقيين؟ 🤔' : 'Which one doesn’t belong? 🤔';
    }
    st.innerHTML = `
      ${top}
      <p class="gm-say" id="gm-say" aria-live="polite">${say}</p>
      <div class="gm-opts gm-n${q.opts.length}">${opts}</div>`;
  }

  function pick(i, btn) {
    if (S.lock || S.won || !S.q) return;
    const q = S.q;
    if (q.opts[i] !== q.ok) {
      S.miss++;
      btn.classList.remove('no'); void btn.offsetWidth; btn.classList.add('no');
      btn.disabled = true;
      sfx('nope');
      return;
    }
    S.lock = true;
    btn.classList.add('ok');
    sfx('star');
    const say = document.getElementById('gm-say');
    const set = html => { if (say) say.innerHTML = html; };
    let wait = 1500;
    if (S.id === 'shadow') {
      const sil = document.querySelector('.gm-sil');
      if (sil) sil.classList.add('reveal');
      set(`${q.ok.e} ${nm2(q.ok)} 👏`);
    } else if (S.id === 'colors') {
      set(`<span class="gm-col" style="--c:${q.col.hex}">${esc(nm(q.col))}</span>${isAr() ? ` <span class="gm-en" dir="ltr">${q.col.en}</span>` : ''} — ${q.ok.e} ${nm2(q.ok)}`);
      wait += 300;
    } else if (S.id === 'count') {
      const st = document.querySelector('.gm-count');
      if (st) st.classList.add('counted');
      wait += q.n * 180;
      set(`<b>${num(q.n)}</b> ${q.e} 👏`);
    } else if (S.id === 'letters') {
      set(`${q.ok.e} <span class="gm-word" dir="auto">${firstLetter(q.ok.w)}</span>${isAr() ? ` <span class="gm-en" dir="ltr">${q.ok.en}</span>` : ''}`);
      wait += 400;
    } else {
      document.querySelectorAll('.gm-opt').forEach(b => { if (b !== btn) b.classList.add('same'); });
      set(isAr()
        ? `${q.ok} <b>${q.B.one.ar}</b>، والباقي ${q.A.ar} 👏`
        : `${q.ok} is <b>${q.B.one.en}</b> — the rest are ${q.A.en} 👏`);
      wait += 600;
    }
    later(() => {
      S.round++;
      S.lock = false;
      if (S.round >= ROUNDS) { S.won = true; paintBar(); showWin(); return; }
      S.q = makeQ();
      paintBar();
      paintRound();
    }, wait);
  }

  /* ---------- 🏆 الفوز ---------- */
  function stars() {
    if (S.id === 'memory') {
      const n = S.lv.n;
      return S.moves <= n + Math.ceil(n / 2) ? 3 : S.moves <= n * 2 ? 2 : 1;
    }
    return S.miss <= 1 ? 3 : S.miss <= 4 ? 2 : 1;
  }

  function showWin(quiet) {
    const app = $();
    if (!app || app.querySelector('.gm-win')) return;
    const st = stars();
    const name = (typeof baby !== 'undefined' && baby && typeof nameBlank === 'function' && !nameBlank(baby.name)) ? baby.name : '';
    const title = name ? (isAr() ? `برافو يا ${esc(name)}! 🎉` : `Bravo, ${esc(name)}! 🎉`) : (isAr() ? 'برافو! 🎉' : 'Bravo! 🎉');
    let line;
    if (S.id === 'memory') {
      const t = S.moves;
      line = isAr()
        ? `لقيت الـ ${num(S.lv.n)} أزواج في ${num(t)} ${t <= 10 ? 'محاولات' : 'محاولة'}`
        : `Found all ${S.lv.n} pairs in ${t} tries`;
    } else {
      line = S.miss === 0
        ? (isAr() ? 'كلهم صح من أول مرة! 👌' : 'All right on the first try! 👌')
        : (isAr() ? `خلصت الـ ${num(ROUNDS)} أسئلة 👏` : `All ${ROUNDS} done 👏`);
    }
    const PAL = ['#FF8FA3', '#FFB88C', '#FFD66B', '#7FD4B0', '#8FB8F5', '#C3A6EE'];
    const confetti = Array.from({ length: 34 }, (_, i) =>
      `<i style="left:${rnd(100)}%;background:${PAL[i % PAL.length]};animation-delay:${(rnd(90) / 100).toFixed(2)}s;animation-duration:${(2.2 + rnd(140) / 100).toFixed(2)}s;--r:${rnd(360)}deg"></i>`).join('');
    const box = document.createElement('div');
    box.className = 'gm-win';
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');
    box.setAttribute('aria-label', isAr() ? 'برافو' : 'Bravo');
    box.innerHTML = `
      <div class="gm-confetti" aria-hidden="true">${confetti}</div>
      <div class="gm-win-card">
        <div class="gm-trophy" aria-hidden="true">🏆</div>
        <div class="gm-stars" aria-label="${num(st)} / ${num(3)}">${[1, 2, 3].map(k => `<span class="${k <= st ? 'on' : ''}" style="--k:${k}">⭐</span>`).join('')}</div>
        <h2>${title}</h2>
        <p>${line}</p>
        <button class="gm-btn" data-act="gmrestart">🔄 ${isAr() ? 'العب تاني' : 'Play again'}</button>
        <a class="gm-btn ghost" href="#/games">🧩 ${isAr() ? 'لعبة تانية' : 'Another game'}</a>
      </div>`;
    app.appendChild(box);
    if (!quiet) sfx('win');
  }

  /* ---------- الأزرار ---------- */
  document.getElementById('app').addEventListener('click', e => {
    const btn = e.target.closest('[data-act^="gm"]');
    if (!btn || !S) return;
    const act = btn.dataset.act;
    if (act === 'gmflip') return memFlip(+btn.dataset.i);
    if (act === 'gmpick') return pick(+btn.dataset.i, btn);
    if (act === 'gmrestart') { S = newGame(S.id); renderGame(); return; }
    if (act === 'gmtheme') { savePref('theme', btn.dataset.v); S = newGame('memory'); renderGame(); return; }
    if (act === 'gmlevel') { savePref('level', +btn.dataset.v); S = newGame('memory'); renderGame(); return; }
    if (act === 'gmcmax') { savePref('cmax', +btn.dataset.v); S = newGame('count'); renderGame(); return; }
  });

  /* بيتنادي من render() في app.js */
  window.renderGames = function (id) {
    const g = GAMES.some(x => x.id === id) ? id : null;
    if (g !== cur) {
      cur = g;
      S = g ? newGame(g) : null;
      if (!g) gen++;
    }
    if (!g) return renderHub();
    renderGame();
  };
})();
