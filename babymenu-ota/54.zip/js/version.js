/* رقم نسخة الويب — بيزيد مع كل نشر OTA (scripts/ota-publish.sh بيغيّره لوحده) */
window.BB_WEB_VERSION = 54;
