/* ============================================================
   🔊 مؤثرات صوت قصيرة (Web Audio) — بتتولد بالكود، من غير ملفات صوت
   - "تك" خفيف على أي ضغطة زرار/كارت
   - "بوب" مبهج لما تعلّمي ✓، ونزلة ناعمة لما تشيلي العلامة
   - نغمة حفظ، ونغمة نجاح لما اليوم يخلص
   مكتوم/شغّال محفوظ في الجهاز (bb_sound) وبيتغيّر من زرار 🔊 فوق
   ============================================================ */
(function () {
  const KEY = 'bb_sound';
  let on = true;
  try { const v = localStorage.getItem(KEY); if (v !== null) on = JSON.parse(v) !== false; } catch (e) {}

  let ctx = null;
  function ac() {
    try {
      if (!ctx) {
        const C = window.AudioContext || window.webkitAudioContext;
        if (!C) return null;
        ctx = new C();
      }
      if (ctx.state === 'suspended') ctx.resume();
      return ctx;
    } catch (e) { return null; }
  }

  /* مستوى الصوت العام — الأصوات القصيرة محتاجة مستوى أعلى عشان تتسمع من سماعة الموبايل */
  const VOL = 3.4;

  /* نغمة واحدة: تردد يتحرك من f0 لـ f1، مع بداية وتلاشي ناعمين عشان مفيش "طقطقة" */
  function tone(c, t0, f0, f1, dur, type, gain) {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f0, t0);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.min(gain * VOL, 0.6), t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(c.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }

  /* 👏 سقفة: دفعة "تشويش" قصيرة متفلترة — كل سقفة ٣ نبضات ورا بعض بسرعة وبعدين تلاشي (زي الكف الحقيقي) */
  let noiseBuf = null;
  function noise(c) {
    if (!noiseBuf || noiseBuf.sampleRate !== c.sampleRate) {
      const len = Math.floor(c.sampleRate * 0.3);
      noiseBuf = c.createBuffer(1, len, c.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    return noiseBuf;
  }
  function clapHit(c, t0, gain, freq) {
    const src = c.createBufferSource();
    src.buffer = noise(c);
    const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 700;
    const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = freq; bp.Q.value = 0.8;
    const g = c.createGain();
    const peak = Math.min(gain * VOL, 0.7);
    g.gain.setValueAtTime(0.0001, t0);
    [0, 0.009, 0.018].forEach(dt => {
      g.gain.setValueAtTime(peak, t0 + dt);
      g.gain.exponentialRampToValueAtTime(peak * 0.25, t0 + dt + 0.007);
    });
    g.gain.setValueAtTime(peak, t0 + 0.027);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.027 + 0.11);
    src.connect(hp); hp.connect(bp); bp.connect(g); g.connect(c.destination);
    src.start(t0, Math.random() * 0.12);
    src.stop(t0 + 0.2);
  }
  /* سقفة كذا مرة ورا بعض، وكل مرة "إيدين" اتنين بفرق بسيط عشان تبان سقفة حقيقية */
  function claps(c, n, gap, gain) {
    const t = c.currentTime + 0.02;
    for (let i = 0; i < n; i++) {
      const ti = t + i * gap + Math.random() * 0.012;
      clapHit(c, ti, gain, 1150 + Math.random() * 500);
      clapHit(c, ti + 0.012 + Math.random() * 0.012, gain * 0.6, 1700 + Math.random() * 700);
    }
  }

  const SOUNDS = {
    tap:    c => { const t = c.currentTime + 0.02; tone(c, t, 560, 380, 0.1, 'sine', 0.07); },
    pop:    c => { const t = c.currentTime + 0.02; tone(c, t, 620, 940, 0.11, 'triangle', 0.11); tone(c, t + 0.08, 940, 1240, 0.16, 'sine', 0.08); },
    untick: c => { const t = c.currentTime + 0.02; tone(c, t, 480, 300, 0.12, 'sine', 0.07); },
    save:   c => { const t = c.currentTime + 0.02; [523, 659, 784].forEach((f, i) => tone(c, t + i * 0.09, f, f, 0.18, 'triangle', 0.09)); },
    win:    c => { const t = c.currentTime + 0.02; [523, 659, 784, 1046].forEach((f, i) => tone(c, t + i * 0.1, f, f, 0.24, 'triangle', 0.1)); },
    /* 🧩 الألعاب: قلب كارت، إجابة صح، ومحاولة تانية (نغمة هادية مش مخيفة) */
    flip:   c => { const t = c.currentTime + 0.02; tone(c, t, 340, 720, 0.09, 'triangle', 0.07); },
    star:   c => { const t = c.currentTime + 0.02; tone(c, t, 880, 880, 0.12, 'triangle', 0.09); tone(c, t + 0.09, 1320, 1320, 0.2, 'sine', 0.08); },
    clap:   c => claps(c, 4, 0.16, 0.2),      /* إجابة صح: ٤ سقفات */
    cheer:  c => claps(c, 9, 0.13, 0.18),     /* آخر اللعبة: سقفة أطول */
    nope:   c => { const t = c.currentTime + 0.02; tone(c, t, 330, 300, 0.13, 'sine', 0.08); tone(c, t + 0.13, 260, 220, 0.2, 'sine', 0.07); },
  };

  const stats = { played: 0, errors: 0, last: null, err: null };
  function play(name) {
    if (!on) return;
    const c = ac();
    if (!c || !SOUNDS[name]) return;
    try { SOUNDS[name](c); stats.played++; stats.last = name; } catch (e) { stats.errors++; stats.err = String(e); }
  }

  /* أي ضغطة: نحدد الصوت قبل ما التطبيق يغيّر الحالة (capture) */
  document.addEventListener('click', e => {
    if (!on || !e.target || !e.target.closest) return;
    const el = e.target.closest('button, a[href], [data-act], .day-card, .age-card, summary');
    if (!el || el.dataset.act === 'sound' || el.dataset.sfx === 'off') return;   /* أزرار الألعاب ليها أصواتها */
    if (el.classList.contains('check')) return play(el.classList.contains('done') ? 'untick' : 'pop');
    if (el.classList.contains('vax-check')) return play(el.getAttribute('aria-pressed') === 'true' ? 'untick' : 'pop');
    if (el.matches('input[type=checkbox]')) return play(el.checked ? 'pop' : 'untick');
    if (el.classList.contains('baby-save') || el.classList.contains('vax-save') || el.dataset.act === 'vaxsave') return play('save');
    play('tap');
  }, true);

  window.BeebySfx = {
    play,
    isOn: () => on,
    stats: () => Object.assign({ ctx: ctx ? ctx.state : null, on }, stats),
    setOn(v) {
      on = !!v;
      try { localStorage.setItem(KEY, JSON.stringify(on)); } catch (e) {}
    },
  };
})();
