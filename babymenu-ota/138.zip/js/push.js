/* ============================================================
   📣 إشعارات عامة من الأدمن (Firebase Cloud Messaging)
   كل الأجهزة مشتركة في topic اسمه "all" + topic باللغة ("lang_ar" أو "lang_en")
   فالأدمن يبعت للكل أو للعربي بس أو للإنجليزي بس — من Firebase Console أو scripts/send-push.js
   لو الإشعار فيه data.route (مثلًا "#/vaccines") الضغط عليه بيفتح الصفحة دي.
   ولو الإشعارات مقفولة للتطبيق بنطلب من المستخدمة تفعّلها (بالكتير مرة كل ~٢٠ ساعة) — شوفي 🔔 تحت.
   ============================================================ */
(function () {
  const store = {
    get(k, f) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : f; } catch { return f; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  };
  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const FM = () => (isNative() && window.Capacitor.Plugins.FirebaseMessaging) || null;
  const lang = () => (document.documentElement.lang === 'en' ? ((window.BBI18N && /^(de|fr|pt)$/.test(BBI18N.ui)) ? BBI18N.ui : 'en') : 'ar');   /* de/fr/pt ليهم قناة إشعارات لوحدهم */

  function openRoute(data) {
    if (!data) return;
    if (data.route === '#/rate') {   /* إشعار طلب التقييم: يفتح صفحة التقييم في المتجر مباشرة */
      const ios = window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform() === 'ios';
      const url = ios ? 'itms-apps://itunes.apple.com/app/id6824734839?action=write-review' : 'market://details?id=com.beebymenu.app';
      setTimeout(() => { try { window.open(url, '_system') || (window.location.href = url); } catch { window.location.href = url; } }, 400);
      return;
    }
    if (data.route && /^#\//.test(data.route)) {
      /* app.js بيرجّع للرئيسية مع كل رجوع من الخلفية — نوقفه لحظة ونروح للصفحة بعده */
      window.__PUSH_ROUTE_UNTIL = Date.now() + 4000;
      setTimeout(() => { location.hash = data.route; }, 400);
    } else if (data.url && /^https:\/\//.test(data.url)) window.open(data.url, '_system');
  }

  /* الإشعار وصل والتطبيق مفتوح: iOS بيعرض البانر لوحده، وأندرويد لأ — فنعرضه جوه التطبيق */
  function showInApp(n) {
    if (!n || (!n.title && !n.body)) return;
    if (window.Capacitor.getPlatform() === 'ios') return;
    document.getElementById('push-banner')?.remove();
    const el = document.createElement('div');
    el.id = 'push-banner';
    el.setAttribute('role', 'alert');
    const b = document.createElement('b');
    b.textContent = n.title || '';
    const p = document.createElement('span');
    p.textContent = n.body || '';
    el.append(b, p);
    el.addEventListener('click', () => { el.remove(); openRoute(n.data); });
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 7000);
  }

  let syncing = null;
  function syncTopics(fm) {
    if (!syncing) syncing = doSyncTopics(fm).finally(() => { syncing = null; });
    return syncing;
  }
  async function doSyncTopics(fm) {
    const want = 'lang_' + lang();
    const had = store.get('bb_pushLang', null);
    if (had === want && store.get('bb_pushAll', false)) return;
    await fm.subscribeToTopic({ topic: 'all' });
    store.set('bb_pushAll', true);
    if (had && had !== want) await fm.unsubscribeFromTopic({ topic: had }).catch(() => {});
    await fm.subscribeToTopic({ topic: want });
    store.set('bb_pushLang', want);
  }

  async function init() {
    const fm = FM();
    if (!fm) return;

    fm.addListener('notificationActionPerformed', e => openRoute(e && e.notification && e.notification.data));
    fm.addListener('notificationReceived', e => showInApp(e && e.notification));
    /* توكن جديد/متجدد ⇒ نتأكد من الاشتراك في الـ topics */
    fm.addListener('tokenReceived', () => {
      store.set('bb_pushAll', false);
      syncTopics(fm).catch(() => {});
    });

    try {
      let perm = await fm.checkPermissions();
      /* لسه ماتسألتش: رسالة النظام مرة واحدة بس، ورسالتنا بتيجي بعدها بيوم لو رفضت */
      if (perm.receive === 'prompt' && !store.get('bb_pushAsked', false)) {
        store.set('bb_pushAsked', true);
        store.set(NAG_KEY, Date.now());
        perm = await fm.requestPermissions();
      }
      if (perm.receive !== 'granted') { maybeAsk(fm, perm.receive); return; }
      await registerWithRetry(fm);
    } catch (e) {
      console.warn('[push]', e && e.message);
    }
  }

  /* على iOS توكن APNs ساعات بيتأخر ثواني بعد الإذن ⇒ getToken بيفشل أول مرة — نحاول تاني */
  async function registerWithRetry(fm) {
    const waits = [0, 3000, 8000, 20000, 60000];
    for (const w of waits) {
      if (w) await new Promise(r => setTimeout(r, w));
      try {
        await fm.getToken();   /* بيسجّل الجهاز عند Firebase/APNs */
        await syncTopics(fm);
        return;
      } catch (e) {
        console.warn('[push] retry', e && e.message);
      }
    }
  }

  /* ============================================================
     🔔 لو الإشعارات مش مفعّلة: نطلب من المستخدمة تفعّلها — بالكتير مرة كل ~٢٠ ساعة
     - لسه ماتسألتش (أو أندرويد سمح نسأل تاني) ⇒ زرار "تفعيل" بيطلّع رسالة النظام
     - رفضت قبل كده ⇒ iOS: زرار بيفتح إعدادات التطبيق · أندرويد: خطوات يدوية
     - لما ترجع من الإعدادات ونلاقيها اتفعّلت ⇒ نسجّل الجهاز ونشكرها
     بتظهر في الرئيسية بس، ومش وقت إعلان أو منتقي صور.
     ============================================================ */
  const NAG_KEY = 'bb_notifNagAt';
  const NAG_EVERY = 20 * 3600 * 1000;
  const isAr = () => document.documentElement.lang !== 'en';
  const plat = () => (window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform()) || 'web';
  let nagState = null;   /* آخر حالة إذن عرفناها (لو مش granted) */
  let nagTimer = null;

  const nagBusy = () => {
    const n = Date.now();
    return !!(window.__AD_ACTIVE || n - (window.__LAST_AD_CLOSE || 0) < 4000 ||
      (window.__PICKER_UNTIL && n < window.__PICKER_UNTIL) || (window.__PUSH_ROUTE_UNTIL && n < window.__PUSH_ROUTE_UNTIL));
  };
  const onHome = () => !location.hash || location.hash === '#/' || location.hash === '#';
  const closeNag = () => { document.getElementById('notif-ask')?.remove(); };
  const thanks = () => {
    if (window.showToast) window.showToast(isAr() ? 'تمام! هيوصلك كل جديد 💛' : 'Done! You’ll get everything new 💛');
  };

  function showNag(fm) {
    if (document.getElementById('notif-ask')) return;
    const ar = isAr();
    const ios = plat() === 'ios';
    const denied = nagState === 'denied';
    const manual = denied && !ios;   /* أندرويد ورفضت: مفيش زرار يفتح الإعدادات — خطوات بس */

    const el = document.createElement('div');
    el.id = 'notif-ask';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-modal', 'true');
    const card = document.createElement('div');
    card.className = 'na-card';
    const ico = document.createElement('div');
    ico.className = 'na-ico';
    ico.textContent = '🔔';
    const h = document.createElement('h3');
    h.textContent = ar ? 'فعّلي الإشعارات' : 'Turn on notifications';
    const p = document.createElement('p');
    if (manual) p.textContent = ar
      ? 'الإشعارات مقفولة للتطبيق. افتحي إعدادات الموبايل ← التطبيقات ← بيبي منيو ← الإشعارات ← وفعّليها 💛'
      : 'Notifications are off for the app. Open your phone Settings → Apps → Baby Menu → Notifications → and turn them on 💛';
    else if (denied) p.textContent = ar
      ? 'عشان يوصلك كل جديد بنضيفه: وصفات وأفكار سناك وألعاب وتحديثات. افتحي الإعدادات وفعّلي "السماح بالإشعارات" 💛'
      : 'To get everything new we add: recipes, snack ideas, games and updates. Open Settings and turn on “Allow Notifications” 💛';
    else p.textContent = ar
      ? 'عشان يوصلك كل جديد بنضيفه: وصفات وأفكار سناك وألعاب وتحديثات التطبيق 💛'
      : 'So you get everything new we add: recipes, snack ideas, games and app updates 💛';

    const go = document.createElement('button');
    go.type = 'button';
    go.className = 'na-go';
    go.textContent = manual ? (ar ? 'تمام' : 'Got it')
      : denied ? (ar ? 'فتح الإعدادات' : 'Open Settings')
      : (ar ? 'تفعيل الإشعارات' : 'Turn on notifications');
    go.addEventListener('click', async () => {
      if (manual) { closeNag(); return; }
      if (denied) { window.open('app-settings:', '_system'); return; }   /* iOS: بنرجع نتأكد لما التطبيق يظهر تاني */
      go.disabled = true;
      let perm;
      try { perm = await fm.requestPermissions(); } catch { perm = { receive: 'denied' }; }
      nagState = perm.receive;
      closeNag();
      if (perm.receive === 'granted') { thanks(); registerWithRetry(fm); }
    });
    card.append(ico, h, p, go);
    if (!manual) {
      const later = document.createElement('button');
      later.type = 'button';
      later.className = 'na-later';
      later.textContent = ar ? 'مش دلوقتي' : 'Not now';
      later.addEventListener('click', closeNag);
      card.append(later);
    }
    el.append(card);
    el.addEventListener('click', e => { if (e.target === el) closeNag(); });
    document.body.appendChild(el);
  }

  function maybeAsk(fm, state) {
    nagState = state;
    if (state === 'granted') return;
    if (Date.now() - store.get(NAG_KEY, 0) < NAG_EVERY) return;
    const tryShow = () => {
      clearTimeout(nagTimer);
      if (document.getElementById('notif-ask')) return;
      /* نستنى لحد ما تبقى في الرئيسية ومفيش إعلان/منتقي صور شغال */
      if (document.visibilityState !== 'visible' || !onHome() || nagBusy()) { nagTimer = setTimeout(tryShow, 4000); return; }
      store.set(NAG_KEY, Date.now());
      showNag(fm);
    };
    nagTimer = setTimeout(tryShow, 3500);
  }

  /* رجعت للتطبيق (غالبًا من الإعدادات): لو الإشعارات اتفعّلت نقفل الرسالة ونسجّل الجهاز */
  async function recheck(fm) {
    try {
      const perm = await fm.checkPermissions();
      if (perm.receive === 'granted') {
        if (nagState && nagState !== 'granted') { nagState = 'granted'; closeNag(); thanks(); registerWithRetry(fm); }
      } else nagState = perm.receive;
    } catch {}
  }
  document.addEventListener('visibilitychange', () => {
    const fm = FM();
    if (fm && document.visibilityState === 'visible' && nagState && nagState !== 'granted') setTimeout(() => recheck(fm), 600);
  });

  /* تغيير اللغة ⇒ نحدّث topic اللغة */
  new MutationObserver(() => {
    const fm = FM();
    if (fm && store.get('bb_pushAll', false)) syncTopics(fm).catch(() => {});
  }).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });

  window.BeebyPush = { init };
  /* بعد ما الصفحة تفتح بثانيتين — عشان طلب الإذن مايطلعش فوق شاشة البداية */
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(init, 2000));
  else setTimeout(init, 2000);
})();
