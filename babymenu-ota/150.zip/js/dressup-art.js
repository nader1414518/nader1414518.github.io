/* ============================================================
   👗 لبّس بوبو — الرسومات (SVG)
   بوبو شخصية كرتونية مقاس ٣٢٠×٤٧٠. دايمًا لابس: لو مفيش حاجة مختارة بيبقى لابس هدوم سادة (فوق وتحت وشرابات)،
   وأي قطعة بتتختار بتحلّ محل الهدوم السادة اللي في مكانها — فمفيش وقت بيظهر فيه من غير ملابس.
   الطبقات من ورا لقدّام: المشهد ← الظل ← الرجلين ← شراب ← بنطلون ← حذاء ← الدراعات ← الرقبة ← الجزء الفوقاني
   ← كوفية ← الراس ← نضارة ← جوانتي ← القبعة.
   كل قطعة: { id, cat, ar, en, fem, pl, where, svg, vb } — svg بإحداثيات الشخصية، و vb = حدود القطعة (للأيقونة اللي في الصينية).
   قياسات الجسم (كل الهدوم مرسومة عليها): الجسم x ١١٦–٢٠٤ / y ٢٠٨–٣٢٦ · الكتف (١١٦،٢٢٨) و(٢٠٤،٢٢٨) والدراع بيميل ١٦° · الرجلين x ١٢٤–١٥٦ و١٦٤–١٩٦ لحد y ٤٣٤.
   بيتحمّل قبل games.js ويحط window.DRESSUP_ART
   ============================================================ */
(function () {
  const INK = '#4b3b3f', SKIN = '#FFD3B5', HAIR = '#5A3A2E';
  const f = n => +n.toFixed(1);
  /* كل الرسم جوه <g> بإطار غامق مدوّر — الأشكال بتحدد اللون بس */
  const G = s => `<g stroke="${INK}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round">${s}</g>`;
  const P = (d, fill, x) => `<path d="${d}" fill="${fill}"${x ? ' ' + x : ''}/>`;
  const E = (cx, cy, rx, ry, fill, x) => `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${fill}"${x ? ' ' + x : ''}/>`;
  const C = (cx, cy, r, fill, x) => `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${fill}"${x ? ' ' + x : ''}/>`;
  const R = (x, y, w, h, rx, fill, xt) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}"${xt ? ' ' + xt : ''}/>`;
  const L = (d, w, x) => `<path d="${d}" fill="none"${w ? ` stroke-width="${w}"` : ''}${x ? ' ' + x : ''}/>`;
  const NS = 'stroke="none"';                                  /* بدون إطار */
  const mir = s => `<g transform="matrix(-1 0 0 1 320 0)">${s}</g>`;   /* نسخة معكوسة حوالين نص الشخصية */
  const both = fn => fn() + mir(fn());
  /* ضل خفيف وبريق (من غير إطار) — بيدّوا القطعة حجم */
  const SH = (d, a) => P(d, `rgba(40,20,20,${a || .13})`, NS);
  const HL = (d, a) => P(d, `rgba(255,255,255,${a || .38})`, NS);
  /* دراع من الكتف بزاوية: g بيتحط جواه شكل مرسوم لتحت من (0,0) */
  const armL = s => `<g transform="translate(116 228) rotate(16)">${s}</g>`;
  const armR = s => `<g transform="translate(204 228) rotate(-16)">${s}</g>`;
  const arms = fn => armL(fn()) + armR(fn());
  const star = (cx, cy, Ro, ri) => {
    let d = '';
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + i * Math.PI / 5, q = i % 2 ? ri : Ro;
      d += (i ? 'L' : 'M') + f(cx + q * Math.cos(a)) + ' ' + f(cy + q * Math.sin(a));
    }
    return d + 'Z';
  };
  /* كُم قصير / طويل (محلي للدراع: من الكتف (0,0) لتحت) */
  const sleeveS = (fill, dark, w) => { const h = w || 19; return P(`M${-h} -3 Q${-h} -17 0 -17 Q${h} -17 ${h} -3 V36 Q${h} 42 ${h - 6} 42 H${-h + 6} Q${-h} 42 ${-h} 36 Z`, fill) + R(-h, 31, h * 2, 11, 5, dark || fill) + SH(`M${h - 9} -14 H${h} V36 Q${h} 40 ${h - 4} 40 H${h - 9} Z`, .1); };
  const sleeveL = (fill, dark, w) => { const h = w || 19; return P(`M${-h} -3 Q${-h} -17 0 -17 Q${h} -17 ${h} -3 V100 Q${h} 106 ${h - 6} 106 H${-h + 6} Q${-h} 106 ${-h} 100 Z`, fill) + R(-h, 92, h * 2, 15, 7, dark || fill) + SH(`M${h - 9} -14 H${h} V100 Q${h} 104 ${h - 4} 104 H${h - 9} Z`, .1); };

  /* ---------- الراس والشعر ---------- */
  const HAIR_BOY = P('M82 118 C78 64 126 40 160 42 C194 40 242 64 238 118 C228 98 208 88 186 84 C162 96 122 92 98 100 C90 104 84 112 82 118 Z', HAIR) +
    P('M150 44 C146 30 160 24 170 32 C164 32 162 38 166 44 Z', HAIR);
  /* وش بوبو (+ رموش للبنت) */
  const faceSvg = girl => `<g stroke="none">${E(132, 136, 8, 11, INK)}${E(188, 136, 8, 11, INK)}${C(129.5, 131, 3, '#fff')}${C(185.5, 131, 3, '#fff')}${C(112, 160, 13, 'rgba(255,120,140,.35)')}${C(208, 160, 13, 'rgba(255,120,140,.35)')}${C(84, 136, 6, 'rgba(255,140,120,.3)')}${C(236, 136, 6, 'rgba(255,140,120,.3)')}</g>` +
    `<g fill="none" stroke="${INK}" stroke-width="3.5" stroke-linecap="round"><path d="M120 116 Q132 109 144 115"/><path d="M176 115 Q188 109 200 116"/><path d="M155 150 Q160 154 165 150"/><path d="M141 162 Q160 180 179 162"/></g>` +
    (girl ? `<g fill="none" stroke="${INK}" stroke-width="3" stroke-linecap="round"><path d="M123 130 L114 124"/><path d="M124 137 L114 137"/><path d="M197 130 L206 124"/><path d="M196 137 L206 137"/></g>` : '');
  const headSvg = (hair, girl) => G(C(84, 136, 13, SKIN) + C(236, 136, 13, SKIN) + E(160, 122, 78, 70, SKIN) + hair) + faceSvg(girl);
  /* شعر البنت: أجزاء: back (ورا الجسم) · mid (بعد الهدوم وقبل الراس) · front (على الراس) */
  const CAPF = col => P('M82 118 C78 62 126 38 160 40 C194 38 242 62 238 118 C232 104 224 98 214 96 Q160 112 106 96 C96 98 88 104 82 118 Z', col) + HL('M100 70 Q108 46 138 42 Q118 54 112 86Z', .3);
  const LOCKS = (col, len) => both(() => P(`M80 120 Q70 ${150 + len / 2} ${80 - 0} ${176 + len} Q94 ${182 + len} 100 ${168 + len} Q92 ${150 + len / 2} 98 112 Z`, col));
  const HAIRS = {
    bob: col => ({ back: G(P('M72 122 C66 56 126 34 160 36 C194 34 254 56 248 122 L254 178 Q252 196 232 196 H88 Q68 196 66 178 Z', col)), mid: '', front: CAPF(col) + LOCKS(col, 0) }),
    long: col => ({ back: G(P('M70 120 C64 54 126 32 160 34 C194 32 256 54 250 120 L260 276 Q254 300 226 296 L218 206 H102 L94 296 Q66 300 60 276 Z', col)) + `<g fill="none" stroke="rgba(0,0,0,.18)" stroke-width="3" stroke-linecap="round"><path d="M80 210 L78 282"/><path d="M240 210 L242 282"/></g>`, mid: '', front: CAPF(col) + LOCKS(col, 40) }),
    pigtails: col => ({ back: '', mid: G(both(() => P('M88 84 C46 82 32 134 48 188 C56 214 94 214 98 192 C86 162 92 126 104 100 Z', col) + R(76, 76, 24, 16, 7, '#E8453C'))), front: CAPF(col) }),
    bun: col => ({ back: '', mid: '', front: G(CAPF(col) + C(160, 26, 24, col) + R(136, 42, 48, 10, 5, '#FF6FA5') + L('M148 18 Q160 10 172 18', 3, 'stroke-opacity=".35"')) }),
    curly: col => ({ back: G(P('M74 112 C48 96 42 138 64 150 C44 172 78 196 96 176 L224 176 C242 196 276 172 256 150 C278 138 272 96 246 112 C262 70 230 36 202 52 C190 24 130 24 118 52 C90 36 58 70 74 112 Z', col)), mid: '', front: G(P('M80 120 C66 72 98 38 160 40 C222 38 254 72 240 120 C232 100 228 98 218 100 C212 88 198 94 190 88 C178 98 158 98 146 88 C136 94 122 88 112 100 C102 98 96 100 80 120Z', col)) + HL('M104 66 Q112 46 138 42 Q120 54 116 80Z', .3) }),
    braids: col => ({ back: '', mid: G(both(() => [176, 200, 224, 248, 272].map((y, i) => E(100 - i * 1.5, y, 13, 15, col)).join('') + C(93, 290, 8, '#E8453C'))), front: CAPF(col) }),
    ponytail: col => ({ back: '', mid: G(P('M196 54 C264 38 294 102 272 162 C264 190 234 188 236 170 C248 140 250 102 206 92 Z', col)), front: CAPF(col) + G(C(202, 62, 9, '#FF6FA5')) }),
  };
  const WIG_COL = { long: '#2E2230', pigtails: '#F2C46B', bun: '#6B3F2A', curly: '#D9622B', braids: '#8A5A3B', ponytail: '#9B6AD9' };

  /* ---------- الجسم ---------- */
  const TORSO = 'M116 246 Q116 210 150 208 H170 Q204 210 204 246 V312 Q204 326 190 326 H130 Q116 326 116 312 Z';
  const BASE_TOP = '#D9CFC2', BASE_BOT = '#B7BFCB';          /* هدوم سادة */

  const body = {
    shadow: `<ellipse cx="160" cy="462" rx="96" ry="11" fill="rgba(60,40,30,.16)"/>`,
    legs: G(R(124, 316, 32, 118, 16, SKIN) + R(164, 316, 32, 118, 16, SKIN)),
    socks: G(R(121, 412, 38, 30, 12, '#fff') + R(161, 412, 38, 30, 12, '#fff')),
    arms: G(arms(() => R(-15, -14, 30, 118, 15, SKIN)) + C(86, 338, 16, SKIN) + C(234, 338, 16, SKIN)) +
      `<g ${NS}>${C(79, 346, 4.5, 'rgba(255,255,255,.4)')}${C(241, 346, 4.5, 'rgba(255,255,255,.4)')}</g>`,
    neck: G(R(144, 182, 32, 32, 9, SKIN)) + `<path d="M146 204 Q160 214 174 204 V212 H146Z" fill="rgba(120,60,40,.14)"/>`,
    /* هدوم سادة (لما مفيش قطعة مختارة) */
    baseTop: G(arms(() => R(-17, -14, 34, 112, 16, BASE_TOP)) + P(TORSO, BASE_TOP) + L('M140 210 Q160 224 180 210')) + SH('M192 232 Q204 246 204 312 Q204 326 190 326 H176 Q194 300 192 232Z'),
    baseBottom: G(P('M116 316 H204 V428 H165 Q164 370 160 362 Q156 370 155 428 H116 Z', BASE_BOT) + R(116, 316, 88, 14, 5, '#A5AEBB')),
    head: headSvg(HAIR_BOY, false),
  };

  /* ---------- القطع ---------- */
  /* جسم التيشيرت/البولو (قصير، رقبة مدوّرة) */
  const TEE = 'M113 250 Q112 212 146 208 Q160 226 174 208 Q208 212 207 250 V322 Q207 335 193 335 H127 Q113 335 113 322 Z';
  /* ---------- الفساتين: صدر على قد الجسم + تنورة واسعة بحافة متموّجة ---------- */
  const FLOWER = (x, y, c, k) => { const r = 6 * (k || 1); return `<g ${NS}>${[0, 72, 144, 216, 288].map(a => C(f(x + r * Math.cos(a * Math.PI / 180)), f(y + r * Math.sin(a * Math.PI / 180)), 4.2 * (k || 1), c)).join('')}${C(x, y, 3.2 * (k || 1), '#FFD43B')}</g>`; };
  const dressPath = (hem, hw, n) => {
    const xr = 160 + hw, xl = 160 - hw, step = (xr - xl) / n;
    let d = `M114 250 Q113 212 146 208 Q160 226 174 208 Q207 212 206 250 Q205 282 199 302 Q${f(160 + hw * .66)} 332 ${xr} ${hem - 8}`;
    for (let i = 0; i < n; i++) d += ` Q${f(xr - step * (i + .5))} ${hem + 9} ${f(xr - step * (i + 1))} ${hem - 8}`;
    return d + ` Q${f(160 - hw * .66)} 332 121 302 Q115 282 114 250 Z`;
  };
  const hemLine = (hem, hw, n, dy) => {                       /* خط بيمشي مع الحافة المتموّجة (للشريط / الدانتيل) */
    const xr = 160 + hw, xl = 160 - hw, step = (xr - xl) / n;
    let d = `M${xr} ${hem - 8 + dy}`;
    for (let i = 0; i < n; i++) d += ` Q${f(xr - step * (i + .5))} ${hem + 9 + dy} ${f(xr - step * (i + 1))} ${hem - 8 + dy}`;
    return d;
  };
  const sleeveP = (fill, trim) => P('M-21 -3 Q-21 -17 0 -17 Q21 -17 21 -3 V24 Q21 36 9 38 H-9 Q-21 36 -21 24 Z', fill) + R(-18, 29, 36, 9, 4, trim) + SH('M10 -14 H21 V24 Q21 34 14 36 H10 Z', .1);
  const neckBand = (c, w) => L('M145 210 Q160 230 175 210', 0, `stroke="${c}" stroke-width="${w || 6}"`);
  const bowAt = (x, y, c, c2, k) => both2(x, () => P(`M${x} ${y} L${x - 24 * k} ${y - 14 * k} Q${x - 30 * k} ${y} ${x - 24 * k} ${y + 14 * k} Z`, c)) + C(x, y, 7 * k, c2);
  const both2 = (cx, fn) => fn() + `<g transform="matrix(-1 0 0 1 ${2 * cx} 0)">${fn()}</g>`;      /* معكوس حوالين خط عمودي x=cx */
  const dots = (pts, c) => `<g ${NS}>${pts.map(d => C(d[0], d[1], d[2] || 5, c)).join('')}</g>`;
  const FOLDS = (hem, c) => L(`M128 322 Q120 366 104 ${hem - 12} M160 316 V${hem - 4} M192 322 Q200 366 216 ${hem - 12}`, 3, `stroke="${c || INK}" stroke-opacity=".28"`);
  const DSH = hem => SH(`M196 318 Q238 340 252 ${hem - 6} Q226 ${hem + 6} 196 ${hem + 2} Q214 366 196 318Z`, .1);
  const DHL = () => HL('M121 238 Q124 222 140 216 Q130 232 130 262Z');
  const STRIPE_CLIP = `<clipPath id="drc-stripe"><path d="${TEE}"/></clipPath>`;
  const items = [
    /* ===== قبعات (على الراس) — الراس: x ٨٢–٢٣٨ والشعر من y ٤٢ (والخصلة لحد ٢٤)، فالقبعة بتغطي القمة كلها وبتنزل على الجبهة لحد y ~١٠٠ ===== */
    { id: 'cap', cat: 'hat', ar: 'كاب', en: 'Cap', fem: false, pl: false,
      svg: G(P('M80 102 C70 2 250 2 240 102 C212 96 108 96 80 102 Z', '#E8453C') +
        L('M160 28 V98', 3) + L('M120 36 Q126 72 130 98', 3) + L('M200 36 Q194 72 190 98', 3) +
        P('M86 100 C120 130 200 130 234 100 C204 110 116 110 86 100 Z', '#B92F28') + C(160, 26, 7, '#fff') +
        HL('M98 70 Q106 36 140 22 Q116 42 110 80 Z', .3)) +
        `<path d="M92 102 Q160 122 228 102 L228 108 Q160 130 92 108Z" fill="rgba(60,30,20,.1)"/>` },
    { id: 'sunhat', cat: 'hat', ar: 'قبعة شمس', en: 'Sun hat', fem: true, pl: false,
      svg: G(E(160, 98, 134, 26, '#F2CC76') + P('M90 98 C84 4 236 4 230 98 Z', '#F6D98E') +
        P('M91 82 C122 96 198 96 229 82 L230 99 C198 112 122 112 90 99 Z', '#E8453C') +
        L('M118 34 Q160 22 202 34', 3, 'stroke-opacity=".45"') + L('M104 58 Q160 44 216 58', 3, 'stroke-opacity=".45"') +
        L('M40 100 Q90 118 160 118', 3, 'stroke-opacity=".4"') + L('M280 100 Q230 118 160 118', 3, 'stroke-opacity=".4"') +
        HL('M108 60 Q118 30 150 18 Q124 36 118 76Z', .4)) },
    { id: 'beanie', cat: 'hat', ar: 'طاقية صوف', en: 'Beanie', fem: true, pl: false,
      svg: G(P('M82 102 C70 -8 250 -8 238 102 Z', '#2F6FE0') + L('M116 34 Q108 70 110 98 M140 20 Q136 60 136 98 M180 20 Q184 60 184 98 M204 34 Q212 70 210 98', 3, 'stroke-opacity=".35"') +
        P('M80 94 Q160 112 240 94 V114 Q160 128 80 114 Z', '#7FB0F5') + L('M104 100 V120 M122 103 V123 M140 105 V125 M158 106 V126 M176 105 V125 M194 103 V123 M212 100 V120', 3, 'stroke-opacity=".5"') +
        C(160, 18, 17, '#fff') + `<g ${NS}>${C(153, 12, 5, '#E7EEF9')}${C(168, 22, 5, '#E7EEF9')}</g>` +
        HL('M100 62 Q108 30 138 20 Q116 40 110 84Z', .3)) },
    { id: 'bucket', cat: 'hat', ar: 'قبعة بوكيت', en: 'Bucket hat', fem: true, pl: false,
      svg: G(E(160, 104, 106, 22, '#3A9B72') + P('M90 104 C82 4 238 4 230 104 Q160 118 90 104 Z', '#4FB286') +
        R(90, 78, 140, 15, 4, '#F6D98E') + L('M104 48 Q160 32 216 48', 3, 'stroke-opacity=".3"') +
        L('M64 106 Q110 126 160 126 M256 106 Q210 126 160 126', 3, 'stroke-opacity=".35"') + HL('M114 62 Q122 30 150 20 Q126 38 122 72Z', .32)) },
    { id: 'bow', cat: 'hat', ar: 'فيونكة', en: 'Hair bow', fem: true, pl: false, girl: true,
      svg: G(P('M122 62 C98 30 72 48 82 72 C92 88 116 76 122 62 Z', '#FF6FA5') + P('M122 62 C146 28 176 46 164 72 C154 88 128 76 122 62 Z', '#FF6FA5') +
        L('M94 52 Q102 62 106 70 M154 48 Q150 58 146 68', 3, 'stroke-opacity=".4"') +
        P('M120 68 L108 98 L118 96 L124 78Z', '#E0558C') + P('M126 68 L140 96 L130 96 L122 78Z', '#E0558C') +
        C(122, 64, 10, '#FF86B5') + HL('M88 58 Q94 50 102 50 Q94 56 92 66Z', .45)) },

    /* ===== فوق (على الجسم) ===== */
    { id: 'tshirt', cat: 'top', ar: 'تيشيرت', en: 'T-shirt', fem: false, pl: false,
      svg: G(arms(() => sleeveS('#4DB8F5', '#35A0DD')) + P(TEE, '#4DB8F5') +
        L('M145 210 Q160 230 175 210', 0, 'stroke="#35A0DD" stroke-width="6"') + R(113, 322, 94, 13, 6, '#35A0DD') +
        P(star(160, 274, 21, 9), '#FFD43B', 'stroke-width="3"')) +
        SH('M192 240 Q206 252 207 322 Q207 335 193 335 H178 Q196 318 192 240Z') + HL('M121 240 Q124 222 140 216 Q130 232 130 262Z') },
    { id: 'stripes', cat: 'top', ar: 'تيشيرت مخطط', en: 'Striped tee', fem: false, pl: false,
      svg: STRIPE_CLIP + G(arms(() => sleeveS('#fff', '#2B4A8B') + R(-19, 4, 38, 10, 0, '#2B4A8B', NS) + R(-19, 21, 38, 10, 0, '#2B4A8B', NS)) + P(TEE, '#fff') +
        `<g clip-path="url(#drc-stripe)" ${NS}>${R(100, 238, 120, 13, 0, '#2B4A8B')}${R(100, 264, 120, 13, 0, '#2B4A8B')}${R(100, 290, 120, 13, 0, '#2B4A8B')}${R(100, 316, 120, 24, 0, '#2B4A8B')}</g>` +
        L(TEE) + L('M145 210 Q160 230 175 210', 0, 'stroke="#2B4A8B" stroke-width="6"')) +
        SH('M192 240 Q206 252 207 322 Q207 335 193 335 H178 Q196 318 192 240Z', .1) },
    { id: 'polo', cat: 'top', ar: 'بولو', en: 'Polo shirt', fem: false, pl: false,
      svg: G(arms(() => sleeveS('#EF6F6C', '#fff')) + P(TEE, '#EF6F6C') + R(113, 322, 94, 13, 6, '#D4524F') +
        R(155, 232, 10, 52, 3, '#D4524F') + C(160, 244, 3.4, '#fff', 'stroke-width="2"') + C(160, 262, 3.4, '#fff', 'stroke-width="2"') +
        both(() => P('M143 204 L160 238 L146 246 L126 218 Z', '#FFE9E3'))) +
        SH('M192 240 Q206 252 207 322 Q207 335 193 335 H178 Q196 318 192 240Z') + HL('M121 240 Q124 222 138 218 Q130 232 130 262Z') },
    { id: 'sweater', cat: 'top', ar: 'بلوفر', en: 'Sweater', fem: false, pl: false,
      svg: G(arms(() => sleeveL('#FB8C1D', '#D4700E')) +
        P(TORSO, '#FB8C1D') + `<g ${NS}>${R(117, 254, 86, 9, 0, '#FFE9C7')}${R(117, 280, 86, 9, 0, '#FFE9C7')}</g>` +
        R(114, 312, 92, 19, 8, '#D4700E') + L('M126 316 V328 M138 316 V328 M150 316 V328 M162 316 V328 M174 316 V328 M186 316 V328 M198 316 V328', 2.5, 'stroke-opacity=".45"') +
        L('M140 210 Q160 228 180 210') + R(142, 202, 36, 13, 6, '#D4700E')) +
        SH('M192 232 Q204 246 204 312 Q204 326 190 326 H176 Q194 300 192 232Z', .12) + HL('M122 236 Q124 220 140 214 Q130 230 130 260Z') },
    { id: 'hoodie', cat: 'top', ar: 'هودي', en: 'Hoodie', fem: false, pl: false,
      svg: G(P('M124 208 Q114 184 140 174 H180 Q206 184 196 208 Q178 220 160 220 Q142 220 124 208 Z', '#228A82') +
        arms(() => sleeveL('#2FA39A', '#228A82')) + P(TORSO, '#2FA39A') +
        P('M124 330 V300 Q124 290 134 288 H186 Q196 290 196 300 V330 Z', '#2A978E') + L('M138 288 L130 328 M182 288 L190 328', 3) +
        R(114, 318, 92, 16, 8, '#228A82') +
        L('M146 214 Q160 226 174 214') + L('M148 218 V250', 3.5, 'stroke="#fff"') + L('M172 218 V250', 3.5, 'stroke="#fff"') + C(148, 253, 3.4, '#fff', 'stroke-width="2"') + C(172, 253, 3.4, '#fff', 'stroke-width="2"')) +
        SH('M192 232 Q204 246 204 312 Q204 326 190 326 H176 Q194 300 192 232Z', .12) + HL('M122 236 Q124 220 140 214 Q130 230 130 260Z') },
    { id: 'coat', cat: 'top', ar: 'جاكيت شتوي', en: 'Winter coat', fem: false, pl: false,
      svg: G(arms(() => sleeveL('#7B61D9', '#5B43B8', 22)) +
        P('M104 250 Q104 210 146 208 H174 Q216 210 216 250 V324 Q216 338 200 338 H120 Q104 338 104 324 Z', '#7B61D9') +
        L('M160 214 V338') + L('M106 252 Q160 262 214 252', 3) + L('M106 284 Q160 294 214 284', 3) + L('M106 316 Q160 326 214 316', 3) +
        R(134, 196, 52, 22, 11, '#5B43B8') + R(150, 252, 8, 20, 3, '#FFD43B', 'stroke-width="3"')) +
        SH('M200 232 Q216 250 216 324 Q216 338 200 338 H184 Q206 306 200 232Z', .14) + HL('M114 246 Q116 224 134 218 Q122 236 122 270Z') },
    { id: 'raincoat', cat: 'top', ar: 'معطف مطر', en: 'Raincoat', fem: true, pl: false,
      svg: G(P('M114 226 Q112 186 160 182 Q208 186 206 226 Q160 214 114 226 Z', '#E0B000') +
        arms(() => sleeveL('#FFD43B', '#E0B000', 20)) +
        P('M110 250 Q110 210 148 208 H172 Q210 210 210 250 L222 338 Q222 350 208 350 H112 Q98 350 98 338 Z', '#FFD43B') +
        L('M160 218 V350') + C(160, 252, 5, '#fff', 'stroke-width="3"') + C(160, 284, 5, '#fff', 'stroke-width="3"') + C(160, 316, 5, '#fff', 'stroke-width="3"') +
        L('M118 296 H146 M174 296 H202', 3) + L('M104 332 H216', 0, 'stroke="#fff" stroke-opacity=".8" stroke-width="4"')) +
        SH('M200 232 Q212 252 222 338 Q222 350 208 350 H190 Q210 310 200 232Z', .12) + HL('M120 244 Q122 224 140 218 Q128 236 126 280Z') },

    { id: 'sundress', cat: 'top', dress: true, girl: true, ar: 'فستان صيفي', en: 'Summer dress', fem: false, pl: false,
      svg: G(arms(() => sleeveP('#FFD45E', '#fff')) + P(dressPath(406, 94, 7), '#FFD45E') + neckBand('#F2A93B') +
        R(121, 296, 78, 13, 6, '#F2A93B') + bowAt(160, 303, '#fff', '#F2A93B', 1) +
        L(hemLine(406, 94, 7, -8), 0, 'stroke="#fff" stroke-width="8" stroke-opacity=".9"') +
        dots([[134, 268, 4], [186, 268, 4], [160, 282, 4], [128, 334, 6], [160, 330, 6], [192, 334, 6], [112, 364, 6], [144, 360, 6], [176, 360, 6], [208, 364, 6], [124, 392, 6], [160, 388, 6], [196, 392, 6]], '#fff')) +
        FOLDS(406) + DSH(406) + DHL() },
    { id: 'partydress', cat: 'top', dress: true, girl: true, ar: 'فستان حفلة', en: 'Party dress', fem: false, pl: false,
      svg: G(P(dressPath(424, 108, 8), '#FFC4DC') + arms(() => sleeveP('#FF7FB0', '#fff')) + P(dressPath(404, 88, 7), '#FF7FB0') + neckBand('#fff', 7) +
        both(() => P('M146 210 Q130 214 126 232 Q142 234 160 226 Z', '#fff', 'stroke-width="3"')) +
        R(119, 294, 82, 17, 7, '#8E6BE8') + bowAt(160, 303, '#8E6BE8', '#A98BF3', 1.25) +
        L('M124 338 Q116 372 104 392 M160 320 V400 M196 338 Q204 372 216 392', 3, 'stroke-opacity=".3"') +
        `<g ${NS}>${[[130, 352], [190, 358], [160, 372], [112, 388], [208, 390]].map(d => P(star(d[0], d[1], 8, 3.4), '#FFE680')).join('')}</g>`) +
        DSH(404) + DHL() },
    { id: 'flowerdress', cat: 'top', dress: true, girl: true, ar: 'فستان ورد', en: 'Flower dress', fem: false, pl: false,
      svg: G(arms(() => sleeveP('#7CCBF7', '#fff')) + P(dressPath(406, 94, 7), '#7CCBF7') + neckBand('#fff', 7) +
        both(() => P('M146 210 Q130 214 126 232 Q142 234 160 226 Z', '#fff', 'stroke-width="3"')) +
        R(121, 296, 78, 13, 6, '#5FBF7A') + bowAt(160, 303, '#5FBF7A', '#3FA25D', 1) +
        L(hemLine(406, 94, 7, -8), 0, 'stroke="#fff" stroke-width="9" stroke-opacity=".95"') +
        [[136, 266, '#fff', .8], [186, 268, '#FF86B5', .8], [126, 338, '#FF86B5', 1.2], [166, 340, '#fff', 1.3], [200, 346, '#FFD43B', 1.1], [112, 372, '#fff', 1.2], [148, 372, '#FFD43B', 1.2], [186, 376, '#FF86B5', 1.3], [220, 372, '#fff', 1.1], [128, 396, '#FF86B5', 1], [172, 398, '#fff', 1]].map(d => FLOWER(d[0], d[1], d[2], d[3])).join('')) +
        FOLDS(406) + DSH(406) + DHL() },
    { id: 'princess', cat: 'top', dress: true, girl: true, ar: 'فستان أميرة', en: 'Princess dress', fem: false, pl: false,
      svg: G(arms(() => sleeveP('#fff', '#F2C94C')) + P(dressPath(412, 104, 8), '#B98CF2') + P('M121 302 Q86 330 82 372 Q116 388 140 374 Q160 392 180 374 Q204 388 238 372 Q234 330 199 302 Z', '#D9C0F8') + neckBand('#F2C94C', 7) +
        R(119, 294, 82, 16, 7, '#F2C94C') + C(160, 302, 8, '#E5484D', 'stroke-width="3"') + P(star(160, 266, 14, 6), '#F2C94C', 'stroke-width="3"') +
        L('M130 322 Q112 350 106 372 M160 312 V386 M190 322 Q208 350 214 372', 3, 'stroke-opacity=".3"') +
        `<g ${NS}>${[[116, 400], [150, 404], [186, 402], [212, 396], [132, 350], [190, 346]].map(d => P(star(d[0], d[1], 7, 3), '#fff')).join('')}</g>`) +
        DSH(412) + DHL() },

    /* ===== تحت (على الرجلين) ===== */
    { id: 'pants', cat: 'bottom', ar: 'بنطلون', en: 'Pants', fem: false, pl: true,
      svg: G(P('M116 316 H204 V432 H165 Q164 372 160 364 Q156 372 155 432 H116 Z', '#C9A66B') + R(116, 316, 88, 15, 5, '#A98544') +
        L('M126 316 V330 M148 316 V330 M172 316 V330 M194 316 V330', 3, 'stroke-opacity=".55"') +
        L('M116 420 H156 M164 420 H204', 3, 'stroke-opacity=".5"') + L('M128 336 Q138 348 150 338', 3) + L('M170 338 Q182 348 192 336', 3)) +
        SH('M138 332 H156 V432 H142 Q150 380 138 332Z', .1) + SH('M182 332 H204 V432 H190 Q196 380 182 332Z', .1) },
    { id: 'jeans', cat: 'bottom', ar: 'جينز', en: 'Jeans', fem: false, pl: true,
      svg: G(P('M116 316 H204 V432 H165 Q164 372 160 364 Q156 372 155 432 H116 Z', '#3E73D6') + R(116, 316, 88, 15, 5, '#2B58B0') + R(154, 318, 12, 11, 3, '#FFD43B', 'stroke-width="2.5"') +
        R(116, 414, 40, 18, 4, '#5C8DE6') + R(164, 414, 40, 18, 4, '#5C8DE6') +
        L('M160 330 V356', 3) + L('M128 336 Q138 350 150 338', 0, 'stroke="#F0B25A" stroke-width="3" stroke-dasharray="5 4"') + L('M170 338 Q182 350 192 336', 0, 'stroke="#F0B25A" stroke-width="3" stroke-dasharray="5 4"')) +
        SH('M138 332 H156 V414 H142 Q150 380 138 332Z', .12) + SH('M182 332 H204 V414 H190 Q196 380 182 332Z', .12) +
        HL('M122 340 Q126 372 124 396 Q118 372 120 340Z', .25) },
    { id: 'joggers', cat: 'bottom', ar: 'بنطلون رياضة', en: 'Joggers', fem: false, pl: true,
      svg: G(P('M116 316 H204 V422 Q204 432 194 432 H172 Q165 432 165 420 Q164 372 160 364 Q156 372 155 420 Q155 432 148 432 H126 Q116 432 116 422 Z', '#A7B0BC') + R(116, 316, 88, 16, 6, '#7E8896') +
        L('M147 332 Q152 342 152 350 M173 332 Q168 342 168 350', 0, 'stroke="#fff" stroke-width="3"') +
        L('M123 336 V418', 5, 'stroke="#fff"') + L('M197 336 V418', 5, 'stroke="#fff"') +
        R(116, 416, 40, 16, 7, '#7E8896') + R(164, 416, 40, 16, 7, '#7E8896')) +
        SH('M138 336 H156 V416 H142 Q150 380 138 336Z', .1) + SH('M182 336 H204 V416 H190 Q196 380 182 336Z', .1) },
    { id: 'shorts', cat: 'bottom', ar: 'شورت', en: 'Shorts', fem: false, pl: true,
      svg: G(P('M116 316 H204 V376 H165 Q164 366 160 360 Q156 366 155 376 H116 Z', '#F7B538') + R(116, 316, 88, 15, 5, '#D9921A') +
        L('M148 331 Q154 342 152 352 M172 331 Q166 342 168 352', 0, 'stroke="#fff" stroke-width="3"') + L('M126 338 Q136 350 148 340', 3) + L('M116 366 H156 M164 366 H204', 3, 'stroke-opacity=".4"')) +
        SH('M182 332 H204 V376 H190 Q194 354 182 332Z', .1) },
    { id: 'skirt', cat: 'bottom', ar: 'جيبة', en: 'Skirt', fem: true, pl: false, girl: true,
      svg: G(P('M118 316 H202 L232 384 Q206 398 183 386 Q160 400 137 386 Q114 398 88 384 Z', '#FF86B5') + R(116, 316, 88, 15, 5, '#E0568F') +
        L('M140 332 L126 384 M160 332 V392 M180 332 L194 384', 3, 'stroke-opacity=".5"') + P('M154 322 L134 330 L134 316 Z M166 322 L186 330 L186 316 Z', '#fff', 'stroke-width="3"') + C(160, 323, 5, '#fff', 'stroke-width="3"')) +
        SH('M186 334 L200 382 L228 384 L206 334Z', .1) },

    { id: 'tutu', cat: 'bottom', girl: true, ar: 'جيبة توتو', en: 'Tutu skirt', fem: true, pl: false,
      svg: G(P('M110 330 H210 L252 384 Q226 398 202 384 Q182 402 160 388 Q138 402 118 384 Q94 398 68 384 Z', '#D9BEFA') +
        P('M114 322 H206 L240 368 Q216 380 196 368 Q178 384 160 372 Q142 384 124 368 Q104 380 80 368 Z', '#C9A6F5') + R(114, 316, 92, 15, 6, '#7B61D9') +
        L('M132 332 L118 372 M160 332 V380 M188 332 L202 372', 3, 'stroke-opacity=".35"')) +
        SH('M190 334 L206 368 L240 368 L212 334Z', .1) },

    /* ===== حذاء (في القدمين) ===== */
    { id: 'sneakers', cat: 'shoes', ar: 'كوتشي', en: 'Sneakers', fem: false, pl: true,
      svg: G(both(() => P('M100 440 Q100 416 128 414 H150 Q166 414 166 436 V448 Q166 462 150 462 H116 Q100 462 100 448 Z', '#fff') +
        P('M100 450 H166 V454 Q166 462 150 462 H116 Q100 462 100 454 Z', '#C9CED8') +
        P('M100 440 Q100 428 112 424 L112 448 H100 Z', '#E8453C', NS) +
        L('M124 422 H146 M122 430 H148', 3) + L('M128 414 Q138 420 148 414', 3, 'stroke-opacity=".5"'))) +
        `<g ${NS}>${HL('M110 436 H118 V444 H110Z', .5)}${mir(HL('M110 436 H118 V444 H110Z', .5))}</g>` },
    { id: 'sandals', cat: 'shoes', ar: 'صندل', en: 'Sandals', fem: false, pl: true,
      svg: G(both(() => P('M104 454 Q104 444 116 444 H156 Q168 444 168 454 Q168 466 156 466 H116 Q104 466 104 454 Z', '#B9803F') +
        P('M112 440 Q112 420 134 418 H150 Q166 420 166 442 Q166 452 150 452 H122 Q110 452 112 440 Z', SKIN) +
        P('M114 432 Q140 422 164 432 L164 442 Q140 432 114 442 Z', '#F0A24B') +
        P('M122 418 H146 V428 H122 Z', '#F0A24B') + C(134, 435, 3, '#FFD43B', 'stroke-width="2"'))) },
    { id: 'schoolshoes', cat: 'shoes', ar: 'جزمة مدرسة', en: 'School shoes', fem: true, pl: true,
      svg: G(both(() => P('M100 446 Q100 426 128 424 H150 Q166 426 166 442 V450 Q166 462 150 462 H116 Q100 462 100 450 Z', '#35313D') +
        P('M100 454 H166 V456 Q166 464 150 464 H116 Q100 464 100 456 Z', '#1F1C25') +
        R(112, 430, 46, 9, 4, '#4B4658') + C(134, 434.5, 3.6, '#FFD43B', 'stroke-width="2"') + `<g ${NS}>${P('M108 440 Q116 434 126 438 Q116 440 108 446Z', 'rgba(255,255,255,.35)')}</g>`)) },
    { id: 'ballet', cat: 'shoes', girl: true, ar: 'جزمة باليه', en: 'Ballet flats', fem: true, pl: true,
      svg: G(both(() => P('M104 450 Q104 434 126 432 H146 Q164 434 164 452 Q164 464 150 464 H118 Q104 464 104 450 Z', '#FF9EC4') +
        P('M104 456 H164 V458 Q164 466 150 466 H118 Q104 466 104 458 Z', '#E0709C') + L('M114 442 Q134 450 154 442', 3, 'stroke-opacity=".45"') +
        P('M134 436 L122 430 L122 442 Z M134 436 L146 430 L146 442 Z', '#fff', 'stroke-width="3"') + C(134, 436, 4, '#FF6FA5', 'stroke-width="2"'))) },
    { id: 'rainboots', cat: 'shoes', ar: 'جزمة مطر', en: 'Rain boots', fem: true, pl: true,
      svg: G(both(() => R(120, 376, 40, 70, 8, '#2FA84F') + E(138, 448, 33, 17, '#2FA84F') + R(116, 372, 48, 13, 6, '#7BD389') +
        L('M128 392 V428', 0, 'stroke="#fff" stroke-opacity=".6" stroke-width="4"') + E(138, 458, 33, 6, '#1F7A38', NS) + P('M108 442 Q116 434 126 440 Q116 444 108 450Z', 'rgba(255,255,255,.3)', NS))) },
    { id: 'winterboots', cat: 'shoes', ar: 'بوت شتوي', en: 'Winter boots', fem: false, pl: true,
      svg: G(both(() => R(120, 392, 40, 54, 8, '#9A6234') + E(138, 448, 33, 17, '#9A6234') + R(112, 380, 56, 20, 10, '#fff') +
        L('M128 408 H148 M128 420 H148 M128 432 H148', 3) + E(138, 460, 33, 5, '#5E3A1C', NS) + `<g ${NS}>${C(120, 384, 4, '#EEF3FA')}${C(132, 380, 4, '#EEF3FA')}${C(146, 380, 4, '#EEF3FA')}${C(158, 384, 4, '#EEF3FA')}</g>`)) },

    /* ===== باروكات (للبنت بس) — الرسم الفعلي بيتبني تحت من HAIRS ===== */
    { id: 'wig_long', cat: 'wig', girl: true, wig: 'long', ar: 'باروكة شعر طويل', en: 'Long hair wig', fem: true, pl: false,
      svg: '' },
    { id: 'wig_pigtails', cat: 'wig', girl: true, wig: 'pigtails', ar: 'باروكة ذيلين', en: 'Pigtails wig', fem: true, pl: false,
      svg: '' },
    { id: 'wig_bun', cat: 'wig', girl: true, wig: 'bun', ar: 'باروكة كعكة', en: 'Bun wig', fem: true, pl: false,
      svg: '' },
    { id: 'wig_curly', cat: 'wig', girl: true, wig: 'curly', ar: 'باروكة شعر كيرلي', en: 'Curly wig', fem: true, pl: false,
      svg: '' },
    { id: 'wig_braids', cat: 'wig', girl: true, wig: 'braids', ar: 'باروكة ضفيرتين', en: 'Braids wig', fem: true, pl: false,
      svg: '' },
    { id: 'wig_ponytail', cat: 'wig', girl: true, wig: 'ponytail', ar: 'باروكة ذيل حصان', en: 'Ponytail wig', fem: true, pl: false,
      svg: '' },

    /* ===== زيادة (نضارة / كوفية / جوانتي) ===== */
    { id: 'sunglasses', cat: 'extra', ar: 'نضارة شمس', en: 'Sunglasses', fem: true, pl: true, where: 'eyes',
      svg: G(L('M110 134 L90 132 M210 134 L230 132', 4) + E(132, 136, 25, 19, '#2E2A2B') + E(188, 136, 25, 19, '#2E2A2B') + L('M157 134 Q160 130 163 134', 4) +
        `<g ${NS}>${E(122, 129, 7, 4, 'rgba(255,255,255,.45)', 'transform="rotate(-20 122 129)"')}${E(178, 129, 7, 4, 'rgba(255,255,255,.45)', 'transform="rotate(-20 178 129)"')}</g>`) },
    { id: 'scarf', cat: 'extra', ar: 'كوفية', en: 'Scarf', fem: true, pl: false, where: 'neck',
      svg: G(P('M172 232 L204 238 L214 308 L180 312 Z', '#E8453C') + L('M176 296 L212 292 M178 304 L214 300', 3) +
        P('M116 204 Q160 236 204 204 L210 228 Q160 258 110 228 Z', '#E8453C') + `<g ${NS}>${P('M128 214 L124 236 L134 238 L138 220 Z', '#fff')}${P('M158 224 L156 246 L166 246 L168 224 Z', '#fff')}${P('M188 220 L192 240 L200 236 L196 216 Z', '#fff')}</g>`) },
    { id: 'gloves', cat: 'extra', ar: 'جوانتي', en: 'Gloves', fem: false, pl: true, where: 'hands',
      svg: G(both(() => R(68, 312, 38, 20, 8, '#C9650B') + E(86, 344, 19, 22, '#FB8C1D') + E(104, 336, 8, 12, '#FB8C1D', 'transform="rotate(-24 104 336)"') + L('M74 322 H100', 3))) },
  ];

  /* الباروكات: back/mid/front من HAIRS، والـsvg (لأيقونة الصينية) = كل الأجزاء مع بعض */
  items.forEach(it => {
    if (it.wig) { it.parts = HAIRS[it.wig](WIG_COL[it.wig]); it.svg = it.parts.back + it.parts.mid + it.parts.front; }
  });
  /* مكان لبس كل قطعة (بالحرف الجر: بتتحط في جملة "... بيتلبس على الراس") */
  const WHERE = {
    hat: { ar: 'على الراس', en: 'on the head' },
    wig: { ar: 'على الراس', en: 'on the head' },
    top: { ar: 'على الجسم', en: 'on the body' },
    bottom: { ar: 'على الرجلين', en: 'on the legs' },
    shoes: { ar: 'في القدمين', en: 'on the feet' },
    eyes: { ar: 'على العينين', en: 'on the eyes' },
    neck: { ar: 'حوالين الرقبة', en: 'around the neck' },
    hands: { ar: 'في الإيدين', en: 'on the hands' },
  };
  items.forEach(it => { it.where = WHERE[it.where || it.cat]; });
  /* حدود كل قطعة (للأيقونة): [x, y, عرض, طول] */
  const VB = {"cap":[75,15,169,112],"sunhat":[22,14,276,114],"beanie":[76,-3,168,133],"bucket":[50,16,220,114],"bow":[75,39,95,63],"tshirt":[82,202,156,137],"stripes":[82,202,156,142],"polo":[82,200,156,139],"sweater":[64,198,192,143],"hoodie":[64,170,192,171],"coat":[61,192,198,150],"raincoat":[63,178,194,176],"sundress":[62,201,196,212],"partydress":[48,201,224,227],"flowerdress":[62,201,196,212],"princess":[52,201,216,218],"pants":[112,312,96,124],"jeans":[112,312,96,124],"joggers":[112,312,96,124],"shorts":[112,312,96,68],"skirt":[84,312,152,85],"tutu":[64,312,192,87],"sneakers":[96,410,128,56],"sandals":[100,414,120,56],"schoolshoes":[96,420,128,48],"ballet":[100,426,120,44],"rainboots":[101,368,118,101],"winterboots":[101,372,118,97],"wig_long":[56,29,208,271],"wig_pigtails":[37,35,245,177],"wig_bun":[77,-2,165,124],"wig_curly":[46,27,227,161],"wig_braids":[77,35,166,267],"wig_ponytail":[77,35,206,152],"sunglasses":[86,113,148,46],"scarf":[106,200,112,116],"gloves":[63,308,194,62]};
  items.forEach(it => { it.vb = VB[it.id]; });

  /* ---------- مشاهد الخلفية (الألوان الأساسية بتيجي من الـCSS) ---------- */
  const cloud = (x, y, k, fill) => `<path transform="translate(${x} ${y}) scale(${k})" d="M-52 22 C-80 22 -80 -12 -52 -14 C-52 -42 -10 -50 6 -28 C22 -52 64 -40 62 -8 C88 -6 88 22 62 22 Z" fill="${fill}"/>`;
  const hill = (fill, y) => `<path d="M0 ${y} Q80 ${y - 18} 160 ${y - 4} T320 ${y - 8} V470 H0 Z" fill="${fill}"/>`;
  const drops = Array.from({ length: 16 }, (_, i) => {
    const x = 14 + (i * 41) % 300, y = 70 + (i * 53) % 120;
    return `<line class="dr-rain" x1="${x}" y1="${y}" x2="${x - 4}" y2="${y + 15}" style="animation-delay:-${(i * .19).toFixed(2)}s;animation-duration:${(.85 + (i % 3) * .18).toFixed(2)}s"/>`;
  }).join('');
  const flakes = Array.from({ length: 18 }, (_, i) => {
    const x = 10 + (i * 37) % 300, y = 20 + (i * 59) % 200, r = 2 + (i % 3) * 1.1;
    return `<circle class="dr-snow" cx="${x}" cy="${y}" r="${r}" style="animation-delay:-${(i * .55).toFixed(2)}s;animation-duration:${(6 + (i % 4)).toFixed(0)}s"/>`;
  }).join('');
  let rays = '';
  for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6; rays += `<line x1="${f(252 + 44 * Math.cos(a))}" y1="${f(78 + 44 * Math.sin(a))}" x2="${f(252 + 58 * Math.cos(a))}" y2="${f(78 + 58 * Math.sin(a))}"/>`; }
  const scenes = {
    free: `<circle cx="64" cy="96" r="48" fill="rgba(255,255,255,.5)"/><circle cx="268" cy="168" r="36" fill="rgba(255,255,255,.45)"/>` +
      `<g fill="#fff" opacity=".85" stroke="none">${P(star(40, 200, 11, 5), '#fff')}${P(star(284, 74, 9, 4), '#fff')}${P(star(250, 258, 7, 3), '#fff')}</g>` +
      hill('#F4C7A6', 438) + `<ellipse cx="160" cy="458" rx="120" ry="14" fill="#EFB690"/>`,
    sun: `<g stroke="#FFC107" stroke-width="5" stroke-linecap="round">${rays}</g>${C(252, 78, 34, '#FFD43B')}` +
      cloud(76, 76, .9, '#fff') + cloud(212, 168, .6, '#fff') + hill('#7BD389', 432) + hill('#5CC171', 448) +
      `<g stroke="none">${C(34, 446, 7, '#FF86B5')}${C(34, 446, 3, '#FFD43B')}${C(288, 440, 7, '#fff')}${C(288, 440, 3, '#FFD43B')}${C(262, 458, 6, '#FF86B5')}${C(262, 458, 2.5, '#FFD43B')}</g>`,
    rain: cloud(78, 60, 1.15, '#8E9BAE') + cloud(204, 46, 1.25, '#9BA7B8') + cloud(290, 104, .8, '#8794A8') +
      `<g stroke="#5E9BE0" stroke-width="3" stroke-linecap="round">${drops}</g>` + hill('#8FB59A', 436) +
      `<ellipse cx="62" cy="456" rx="38" ry="7" fill="#8FB9E0"/><ellipse cx="262" cy="458" rx="32" ry="6" fill="#8FB9E0"/>`,
    cold: cloud(92, 62, .95, '#fff') + cloud(252, 122, .7, '#fff') +
      `<g fill="#fff" stroke="none">${flakes}</g>` + `<path d="M0 424 Q60 402 120 418 T240 414 T320 416 V470 H0 Z" fill="#fff"/><path d="M0 446 Q90 432 180 446 T320 442 V470 H0 Z" fill="#E4EEF8"/>` +
      `<g stroke="${INK}" stroke-width="3" stroke-linejoin="round">${C(44, 418, 20, '#fff')}${C(44, 390, 14, '#fff')}<path d="M44 390 L62 394 L44 396 Z" fill="#FB8C1D"/></g><g stroke="none">${C(39, 386, 2, INK)}${C(49, 386, 2, INK)}</g>`,
  };

  /* بيركّب بوبو لابس القطع ids (قطعة واحدة لكل مكان: قبعة/فوق/تحت/حذاء/باروكة — والزيادة (نضارة/كوفية/جوانتي) تتجمع).
     girl = بوبو بنت (شعر بوب أو الباروكة المختارة + رموش). الفستان بيغطّي فوق وتحت مع بعض */
  const GIRL_HAIR = HAIRS.bob(HAIR);
  function compose(ids, girl) {
    const by = cat => items.find(it => it.cat === cat && ids.includes(it.id));
    const one = id => items.find(it => it.id === id && ids.includes(id));
    const top = by('top'), bottom = by('bottom'), shoes = by('shoes'), hat = by('hat');
    const sc = one('scarf'), sg = one('sunglasses'), gl = one('gloves');
    const wig = girl ? by('wig') : null;
    const hair = girl ? (wig ? wig.parts : GIRL_HAIR) : null;
    const dress = top && top.dress;
    const w = it => (it ? `<g class="dr-it" data-it="${it.id}">${it.svg}</g>` : '');
    return [
      body.shadow, hair ? hair.back : '', body.legs, body.socks,
      dress ? '' : (bottom ? w(bottom) : body.baseBottom),
      w(shoes),
      body.arms, body.neck,
      top ? w(top) : body.baseTop,
      w(sc),
      hair ? hair.mid : '',
      girl ? headSvg(hair.front, true) : body.head,
      w(sg), w(gl), w(hat),
    ].join('');
  }

  window.DRESSUP_ART = { vb: [0, 0, 320, 470], items, body, WHERE, scenes, compose, VB };
})();
