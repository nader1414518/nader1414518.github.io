/* ============================================================
   بيبي منيو 🍼 — منطق التطبيق (راوتر + عرض + لغتين + وضعين)
   ============================================================ */

const $app = document.getElementById('app');

/* التطبيق يبدأ دايمًا من الرئيسية — ويرجع لها مع كل رجوع من الخلفية */
if (location.hash && location.hash !== '#/' && location.hash !== '#') {
  location.replace(location.pathname + location.search + '#/');
}
(function () {
  let openedAt = Date.now();
  const goHomeSoft = () => {
    if (Date.now() - openedAt < 2500) return;
    /* إعلان بيني شغال أو لسه مقفل من ثانية ونص؟ مش رجوع حقيقي من الخلفية */
    if (window.__AD_ACTIVE) return;
    if (Date.now() - (window.__LAST_AD_CLOSE || 0) < 4000) return;
    /* منتقي الصور مفتوح أو لسه راجع منه؟ نفس الحكاية */
    if (window.__PICKER_UNTIL && Date.now() < window.__PICKER_UNTIL) return;
    /* فتحت التطبيق من إشعار بيودّي لصفحة معيّنة (push.js) — منرجعش للرئيسية */
    if (window.__PUSH_ROUTE_UNTIL && Date.now() < window.__PUSH_ROUTE_UNTIL) return;
    if (location.hash && location.hash !== '#/' && location.hash !== '#') {
      location.hash = '#/';
    }
  };
  /* الطريقة الأضمن: الصفحة بقت ظاهرة = المستخدمة رجعت للتطبيق */
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') setTimeout(goHomeSoft, 150);
  });
  /* ونسخة الكاباسيتور احتياطيًا */
  if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
    try {
      window.Capacitor.Plugins.App.addListener('appStateChange', st => { if (st && st.isActive) setTimeout(goHomeSoft, 150); });
    } catch {}
  }
})();

/* ---------- التخزين ---------- */
const store = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
    catch { return fallback; }
  },
  set(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
  },
};

let baby = store.get('bb_baby', { name: '', birth: '' });
let babyPhoto = store.get('bb_photo', null); /* صورة البيبي (base64 صغير) — اختيارية */
let checks = store.get('bb_checks', {});
let swaps = store.get('bb_swaps', {});
if (typeof globalThis.DIET === 'object') globalThis.DIET.dairyFree = !!baby.dairyFree;
let shopWeekSel = store.get('bb_shopweek', 0);
let shopChecks = store.get('bb_shop', {});
let favsMom = store.get('bb_momfavs', {});
globalThis.MEAL_OVERRIDES = swaps; /* المولّد بيقرا الاستبدالات من هنا */

/* ---------- اللغة والوضع ---------- */
/* الافتراضي لغة الجهاز: عربي لو عربي، إنجليزي لأي حاجة تانية — والاختيار اليدوي بيتخزن وبيفضل */
let lang = store.get('bb_lang', null) ||
  ((navigator.language || 'en').toLowerCase().indexOf('ar') === 0 ? 'ar' : 'en');
let theme = store.get('bb_theme', null) ||
  (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');

const isAr = () => lang === 'ar';
const L = () => lang;

function applyLangTheme() {
  document.documentElement.lang = lang;
  document.documentElement.dir = isAr() ? 'rtl' : 'ltr';
  document.documentElement.dataset.theme = theme;
}
applyLangTheme();

/* مساعدات محتوى */
const tx = obj => (obj ? obj[lang] ?? obj.ar : '');
const fname = f => isAr() ? f.n : (f.en_n || f.n);
const fing = f => isAr() ? f.ing : (f.en_ing || f.ing);
const fprep = f => isAr() ? f.prep : (f.en_prep || f.prep);
const fnote = f => isAr() ? f.note : (f.en_note ?? f.note);
const num = n => isAr() ? toAr(n) : String(n);

/* نصوص الواجهة */
const T = {
  appTitle:     { ar: 'بيبي منيو', en: 'Baby Menu' },
  tagline:      { ar: 'جداول أكل صحي للبيبي — من ٦ شهور لحد ٣ سنين', en: 'Healthy meal plans for your baby — 6 months to 3 years' },
  babyInfo:     { ar: '👶 بيانات البيبي', en: '👶 Baby\u2019s info' },
  optional:     { ar: '(اختياري)', en: '(optional)' },
  babyName:     { ar: 'اسم البيبي', en: 'Baby\u2019s name' },
  save:         { ar: 'حفظ 💾', en: 'Save 💾' },
  nowAge:       { ar: 'دلوقتي', en: 'now' },
  statusAge:    (name, age, d) => isAr()
                  ? `عمر ${name} دلوقتي ${age} — في اليوم ${toAr(d)}`
                  : `${name} is ${age} — on day ${d}`,
  statusAge3:   (name, age) => isAr() ? `عمر ${name} دلوقتي ${age} 😍` : `${name} is ${age} 😍`,
  readyToday:   { ar: 'جاهز تشوف جدول النهارده؟', en: 'Ready for today\u2019s plan?' },
  tooOld:       { ar: 'عمره عدّى ٣ سنين — التطبيق إرشادي لحد ٣ سنين بس', en: 'Past 3 years — this guide covers up to age 3 only' },
  todayPlan:    { ar: 'جدول النهارده ✨', en: 'Today\u2019s plan ✨' },
  saved:        { ar: 'تم الحفظ 💛', en: 'Saved 💛' },
  savedBirth:   { ar: 'تمام! هنوديك على جدول البيبي 💛', en: 'Done! We\u2019ll take you to baby\u2019s plan 💛' },
  chooseAge:    { ar: '🍽️ اختار عمر البيبي', en: '🍽️ Choose baby\u2019s age' },
  tipsStage:    { ar: '💡 نصايح المرحلة دي', en: '💡 Tips for this stage' },
  pickDay:      { ar: '📅 اختار اليوم', en: '📅 Pick a day' },
  daysFull:     { ar: '30 يوم بجدول أكل كامل', en: '30 days, a full plan every day' },
  ageTitle:     { ar: 'عمر', en: 'Age' },
  dayWord:      { ar: 'اليوم', en: 'Day' },
  todayHead:    { ar: 'جدول النهارده ✨', en: 'Today\u2019s plan ✨' },
  rightTexture: { ar: '🥄 القوام المناسب', en: '🥄 Right texture' },
  mealsDone:    (d, t) => isAr() ? `<b id="prog-txt">${toAr(d)}</b> من ${toAr(t)} وجبات خلصت` : `<b id="prog-txt">${d}</b> of ${t} meals done`,
  recipe:       { ar: 'الوصفة والمكونات', en: 'Recipe & ingredients' },
  ingredients:  { ar: '🧺 <b>المكونات:</b>', en: '🧺 <b>Ingredients:</b>' },
  disclaimer:   {
    ar: 'كميات الأكل تقريبية — البيبي اللي بياكل أكتر أو أقل ده عادي، اتبعي شهيته.<br>🍼 التطبيق إرشادي — راجعي طبيب الأطفال في أي قرار تغذية.',
    en: 'Amounts are approximate — eating more or less than shown is normal; follow baby\u2019s appetite.<br>🍼 This app is a guide — always check with your pediatrician on any feeding decision.',
  },
  /* رخصة رسومات الأكل (Twemoji — CC-BY 4.0) بتطلب ذكر المصدر */
  iconsCredit: { ar: 'أيقونات الأكل من Twemoji (Twitter والمساهمين) — رخصة CC-BY 4.0', en: 'Food icons: Twemoji by Twitter, Inc. and contributors — CC-BY 4.0' },
  disclaimerHome: {
    ar: '🍼 التطبيق إرشادي للاسترشاد بس ومش بديل عن استشارة طبيب الأطفال.<br>قبل بدء أي طعام، اتأكدي إن البيبي جاهز وراجعي الطبيب لو فيه حساسية في العيلة.',
    en: '🍼 This app is a general guide only, not a substitute for your pediatrician.<br>Before starting solids make sure baby is ready, and check with your doctor if allergies run in the family.',
  },
  doneDay:      { ar: 'برافو! جدول النهارده خلص 🎉💕', en: 'Bravo! Today\u2019s plan is complete 🎉💕' },
  doneMeal:     { ar: 'تمام يا شاطر! 💪', en: 'Well done! 💪' },
  daySmall:     (age, date) => isAr() ? `عمر ${age}${date ? ' • ' + date : ''}` : `${age}${date ? ' • ' + date : ''}`,
};

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.remove('show');
  void t.offsetWidth; /* إعادة تشغيل الأنيميشن */
  t.classList.add('show');
  clearTimeout(t._h);
  t._h = setTimeout(() => t.classList.remove('show'), 2400);
}

/* ---------- الراوتر ---------- */
function parseHash() {
  const parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  if (parts[0] === 'sources') return { view: 'sources' };
  if (parts[0] === 'momtime') return { view: 'momtime' };
  if (parts[0] === 'aid') return { view: 'aid' };
  if (parts[0] === 'vaccines') return { view: 'vaccines' };
  if (parts[0] === 'dairyfree') return { view: 'dairyfree' };   /* الألبان والمصادر اتشالوا من الرئيسية (١٠ نوفمبر) — الصفحات لسه هنا لو رجعناهم */
  if (parts[0] === 'mealspec' && parts[1] === 'tips') return { view: 'mealspecTips' };
  if (parts[0] === 'mealspec') return { view: 'mealspec' };
  if (parts[0] === 'age' && AGES.includes(+parts[1])) {
    const m = +parts[1];
    if (parts[2] === 'shop') return { view: 'shop', m };
    if (parts[2] === 'tips') return { view: 'tips', m };
    const day = parts[2] === 'day' && +parts[3] >= 1 && +parts[3] <= 30 ? +parts[3] : null;
    return { view: day ? 'day' : 'age', m, day };
  }
  return { view: 'home' };
}

/* تاريخ ميلاد البيبي => العمر الحالي بالشهر واليوم */
function babyNow() {
  if (!baby.birth) return null;
  const b = new Date(baby.birth + 'T00:00:00');
  if (isNaN(b)) return null;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  if (now < b) return null;

  /* الشهور التقويمية الكاملة */
  let m = (now.getFullYear() - b.getFullYear()) * 12 + (now.getMonth() - b.getMonth());
  const probe = new Date(b);
  probe.setMonth(probe.getMonth() + m);
  if (probe > now) m -= 1;

  /* اليوم جوا الشهر: من تاريخ الميلاد + m شهور لحد النهارده */
  const anchor = new Date(b);
  anchor.setMonth(anchor.getMonth() + m);
  const day = Math.floor((now - anchor) / 86400000) + 1;

  return { m, day: Math.max(1, Math.min(30, day)), future: m > 36 };
}

/* تاريخ يوم معين من جدول عمر معين (تقويم حقيقي) */
function dateOfDay(m, d) {
  if (!baby.birth) return null;
  const a = new Date(baby.birth + 'T00:00:00');
  a.setMonth(a.getMonth() + m);
  a.setDate(a.getDate() + (d - 1));
  return a.getTime();
}

/* العمر الحقيقي زي ما هو — بس بعد ٣ سنين بيقف عند ٣ سنين (مفيش تقريب لـ ٥ شهور للأصغر) */
function clampAge(m) { return Math.min(36, m); }

function fmtDate(ms) {
  try {
    return new Intl.DateTimeFormat(isAr() ? 'ar-EG' : 'en-GB',
      { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(ms));
  } catch { return ''; }
}

function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

/* ألوان حسب الوضع */

/* أيقونة الأكلة: صورة كرتونية فلات (Twemoji) على خلفية باستيل دائرية */
function emojiFile(e) {
  const cps = [];
  for (const ch of e) {
    const o = ch.codePointAt(0);
    if (o === 0xfe0f) continue;
    if (o === 0x200d) { if (cps.length) cps[cps.length - 1] += '-200d'; continue; }
    const hex = o.toString(16);
    if (cps.length && cps[cps.length - 1].endsWith('-200d')) cps[cps.length - 1] += '-' + hex;
    else cps.push(hex);
  }
  return cps.join('-');
}
function mealIcon(e, cls) {
  return `<img src="icons/food/${emojiFile(e)}.png" class="foodimg ${cls || ''}" alt="" loading="lazy" onerror="this.outerHTML='${e}'">`;
}
const catGrad = f => {
  const pair = (CAT_COLORS[f.c] || CAT_COLORS.dish)[theme === 'dark' ? 1 : 0];
  return `background:linear-gradient(135deg,${pair[0]},${pair[1]})`;
};
const ageColor = m => `background:${AGE_PALETTES[theme === 'dark' ? 1 : 0][m % 8]}`;
/* كروت الشهور زي صورة مامي: لون باستيل + رقم كبير مدوّر + أيقونة لطيفة (6 لـ 36 شهر) */
/* أيقونة طبق أكل من تصميم التطبيق (مش صور من النت — عشان حقوق النشر) على أيام كل الشهور من 6 لـ 36:
   طبق بحافة بلون كارت الشهر، وعليه وش بيضحك من أكل: بروكلي، عيون توت أزرق، مناخير جزرة، خدود فراولة، وابتسامة نص شريحة برتقان */
const PLATE_RIM = { peach: '#FCDCCD', mint: '#D3EBE3', lav: '#E5DAF6', cream: '#FCE5C4', blue: '#D6E3FA', pink: '#FAD8E0', green: '#DAEAD3' };
const hasPlate = m => m >= 6 && m <= 36;
const plateIcon = m => `<svg class="day-plate" viewBox="0 0 100 100" aria-hidden="true">
  <circle cx="50" cy="50" r="48" fill="${PLATE_RIM[(AGE_CARD[m] || ['peach'])[0]]}"/>
  <circle cx="50" cy="50" r="48" fill="none" stroke="rgba(90,55,25,.16)" stroke-width="1.5"/>
  <circle cx="50" cy="51" r="38" fill="#FFFFFF"/>
  <circle cx="50" cy="51" r="38" fill="none" stroke="rgba(90,55,25,.07)" stroke-width="3"/>
  <g fill="#5DA853"><circle cx="37" cy="30" r="6.5"/><circle cx="45" cy="25" r="7.5"/><circle cx="55" cy="25" r="7.5"/><circle cx="63" cy="30" r="6.5"/></g>
  <g fill="#7CC46E"><circle cx="43" cy="23" r="2.6"/><circle cx="55" cy="22" r="2.6"/><circle cx="62" cy="28" r="2"/><circle cx="36" cy="28" r="2"/></g>
  <circle cx="40" cy="45" r="5" fill="#2F3A6E"/><circle cx="60" cy="45" r="5" fill="#2F3A6E"/>
  <circle cx="38.6" cy="43.6" r="1.5" fill="#fff"/><circle cx="58.6" cy="43.6" r="1.5" fill="#fff"/>
  <ellipse cx="31" cy="55" rx="4.6" ry="3.6" fill="#FF8FA3" opacity=".8"/><ellipse cx="69" cy="55" rx="4.6" ry="3.6" fill="#FF8FA3" opacity=".8"/>
  <path d="M46.5 50 L53.5 50 L50 58 Z" fill="#F28B3A" stroke="#DD7426" stroke-width="1" stroke-linejoin="round"/>
  <path d="M34 62 A16 15 0 0 0 66 62 Z" fill="#FFB547" stroke="#F29A1F" stroke-width="1.6" stroke-linejoin="round"/>
  <path d="M37.5 63.5 A12.5 11.5 0 0 0 62.5 63.5 Z" fill="#FFD27F"/>
  <g stroke="#F6B24A" stroke-width="1.1" stroke-linecap="round"><path d="M50 63.5 L50 74"/><path d="M50 63.5 L42 71.5"/><path d="M50 63.5 L58 71.5"/></g>
</svg>`;
const acUnit = m => (isAr() ? (m === 36 ? 'شهر' : 'شهور') : 'months');   /* آخر كارت: "٣٦ شهر" زي ما مامي كتبت */
const AGE_CARD = {
  6: ['peach', '🧸'], 7: ['mint', '🌈'], 8: ['lav', '⭐'], 9: ['cream', '🎈'], 10: ['blue', '⛵'], 11: ['pink', '🐰'],
  12: ['green', '🚗'], 13: ['lav', '🌞'], 14: ['cream', '🦒'], 15: ['mint', '☁️'], 16: ['pink', '🦋'], 17: ['blue', '🐻'],
  18: ['lav', '🌙'], 19: ['peach', '🐥'], 20: ['green', '🧩'], 21: ['cream', '🐘'], 22: ['blue', '🌟'], 23: ['lav', '🐳'],
  24: ['pink', '🎂'], 25: ['green', '🦊'], 26: ['peach', '🐢'], 27: ['mint', '🦄'], 28: ['lav', '🐼'], 29: ['cream', '🐝'],
  30: ['blue', '🌼'], 31: ['pink', '🐞'], 32: ['green', '🦁'], 33: ['peach', '🐠'], 34: ['mint', '🪁'], 35: ['lav', '🐶'],
  36: ['cream', '🎉'],
};

/* أزرار اللغة والوضع */
const soundOn = () => !window.BeebySfx || window.BeebySfx.isOn();

function togglesHtml() {
  return `
    <div class="toggles">
      <button class="tbtn" data-act="lang" aria-label="language">${isAr() ? 'EN' : 'ع'}</button>
      <button class="tbtn" data-act="theme" aria-label="theme">${theme === 'dark' ? '☀️' : '🌙'}</button>
      <button class="tbtn" data-act="sound" aria-label="${isAr() ? 'الصوت' : 'sound'}" aria-pressed="${soundOn()}">${soundOn() ? '🔊' : '🔇'}</button>
    </div>`;
}

/* ---------- شاشة الرئيسية ---------- */
function renderHome() {
  babyPhoto = store.get('bb_photo', null);
  const now = babyNow();
  const ageL = now ? ageLabel(clampAge(now.m))[lang] : '';
  /* أصغر من ٦ شهور: العمر الحقيقي بس — من غير "جدول النهارده" (الجداول بتبدأ من ٦ شهور) */
  const young = now && now.m < 6;
  /* الشهور: لما تاريخ الميلاد يتحط بيظهر شهر البيبي بس (وأصغر من ٦ شهور مفيش شهر يظهر) —
     ولو تاريخ الميلاد اتمسح بترجع كل الشهور */
  const gridAges = now ? AGES.filter(m => m === clampAge(now.m)) : AGES;
  const statusHtml = now ? `
    <div class="baby-status">
      <div class="txt">${esc(now.future || young ? T.statusAge3(esc(baby.name || tx({ ar: 'البيبي', en: 'Baby' })), ageL) : T.statusAge(esc(baby.name || tx({ ar: 'البيبي', en: 'Baby' })), ageL, now.day))}
        ${young ? '' : `<small>${now.future ? T.tooOld[lang] : T.readyToday[lang]}</small>`}
      </div>
      ${now.future || young ? '' : `<a class="go-today" href="#/age/${clampAge(now.m)}/day/${now.day}">${T.todayPlan[lang]}</a>`}
    </div>` : '';

  $app.innerHTML = `
    <div class="home-toggles">${togglesHtml()}</div>
    <div class="hero">
      <div class="mascot-wrap">
        <div class="mascot${babyPhoto ? ' has-photo' : ''}">${babyPhoto ? `<img src="${babyPhoto}" class="baby-photo" alt="baby" data-act="photomenu">` : '👶'}</div>
        <button class="cam-badge" data-act="babycam" aria-label="photo">📷</button>
        <input type="file" id="baby-photo-input" accept="image/*" hidden>
      </div>
      <h2>${T.appTitle[lang]}</h2>
    </div>

    <div class="baby-card">
      <div class="baby-head">
        <h3>${T.babyInfo[lang]} <small style="font-weight:600;color:var(--ink-soft)">${T.optional[lang]}</small></h3>
        <button class="baby-save" id="baby-save">${T.save[lang]}</button>
      </div>
      <div class="baby-row">
        <input id="baby-name" type="text" placeholder="${T.babyName[lang]}" value="${esc(baby.name)}" maxlength="20">
        <span class="date-wrap ${baby.birth ? 'has-val' : ''}">
          <input id="baby-birth" type="date" value="${esc(baby.birth)}" max="${new Date().toISOString().slice(0, 10)}">
          <button type="button" class="date-clear" data-act="dateclear" aria-label="${isAr() ? 'امسحي التاريخ' : 'Clear date'}">✕</button>
        </span>
      </div>
      <label class="dairy-toggle ${baby.dairyFree ? 'on' : ''}">
        <input type="checkbox" id="dairy-free-chk" ${baby.dairyFree ? 'checked' : ''}>
        <span class="dt-track"><span class="dt-dot"></span></span>
        <span class="dt-lab">🥛❌ ${T.dairyToggle[lang]}</span>
      </label>
      ${statusHtml}
    </div>

    <div class="mom-row">
      <a class="pillbtn rise" style="--i:2" href="#/momtime">${T.momBtn[lang]}</a>
      <a class="pillbtn aidbtn rise" style="--i:3" href="#/aid">🚑 ${T.aidBtn[lang]}</a>
    </div>
    <a class="pillbtn vaxbtn rise" style="--i:4" href="#/vaccines">💉 ${T.vaxBtn[lang]}</a>

    ${gridAges.length ? `<div class="sec-title">${T.chooseAge[lang]} <span class="dash"></span></div>
    <div class="age-grid">
      ${gridAges.map((m, i) => `
        <a class="age-card ac ac-${(AGE_CARD[m] || ['peach'])[0]} rise ${now && clampAge(now.m) === m && !now.future ? 'today' : ''}" style="--i:${i % 12}" data-now="${T.nowAge[lang]}" href="#/age/${m}" aria-label="${isAr() ? toAr(m) : m} ${acUnit(m)}">
          <i class="ac-deco" aria-hidden="true">${i % 2 ? '✦' : '♥'}</i>
          <span class="ac-top" aria-hidden="true"><b class="ac-num">${isAr() ? toAr(m) : m}</b><span class="ac-ico">${(AGE_CARD[m] || ['', '🍼'])[1]}</span></span>
          <span class="ac-unit" aria-hidden="true">${acUnit(m)}</span>
        </a>`).join('')}
    </div>` : ''}

    <a class="pillbtn mealspecbtn rise" style="--i:2" href="#/mealspec">🍽️ ${T.mealSpecBtn[lang]}</a>

    <p class="disclaimer">${T.disclaimerHome[lang]}</p>
    <p class="disclaimer credit">${T.iconsCredit[lang]}</p>
  `;

  if (window.BeebyAds) window.BeebyAds.showBanner();

  document.getElementById('baby-save').addEventListener('click', () => {
    const name = document.getElementById('baby-name').value.trim();
    const birth = document.getElementById('baby-birth').value;
    baby = { ...baby, name, birth };
    store.set('bb_baby', baby);
    if (window.MealAlerts) MealAlerts.reschedule();   /* التنبيهات على العمر الجديد (وأقل من ٦ شهور مفيش) */
    showToast(birth ? T.savedBirth[lang] : T.saved[lang]);
    renderHome();
  });
}

/* ---------- شاشة العمر ---------- */
function renderAge(m) {
  const now = babyNow();
  const label = ageLabel(m)[lang];

  const dayCards = [];
  for (let d = 1; d <= 30; d++) {
    const dj = getDay(m, d);
    const foods = dj.meals
      .flatMap(x => x.type === 'combo' ? x.parts.map(p => p.food.e) : (x.type === 'food' || x.type === 'finger' ? [x.food.e] : []))
      .slice(0, 2).map(e => mealIcon(e, 'mini-img')).join('');
    const allDone = dj.meals.every(x => checks[`${m}-${d}-${x.k}`]);
    const isToday = now && !now.future && clampAge(now.m) === m && now.day === d;
    dayCards.push(`
      <a class="day-card rise ${allDone ? 'done' : ''} ${isToday ? 'today' : ''}" style="--i:${d % 12}" href="#/age/${m}/day/${d}">
        <span class="num">${num(d)}</span>
        <span class="mini">${hasPlate(m) ? plateIcon(m) : foods}</span>
      </a>`);
  }

  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/">←</a>
      <div class="logo">${ageEmoji(m)}</div>
      <h1>${T.ageTitle[lang]} ${label}<small>${T.daysFull[lang]}</small></h1>
      ${togglesHtml()}
    </div>

    <div class="age-hero">
      <div class="em em-baby"><img src="img/baby-bowl.png" alt="" aria-hidden="true" decoding="async"></div>
      <h2>${label}</h2>
      <p>${tx(textureFor(m))}</p>
    </div>

    <div class="day-note center age-after">📌 ${isAr()
      ? `الوجبات دي بتتقدم بعد إتمام <b>${label.replace(/^عمر\s*/, '')}</b>`
      : `These meals start after completing <b>${label}</b>`}</div>

    <a class="pillbtn" href="#/age/${m}/shop">🛒 ${T.shopBtn[lang]}</a>
    <a class="pillbtn tipsbtn" href="#/age/${m}/tips">${T.tipsStage[lang]}</a>
    <label class="dairy-toggle notify-toggle ${window.MealAlerts && MealAlerts.isEnabled() ? 'on' : ''}">
      <input type="checkbox" id="meal-alerts-chk" ${window.MealAlerts && MealAlerts.isEnabled() ? 'checked' : ''}>
      <span class="dt-track"><span class="dt-dot"></span></span>
      <span class="dt-lab">🔔 ${isAr() ? 'تنبيهات مواعيد الوجبات' : 'Meal-time reminders'}</span>
    </label>

    <div class="sec-title">${T.pickDay[lang]} <span class="dash"></span></div>
    <div class="day-grid">${dayCards.join('')}</div>
  `;
}

/* ---------- نصايح المرحلة: صفحة لوحدها لكل شهر (زرارها فوق "اختار اليوم" في صفحة الشهر) ---------- */
function renderTips(m) {
  const tipList = tipsFor(m)[lang];
  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/age/${m}">←</a>
      <div class="logo">💡</div>
      <h1>${T.tipsStage[lang].replace(/^💡\s*/, '')}<small>${ageLabel(m)[lang]}</small></h1>
      ${togglesHtml()}
    </div>
    <div class="tips">
      ${tipList.map((t, i) => `<div class="tip rise" style="--i:${i % 10}"><span class="ic">✨</span><span>${t}</span></div>`).join('')}
    </div>
  `;
}

/* ---------- شاشة اليوم ---------- */
function renderDay(m, d) {
  const dj = getDay(m, d);
  if (window.BeebyAds) window.BeebyAds.maybeInterstitial(`${m}-${d}`);
  const now = babyNow();
  const isToday = now && !now.future && clampAge(now.m) === m && now.day === d;
  const dayDate = dateOfDay(m, d) && fmtDate(dateOfDay(m, d));
  const doneCount = dj.meals.filter(x => checks[`${m}-${d}-${x.k}`]).length;

  const badgeHtml = f => `
    ${f.iron ? '<span class="chip iron">🩸 ' + (isAr() ? 'حديد' : 'Iron') + '</span>' : ''}
    ${f.vitC ? '<span class="chip vitc">🍊 ' + (isAr() ? 'فيتامين C' : 'Vit C') + '</span>' : ''}`;

  /* من الشهر الثامن (3 وجبات متكاملة في اليوم): كل وجبة باسمها */
  const MEAL3_NAMES = {
    b: { ar: '🍳 إفطار متكامل', en: '🍳 Complete breakfast' },
    l: { ar: '🍽️ غداء متكامل', en: '🍽️ Complete lunch' },
    d: { ar: '🌙 عشاء متكامل', en: '🌙 Complete dinner' },
  };

  /* اسم الجزء: الكمية + الاسم المختصر من جدول مامي (زي "ملعقتين كوسة") — ولو اتبدل بياخد اسم الأكلة الجديدة */
  const partName = p => {
    const nm = (p.foods || [p.food]).map(f => (p.label && f.id === p.orig) ? tx(p.label) : (p.short && p.short[f.id]) ? tx(p.short[f.id]) : fname(f)).join(isAr() ? ' أو ' : ' or ');
    if (!p.amt) return nm;
    return isAr() && p.amt.arAfter ? `${nm} ${tx(p.amt)}` : `${tx(p.amt)} ${nm}`;   /* "صفار كامل" */
  };

  /* تقسيم الطبق: نص خضار/فاكهة + ربع بروتين + ربع نشويات (لما الوجبة فيها المجموعات التلاتة) */
  const plateSplitHtml = parts => {
    const g = { vf: 0, pr: 0, st: 0 };
    parts.forEach(p => { if (p.role === 'v' || p.role === 'f') g.vf++; else if (p.role === 'p' || p.role === 'd') g.pr++; else if (p.role === 's') g.st++; });
    if (!(g.vf && g.pr && g.st)) return '';
    const L = isAr()
      ? { vf: 'نص الطبق خضار / فاكهة', pr: 'ربع بروتين', st: 'ربع نشويات' }
      : { vf: 'Half: veg / fruit', pr: 'Quarter: protein', st: 'Quarter: starch' };
    return `<div class="plate-split" aria-label="${esc(L.vf + ' · ' + L.pr + ' · ' + L.st)}">
      <div class="ps-bar"><span class="ps-vf"></span><span class="ps-pr"></span><span class="ps-st"></span></div>
      <div class="ps-legend"><span><i class="ps-vf"></i>${L.vf}</span><span><i class="ps-pr"></i>${L.pr}</span><span><i class="ps-st"></i>${L.st}</span></div>
    </div>`;
  };

  const mealHtml = (x, i) => {
    const done = !!checks[`${m}-${d}-${x.k}`];
    const isMilk = x.type === 'milk' || x.type === 'milkcup';

    if (x.type === 'combo') {
      const head = (x.fixed && m === 6) ? (isAr() ? '🥄 أكلة اليوم' : '🥄 Today’s food') : (x.fixed && m === 7) ? (x.k === 'b' ? (isAr() ? '🍽️ الوجبة الأولى (الفطار)' : '🍽️ First meal (breakfast)') : (isAr() ? '⚖️ الوجبة التانية (الغدا)' : '⚖️ Second meal (lunch)')) : (m >= 8 && MEAL3_NAMES[x.k]) ? tx(MEAL3_NAMES[x.k]) : x.k === 'b' ? (isAr() ? '🍽️ فطار متكامل' : '🍽️ Complete breakfast') : (isAr() ? '⚖️ وجبة كاملة' : '⚖️ Complete meal');
      const swapKey = r => `${m}-${d}-${x.k}-${r}`;
      return `
      <div class="meal combo" data-key="${m}-${d}-${x.k}" style="--i:${i}">
        <div class="meal-img combo-img" style="${catGrad(x.parts[0].food)}"><span class="plate">🍽️</span></div>
        <div class="meal-body">
          <div class="meal-top">
            <div class="meal-name">${head}<small class="combo-hint">${x.fixed ? '' : (isAr() ? 'خضار/فاكهة + بروتين + نشويات' : 'veg/fruit + protein + starch')}</small></div>
            <button class="swapbtn" data-act="swapcombo" data-key="${m}-${d}-${x.k}" aria-label="swap">🔄</button>
            <button class="check ${done ? 'done' : ''}" data-act="check" aria-label="done">✓</button>
          </div>
          <div class="combo-parts">
            ${x.parts.map(p => `
              <div class="combo-part">
                <span class="cpart-emo" style="${catGrad(p.food)}">${mealIcon(p.food.e)}</span>
                <span class="cpart-txt"><b>${esc(partName(p))}</b><i>${ROLE_LABEL[p.role][lang]}${p.isNew ? (isAr() ? ' · 🆕 صنف جديد' : ' · 🆕 new') : ''}</i></span>
                ${badgeHtml(p.food)}
              </div>`).join('')}
          </div>
          ${x.note ? `<div class="meal-note cook-note">👩‍🍳 ${esc(tx(x.note))}</div>` : ''}
          ${plateSplitHtml(x.parts)}
          <div class="chips">
            <span class="chip time">⏰ ${tx(x.time)}</span>
            ${x.portion ? `<span class="chip">🍽️ ${esc(tx(x.portion))}</span>` : ''}
            ${x.tags.map(tg => `<span class="chip allergen">${ALLERGEN_LABEL[tg][lang] || tg}</span>`).join('')}
          </div>
          <button class="prep-toggle" data-act="prep">${T.recipe[lang]} ▾</button>
          <div class="prep">
            ${x.parts.flatMap(p => p.foods || [p.food]).map(pf => `
              <div class="ing">${mealIcon(pf.e, "ing-img")} <b>${esc(fname(pf))}</b> — ${T.ingredients[lang]} ${esc(fing(pf))}</div>
              <ol>${fprep(pf).map(pp => `<li>${esc(pp)}</li>`).join('')}</ol>`).join('')}
          </div>
          ${(() => { const fs = x.parts.flatMap(p => p.foods || [p.food]).filter(f => fnote(f)); return fs.length ? `<div class="meal-note">${fs.map(f => `• ${esc(fname(f))}: ${esc(fnote(f))}`).join('<br>')}</div>` : ''; })()}
        </div>
      </div>`;
    }

    const f = x.food;
    /* اللي بين الوجبات (الضحى والعصر) من بعد السنة: اسمه "سناك" والأكلة تحته — قبل السنة دول رضعات/مية مش سناك */
    const isSnack = x.type === 'food' && (x.k === 's1' || x.k === 's2');
    return `
    <div class="meal ${isMilk ? 'itsmilk' : ''}" data-key="${m}-${d}-${x.k}" style="--i:${i}">
      <div class="meal-img" style="${catGrad(f)}">${mealIcon(f.e)}</div>
      <div class="meal-body">
        <div class="meal-top">
          <div class="meal-name">${isSnack ? `${isAr() ? '🍎 سناك' : '🍎 Snack'}<small class="snack-food">${esc(fname(f))}</small>` : esc(fname(f))}</div>
          ${x.type === 'food' ? `<button class="swapbtn" data-act="swap" aria-label="swap">🔄</button>` : ''}
          <button class="check ${done ? 'done' : ''}" data-act="check" aria-label="done">✓</button>
        </div>
        <div class="chips">
          <span class="chip time">⏰ ${tx(x.time)}</span>
          <span class="chip">🍽️ ${esc(tx(x.portion))}</span>
          ${x.light ? `<span class="chip vitc">🌙 ${isAr() ? 'خفيف سهل الهضم' : 'Light & easy to digest'}</span>` : ''}
          ${badgeHtml(f)}
          ${x.tags.map(tg => `<span class="chip allergen">${ALLERGEN_LABEL[tg][lang] || tg}</span>`).join('')}
        </div>
        <button class="prep-toggle" data-act="prep">${T.recipe[lang]} ▾</button>
        <div class="prep">
          <div class="ing">${T.ingredients[lang]} ${esc(fing(f))}</div>
          <ol>${fprep(f).map(p => `<li>${esc(p)}</li>`).join('')}</ol>
        </div>
        ${fnote(f) ? `<div class="meal-note">${esc(fnote(f))}</div>` : ''}
      </div>
    </div>`;
  };

  const mealsHtml = dj.meals.map(mealHtml).join('');

  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/age/${m}">←</a>
      <div class="logo">📅</div>
      <h1>${T.dayWord[lang]} ${num(d)}<small>${T.daySmall(ageLabel(m)[lang], dayDate)}</small></h1>
      ${togglesHtml()}
    </div>

    <div class="day-head">
      <h2>${isToday ? T.todayHead[lang] : `${T.dayWord[lang]} ${num(d)}`}</h2>
      <span class="texture-chip">${T.rightTexture[lang]}: ${tx(dj.texture)}</span>
    </div>

    ${dj.note ? `<div class="day-note rise">📌 ${tx(dj.note)}</div>` : ''}

    <div class="progress-wrap">
      <span class="progress-txt">${T.mealsDone(doneCount, dj.meals.length)}</span>
      <div class="progress-bar"><i id="prog-fill" style="width:${(doneCount / dj.meals.length) * 100}%"></i></div>
    </div>

    ${mealsHtml}

    <p class="disclaimer">${T.disclaimer[lang]}</p>
  `;
}

/* ---------- التبديلات ---------- */
function switchLang() {
  lang = isAr() ? 'en' : 'ar';
  store.set('bb_lang', lang);
  applyLangTheme();
  render();
}

function switchTheme() {
  theme = theme === 'dark' ? 'light' : 'dark';
  store.set('bb_theme', theme);
  applyLangTheme();
  showToast(theme === 'dark' ? (isAr() ? 'وضع ليلي هادي 🌙' : 'Cozy dark mode 🌙') : (isAr() ? 'وضع نهاري مشرق ☀️' : 'Bright light mode ☀️'));
  render();
}

$app.addEventListener('click', async e => {
  if (e.target.id === 'meal-alerts-chk') {
    const on = e.target.checked;
    if (window.MealAlerts) {
      if (on) {
        const ok = await MealAlerts.enable();
        const young = (babyNow() || { m: 6 }).m < 6;   /* أقل من ٦ شهور: مفيش تنبيهات لحد ما يكمل ٦ شهور */
        if (!ok) e.target.checked = false;
        else showToast(young
          ? (isAr() ? 'التنبيهات هتبدأ لما البيبي يكمل ٦ شهور 🔔' : 'Reminders will start when baby turns 6 months 🔔')
          : (isAr() ? 'التنبيهات شغالة! هنبقّلك قبل كل وجبة 🔔💛' : 'Reminders on! We\u2019ll ping you before every meal 🔔💛'));
      } else {
        await MealAlerts.disable();
        showToast(isAr() ? 'اتوقفت التنبيهات 🔕' : 'Reminders off 🔕');
      }
      const p = parseHash();
      if (p.view === 'age') renderAge(p.m); else renderHome();
    }
    return;
  }
  if (e.target.id === 'dairy-free-chk') {
    baby.dairyFree = e.target.checked;
    store.set('bb_baby', baby);
    if (typeof globalThis.DIET === 'object') globalThis.DIET.dairyFree = baby.dairyFree;
    invalidateDayCache();
    showToast(baby.dairyFree ? T.dairyOn[lang] : (isAr() ? 'رجعت الجداول العادية 🥛' : 'Regular schedules restored 🥛'));
    renderHome();
    return;
  }
  const btn = e.target.closest('[data-act]');
  if (!btn) return;

  if (btn.dataset.act === 'dateclear') {
    const inp = btn.parentElement.querySelector('input[type="date"]');
    if (inp) {
      inp.value = '';
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return;
  }
  if (btn.dataset.act === 'lang') return switchLang();
  if (btn.dataset.act === 'babycam') { window.__PICKER_UNTIL = Date.now() + 90000; document.getElementById('baby-photo-input').click(); return; }
  if (btn.dataset.act === 'photomenu') {
    openSheet(isAr() ? '👶 صورة البيبي' : '👶 Baby photo', `
      <div class="photo-menu">
        <button class="pm-item" data-act="pm-change"><span class="sw-emo">🔄</span><span class="sw-txt"><b>${isAr() ? 'غيّري الصورة' : 'Change photo'}</b><i>${isAr() ? 'اختاري صورة جديدة من المعرض' : 'Pick a new one from gallery'}</i></span></button>
        <button class="pm-item" data-act="pm-remove"><span class="sw-emo">🗑️</span><span class="sw-txt"><b>${isAr() ? 'شيلي الصورة' : 'Remove photo'}</b><i>${isAr() ? 'يرجع أيقونة البيبي 👶 زي الأول' : 'Back to the original 👶 icon'}</i></span></button>
      </div>
    `);
    return;
  }
  if (btn.dataset.act === 'pm-change') { closeSheet(); window.__PICKER_UNTIL = Date.now() + 90000; document.getElementById('baby-photo-input').click(); return; }
  if (btn.dataset.act === 'pm-remove') {
    babyPhoto = null;
    store.set('bb_photo', null);
    closeSheet();
    renderHome();
    showToast(isAr() ? 'اتشالت الصورة — رجعت أيقونة البيبي 👶' : 'Removed — back to the 👶 icon');
    return;
  }
  if (btn.dataset.act === 'delphoto') {
    babyPhoto = null;
    store.set('bb_photo', null);
    renderHome();
    return;
  }
  if (btn.dataset.act === 'openpro') return openProSheet();
  if (btn.dataset.act === 'buynow') {
    if (window.MomPro) await MomPro.purchase();
    return;
  }
  if (btn.dataset.act === 'restorepro') {
    if (window.MomPro) await MomPro.restore();
    return;
  }
  if (btn.dataset.act === 'openaid') return openAid(btn.dataset.id);
  if (btn.dataset.act === 'pcvrisk') {
    pcvRisk = !pcvRisk;
    store.set('bb_pcvRisk', pcvRisk);
    return renderVax();
  }
  if (btn.dataset.act === 'vaxtoggle') return toggleVax(btn.dataset.id);
  if (btn.dataset.act === 'vaxsave') return saveVax(btn.dataset.id);
  if (btn.dataset.act === 'vaxtype') {
    vaxType[btn.dataset.id] = btn.dataset.type;
    store.set('bb_vaxType', vaxType);
    return renderVax();
  }
  if (btn.dataset.act === 'momage') {
    momAgeSel = +btn.dataset.w === -1 ? null : +btn.dataset.w;
    renderMomtime();
    return;
  }
  if (btn.dataset.act === 'coffeego') {
    coffeeStart = Date.now();
    renderMomtime();
    startCoffeeTimer();
    return;
  }
  if (btn.dataset.act === 'coffeestop') {
    const mins = coffeeStart ? Math.floor((Date.now() - coffeeStart) / 60000) : 0;
    if (mins >= 1) {
      coffeeTotal += mins;
      store.set('bb_coffee', coffeeTotal);
      showToast(isAr() ? `كسبتِ ${toAr(mins)} دقيقة هدوء! قهوتك على حسابنا 🌸☕` : `You earned ${mins} calm minutes! Coffee on us 🌸☕`);
    } else {
      showToast(isAr() ? 'لحظة واحدة قهوة؟ جربي تاني 🌸' : 'A one-second break? Try again 🌸');
    }
    coffeeStart = null;
    clearInterval(coffeeTimer);
    renderMomtime();
    return;
  }
  if (btn.dataset.act === 'favact') {
    favsMom[btn.dataset.id] = !favsMom[btn.dataset.id];
    store.set('bb_momfavs', favsMom);
    btn.classList.toggle('done', !!favsMom[btn.dataset.id]);
    showToast(T.momSaved ? T.momSaved[lang] : (lang === 'ar' ? 'اتحفظت 💛' : 'Saved 💛'));
    return;
  }
  if (btn.dataset.act === 'sound') {
    if (window.BeebySfx) {
      window.BeebySfx.setOn(!window.BeebySfx.isOn());
      window.BeebySfx.play('pop');
    }
    showToast(soundOn() ? (isAr() ? 'الصوت شغّال 🔊' : 'Sound on 🔊') : (isAr() ? 'الصوت مكتوم 🔇' : 'Sound off 🔇'));
    return render();
  }
  if (btn.dataset.act === 'theme') return switchTheme();
  if (btn.dataset.act === 'swap') return openSwapSheet(btn.closest('.meal'));
  if (btn.dataset.act === 'swapcombo') {
    const kk = btn.dataset.key.split('-');
    return openComboSwapSheet(+kk[0], +kk[1], kk[2]);
  }
  if (btn.dataset.act === 'pickswap') return applySwap(btn.dataset.key, btn.dataset.id);
  if (btn.dataset.act === 'shopweek') { shopWeekSel = +btn.dataset.w; store.set('bb_shopweek', shopWeekSel); render(); return; }
  if (btn.dataset.act === 'shopcheck') {
    const on = !shopChecks[btn.dataset.k];
    shopChecks[btn.dataset.k] = on;
    /* علامة في قائمة الأسبوع ⇒ نفس الصنف يتعلّم في قائمة الشهر كمان (الشهر = أسبوع رقم 4)
       ولو اتشالت: نشيلها من الشهر بس لو مفيش أسبوع تاني لسه متعلّم عليه */
    const [sm, sw, sid] = btn.dataset.k.split(':');
    if (sw !== '4') {
      const monthKey = `${sm}:4:${sid}`;
      if (on) shopChecks[monthKey] = true;
      else if (![0, 1, 2, 3].some(i => shopChecks[`${sm}:${i}:${sid}`])) shopChecks[monthKey] = false;
    }
    store.set('bb_shop', shopChecks);
    (btn.closest('.shop-item') || btn).classList.toggle('on', on);
    return;
  }

  if (btn.dataset.act === 'prep') {
    const prep = btn.nextElementSibling;
    const open = prep.classList.toggle('open');
    btn.textContent = `${T.recipe[lang]} ${open ? '▴' : '▾'}`;
  }

  if (btn.dataset.act === 'check') {
    const meal = btn.closest('.meal');
    const key = meal.dataset.key;
    checks[key] = !checks[key];
    store.set('bb_checks', checks);
    btn.classList.toggle('done', checks[key]);

    const total = $app.querySelectorAll('.meal').length;
    const doneN = $app.querySelectorAll('.check.done').length;
    const txt = document.getElementById('prog-txt');
    const fill = document.getElementById('prog-fill');
    if (txt) {
      const prog = T.mealsDone(doneN, total);
      const tmp = document.createElement('span');
      tmp.innerHTML = prog;
      txt.textContent = tmp.querySelector('b').textContent;
    }
    if (fill) fill.style.width = (doneN / total) * 100 + '%';

    if (doneN === total && total > 0) { showToast(T.doneDay[lang]); if (window.BeebySfx) setTimeout(() => window.BeebySfx.play('win'), 160); }
    else if (checks[key]) showToast(T.doneMeal[lang]);

    /* تحديث علامة اليوم في صفحة العمر لو مفتوحة */
    const p = parseHash();
    if (p.view === 'age') {
      const dKey = key.split('-')[1];
      const card = $app.querySelector(`.day-card[href="#/age/${p.m}/day/${+dKey}"]`);
      if (card) {
        const dj = getDay(p.m, +dKey);
        card.classList.toggle('done', dj.meals.every(x => checks[`${p.m}-${dKey}-${x.k}`]));
      }
    }
  }
});

document.addEventListener('change', e => {
  /* تاريخ الميلاد في الرئيسية بيتحفظ على طول — اختيار من التقويم أو مسح أو ✕ — من غير زرار "حفظ"
     (المسح بيظهر كل جداول الشهور) */
  if (e.target.id === 'baby-birth' && e.target.value !== (baby.birth || '')) {
    const birth = e.target.value;
    const nameEl = document.getElementById('baby-name');
    baby = { ...baby, name: nameEl ? nameEl.value.trim() : baby.name, birth };
    store.set('bb_baby', baby);
    if (window.MealAlerts) MealAlerts.reschedule();
    showToast(birth ? T.savedBirth[lang] : (isAr() ? 'اتمسح تاريخ الميلاد — دي كل الجداول 💛' : 'Birth date cleared — here are all the plans 💛'));
    renderHome();
    return;
  }
  if (e.target.id === 'vax-birth') {
    baby.birth = e.target.value;
    store.set('bb_baby', baby);
    if (window.MealAlerts) MealAlerts.reschedule();
    return renderVax();
  }
  if (e.target.classList.contains('vax-date')) {
    vaxDraft[e.target.dataset.id] = e.target.value;
    return renderVax();
  }
  if (e.target.id !== 'baby-photo-input') return;
  window.__PICKER_UNTIL = 0;
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => openBabyCropper(ev.target.result);
  reader.readAsDataURL(file);
  e.target.value = '';
});

/* ===== 📐 أداة قص صورة البيبي على مقاس البرواز الدائري ===== */
function openBabyCropper(src) {
  document.getElementById('crop-overlay')?.remove();
  const ar = document.documentElement.lang !== 'en';
  const MAX_ZOOM = 5; /* أقصى تقريب: ٥ أضعاف الصورة وهي مالية البرواز */
  const ov = document.createElement('div');
  ov.id = 'crop-overlay';
  ov.innerHTML = `
    <div class="crop-box">
      <h3>${ar ? '⚖️ ظبّطي صورة البيبي' : '⚖️ Adjust baby photo'}</h3>
      <div class="crop-stage" id="crop-stage">
        <img id="crop-img" src="${src}" alt="" draggable="false">
        <div class="crop-hole"></div>
      </div>
      <div class="crop-zoom">
        <span>🔍</span>
        <input type="range" id="crop-scale" min="1" max="${MAX_ZOOM}" step="0.01" value="1">
        <span>🔎</span>
      </div>
      <div class="crop-actions">
        <button class="crop-cancel" id="crop-cancel">${ar ? 'إلغاء' : 'Cancel'}</button>
        <button class="crop-ok" id="crop-ok">${ar ? '✓ تمّ' : '✓ Done'}</button>
      </div>
      <small class="crop-hint">${ar ? 'حرّكي الصورة بصباعك، وقرّبي أو بعّدي بصباعين أو من السلايدر — الدايرة هي الشكل النهائي' : 'Drag to move, pinch with two fingers or use the slider to zoom — the circle is the final shape'}</small>
    </div>`;
  document.body.appendChild(ov);

  const img = ov.querySelector('#crop-img');
  const slider = ov.querySelector('#crop-scale');
  const stage = ov.querySelector('#crop-stage');
  /* الصورة بتترسم بمقاسها المعروض على طول (مش scale) عشان تفضل حادة في أي تقريب:
     s = بكسل شاشة لكل بكسل من الصورة الأصلية، و(tx, ty) مكان ركنها جوه البرواز */
  let S = 280, nw = 0, nh = 0, base = 1, s = 1, tx = 0, ty = 0;
  const apply = () => {
    /* الصورة لازم تفضل مالية البرواز — مفيش أطراف فاضية */
    tx = Math.min(0, Math.max(S - nw * s, tx));
    ty = Math.min(0, Math.max(S - nh * s, ty));
    img.style.width = nw * s + 'px';
    img.style.height = nh * s + 'px';
    img.style.transform = `translate(${tx}px, ${ty}px)`;
    slider.value = s / base;
  };
  const clampZoom = v => Math.min(base * MAX_ZOOM, Math.max(base, v));
  /* تقريب حوالين نقطة: الحتة اللي تحت الصباع (أو نص البرواز) تفضل مكانها */
  const zoomAt = (ns, fx, fy) => {
    ns = clampZoom(ns);
    tx = fx - (fx - tx) * ns / s;
    ty = fy - (fy - ty) * ns / s;
    s = ns;
    apply();
  };
  img.onload = () => {
    S = stage.clientWidth || 280;
    nw = img.naturalWidth; nh = img.naturalHeight;
    /* البداية على أبعد حاجة: الصورة كلها مالية البرواز وفي النص */
    base = s = Math.max(S / nw, S / nh);
    tx = (S - nw * s) / 2; ty = (S - nh * s) / 2;
    apply();
  };
  img.onerror = () => {
    ov.remove();
    showToast(ar ? 'مش قادرين نفتح الصورة دي — جربي صورة تانية 📷' : 'Couldn’t open that photo — try another one 📷');
  };
  slider.addEventListener('input', () => zoomAt(base * parseFloat(slider.value), S / 2, S / 2));

  /* صباع واحد = تحريك، صباعين = تقريب وتبعيد، والماوس: سحب + عجلة */
  const pts = new Map();
  let g = null; /* حالة الحركة وقت ما بدأت */
  const local = e => { const r = stage.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  const begin = () => {
    const [a, b] = pts.values();
    g = { s, tx, ty, a, d: b ? Math.hypot(b.x - a.x, b.y - a.y) : 0, m: b ? { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 } : null };
  };
  stage.addEventListener('pointerdown', e => {
    stage.setPointerCapture(e.pointerId);
    pts.set(e.pointerId, local(e));
    begin();
  });
  stage.addEventListener('pointermove', e => {
    if (!pts.has(e.pointerId) || !nw) return;
    pts.set(e.pointerId, local(e));
    const [a, b] = pts.values();
    if (!b) {
      tx = g.tx + a.x - g.a.x;
      ty = g.ty + a.y - g.a.y;
      apply();
    } else if (g.d) {
      const ns = clampZoom(g.s * Math.hypot(b.x - a.x, b.y - a.y) / g.d);
      const m = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      /* الحتة اللي كانت بين الصباعين بتمشي معاهم */
      tx = m.x - (g.m.x - g.tx) * ns / g.s;
      ty = m.y - (g.m.y - g.ty) * ns / g.s;
      s = ns;
      apply();
    }
  });
  const lift = e => { if (pts.delete(e.pointerId)) begin(); };
  stage.addEventListener('pointerup', lift);
  stage.addEventListener('pointercancel', lift);
  stage.addEventListener('wheel', e => {
    e.preventDefault();
    const p = local(e);
    zoomAt(s * Math.exp(-e.deltaY * 0.002), p.x, p.y);
  }, { passive: false });
  /* iOS: الصباعين يكبّروا الصورة بس، مش الصفحة كلها */
  ov.addEventListener('gesturestart', e => e.preventDefault());

  ov.querySelector('#crop-cancel').addEventListener('click', () => ov.remove());
  ov.querySelector('#crop-ok').addEventListener('click', () => {
    if (!nw) return;
    /* اللي ظاهر جوه البرواز بالظبط ← كانفاس 320 */
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 320;
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, -tx / s, -ty / s, S / s, S / s, 0, 0, 320, 320);
    babyPhoto = canvas.toDataURL('image/jpeg', 0.88);
    store.set('bb_photo', babyPhoto);
    ov.remove();
    renderHome();
  });
}

window.addEventListener('hashchange', render);
/* إعلان عند الانتقال لأي صفحة — بحد أقصى مرة كل دقيقة (التفاصيل في ads.js) */
window.addEventListener('hashchange', () => { if (window.BeebyAds && window.BeebyAds.onNavigate) window.BeebyAds.onNavigate(location.hash); });

function render() {
  applyLangTheme();
  const p = parseHash();
  window.scrollTo(0, 0);
  if (p.view === 'day') renderDay(p.m, p.day);
  else if (p.view === 'shop') renderShop(p.m);
  else if (p.view === 'tips') renderTips(p.m);
  else if (p.view === 'sources') renderSources();
  else if (p.view === 'momtime') { renderMomtime(); if (coffeeStart) startCoffeeTimer(); }
  else if (p.view === 'aid') renderAid();
  else if (p.view === 'vaccines') renderVax();
  else if (p.view === 'dairyfree') renderDairy();
  else if (p.view === 'mealspec') renderMealSpec();
  else if (p.view === 'mealspecTips') renderMealSpecTips();
  else if (p.view === 'age') renderAge(p.m);
  else renderHome();
}


Object.assign(T, {
  momBtn: { ar: 'وقت راحتك يا مامي 🌸', en: 'Mom’s break time 🌸' },
  momTitle: { ar: 'وقت راحتك يا مامي 🌸', en: 'Mom’s break time 🌸' },
  momSub: { ar: 'أفكار ذكية تشغل الصغير.. وتخلي القهوة سخنة!', en: 'Clever ideas that keep little hands busy.. and your coffee hot!' },
  momIntro: {
    ar: 'أهلاً بكِ يا مامي! 🌸 خذي نفساً عميقاً، جهزي قهوتكِ المفضلة واجعليها ساخنة، واتركي الباقي علينا. هذه الأنشطة مصممة بعناية لتجذب انتباه طفلكِ، تفرغ طاقته، وتمنحكِ دقائق ذهبية من الهدوء والاسترخاء!',
    en: 'Welcome, mama! 🌸 Take a deep breath, brew your favorite coffee and keep it hot — we’ll handle the rest. Carefully designed activities that capture your baby’s attention, release their energy, and gift you golden minutes of calm!',
  },
  momPickAge: { ar: '👶 اختاري عمر البيبي', en: '👶 Pick baby’s age' },
  momStage: m => {
    if (m <= 9) return { ar: '٦-٩ شهور — عالم الحواس', en: '6-9 months — the sensory world' };
    if (m <= 12) return { ar: '٩-١٢ شهر — الاستكشاف والإمساك', en: '9-12 months — exploring & grabbing' };
    if (m <= 18) return { ar: '١٢-١٨ شهر — أول مهارات', en: '12-18 months — first skills' };
    if (m <= 24) return { ar: '١٨-٢٤ شهر — الدارج الصغير', en: '18-24 months — the little toddler' };
    return { ar: '٢-٣ سنين — استقلال وخيال', en: '2-3 years — independence & imagination' };
  },
  momSkill: { ar: 'ينمّي', en: 'Builds' },
  momDur: min => isAr() ? `${toAr(min)} دقايق تقريبًا` : `~${min} min`,
  momSips: { ar: '☕ فرصة قهوتك', en: '☕ Your coffee window' },
  momAll: { ar: 'كل الأنشطة', en: 'All activities' },
});

let momAgeSel = null;
let coffeeStart = null;        /* وقت بداية وقفتك الحالية */
let coffeeTimer = null;
let coffeeTotal = store.get('bb_coffee', 0); /* رصيدك التراكمي من الهدوء (دقايق) */

const COFFEE_RANKS = [
  { at: 0,   ar: '☕ لسه أول جرعة!', en: '☕ First sip yet to come!' },
  { at: 10,  ar: '☕ فنجان صغيصجي — بداية حلوة!', en: '☕ A tiny cup — sweet start!' },
  { at: 30,  ar: '☕☕ فنجانين كاملين — برافو!', en: '☕☕ Two full cups — bravo!' },
  { at: 60,  ar: '🥐 ☕☕ فنجانين وكرواسون — إحترافية!', en: '🥐 ☕☕ Two cups + croissant — pro!' },
  { at: 120, ar: '🏆 قهوة فاخرة — مامي العام!', en: '🏆 Fancy brew — Mom of the Year!' },
];
function coffeeRank() {
  let r = COFFEE_RANKS[0];
  for (const x of COFFEE_RANKS) if (coffeeTotal >= x.at) r = x;
  return lang === 'ar' ? r.ar : r.en;
}

function fmtClock(sec) {
  const m = Math.floor(sec / 60), ss = sec % 60;
  return (isAr() ? toAr(m) : m) + ':' + (isAr() ? toAr(String(ss).padStart(2, '0')) : String(ss).padStart(2, '0'));
}

function renderCoffeeCard() {
  const running = !!coffeeStart;
  const mins = running ? Math.floor((Date.now() - coffeeStart) / 60000) : 0;
  return `
  <div class="coffee-card rise" id="coffee-card">
    <div class="cup-wrap">${running ? '<span class="steam">💨</span>' : ''}<span class="cup">☕</span></div>
    <div class="coffee-mid">
      <b class="coffee-clock" id="coffee-clock">${running ? fmtClock(Math.floor((Date.now() - coffeeStart) / 1000)) : '0:00'}</b>
      <small>${running ? (isAr() ? 'البيبي مشغول.. قهوتك بتدفّى ☕' : 'Baby is busy.. your coffee is warming ☕') : (isAr() ? 'دوسي ابدي ووقفتك تبدأ' : 'Tap start when your break begins')}</small>
      <small class="coffee-total">🌸 ${isAr() ? 'رصيدك من الهدوء' : 'Calm balance'}: ${num(coffeeTotal)} ${isAr() ? 'دقيقة' : 'min'} — ${coffeeRank()}</small>
    </div>
    <button class="coffee-btn ${running ? 'stop' : ''}" data-act="${running ? 'coffeestop' : 'coffeego'}">${running ? '✨' : '▶'}</button>
  </div>`;
}

function startCoffeeTimer() {
  clearInterval(coffeeTimer);
  coffeeTimer = setInterval(() => {
    const el = document.getElementById('coffee-clock');
    if (el && coffeeStart) el.textContent = fmtClock(Math.floor((Date.now() - coffeeStart) / 1000));
  }, 1000);
}

function renderMomtime() {
  const now = babyNow();
  /* أقل من ٦ شهور (مفيش أنشطة لعمره لسه) أو أكبر من ٣ سنين: الصفحة بتفتح عادي بكل الأنشطة */
  const m = momAgeSel !== null ? momAgeSel : (now && !now.future && now.m >= 6 ? clampAge(now.m) : null);
  /* أنشطة العمر المختار الأول، والأنشطة العامة (المتاحة لكل الأعمار) في الآخر —
     عشان المامي تحس باختلاف حقيقي لما تبدل بين الأعمار */
  const list = m !== null ? actsFor(m).slice().sort((a, b) => b.m - a.m) : ACTIVITIES;

  const cat = a => ACT_CATS[a.cat];
  const cards = list.map((a, i) => {
    const locked = window.MomPro && !MomPro.isFreeAct(a);
    return `
    <div class="act-card rise ${locked ? 'locked' : ''}" style="--i:${i % 10}" ${locked ? `data-act="openpro"` : ''}>
      <div class="act-emo">${locked ? '🔒' : mealIcon(a.e)}</div>
      <div class="act-body">
        <div class="act-top">
          <b class="act-name">${locked ? (isAr() ? 'نشاط مميز 🌟' : 'Premium activity 🌟') : esc(isAr() ? a.n : a.en_n)}</b>
          ${locked ? '<span class="pro-tag">PRO</span>' : `<button class="check ${favsMom[a.id] ? 'done' : ''}" data-act="favact" data-id="${a.id}" aria-label="fav">💛</button>`}
        </div>
        ${locked
          ? `<p class="act-desc blur">${esc(isAr() ? a.d : a.en_d)}</p>`
          : `<p class="act-desc">${esc(isAr() ? a.d : a.en_d)}</p>`}
        ${locked ? '' : `
        <div class="chips">
          <span class="chip time">${cat(a).icon} ${cat(a)[lang]}</span>
          <span class="chip">⏱️ ${T.momDur(a.dur)}</span>
          <span class="chip vitc">💪 ${T.momSkill[lang]}: ${esc(a.skill[lang])}</span>
          <span class="chip">${isAr() ? 'من' : 'from'} ${toAr(a.m)} ${isAr() ? 'شهور' : 'mo'}</span>
        </div>`}
        ${locked ? `<button class="unlock-mini" data-act="openpro">${isAr() ? `🔓 افتحي بـ ${MomPro.priceText()}` : `🔓 Unlock for ${MomPro.priceText()}`}</button>` : ''}
      </div>
    </div>`;
  }).join('');

  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/">←</a>
      <div class="logo">☕</div>
      <h1>${T.momTitle[lang]}<small>${T.momSub[lang]}</small></h1>
      ${togglesHtml()}
    </div>
    <div class="mom-welcome rise">${T.momIntro[lang]}</div>
    ${renderCoffeeCard()}
    

    <div class="week-chips">
      ${AGES.filter(mm => [6, 9, 12, 18, 24, 30].includes(mm)).map(mm => `
        <button class="wk-chip ${m === mm ? 'sel' : ''}" data-act="momage" data-w="${mm}">${ageLabel(mm)[lang]}</button>`).join('')}
      ${m !== null ? `<button class="wk-chip" data-act="momage" data-w="-1">${T.momAll[lang]}</button>` : ''}
    </div>
    ${m !== null ? `<div class="day-note center">${T.momStage(m)[lang]}</div>` : ''}


    ${cards}
    <p class="disclaimer">${T.momSips[lang]} ☕ — راقبي دايمًا البيبي أثناء اللعب، والمواد الصغيرة تحت المراقبة.</p>
  `;
}


Object.assign(T, {
  aidBtn: { ar: 'إسعافات الطوارئ', en: 'First aid' },
  aidTitle: { ar: '🚑 إسعافات الطوارئ السريعة', en: '🚑 Quick first aid' },
  aidSub: { ar: 'طوارئ المطبخ والبيت — خطوات فورية بدون بحث طويل', en: 'Kitchen & home emergencies — instant steps, no long searching' },
  aidIntro: { ar: 'دوسي على الحالة وتلاقي فورًا: 🟢 اعملي دلوقتي · 🔴 متعمليش أبدًا · 🏥 متى للطوارئ', en: 'Tap a situation to get instantly: 🟢 Do now · 🔴 Never do · 🏥 When to go to the ER' },
  aidDo: { ar: '🟢 اعملي دلوقتي', en: '🟢 Do now' },
  aidDont: { ar: '🔴 متعمليش أبدًا', en: '🔴 Never do' },
  aidUrgent: { ar: '🏥 روحي للطوارئ لو', en: '🏥 Go to the ER if' },
  aidCall: { ar: '📞 اطلبي الإسعاف', en: '📞 Call ambulance' },
});

function aidCard(a, i) {
  const t = AID_TONES[a.tone];
  return `
  <button class="aid-card ${a.tone} rise" style="--i:${i % 8}" data-act="openaid" data-id="${a.id}">
    <span class="aid-emo">${a.e}</span>
    <span class="aid-txt"><b>${esc(isAr() ? a.n : a.en_n)}</b>
      <i>${esc(isAr() ? a.sub : a.en_sub)}</i></span>
    <span class="aid-arrow">${isAr() ? '‹' : '›'}</span>
  </button>`;
}

function renderAid() {
  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/">←</a>
      <div class="logo">🚑</div>
      <h1>${T.aidTitle[lang]}<small>${T.aidSub[lang]}</small></h1>
      ${togglesHtml()}
    </div>
    ${FIRSTAID.map(aidCard).join('')}
    <p class="disclaimer">${isAr() ? 'المحتوى إرشادي للمساعدة الفورية في اللحظات الأولى — القرار النهائي دايمًا للطوارئ أو طبيب الأطفال.' : 'This content is immediate first-aid guidance — the final call is always the ER or your pediatrician.'}</p>
  `;
}

function openAid(id) {
  const a = FIRSTAID.find(x => x.id === id);
  if (!a) return;
  const fmt = arr => arr[lang === 'ar' ? 'ar' : 'en'].map(x => `<li>${x.replace(/\*\*/g, '')}</li>`).join('');
  openSheet(`${a.e} ${esc(isAr() ? a.n : a.en_n)}`, `
    <div class="aid-sheet">
      <div class="aid-sec do"><h4>${T.aidDo[lang]}</h4><ol>${fmt(a.do)}</ol></div>
      <div class="aid-sec dont"><h4>${T.aidDont[lang]}</h4><ul>${fmt(a.dont)}</ul></div>
      <div class="aid-sec urgent"><h4>${T.aidUrgent[lang]}</h4><ul>${fmt(a.urgent)}</ul></div>
    </div>
  `);
}


Object.assign(T, {
  vaxBtn: { ar: 'متابعة التطعيمات الاختيارية', en: 'Optional vaccines tracker' },
  vaxTitle: { ar: 'التطعيمات الاختيارية', en: 'Optional vaccines' },
  vaxSub: { ar: 'اكتبي تاريخ الميلاد ونحسبلك مواعيد الجرعات', en: 'Enter the birth date and we’ll work out the dose dates' },
  vaxBirth: { ar: '📅 تاريخ ميلاد البيبي', en: '📅 Baby’s birth date' },
  vaxNoBirth: { ar: 'اكتبي تاريخ الميلاد فوق عشان تظهر مواعيد الجرعات', en: 'Enter the birth date above to see the dose dates' },
  vaxDoses: { ar: ['الجرعة الأولى', 'الجرعة التانية', 'الجرعة التالتة'], en: ['First dose', 'Second dose', 'Third dose'] },
  vaxMinAge: { ar: l => `مينفعش قبل ما الطفل يتم ${l} — هيبقى متاح من`, en: l => `Not before the child is ${l} old — available from` },
  vaxDoseCount: { ar: 'عدد الجرعات', en: 'Number of doses' },
  vaxBooster: { ar: 'الجرعة المنشطة', en: 'Booster dose' },
  vaxOpen: { ar: 'الفترة المسموحة بدأت', en: 'The allowed period has started' },
  fluNotYet: { ar: 'مينفعش قبل 6 شهور — هيبقى متاح من', en: 'Not before 6 months — available from' },
  vaxNoMax: { ar: 'ومفيش حد أقصى مذكور', en: 'with no upper limit listed' },
  vaxOutside: { ar: 'التاريخ ده برا الفترة المسموحة — راجعي الطبيب', en: 'This date is outside the allowed period — check with your doctor' },
  vaxEnter: { ar: 'تاريخ الأخذ الفعلي', en: 'Date given' },
  vaxSave: { ar: 'احفظي التاريخ', en: 'Save date' },
  vaxWhen: { ar: 'المعاد', en: 'Date' },
  vaxWindow: { ar: 'الفترة المسموحة', en: 'Allowed period' },
  vaxFrom: { ar: 'من', en: 'from' },
  vaxUntil: { ar: 'لحد', en: 'until' },
  vaxDue: { ar: 'جه ميعادها', en: 'Due now' },
  vaxLate: { ar: 'عدّى آخر معاد مسموح — اسألي الطبيب', en: 'Past the allowed period — ask your doctor' },
  vaxGiven: { ar: 'اتاخدت يوم', en: 'Given on' },
  vaxSaved: { ar: 'اتسجلت الجرعة 💉', en: 'Dose logged 💉' },
  vaxDisclaimer: { ar: 'المواعيد دي محسوبة من تاريخ الميلاد للمتابعة بس — طبيب الأطفال هو اللي يحدد النوع والمعاد المناسب.', en: 'These dates are calculated from the birth date for tracking only — your pediatrician decides the right type and timing.' },
});

Object.assign(T, {
  pcvRisk: { ar: 'عند الطفل مرض مزمن أو ضعف مناعة أو عامل خطورة', en: 'Child has a chronic condition, weak immunity or a risk factor' },
  pcvRiskMsg: { ar: 'الأطفال اللي عندهم أمراض مزمنة (قلب، رئة، كلى، سكر، أنيميا منجلية…) أو ضعف مناعة أو عوامل خطورة بيحدد الطبيب جدول المكورات الرئوية ليهم — التطبيق مش بيحسبه تلقائيًا. اسألي طبيب الأطفال.', en: 'For children with chronic conditions (heart, lung, kidney, diabetes, sickle cell…), weak immunity or risk factors, the doctor sets the pneumococcal schedule — the app doesn’t calculate it automatically. Ask your pediatrician.' },
  pcvTooOld: { ar: 'العمر 17 سنة أو أكتر — الحساب التلقائي هنا لحد 17 سنة بس. اسألي طبيب الأطفال.', en: 'Age 17 years or more — automatic calculation here is for under 17 years only. Ask your pediatrician.' },
  pcvBirthFuture: { ar: 'تاريخ الميلاد في المستقبل — راجعي التاريخ.', en: 'The birth date is in the future — please check it.' },
  pcvDose: { ar: n => `الجرعة ${toAr(n)}`, en: n => `Dose ${n}` },
  pcvFinal: { ar: 'الجرعة الأخيرة', en: 'Last dose' },
  pcvCounted: { ar: 'محتسبة', en: 'Counted' },
  pcvAtAge: { ar: m => `بعمر ${toAr(m)} شهر`, en: m => `at ${m} months` },
  pcvEarliest: { ar: 'أبكر ميعاد', en: 'Earliest date' },
  pcvUsual: { ar: 'المعتاد', en: 'Usual' },
  pcvUpcoming: { ar: 'لسه الفاصل مخلصش — استني للميعاد ده', en: 'Waiting period not over yet — wait for this date' },
  pcvPlanned: { ar: 'بعد اللي قبلها', en: 'After the previous dose' },
  pcvOverdue: { ar: d => `متأخرة ${toAr(d)} يوم عن الميعاد المعتاد — خديها في أقرب وقت. التأخير مش بيزوّد جرعات`, en: d => `${d} days later than usual — give it as soon as possible. Delay doesn’t add doses` },
  pcvDone: { ar: 'الجدول اتكمل ✅ مفيش جرعات تانية مطلوبة (للأطفال الأصحاء)', en: 'Schedule complete ✅ no more doses needed (healthy children)' },
  pcvExtra: { ar: 'جرعة زيادة — مش محتاجة بعد اكتمال الجدول', en: 'Extra dose — not needed after the schedule is complete' },
  pcvDoctor: { ar: 'فيه جرعة مش محتسبة — راجعي الطبيب يأكد الموقف قبل ما تكملي', en: 'A dose was not counted — check with your doctor before continuing' },
  pcvWhy: {
    ar: { future: 'التاريخ في المستقبل — مش مقبول كجرعة مأخوذة', beforeBirth: 'التاريخ قبل الميلاد', minAge: 'اتاخدت قبل عمر 6 أسابيع', sameDate: 'نفس تاريخ الجرعة اللي قبلها', needs12: 'الجرعة دي لازم تتاخد بعد عمر 12 شهر', interval: (n, g) => `الفاصل ${toAr(g)} يوم، والمطلوب ${toAr(n)} يوم على الأقل`, extra: 'جرعة زيادة' },
    en: { future: 'Date is in the future — not accepted as given', beforeBirth: 'Date is before birth', minAge: 'Given before 6 weeks of age', sameDate: 'Same date as the previous dose', needs12: 'This dose must be given after 12 months of age', interval: (n, g) => `Gap is ${g} days, at least ${n} days required`, extra: 'Extra dose' },
  },
  pcvNotCounted: { ar: 'مش محتسبة', en: 'Not counted' },
  pcvEnteredBad: { ar: 'جرعة مسجّلة (غير محتسبة)', en: 'Entered dose (not counted)' },
});

let vaxDone = store.get('bb_vax', {});
let pcvRisk = store.get('bb_pcvRisk', false);
let vaxDraft = {};
let vaxType = store.get('bb_vaxType', {});

function vaxIso(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function vaxParse(iso) {
  return new Date(iso + 'T00:00:00');
}

function vaxAddMonths(d, months) {
  const next = new Date(d);
  next.setMonth(next.getMonth() + months);
  return next;
}

function vaxFromBirth(months) {
  return vaxAddMonths(vaxParse(baby.birth), months);
}

/* العمر بالشهور الكاملة في تاريخ معين */
function vaxAgeMonths(d) {
  const birth = vaxParse(baby.birth);
  const m = (d.getFullYear() - birth.getFullYear()) * 12 + d.getMonth() - birth.getMonth();
  return d.getDate() < birth.getDate() ? m - 1 : m;
}

function vaxAddDays(d, days) {
  const next = new Date(d);
  next.setDate(next.getDate() + days);
  return next;
}

function vaxDateText(d) {
  return d.toLocaleDateString(isAr() ? 'ar-EG' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
}

/* لكل جرعة: معادها المعتاد والفترة المسموحة — الجرعة التالية بتتحسب من تاريخ أخد اللي قبلها */
function vaxPlan(v, type) {
  const birth = vaxParse(baby.birth);
  const end = vaxAddDays(vaxFromBirth(v.doneBeforeMonths), -1);
  const n = type.at.length;
  let prev = null;
  return type.at.map((at, i) => {
    const id = `${v.id}-${i}`;
    const done = vaxDone[id];
    const from = i ? vaxAddDays(prev, v.gapDays) : vaxAddDays(birth, v.minWeeks * 7);
    const to = i ? vaxAddDays(end, -v.gapDays * (n - 1 - i)) : vaxAddDays(birth, v.firstBeforeWeeks * 7 - 1);
    const usual = vaxFromBirth(at);
    const when = usual < from ? from : usual;
    const ready = !i || !!vaxDone[`${v.id}-${i - 1}`];
    prev = done ? vaxParse(done) : from;
    return { id, done, from, to, when, ready };
  });
}

/* خطة تدارك: عدد الجرعات والفاصل بيتحددوا من العمر عند أول جرعة، واللي اتأخر معاده بيبقى النهارده */
function vaxCatchUp(v, today, src = v) {
  const first = vaxDone[`${src.id}-0`];
  const usual = vaxFromBirth(src.firstAt);
  const start = first ? vaxParse(first) : (usual < today ? today : usual);
  const age = vaxAgeMonths(start);
  const step = src.catchUp.find(x => age <= x.upTo) || src.catchUp[src.catchUp.length - 1];
  const maxAge = src.maxAgeMonths != null ? vaxFromBirth(src.maxAgeMonths) : null;
  const plan = [];
  let prev = null;
  for (let i = 0; i < step.doses; i++) {
    const id = `${src.id}-${i}`;
    const done = vaxDone[id];
    const gapFrom = i ? vaxAddMonths(prev, step.gapMonths) : null;
    let when = i ? gapFrom : start;
    if (i && when < today) when = today;
    const from = i ? gapFrom : usual;
    const to = i && step.maxGapMonths != null ? vaxAddMonths(prev, step.maxGapMonths) : maxAge;
    plan.push({ id, done, when, from, to, ready: !i || !!vaxDone[`${src.id}-${i - 1}`] });
    prev = done ? vaxParse(done) : when;
  }
  if (step.booster) {
    const b = src.booster;
    const id = `${src.id}-b`;
    const earliest = vaxAddDays(prev, b.minGapDays);
    const min = vaxFromBirth(b.from);
    const from = min < earliest ? earliest : min;
    const to = vaxFromBirth(b.to);
    const usualB = vaxFromBirth(b.at);
    let when = usualB < from ? from : usualB;
    if (when < today && today <= to) when = today;
    plan.push({ id, done: vaxDone[id], when, from, to, ready: !!vaxDone[plan[plan.length - 1].id], booster: true });
  }
  return plan;
}

function vaxRow(dose, i, today) {
  const label = dose.booster ? T.vaxBooster[lang] : T.vaxDoses[lang][i];
  const late = !dose.done && dose.to && (today > dose.to || dose.when > dose.to);
  const due = !dose.done && !late && dose.ready && today >= dose.when;
  const open = !dose.done && !late && !due && dose.ready && dose.from && today >= dose.from;
  const given = dose.done && vaxParse(dose.done);
  const outside = given && dose.from && (given < dose.from || (dose.to && given > dose.to));
  const win = dose.from ? `${T.vaxFrom[lang]} ${vaxDateText(dose.from)} ${dose.to ? `${T.vaxUntil[lang]} ${vaxDateText(dose.to)}` : T.vaxNoMax[lang]}` : '';
  return `
    <div class="vax-dose ${dose.done ? 'done' : late ? 'late' : due || open ? 'due' : ''}">
      <button class="vax-check" data-act="vaxtoggle" data-id="${dose.id}" aria-pressed="${!!dose.done}" aria-label="${label}">${dose.done ? '✓' : ''}</button>
      <span class="vax-info"><b>${label}</b>
        <i>${dose.done ? T.vaxGiven[lang] : T.vaxWhen[lang]}: ${vaxDateText(given || dose.when)}</i>
        ${win ? `<i>${T.vaxWindow[lang]}: ${win}</i>` : ''}
        ${late ? `<em>${T.vaxLate[lang]}</em>` : due ? `<em>${T.vaxDue[lang]}</em>` : open ? `<em>${T.vaxOpen[lang]}</em>` : ''}
        ${outside ? `<em class="vax-warn">${T.vaxOutside[lang]}</em>` : ''}
      </span>
      <div class="vax-enter"><span>${T.vaxEnter[lang]}</span>
        <input class="vax-date" type="date" data-id="${dose.id}" value="${dose.id in vaxDraft ? vaxDraft[dose.id] : (dose.done || '')}" max="${vaxIso(today)}" aria-label="${label}">
        ${dose.id in vaxDraft && vaxDraft[dose.id] !== (dose.done || '') ? `<button class="baby-save vax-save" data-act="vaxsave" data-id="${dose.id}">${T.vaxSave[lang]}</button>` : ''}
      </div>
    </div>`;
}

function vaxDoses(v, type) {
  if (!baby.birth) return `<p class="vax-rules">${T.vaxNoBirth[lang]}</p>`;
  const today = vaxParse(vaxIso(new Date()));
  const plan = type && type.at ? vaxPlan(v, type) : vaxCatchUp(v, today, type || v);
  if (v.tooLate && today > plan[0].to && !plan.some(d => d.done)) return `<p class="vax-rules vax-stop">${esc(v.tooLate[lang === 'ar' ? 'ar' : 'en'])}</p>`;
  return plan.map((d, i) => vaxRow(d, i, today)).join('');
}

/* موسمي: الموسم من سبتمبر لمارس، ومن 6 شهور لـ 9 سنين أول مرة جرعتين بينهم شهر */
function fluPlan(v, today) {
  const m = today.getMonth();
  const sy = m >= 8 ? today.getFullYear() : m <= 2 ? today.getFullYear() - 1 : today.getFullYear();
  const seasonStart = new Date(sy, 8, 1);
  const to = new Date(sy + 1, 2, 31);
  const eligible = vaxAddMonths(vaxParse(baby.birth), 6);
  const start = eligible > seasonStart ? eligible : seasonStart;
  if (start > to) return { none: true, eligible };
  const firstEver = !Object.keys(vaxDone).some(k => k.startsWith(`${v.id}-`) && +k.split('-')[1] < sy);
  const count = firstEver && vaxAgeMonths(seasonStart) < 108 ? 2 : 1;
  const rows = [];
  let prev = null;
  for (let i = 0; i < count; i++) {
    const id = `${v.id}-${sy}-${i}`;
    const done = vaxDone[id];
    const when = i ? vaxAddMonths(prev, 1) : (today >= start && today <= to ? today : start);
    rows.push({ id, done, when, from: i ? when : start, to, ready: !i || !!vaxDone[`${v.id}-${sy}-${i - 1}`] });
    prev = done ? vaxParse(done) : when;
  }
  return { rows };
}

function fluDoses(v) {
  if (!baby.birth) return `<p class="vax-rules">${T.vaxNoBirth[lang]}</p>`;
  const today = vaxParse(vaxIso(new Date()));
  const res = fluPlan(v, today);
  if (res.none) return `<p class="vax-rules vax-stop">${T.fluNotYet[lang]} ${vaxDateText(res.eligible)}</p>`;
  return res.rows.map((d, i) => vaxRow(d, i, today)).join('');
}

function pcvRow(o, today) {
  const label = o.number ? T.pcvDose[lang](o.number) + (o.final && !o.given ? ` — ${T.pcvFinal[lang]}` : '') : T.pcvEnteredBad[lang];
  const cls = o.given ? (o.valid ? 'done' : 'late') : (o.status === 'overdue' ? 'late' : o.status === 'due' ? 'due' : '');
  const why = o.reason && o.reason !== 'extra' ? T.pcvWhy[lang === 'ar' ? 'ar' : 'en'][o.reason] : '';
  const whyText = typeof why === 'function' ? why(o.need, o.gap) : why;
  const date = o.given ? vaxParse(o.given) : o.earliest;
  const line1 = o.given
    ? `${T.vaxGiven[lang]}: ${vaxDateText(date)} · ${T.pcvAtAge[lang](o.ageMonths)}`
    : `${T.pcvEarliest[lang]}: ${vaxDateText(date)}`;
  const note = o.given
    ? (o.valid ? `<em>✓ ${T.pcvCounted[lang]}</em>` : o.reason === 'extra' ? `<em>${T.pcvExtra[lang]}</em>` : `<em class="vax-warn">⚠ ${T.pcvNotCounted[lang]} — ${esc(whyText)}</em>`)
    : o.status === 'overdue' ? `<em>⚠ ${T.pcvOverdue[lang](o.lateDays)}</em>`
    : o.status === 'due' ? `<em>${T.vaxDue[lang]}</em>`
    : o.status === 'upcoming' ? `<em>${T.pcvUpcoming[lang]}</em>`
    : `<em>${T.pcvPlanned[lang]}</em>`;
  const usual = !o.given && o.usual ? `<i>${T.pcvUsual[lang]}: ${vaxDateText(o.usual)}</i>` : '';
  return `
    <div class="vax-dose ${cls}">
      <button class="vax-check" data-act="vaxtoggle" data-id="${o.id}" aria-pressed="${!!(o.given && o.valid)}" aria-label="${label}">${o.given && o.valid ? '✓' : ''}</button>
      <span class="vax-info"><b>${label}</b>
        <i>${line1}</i>${usual}${note}
      </span>
      <div class="vax-enter"><span>${T.vaxEnter[lang]}</span>
        <input class="vax-date" type="date" data-id="${o.id}" value="${o.id in vaxDraft ? vaxDraft[o.id] : (o.given || '')}" max="${vaxIso(today)}" aria-label="${label}">
        ${o.id in vaxDraft && vaxDraft[o.id] !== (o.given || '') ? `<button class="baby-save vax-save" data-act="vaxsave" data-id="${o.id}">${T.vaxSave[lang]}</button>` : ''}
      </div>
    </div>`;
}

/* المكورات الرئوية: الحساب كله في PCV.analyze (js/pcv.js) من تاريخ الميلاد وتواريخ الجرعات الفعلية */
function pcvBody(v) {
  if (!baby.birth) return `<p class="vax-rules">${T.vaxNoBirth[lang]}</p>`;
  const today = vaxParse(vaxIso(new Date()));
  const riskBtn = `<button class="vax-risk ${pcvRisk ? 'on' : ''}" data-act="pcvrisk" aria-pressed="${pcvRisk}">${pcvRisk ? '☑' : '☐'} ${T.pcvRisk[lang]}</button>`;
  const slots = [];
  for (let i = 0; i < PCV.MAX_DOSES; i++) slots.push(vaxDone[`${v.id}-${i}`] || '');
  const res = PCV.analyze(baby.birth, slots, vaxIso(today), { risk: pcvRisk });
  if (res.scope === 'risk') return `${riskBtn}<p class="vax-rules vax-stop">${T.pcvRiskMsg[lang]}</p>`;
  if (res.scope === 'doctor') return `${riskBtn}<p class="vax-rules vax-stop">${T.pcvBirthFuture[lang]}</p>`;
  const rows = [];
  let counted = 0;
  res.doses.forEach(d => rows.push(pcvRow({ id: `${v.id}-${d.slot}`, number: d.valid ? ++counted : 0, given: d.iso, valid: d.valid, reason: d.reason, need: d.need, gap: d.gap, ageMonths: d.ageMonths }, today)));
  const free = [];
  for (let i = 0; i < PCV.MAX_DOSES; i++) if (!slots[i]) free.push(i);
  res.next.forEach((n, i) => {
    if (free[i] === undefined) return;
    rows.push(pcvRow({ id: `${v.id}-${free[i]}`, number: n.number, earliest: n.earliest, usual: n.usual, status: n.status, lateDays: n.lateDays, final: n.final }, today));
  });
  const msgs = [];
  if (res.scope === 'tooOld') msgs.push(`<p class="vax-rules vax-stop">${T.pcvTooOld[lang]}</p>`);
  if (res.doctor.includes('invalidDose')) msgs.push(`<p class="vax-rules vax-stop">⚠ ${T.pcvDoctor[lang]}</p>`);
  if (res.complete) msgs.push(`<p class="vax-rules vax-ok">${T.pcvDone[lang]}</p>`);
  return riskBtn + rows.join('') + msgs.join('');
}

/* أقل عمر مسموح لأول جرعة: قبله الإدخال بيتقفل وبتظهر رسالة حمرا بتاريخ الإتاحة */
function vaxGate(v, type) {
  const minAge = (type && type.minAge) || v.minAge;
  if (!minAge || !baby.birth) return '';
  const today = vaxParse(vaxIso(new Date()));
  const min = minAge.days ? vaxAddDays(vaxParse(baby.birth), minAge.days) : vaxFromBirth(minAge.months);
  if (today >= min) return '';
  return `<p class="vax-rules vax-stop">${T.vaxMinAge[lang](minAge.label[lang === 'ar' ? 'ar' : 'en'])} ${vaxDateText(min)}</p>`;
}

function vaxCard(v, n) {
  const type = v.types && (v.types.find(x => x.id === vaxType[v.id]) || v.types[0]);
  return `
    <div class="vax-card rise" style="--i:${n}">
      <div class="vax-head"><span class="aid-emo">${v.e}</span>
        <span class="aid-txt"><b>${esc(isAr() ? v.n : v.en_n)}</b>${v.brand ? `<span class="vax-brand">${esc(v.brand[lang === 'ar' ? 'ar' : 'en'])}</span>` : ''}<i>${esc(isAr() ? v.sub : v.en_sub)}</i></span></div>
      ${type ? `<div class="vax-types">${v.types.map(x => `
        <button class="${x === type ? 'on' : ''}" data-act="vaxtype" data-id="${v.id}" data-type="${x.id}" aria-pressed="${x === type}">${v.stackCount ? `${x.n}<small>${T.vaxDoseCount[lang]}: ${x.count[lang === 'ar' ? 'ar' : 'en']}</small>` : `${x.n} · ${x.count[lang === 'ar' ? 'ar' : 'en']}`}</button>`).join('')}
      </div>` : ''}
      ${vaxGate(v, type) || (v.calc === 'pcv' ? pcvBody(v) : v.seasonal ? fluDoses(v) : vaxDoses(v, type))}
      <ul class="vax-rules">${(type && type.rules || v.rules)[lang === 'ar' ? 'ar' : 'en'].map(r => `<li>${esc(r)}</li>`).join('')}</ul>
    </div>`;
}

function renderVax() {
  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/">←</a>
      <div class="logo">💉</div>
      <h1>${T.vaxTitle[lang]}<small>${T.vaxSub[lang]}</small></h1>
      ${togglesHtml()}
    </div>
    <div class="vax-birth"><span>${T.vaxBirth[lang]}</span>
      <span class="date-wrap ${baby.birth ? 'has-val' : ''}">
        <input id="vax-birth" type="date" value="${esc(baby.birth)}" max="${vaxIso(new Date())}" aria-label="${T.vaxBirth[lang]}">
        <button type="button" class="date-clear" data-act="dateclear" aria-label="${isAr() ? 'امسحي التاريخ' : 'Clear date'}">✕</button>
      </span>
    </div>
    ${VACCINES.map(vaxCard).join('')}
    <p class="disclaimer">${T.vaxDisclaimer[lang]}</p>
  `;
}

/* التاريخ بيتحفظ بس لما تضغطي "احفظي التاريخ" — فتح الخانة لوحده مش بيسجّل الجرعة */
function saveVax(id) {
  const value = vaxDraft[id];
  delete vaxDraft[id];
  if (value) { vaxDone[id] = value; showToast(T.vaxSaved[lang]); }
  else delete vaxDone[id];
  store.set('bb_vax', vaxDone);
  renderVax();
}

function toggleVax(id) {
  delete vaxDraft[id];
  if (vaxDone[id]) delete vaxDone[id];
  else { vaxDone[id] = vaxIso(new Date()); showToast(T.vaxSaved[lang]); }
  store.set('bb_vax', vaxDone);
  renderVax();
}


Object.assign(T, {
  dairyBtn: { ar: 'أكلات خالية من الألبان', en: 'Dairy-free' },
  dairyTitle: { ar: '🥛❌ أكلات خالية من الألبان', en: '🥛❌ Dairy-free eating' },
  dairySub: { ar: 'أكل صحي وآمن.. وبدون تعب في تدوير البدائل!', en: 'Safe, healthy eating.. with zero swap-hunting!' },
  dairyToggle: { ar: 'حساسية ألبان / لاكتوز', en: 'Dairy / lactose allergy' },
  dairyOn: { ar: 'الفلتر شغّال: كل الجداول اتظبطت وخالية من الألبان ✅', en: 'Filter ON: every schedule is now dairy-free ✅' },
  dairyOff: { ar: 'الفلتر مقفول — شغّليه من كارت بيانات البيبي في الرئيسية', en: 'Filter is off — enable it from baby’s card on the home screen' },
  dairyGoBaby: { ar: '🚀 فعّلي من بيانات البيبي', en: '🚀 Enable from baby’s info' },
  dairyNote: { ar: 'الرضاعة الطبيعية غالبًا آمنة مع عدم تحمل اللاكتوز — واختيار الحليب البديل دايمًا مع طبيب الأطفال. والكالسيوم؟ القسم تحت بيقولك منين 😉', en: 'Breastfeeding is usually fine with lactose intolerance — alternative milk is always chosen with your pediatrician. Calcium? The section below has you covered 😉' },
});

function renderDairy() {
  const g = DAIRY_GUIDE;
  const lang2 = lang === 'ar' ? 'ar' : 'en';
  const sec = (x, i) => `
    <div class="dairy-sec rise" style="--i:${i}">
      <h4>${x.t[lang2]}</h4>
      <ul>${x.items[lang2].map(it => `<li>${esc(it)}</li>`).join('')}</ul>
    </div>`;
  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/">←</a>
      <div class="logo">🥛</div>
      <h1>${T.dairyTitle[lang]}<small>${T.dairySub[lang]}</small></h1>
      ${togglesHtml()}
    </div>

    <div class="day-note center ${baby.dairyFree ? '' : 'warnish'}">
      ${baby.dairyFree ? T.dairyOn[lang] : T.dairyOff[lang]}
      ${!baby.dairyFree ? `<div style="margin-top:8px"><a class="go-today" href="#/">${T.dairyGoBaby[lang]}</a></div>` : ''}
    </div>

    ${sec(g.banned, 0)}
    ${sec(g.swaps, 1)}
    ${sec(g.calcium, 2)}

    <div class="mom-welcome rise">${T.dairyNote[lang]}</div>
    <p class="disclaimer">${isAr() ? 'المحتوى إرشادي — نوع الحساسية وشدتها بيحددهم الطبيب، ولو الحساسية شديدة راجعي كل مكون مع الطبيب.' : 'Guidance only — allergy type and severity are decided by your doctor; with severe allergy double-check every ingredient with them.'}</p>
  `;
}


function openProSheet() {
  openSheet(isAr() ? '🌸 ترقية وقت راحتك يا مامي' : '🌸 Upgrade Mom’s break time', `
    <div class="pro-sheet">
      <div class="pro-hero">🌸</div>
      <b class="pro-price">${isAr() ? `${MomPro.priceText()} فقط` : `Just ${MomPro.priceText()}`} — <span>${isAr() ? 'شراء مرة واحدة وإلى الأبد' : 'one-time, forever'}</span></b>
      <ul class="pro-perks">
        <li>🔓 ${isAr() ? 'كل الـ ٣٨ نشاط (بدل نشاط واحد لكل مرحلة)' : 'All 38 activities (instead of one per stage)'}</li>
        <li>🧩 ${isAr() ? 'أنشطة جديدة بتتضاف باستمرار — مجانًا لعضويات Pro' : 'New activities added regularly — free for Pro'}</li>
        <li>⏱️ ${isAr() ? 'مؤقت القهوة ورتب المامي' : 'The coffee timer & mom ranks'}</li>
        <li>💛 ${isAr() ? 'دعم تطبيق بيبي منيو يستمر' : 'Supports Baby Menu to keep growing'}</li>
      </ul>
      <button class="pro-buy" data-act="buynow">🔓 ${isAr() ? `اشتري دلوقتي — ${MomPro.priceText()}` : `Buy now — ${MomPro.priceText()}`}</button>
      <button class="pro-restore" data-act="restorepro">${isAr() ? 'استعادة شراء سابق' : 'Restore previous purchase'}</button>
      <small class="pro-fine">${isAr() ? 'دفعة آمنة عبر متجر جوجل بلاي / آب ستور — من غير اشتراك متجدد.' : 'Secure one-time payment via Google Play / App Store — not a subscription.'}</small>
    </div>
  `);
}

/* ============================================================
   زر البدائل 🔄
   ============================================================ */
Object.assign(T, {
  swapTitle: { ar: '🔄 بدائل مناسبة', en: '🔄 Suitable alternatives' },
  swapCurrent: { ar: 'الأكلة الحالية', en: 'Current meal' },
  swapReset: { ar: '↺ رجوع للأكلة الأصلية', en: '↺ Restore original meal' },
  swapDone: { ar: 'تم التبديل! 🔄', en: 'Swapped! 🔄' },
  swapResetMsg: { ar: 'رجعنا الجدول الأصلي', en: 'Original plan restored' },
  shopBtn: { ar: '🛒 قائمة تسوق الشهر', en: '🛒 Monthly shopping list' },
  shopTitle: { ar: 'قائمة التسوق', en: 'Shopping list' },
  weekNames: { ar: ['الأسبوع الأول', 'الأسبوع التاني', 'الأسبوع الثالث', 'الأسبوع الرابع'],
               en: ['Week 1', 'Week 2', 'Week 3', 'Week 4'] },
  fullMonth: { ar: 'الشهر كله', en: 'Whole month' },
  inDays: n => isAr() ? `موجودة في ${toAr(n)} ${n === 1 ? 'يوم' : 'أيام'}` : `on ${n} day${n > 1 ? 's' : ''}`,
  shopMilk: { ar: '🍼 + رضاعة أو حليب حسب عمر البيبي', en: '🍼 + milk feeds as per age' },
  sexQ: { ar: 'نوع البيبي؟', en: 'Baby\u2019s sex?' },
  boy: { ar: '👦 ولد', en: '👦 Boy' },
  girl: { ar: '👧 بنت', en: '👧 Girl' },
  weight: { ar: 'الوزن (كجم)', en: 'Weight (kg)' },
  height: { ar: 'الطول (سم)', en: 'Height (cm)' },
  addMeasure: { ar: 'حفظ القياس', en: 'Save measurement' },
  needBirth: { ar: '📅 ضيفي تاريخ ميلاد البيبي من الرئيسية الأول عشان نحسب عمره على المنحنى', en: '📅 Add baby\u2019s birth date on the home screen first so we can plot the age' },
  chartW: { ar: 'الوزن حسب العمر (كجم)', en: 'Weight-for-age (kg)' },
  chartH: { ar: 'الطول حسب العمر (سم)', en: 'Height-for-age (cm)' },
  monthsAx: { ar: 'العمر بالشهور', en: 'Age (months)' },
  entries: { ar: 'القياسات المحفوظة', en: 'Saved measurements' },
  noMeasure: { ar: 'لسه مفيش قياسات — ضيفي أول قياس من الفوق 👆', en: 'No measurements yet — add the first one above 👆' },
  inBand: { ar: '✅ آخر قياس ضمن النطاق الطبيعي', en: '✅ Latest measurement is within the normal range' },
  belowBand: { ar: '⚠️ آخر قياس أقل من النطاق — راجعي طبيب الأطفال', en: '⚠️ Latest measurement is below the range — check with your pediatrician' },
  aboveBand: { ar: '📌 آخر قياس أعلى من النطاق — راجعي طبيب الأطفال', en: '📌 Latest measurement is above the range — check with your pediatrician' },
  measureSaved: { ar: 'اتسجل القياس 📏', en: 'Measurement saved 📏' },
});

const $sheet = document.getElementById('sheet');

function openSheet(title, bodyHtml) {
  document.getElementById('sheet-title').textContent = title;
  document.getElementById('sheet-body').innerHTML = bodyHtml;
  $sheet.hidden = false;
  requestAnimationFrame(() => $sheet.classList.add('open'));
}
function closeSheet() {
  $sheet.classList.remove('open');
  setTimeout(() => { $sheet.hidden = true; }, 260);
}
document.getElementById('sheet-close').addEventListener('click', closeSheet);
$sheet.addEventListener('click', e => { if (e.target === $sheet) closeSheet(); });
document.getElementById('sheet-body').addEventListener('click', async e => {
  const btn = e.target.closest('[data-act="pickswap"]');
  if (btn) return applySwap(btn.dataset.key, btn.dataset.id);
  const pm = e.target.closest('[data-act="pm-change"], [data-act="pm-remove"]');
  if (pm) {
    if (pm.dataset.act === 'pm-change') { closeSheet(); window.__PICKER_UNTIL = Date.now() + 90000; document.getElementById('baby-photo-input').click(); }
    else {
      babyPhoto = null;
      store.set('bb_photo', null);
      closeSheet();
      renderHome();
      showToast(isAr() ? 'اتشالت الصورة — رجعت أيقونة البيبي 👶' : 'Removed — back to the 👶 icon');
    }
    return;
  }
  const act = e.target.closest('[data-act="buynow"], [data-act="restorepro"]');
  if (act) {
    if (window.MomPro) {
      const ok = act.dataset.act === 'buynow' ? await MomPro.purchase() : (await MomPro.restore(), MomPro.state.pro);
      if (ok) closeSheet();
    }
  }
});

function openComboSwapSheet(m, d, slotK) {
  const dj = getDay(m, d);
  const meal = dj.meals.find(x => x.k === slotK);
  if (!meal || meal.type !== 'combo') return;
  const LETTER = { b: 'b', l: 'l', d: 'd', s1: 's', s2: 's' };

  /* البدايل من نفس مجموعة كل جزء بس (فاكهة بفاكهة، خضار بخضار، بروتين ببروتين، نشويات بنشويات)
     الوجبات الثابتة (الشهر 6-8) بتتبدل برقم الجزء، والباقي بالدور */
  const inMeal = new Set(meal.parts.flatMap(q => (q.foods || [q.food]).map(f => f.id)));
  const body = meal.parts.map(p => {
    const key = meal.fixed ? `${m}-${d}-${slotK}-${p.idx}` : `${m}-${d}-${slotK}-${p.role}`;
    const pool = (meal.fixed
      ? FOODS.filter(f => f.m <= m && roleOf(f) === p.role && foodAllowed(f))
      : poolRole(m, slotK, p.role, true)).filter(f => !inMeal.has(f.id));
    return `
      <div class="sw-role">${ROLE_LABEL[p.role][lang]}</div>
      <div class="sw-cur">
        <span class="sw-emo" style="${catGrad(p.food)}">${mealIcon(p.food.e)}</span>
        <div><small>${isAr() ? 'الحالي' : 'Current'}</small><b>${esc(fname(p.food))}</b></div>
      </div>
      <div class="sw-list">
        ${pool.map(f => `
          <button class="sw-item" data-act="pickswap" data-key="${key}" data-id="${f.id}">
            <span class="sw-emo" style="${catGrad(f)}">${mealIcon(f.e)}</span>
            <span class="sw-txt"><b>${esc(fname(f))}</b>
              ${f.tags.length ? `<i>${f.tags.map(tg => ALLERGEN_LABEL[tg][lang]).join(' · ')}</i>` : ''}
            </span>
          </button>`).join('')}
      </div>`;
  }).join('');

  openSheet(isAr() ? '🔄 بدائل مكوّنات الوجبة' : '🔄 Swap meal parts', body);
}

function openSwapSheet(mealEl) {
  const key = mealEl.dataset.key; /* m-d-slot */
  const parts = key.split('-');
  const m = +parts[0], d = +parts[1], slotK = parts[2];
  const cur = getDay(m, d).meals.find(x => x.k === slotK);
  if (!cur || cur.type !== 'food') return;

  const LETTER = { b: 'b', l: 'l', d: 'd', s1: 's', s2: 's' };
  /* البدايل من نفس مجموعة الأكلة بس — والسناك بيتبدل بسناك تاني من قايمة السناك */
  const opts = isSnackSlot(slotK)
    ? snackPool(m).filter(f => f.id !== cur.food.id)
    : poolFor(m, slotK, true).filter(f => f.id !== cur.food.id && roleOf(f) === roleOf(cur.food));

  const curHtml = `
    <div class="sw-cur">
      <span class="sw-emo" style="${catGrad(cur.food)}">${mealIcon(cur.food.e)}</span>
      <div><small>${T.swapCurrent[lang]}</small><b>${esc(fname(cur.food))}</b></div>
    </div>
    <div class="sw-list">
      ${opts.map(f => `
        <button class="sw-item" data-act="pickswap" data-key="${key}" data-id="${f.id}">
          <span class="sw-emo" style="${catGrad(f)}">${mealIcon(f.e)}</span>
          <span class="sw-txt"><b>${esc(fname(f))}</b>
            ${f.tags.length ? `<i>${f.tags.map(tg => ALLERGEN_LABEL[tg][lang]).join(' · ')}</i>` : ''}
          </span>
        </button>`).join('')}
    </div>
    ${swaps[key] ? `<button class="sw-reset" data-act="pickswap" data-key="${key}" data-id="">${T.swapReset[lang]}</button>` : ''}
  `;
  openSheet(T.swapTitle[lang], curHtml);
}

function applySwap(key, id) {
  if (id && typeof foodAllowed === 'function' && !foodAllowed(FOOD_MAP[id])) {
    showToast(isAr() ? 'الأكلة دي فيها ألبان — مش هتنفع مع فلتر الحساسية 🥛❌' : 'That meal contains dairy — not allowed with your dairy filter 🥛❌');
    return;
  }
  if (id) swaps[key] = id;
  else delete swaps[key];
  store.set('bb_swaps', swaps);
  globalThis.MEAL_OVERRIDES = swaps;
  invalidateDayCache();
  closeSheet();
  /* نعيد رسم اليوم مكانه (من غير ما الصفحة تطلع لفوق) عشان البديل يبان على طول */
  const p = parseHash();
  if (p.view === 'day') renderDay(p.m, p.day); else render();
  showToast(id ? T.swapDone[lang] : T.swapResetMsg[lang]);
}

/* ============================================================
   قائمة التسوق 🛒
   ============================================================ */
const SHOP_WEEKS = [[1, 7], [8, 14], [15, 21], [22, 28]];

function renderShop(m) {
  if (window.BeebyAds) window.BeebyAds.maybeInterstitial('shop');
  const w = Math.max(0, Math.min(4, shopWeekSel));
  const [from, to] = w === 4 ? [1, 30] : SHOP_WEEKS[w];

  const map = new Map();
  const bump = f => { if (!map.has(f.id)) map.set(f.id, { f, days: 0 }); map.get(f.id).days++; };
  for (let d = from; d <= to; d++) {
    for (const x of getDay(m, d).meals) {
      if (x.type === 'food') bump(x.food);
      else if (x.type === 'combo') x.parts.forEach(p => bump(p.food));
    }
  }

  const groups = {};
  for (const { f, days } of map.values()) {
    (groups[f.c] = groups[f.c] || []).push({ f, days });
  }

  const listHtml = Object.keys(groups).map(cat => `
    <div class="sec-title shop-cat">${CAT_LABEL[cat][lang]} <span class="dash"></span></div>
    ${groups[cat].map(({ f, days }) => {
      const ck = `${m}:${w}:${f.id}`;
      return `
      <label class="shop-item ${shopChecks[ck] ? 'on' : ''}">
        <input type="checkbox" data-act="shopcheck" data-k="${ck}" ${shopChecks[ck] ? 'checked' : ''}>
        <span class="sw-emo" style="${catGrad(f)}">${mealIcon(f.e)}</span>
        <span class="sw-txt"><b>${esc(fname(f))}</b> <small>${T.inDays(days)}</small>
          <i>${esc(fing(f))}</i>
        </span>
      </label>`;
    }).join('')}
  `).join('');

  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/age/${m}">←</a>
      <div class="logo">🛒</div>
      <h1>${T.shopTitle[lang]}<small>${ageLabel(m)[lang]} • ${isAr() ? `اليوم ${toAr(from)} لـ ${toAr(to)}` : `day ${from}–${to}`}</small></h1>
      ${togglesHtml()}
    </div>

    <div class="week-chips">
      ${SHOP_WEEKS.map((_, i) => `<button class="wk-chip ${w === i ? 'sel' : ''}" data-act="shopweek" data-w="${i}">${T.weekNames[lang][i]}</button>`).join('')}
      <button class="wk-chip ${w === 4 ? 'sel' : ''}" data-act="shopweek" data-w="4">${T.fullMonth[lang]}</button>
    </div>

    ${listHtml || `<p class="disclaimer">—</p>`}
    <div class="day-note">🍼 ${T.shopMilk[lang]}</div>
    <p class="disclaimer">${isAr() ? 'الكميات موجودة جوه كل أكلة — انسخي اللي محتاجاه أو اصوري القائمة' : 'Quantities are inside each meal — copy what you need or snap a photo'}</p>
  `;
}



Object.assign(T, {
  sourcesBtn: { ar: 'المصادر والمراجع العلمية', en: 'Scientific sources & references' },
  sourcesTitle: { ar: '📚 المصادر والمراجع', en: '📚 Sources & references' },
  sourcesIntro: {
    ar: 'جداول التطبيق وإرشاداته مبنية على الدليل العلمي المعتمد في تغذية الرضع والأطفال الصغار — وأهمها:',
    en: 'The schedules and guidance in this app are built on evidence-based infant & young-child feeding references, led by:',
  },
  sourcesNote: {
    ar: 'التطبيق إرشادي لتسهيل الحياة اليومية، ومش بديل عن استشارة طبيب الأطفال المتابع لحالة البيبي.',
    en: 'This app is a daily-life guide and never replaces your own pediatrician who knows your baby best.',
  },
});

const SOURCES = [
  { icon: '🩺', ar_t: 'Pediatric Nutrition — الأكاديمية الأمريكية لطب الأطفال (AAP)', en_t: 'Pediatric Nutrition — American Academy of Pediatrics (AAP)',
    ar: 'المرجع الأول عالميًا (الشهير بالمرجع الأخضر) لقواعد بدء الأكل الصلب، النسب الغذائية، الكميات، وتجنب الحساسية حسب كل مرحلة عمرية.',
    en: 'The world’s leading reference (the “Green Book”) for starting solids, nutrient ratios, amounts and allergy prevention by age stage.' },
  { icon: '🌍', ar_t: 'منظمة الصحة العالمية (WHO) وأدلة وزارات الصحة العربية', en_t: 'World Health Organization (WHO) & Arab health-ministry guides',
    ar: 'إرشادات بدء التغذية المكملة حوالين عمر 6 شهور، ومكونات محلية متاحة (فول، حمص، عدس، شوفان، كوسة، بطاطا) بجدول يومي متوازن.',
    en: 'Complementary-feeding guidance starting around 6 months, using affordable local staples (fava, chickpeas, lentils, oats, zucchini, sweet potato).' },
  { icon: '🧠', ar_t: 'Child of Mine — Ellyn Satter (تقسيم المسؤولية في التغذية)', en_t: 'Child of Mine — Ellyn Satter (Division of Responsibility)',
    ar: 'أنتي مسؤولة عن إيه يتقدم وإتى وأين — والبيبي مسؤوله عن هل يأكل وكم. أساس التعامل السلوكي مع رفض الأكل والانتقائية.',
    en: 'You decide what, when and where is offered — baby decides whether and how much. The behavioral gold standard for picky eating.' },
  { icon: '🥄', ar_t: 'First Bites — Sarah Almond Bushell', en_t: 'First Bites — Sarah Almond Bushell',
    ar: 'دليل عملي للانتقال من التذوق عند 6 شهور للوجبات المتكاملة (خضار + بروتين + نشويات) — نفس بنية جداول التطبيق.',
    en: 'A practical path from first tastes at 6 months to full balanced plates (veg + protein + starch) — the same structure this app uses.' },
  { icon: '🤲', ar_t: 'The Baby-Led Weaning Cookbook — Gill Rapley & Tracey Murkett', en_t: 'The Baby-Led Weaning Cookbook — Rapley & Murkett',
    ar: 'منهج الأكل الذاتي وأطعمة الأصابع الآمنة بدون ملح أو سكر — مصدر أفكار السناكات والأكل بالإيد في التطبيق.',
    en: 'The baby-led weaning approach and safe no-salt no-sugar finger foods — the source behind this app’s snack and self-feeding ideas.' },
  { icon: '📘', ar_t: 'تغذية الطفل من الولادة حتى المراهقة — د. سناء يوسف', en_t: 'Child Nutrition from Birth to Adolescence — Dr. Sanaa Youssef',
    ar: 'مرجع عربي شامل يغطي احتياجات كل مرحلة مع مراعاة ثقافة الأكل العربي ومكوناته.',
    en: 'A comprehensive Arabic reference covering every stage’s needs within Arab food culture and ingredients.' },
  { icon: '🪄', ar_t: 'The Montessori Baby & The Montessori Toddler — Simone Davies', en_t: 'The Montessori Baby & Toddler — Simone Davies',
    ar: 'الأساس العلمي لقسم "وقت راحتك يا مامي" — بيئة منزلية مهيأة وأنشطة تنمي الحواس والمهارات الحركية الدقيقة وحياة البيت العملية.',
    en: 'The scientific base of our “Mom’s break time” section — a prepared home environment with sensory, fine-motor and practical-life activities.' },
  { icon: '🎨', ar_t: '150+ Screen-Free Activities — Asia Citro | The Toddler’s Busy Book — Trish Kuffner', en_t: '150+ Screen-Free Activities — Citro | The Toddler’s Busy Book — Kuffner',
    ar: 'أفكار الأنشطة المنزلية بدون شاشات — عجائن وصلصال آمنة وصناديق حسية بأدوات المطبخ، مقسمة حسب العمر.',
    en: 'Screen-free home play ideas — safe doughs, sensory bins with kitchen tools, split by age.' },
  { icon: '🤸', ar_t: 'Retro Baby — Dr. Anne Zachry (أخصائية علاج وظيفي)', en_t: 'Retro Baby — Dr. Anne Zachry (pediatric OT)',
    ar: 'أنشطة موجهة بالأشهر لتطوير الجلوس والحبو والتقاط الأشياء — ربط كل نشاط بمرحلة نمائية محددة.',
    en: 'Month-by-month activities for sitting, crawling and grasping — each tied to a specific developmental stage.' },
  { icon: '📋', ar_t: 'Starting Solid Foods — Alberta Health Services', en_t: 'Starting Solid Foods — Alberta Health Services',
    ar: 'الدليل الرسمي المعتمد في تحديد مراحل القوام (مهروس ← متكتل ← مكعبات) والمشروبات المسموحة والممنوعة قبل سنتين.',
    en: 'The official guide behind this app’s texture stages (purée ← lumpy ← cubes) and the drinks rules before age two.' },
];

function renderSources() {
  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/">←</a>
      <div class="logo">📚</div>
      <h1>${T.sourcesTitle[lang]}</h1>
      ${togglesHtml()}
    </div>
    <p class="disclaimer" style="text-align:start;padding:14px 4px 4px">${T.sourcesIntro[lang]}</p>
    ${SOURCES.map((x, i) => `
      <div class="tip rise" style="--i:${i % 10}">
        <span class="ic">${x.icon}</span>
        <span><b style="display:block;margin-bottom:4px">${isAr() ? x.ar_t : x.en_t}</b>${isAr() ? x.ar : x.en}</span>
      </div>`).join('')}
    <p class="disclaimer">${T.sourcesNote[lang]}</p>
  `;
}

/* ---------- مواصفات الوجبة الكاملة 🍽️ (جدول مامي — كل صنف من إمتى، ملوّن بالشهر) ---------- */
Object.assign(T, {
  mealSpecBtn: { ar: 'مواصفات الوجبة الكاملة', en: 'The complete meal' },
  mealSpecHow: {
    ar: 'بنختار صنف من كل عمود ونكوّن بيهم وجبة كاملة. الخضار والفاكهة والحبوب بتدخل بالتدريج من المتاح عندنا من إتمام الشهر السادس، وكل نوع بروتين مكتوب جنبه العمر المناسب.',
    en: 'Pick one item from each column to build a complete meal. Vegetables, fruit and grains come in gradually from whatever you have, starting after 6 months; each protein shows its own starting age.',
  },
  mealSpecFrom: m => isAr() ? `من ${toAr(m)} شهور` : `From ${m} months`,
  mealSpecOverOne: { ar: '🎂 فوق السنة', en: '🎂 After age one' },
  mealSpecNotes: { ar: '📝 ملاحظات مهمة', en: '📝 Good to know' },
  mealSpecTips: { ar: '💡 نصايح هامة', en: '💡 Helpful tips' },
  mealSpecBalanced: { ar: '⚖️ نصايح لغذاء متوازن', en: '⚖️ For a balanced diet' },
});

function renderMealSpec() {
  const L = x => (isAr() ? x.ar : x.en);
  const pill = it => `<span class="ms-item">${isAr() ? it[0] : it[1]}</span>`;
  const cell = (groups, m) => `<div class="ms-cell ms-m${m}">${groups.length
    ? groups.map(g => `${g.ar ? `<span class="ms-sub">${L(g)}</span>` : ''}${g.items.map(pill).join('')}`).join('')
    : '<span class="ms-none">—</span>'}</div>`;
  const PL = isAr()
    ? { vf: 'نص الطبق خضار / فاكهة', pr: 'ربع بروتين', st: 'ربع نشويات' }
    : { vf: 'Half: veg / fruit', pr: 'Quarter: protein', st: 'Quarter: starch' };

  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/">←</a>
      <div class="logo">🍽️</div>
      <h1>${T.mealSpecBtn[lang]}</h1>
      ${togglesHtml()}
    </div>

    <div class="ms-plate rise">
      <div class="ps-bar"><span class="ps-vf"></span><span class="ps-pr"></span><span class="ps-st"></span></div>
      <div class="ps-legend"><span><i class="ps-vf"></i>${PL.vf}</span><span><i class="ps-pr"></i>${PL.pr}</span><span><i class="ps-st"></i>${PL.st}</span></div>
    </div>
    <div class="day-note">💡 ${T.mealSpecHow[lang]}</div>

    <div class="ms-legend">${MEAL_SPEC.months.map(x => `<span class="ms-key ms-m${x.m}">${T.mealSpecFrom(x.m)}</span>`).join('')}</div>

    <div class="ms-table">
      ${MEAL_SPEC.cols.map(c => `<div class="ms-head">${c.e} ${L(c)}<small>${L(c.share)}</small></div>`).join('')}
      ${MEAL_SPEC.months.map(x => `
        <div class="ms-band ms-m${x.m}">${T.mealSpecFrom(x.m)}</div>
        ${MEAL_SPEC.cols.map(c => cell(x[c.k], x.m)).join('')}`).join('')}
    </div>

    <div class="ms-over ms-m12">
      <b>${T.mealSpecOverOne[lang]}</b>
      <div class="ms-items">${MEAL_SPEC.overOne.items.map(pill).join('')}</div>
      <small>${L(MEAL_SPEC.overOne.note)}</small>
    </div>

    <a class="pillbtn tipsbtn" href="#/mealspec/tips">${T.mealSpecBalanced[lang]}</a>
    <p class="disclaimer">${T.sourcesNote[lang]}</p>
  `;
}

/* ---------- نصايح لغذاء متوازن: ملاحظات الجدول + النصايح في صفحة لوحدها (زرارها في آخر صفحة الوجبة الكاملة) ---------- */
function renderMealSpecTips() {
  const L = x => (isAr() ? x.ar : x.en);
  $app.innerHTML = `
    <div class="topbar">
      <a class="backbtn" href="#/mealspec">←</a>
      <div class="logo">⚖️</div>
      <h1>${T.mealSpecBalanced[lang].replace(/^⚖️\s*/, '')}<small>${T.mealSpecBtn[lang]}</small></h1>
      ${togglesHtml()}
    </div>

    <div class="sec-title">${T.mealSpecNotes[lang]} <span class="dash"></span></div>
    <div class="tips">
      ${MEAL_SPEC.notes.map((n, i) => `<div class="tip rise" style="--i:${i}"><span class="ic">${n.e}</span><span>${L(n)}</span></div>`).join('')}
    </div>

    <div class="sec-title">${T.mealSpecTips[lang]} <span class="dash"></span></div>
    <div class="ms-tipgrid">
      ${MEAL_SPEC.tips.map((t, i) => `<div class="ms-tipcard rise" style="--i:${i % 10}"><span class="ic">${t.e}</span>${L(t)}</div>`).join('')}
    </div>

    <div class="sec-title">${T.mealSpecBalanced[lang]} <span class="dash"></span></div>
    <ol class="ms-list rise">${MEAL_SPEC.balanced.map(b => `<li>${L(b)}</li>`).join('')}</ol>
    <p class="disclaimer">${T.sourcesNote[lang]}</p>
  `;
}

render();

/* ---------- خدمة العمل أوفلاين (متوقفة جوا التطبيق الأصلي) ---------- */
if (!window.Capacitor && 'serviceWorker' in navigator && (location.protocol === 'https:' || ['127.0.0.1', 'localhost'].includes(location.hostname))) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}


/* ===== 📅 خانات التاريخ على iOS =====
   زرار "Reset" في منتقي التاريخ بتاع iOS بيرجّع القيمة اللي في الـ HTML (value attribute)
   يعني التاريخ المحفوظ — فمكانش بيتمسح أبدًا. الحل: نحط القيمة بالـ JS ونشيل الـ attribute
   فالـ Reset يفضّي الخانة، وزرار ✕ يبان لما يكون فيه تاريخ. */
function fixDateInputs(root) {
  root.querySelectorAll('input[type="date"][value]').forEach(inp => {
    const v = inp.getAttribute('value');
    inp.value = v;                  /* القيمة "متعدّلة" دلوقتي فمش هتتأثر بشيل الـ attribute */
    inp.removeAttribute('value');   /* defaultValue = '' ⇒ Reset = مسح */
    inp.value = v;
  });
}
new MutationObserver(() => fixDateInputs($app)).observe($app, { childList: true, subtree: true });
fixDateInputs($app);
['input', 'change'].forEach(ev => document.addEventListener(ev, e => {
  if (e.target.type !== 'date') return;
  const wrap = e.target.closest('.date-wrap');
  if (wrap) wrap.classList.toggle('has-val', !!e.target.value);
}, true));
